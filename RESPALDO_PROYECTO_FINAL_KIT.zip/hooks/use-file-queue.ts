'use client'

import { arrayMove } from '@dnd-kit/sortable'
import { useCallback, useRef, useState } from 'react'
import { hasPdfSignature } from '@/lib/files'

export interface QueuedFile {
  id: string
  file: File
  error?: string
}

/** Files live only in memory for this tab; nothing is uploaded or stored. */
export function useFileQueue() {
  const [items, setItems] = useState<QueuedFile[]>([])
  const [rejected, setRejected] = useState<string[]>([])
  const counter = useRef(0)

  const add = useCallback(async (list: FileList | File[]) => {
    const accepted: QueuedFile[] = []
    const invalid: string[] = []
    for (const file of Array.from(list)) {
      const valid = await hasPdfSignature(file).catch(() => false)
      if (valid) accepted.push({ id: `f${++counter.current}`, file })
      else invalid.push(file.name)
    }
    setRejected(invalid)
    if (accepted.length) setItems((prev) => [...prev, ...accepted])
    return { accepted, invalid }
  }, [])

  const remove = useCallback((id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id))
  }, [])

  const move = useCallback((from: number, to: number) => {
    setItems((prev) => (to < 0 || to >= prev.length ? prev : arrayMove(prev, from, to)))
  }, [])

  const markError = useCallback((id: string, error: string) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, error } : item)))
  }, [])

  const clear = useCallback(() => {
    setItems([])
    setRejected([])
  }, [])

  return { items, rejected, add, remove, move, markError, clear, dismissRejected: () => setRejected([]) }
}
