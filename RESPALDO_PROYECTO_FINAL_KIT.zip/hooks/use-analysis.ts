'use client'

import { useCallback, useRef, useState } from 'react'
import {
  analyzeDocuments,
  UnreadablePdfError,
  type AnalysisInput,
  type AnalysisProgress,
  type AnalysisResult,
} from '@/lib/pipeline/analyze'
import { analyzeRemote, RemoteUnavailableError } from '@/lib/pipeline/remote'

export type AnalysisState =
  | { status: 'idle' }
  | { status: 'running'; progress: AnalysisProgress; merging: boolean }
  | { status: 'done'; result: AnalysisResult; runId: number }
  | { status: 'error'; message: string }

export function useAnalysis({ onUnreadable }: { onUnreadable: (fileId: string) => void }) {
  const [state, setState] = useState<AnalysisState>({ status: 'idle' })
  const runRef = useRef(0)

  const run = useCallback(
    async (inputs: AnalysisInput[]) => {
      const runId = ++runRef.current
      const merging = inputs.length > 1
      const report = (progress: AnalysisProgress) => {
        if (runRef.current === runId) setState({ status: 'running', merging, progress })
      }
      report({ stage: merging ? 'merging' : 'reading', detail: 'Preparando archivos', value: 0.02 })

      try {
        let result: AnalysisResult
        try {
          result = await analyzeRemote(inputs, report)
        } catch (error) {
          if (!(error instanceof RemoteUnavailableError)) throw error
          // Server unreachable or upload too large: same analysis, on this device.
          if (runRef.current !== runId) return
          result = await analyzeDocuments(inputs, report)
        }
        if (runRef.current === runId) setState({ status: 'done', result, runId })
      } catch (error) {
        if (runRef.current !== runId) return
        if (error instanceof UnreadablePdfError) {
          onUnreadable(error.fileId)
          setState({ status: 'error', message: 'No se pudo leer este archivo.' })
        } else {
          console.error('[FileKit] analysis failed', error)
          setState({ status: 'error', message: 'No se pudo procesar los archivos. Inténtalo de nuevo.' })
        }
      }
    },
    [onUnreadable],
  )

  const reset = useCallback(() => {
    runRef.current++
    setState({ status: 'idle' })
  }, [])

  return { state, run, reset }
}
