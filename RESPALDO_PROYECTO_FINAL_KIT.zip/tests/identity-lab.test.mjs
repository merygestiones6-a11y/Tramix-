import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  batchToCsv,
  buildCurpBase,
  buildRfcBase,
  curpCheckDigit,
  generateCurp,
  generateRfcFromCurp,
  generateRfcFromData,
  normalizeText,
  parseCsv,
  processBatch,
  rfcCheckDigit,
  validateKey,
} from '../lib/identity-lab/engine.ts'

const person = (nombre, primerApellido, segundoApellido, fechaNacimiento, sexo = 'H', entidad = 'DF') => ({
  nombre,
  primerApellido,
  segundoApellido,
  fechaNacimiento,
  sexo,
  entidad,
})

test('normalización: acentos fuera, Ñ se conserva', () => {
  assert.equal(normalizeText('  José   Núñez Güemes '), 'JOSE NUÑEZ GUEMES')
})

test('CURP: dígito verificador coincide con CURP reales', () => {
  for (const curp of ['SALR880719HCCNPD08', 'MAEI990401MDFRVN00', 'XOCD111125MVZCLNA2', 'HEHL841029HCCRRS01', 'MELJ110725HGRNYSA8']) {
    assert.equal(curpCheckDigit(curp.slice(0, 17)), curp[17], curp)
    assert.equal(validateKey(curp).status, 'valida', curp)
  }
})

test('CURP: regla general', () => {
  const r = generateCurp(person('Juan', 'Pérez', 'López', '1990-05-12'))
  assert.ok(r.ok)
  assert.equal(r.candidates[0].id.slice(0, 16), 'PELJ900512HDFRPN')
  assert.equal(r.candidates[0].id[16], '0')
  assert.equal(r.candidates.length, 5)
  assert.equal(new Set(r.candidates.map((c) => c.id)).size, 5, 'sin duplicados')
  for (const c of r.candidates) assert.equal(validateKey(c.id).status, 'valida')
})

test('CURP: nacidos desde 2000 usan letra como diferenciador', () => {
  const r = generateCurp(person('Ana', 'Ruiz', 'Soto', '2004-02-29', 'M', 'JC'))
  assert.deepEqual(r.candidates.map((c) => c.id[16]), ['A', 'B', 'C', 'D', 'E'])
})

test('CURP: nombres compuestos MARIA / JOSE y partículas', () => {
  assert.equal(buildCurpBase(person('María José', 'Gómez', 'Díaz', '1980-01-01', 'M')).base.base16.slice(0, 4), 'GODJ')
  assert.equal(buildCurpBase(person('María de los Ángeles', 'de la Cruz', 'del Valle', '1980-01-01', 'M')).base.base16.slice(0, 4), 'CUVA')
  assert.equal(buildCurpBase(person('José', 'Gómez', 'Díaz', '1980-01-01')).base.base16.slice(0, 4), 'GODJ', 'JOSE solo se conserva')
})

test('CURP: palabra inconveniente, Ñ y sin segundo apellido', () => {
  assert.equal(buildCurpBase(person('Yolanda', 'Buendía', 'Estrada', '1970-03-04', 'M')).base.base16.slice(0, 4), 'BXEY')
  const n = buildCurpBase(person('Iñaki', 'Muñoz', 'Ortiz', '1985-07-07')).base.base16
  assert.equal(n.slice(0, 4), 'MUOI')
  assert.equal(n.slice(13, 16), 'XRX', 'Ñ interna → X')
  const one = buildCurpBase(person('Luis', 'Hernández', '', '1999-12-31', 'H', 'NE')).base.base16
  assert.equal(one, 'HEXL991231HNERXS')
})

test('CURP: caracteres especiales y sexo X', () => {
  const r = buildCurpBase(person('Sean', "O'Brien", 'Ruiz', '1991-01-15', 'X', 'NL')).base.base16
  assert.equal(r.slice(0, 4), 'OIRS', "el apóstrofo se omite al buscar la vocal interna")
  assert.equal(r[10], 'X')
})

test('CURP: errores de entrada', () => {
  assert.ok(!generateCurp(person('Ana', 'Ruiz', 'Soto', '2023-02-29', 'M')).ok, 'fecha inexistente')
  assert.ok(!generateCurp(person('Ana', 'Ruiz', 'Soto', '2999-01-01', 'M')).ok, 'fecha futura')
  assert.ok(!generateCurp(person('Ana', 'Ruiz', 'Soto', '1990-01-01', '', 'DF')).ok, 'sin sexo')
  assert.ok(!generateCurp(person('Ana', 'Ruiz', 'Soto', '1990-01-01', 'M', 'ZZ')).ok, 'entidad inválida')
  assert.ok(!generateCurp(person('Ana3', 'Ruiz', 'Soto', '1990-01-01', 'M')).ok, 'dígitos en el nombre')
  assert.ok(!generateCurp(person('', 'Ruiz', 'Soto', '1990-01-01', 'M')).ok, 'sin nombre')
  assert.ok(!generateCurp(person('Ana', '', '', '1990-01-01', 'M')).ok, 'sin apellidos')
})

test('RFC: ejemplo publicado por el SAT (Emma Gómez Díaz)', () => {
  const r = generateRfcFromData(person('Emma', 'Gómez', 'Díaz', '1956-12-31'))
  assert.equal(r.candidates[0].id, 'GODE561231GR8')
  assert.equal(r.candidates.length, 1, 'no se rellenan candidatos sin justificación')
})

test('RFC: excepciones de formación', () => {
  assert.equal(buildRfcBase(person('Luis', 'Hernández', '', '1999-12-31')).base.base10, 'HELU991231', 'un solo apellido')
  assert.equal(buildRfcBase(person('Ana', 'Li', 'Wong', '1990-01-01')).base.base10, 'LWAN900101', 'paterno corto')
  assert.equal(buildRfcBase(person('Yolanda', 'Buendía', 'Estrada', '1970-03-04')).base.base10, 'BUEX700304', 'inconveniente SAT')
  assert.equal(buildRfcBase(person('María José', 'de la Cruz', 'Ruiz', '1980-01-01')).base.base10, 'CURJ800101', 'compuestos y partículas')
  assert.equal(buildRfcBase(person('Ignacio', 'Núñez', 'Ortiz', '1980-01-01')).base.base10.slice(0, 4), 'NUOI')
})

test('RFC: dígito verificador física y moral', () => {
  assert.equal(rfcCheckDigit('GODE561231GR'), '8')
  assert.equal(rfcCheckDigit('SAT970701NN'), '3', 'moral con relleno inicial')
  assert.equal(validateKey('SAT970701NN3').kind, 'RFC moral')
  assert.equal(validateKey('SAT970701NN3').status, 'valida')
  assert.equal(validateKey('GODE561231GR8').kind, 'RFC física')
  assert.equal(validateKey('XAXX010101000').kind, 'RFC genérico')
})

test('RFC por CURP: parcial sin nombre, completo con nombre coherente', () => {
  const curp = generateCurp(person('Emma', 'Gómez', 'Díaz', '1956-12-31', 'M')).candidates[0].id
  const partial = generateRfcFromCurp(curp)
  assert.equal(partial.candidates[0].id, 'GODE561231')
  assert.equal(partial.candidates[0].status, 'parcial')
  const full = generateRfcFromCurp(curp, { nombre: 'Emma', primerApellido: 'Gómez', segundoApellido: 'Díaz' })
  assert.equal(full.candidates[0].id, 'GODE561231GR8')
  assert.equal(full.candidates[0].status, 'estructura-valida')
  const mismatch = generateRfcFromCurp(curp, { nombre: 'Pedro', primerApellido: 'Gómez', segundoApellido: 'Díaz' })
  assert.equal(mismatch.candidates[0].status, 'verificar')
  assert.ok(!generateRfcFromCurp('ABC').ok)
})

test('Validador: estructuras inválidas', () => {
  assert.equal(validateKey('SALR880719HCCNPD09').status, 'invalida', 'dígito verificador')
  assert.equal(validateKey('SALR881319HCCNPD08').status, 'invalida', 'mes 13')
  assert.equal(validateKey('SALR880719ZCCNPD08').status, 'invalida', 'sexo')
  assert.equal(validateKey('SALR880719HZZNPD08').status, 'invalida', 'entidad')
  assert.equal(validateKey('BUEY700304MDFNSL04').status, 'invalida', 'palabra inconveniente')
  assert.equal(validateKey('123').status, 'invalida')
  assert.equal(validateKey('GODE561231GR7').status, 'verificar', 'dv RFC distinto')
  assert.equal(validateKey('GODE561331GR8').status, 'invalida', 'fecha RFC')
})

test('CSV: comillas, punto y coma, duplicados y vínculo con la fila', () => {
  assert.deepEqual(parseCsv('a;b\r\n"x;1";"di""ce"\n'), [['a', 'b'], ['x;1', 'di"ce']])
  const csv = [
    'nombre,primer_apellido,segundo_apellido,fecha_nacimiento,sexo,entidad',
    'Emma,Gómez,Díaz,31/12/1956,Mujer,Ciudad de México',
    'emma,GOMEZ,diaz,1956-12-31,M,DF',
    'Ana,Ruiz,Soto,2023-02-29,M,JC',
    '"María José","de la Cruz",Ruiz,1980-01-01,M,CDMX',
  ].join('\n')
  const { rows, error } = processBatch(csv)
  assert.equal(error, null)
  assert.deepEqual(rows.map((r) => [r.row, r.status]), [[2, 'ok'], [3, 'duplicado'], [4, 'error'], [5, 'ok']])
  assert.equal(rows[0].rfc, 'GODE561231GR8')
  assert.equal(rows[1].message, 'Duplicado de la fila 2.')
  assert.equal(rows[3].curp.slice(0, 4), 'CURJ')
  const out = parseCsv(batchToCsv(rows))
  assert.equal(out.length, 5)
  assert.equal(out[1][0], '2')
  assert.equal(processBatch('nombre\nx').error, 'Faltan columnas: primer_apellido, fecha_nacimiento, sexo, entidad.')
})

test('CSV: protege contra inyección de fórmulas', () => {
  const out = batchToCsv([{ row: 2, input: person('=CMD', 'X', '', '1990-01-01'), curp: '', curpBase: '', rfc: '', status: 'error', message: '' }])
  assert.ok(out.includes("'=CMD"))
})
