import { test } from 'node:test'
import assert from 'node:assert/strict'
import { addressQuery, compareAddress, FOLIO_PATTERN } from '../lib/buro/schema.ts'

const place = (over = {}) => ({
  formatted: 'Calle Falsa 123, Centro, 06000 Ciudad de México, CDMX, México',
  lat: 19.43,
  lng: -99.13,
  codigoPostal: '06000',
  municipio: 'Cuauhtémoc',
  entidad: 'Ciudad de México',
  colonia: 'Centro',
  aproximada: false,
  ...over,
})
const cred = { codigoPostal: '06000', municipio: 'CUAUHTEMOC', entidad: 'CDMX' }

test('coincide cuando CP, entidad y municipio concuerdan', () => {
  assert.equal(compareAddress(cred, place()).result, 'COINCIDE')
})

test('no coincide cuando el CP es distinto', () => {
  const r = compareAddress(cred, place({ codigoPostal: '06700' }))
  assert.equal(r.result, 'NO COINCIDE')
  assert.match(r.details.join(' '), /06000.*06700/)
})

test('no coincide cuando la entidad es distinta', () => {
  assert.equal(compareAddress(cred, place({ entidad: 'Jalisco' })).result, 'NO COINCIDE')
})

test('parcial cuando la ubicación es aproximada o falta CP', () => {
  assert.equal(compareAddress(cred, place({ aproximada: true })).result, 'COINCIDENCIA PARCIAL')
  assert.equal(compareAddress(cred, place({ codigoPostal: '' })).result, 'COINCIDENCIA PARCIAL')
})

test('sin comprobar si no hay geocodificación', () => {
  assert.equal(compareAddress(cred, null).result, 'SIN COMPROBAR')
})

test('consulta incluye domicilio, CP y México sin duplicar', () => {
  const q = addressQuery({ domicilio: 'C FALSA 123 | COL CENTRO 06000 | CUAUHTEMOC, CDMX', codigoPostal: '06000', municipio: 'CUAUHTEMOC', entidad: 'CDMX' })
  assert.equal(q, 'C FALSA 123, COL CENTRO 06000, CUAUHTEMOC, CDMX, México')
})

test('formato de folio', () => {
  assert.ok(FOLIO_PATTERN.test('BC-261016-ABCD2345'))
  assert.ok(!FOLIO_PATTERN.test('BC-261016-ABCD0O11'))
})
