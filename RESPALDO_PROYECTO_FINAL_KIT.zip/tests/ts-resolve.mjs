// Test-only: lets Node resolve extensionless relative imports (`./engine`) to `.ts`,
// matching how Next.js bundles the same files.
import { register } from 'node:module'

register(
  'data:text/javascript,' +
    encodeURIComponent(`
export async function resolve(specifier, context, next) {
  try {
    return await next(specifier, context)
  } catch (error) {
    if (specifier.startsWith('.') && !/\\.[cm]?[jt]s$/.test(specifier)) return next(specifier + '.ts', context)
    throw error
  }
}`),
)
