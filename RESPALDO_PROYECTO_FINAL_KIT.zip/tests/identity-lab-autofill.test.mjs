import { test } from 'node:test'
import assert from 'node:assert/strict'
import { missingFields, parseFreeText, REQUIRED_FOR_CURP, REQUIRED_FOR_RFC } from '../lib/identity-lab/autofill.ts'
import { generateCurp, generateRfcFromData } from '../lib/identity-lab/engine.ts'

test('texto libre en prosa: nombre, fecha, sexo y entidad', () => {
  const r = parseFreeText('Me llamo Emma Gómez Díaz, nací el 31 de diciembre de 1956, mujer, nacida en Ciudad de México')
  assert.equal(r.values.nombre, 'Emma')
  assert.equal(r.values.primerApellido, 'Gómez')
  assert.equal(r.values.segundoApellido, 'Díaz')
  assert.equal(r.values.fechaNacimiento, '1956-12-31')
  assert.equal(r.values.sexo, 'M')
  assert.equal(r.values.entidad, 'DF')
  assert.equal(generateRfcFromData(r.values).candidates[0].id, 'GODE561231GR8')
})

test('datos etiquetados en cualquier orden', () => {
  const r = parseFreeText('Sexo: Hombre\nEntidad: Campeche\nFecha de nacimiento: 19/07/1988\nApellido materno: López\nApellido paterno: Santos\nNombre: Ricardo')
  assert.deepEqual(r.values, {
    nombre: 'Ricardo', primerApellido: 'Santos', segundoApellido: 'López', fechaNacimiento: '1988-07-19', sexo: 'H', entidad: 'CC',
  })
  assert.equal(r.orderAssumed, false)
  assert.ok(generateCurp(r.values).candidates[0].id.startsWith('SALR880719HCCNPC'))
})

test('partículas agrupadas con el apellido', () => {
  const r = parseFreeText('Ricardo de la Cruz López 1988-07-19')
  assert.equal(r.values.nombre, 'Ricardo')
  assert.equal(r.values.primerApellido, 'de la Cruz')
  assert.equal(r.values.segundoApellido, 'López')
})

test('nombre compuesto y orden apellidos primero', () => {
  const a = parseFreeText('María Guadalupe López Hernández')
  assert.equal(a.values.nombre, 'María Guadalupe')
  assert.equal(a.values.primerApellido, 'López')
  const b = parseFreeText('LÓPEZ HERNÁNDEZ MARÍA GUADALUPE', 'apellidos-primero')
  assert.equal(b.values.primerApellido, 'López')
  assert.equal(b.values.segundoApellido, 'Hernández')
  assert.equal(b.values.nombre, 'María Guadalupe')
  assert.ok(b.orderAssumed)
})

test('apellidos, nombre separados por coma', () => {
  const r = parseFreeText('Pérez García, José Luis')
  assert.equal(r.values.primerApellido, 'Pérez')
  assert.equal(r.values.segundoApellido, 'García')
  assert.equal(r.values.nombre, 'José Luis')
})

test('no inventa datos faltantes y los reporta', () => {
  const r = parseFreeText('Juan Pérez')
  assert.equal(r.values.segundoApellido, '')
  // The sex is only a suggestion from the first name, never read as stated.
  assert.equal(r.detected.find((d) => d.field === 'sexo').source, 'sugerencia')
  assert.deepEqual(missingFields(r.values, REQUIRED_FOR_CURP), ['fechaNacimiento', 'entidad'])
  assert.deepEqual(missingFields(r.values, REQUIRED_FOR_RFC), ['fechaNacimiento'])
})

test('ambigüedades: varias fechas, «México» y letras sueltas no se asignan', () => {
  const r = parseFreeText('Ana Ruiz Soto, 01/02/1990, 03/04/1991, México, M')
  assert.equal(r.values.fechaNacimiento, '')
  assert.equal(r.values.entidad, '')
  // The lone «M» is not taken as the sex; only the name-based suggestion fills it.
  assert.ok(r.warnings.some((w) => w.includes('letra suelta')))
  assert.equal(r.detected.find((d) => d.field === 'sexo').source, 'sugerencia')
  assert.ok(r.warnings.some((w) => w.includes('varias fechas')))
  assert.ok(r.warnings.some((w) => w.includes('México')))
})

test('ignora CURP, RFC, correos y números para no mezclarlos con el nombre', () => {
  const r = parseFreeText('Pedro Pech Ochoa SALR880719HCCNPD08 pedro@mail.com 9991234567 10/10/1995')
  assert.equal(r.values.nombre, 'Pedro')
  assert.equal(r.values.primerApellido, 'Pech')
  assert.equal(r.values.segundoApellido, 'Ochoa')
  assert.equal(r.values.fechaNacimiento, '1995-10-10')
  assert.ok(r.warnings.some((w) => w.includes('Se ignoró una clave')))
})

test('fecha imposible se detecta pero se advierte', () => {
  const r = parseFreeText('Fecha: 31/02/1990')
  assert.equal(r.values.fechaNacimiento, '1990-02-31')
  assert.ok(r.warnings.some((w) => w.includes('no existe')))
})

test('WhatsApp: «un acta porfa» se ignora y se extraen todos los datos', () => {
  const r = parseFreeText('un acta porfa\ncarlos efren betancourt sandoval\n14 abril 2004\nguerrero')
  assert.deepEqual(
    { ...r.values },
    { nombre: 'Carlos Efren', primerApellido: 'Betancourt', segundoApellido: 'Sandoval', fechaNacimiento: '2004-04-14', sexo: 'H', entidad: 'GR' },
  )
  assert.deepEqual(r.sexSuggestion, { sexo: 'H', basedOn: 'CARLOS' })
  assert.equal(r.detected.find((d) => d.field === 'sexo').source, 'sugerencia')
})

test('mismo mensaje en una sola línea: la fecha separa nombre y entidad', () => {
  const r = parseFreeText('carlos efren betancourt sandoval 14 abril 2004 guerrero')
  assert.equal(r.values.segundoApellido, 'Sandoval')
  assert.equal(r.values.entidad, 'GR')
})

test('solicitudes y saludos nunca se leen como nombre', () => {
  for (const [text, nombre, apellido] of [
    ['necesito una CURP de maria jose lopez de la cruz 3/02/1999 jalisco', 'Maria Jose', 'Lopez'],
    ['hola buenas tardes sácame el RFC\nJUAN PEREZ\n1990-05-12', 'Juan', 'Perez'],
    ['Buenos días, me ayuda con el acta de nacimiento de mi hijo porfa\nLuis Ángel Ramírez Ortega\nnació el 5 de enero del 2010 en Oaxaca\ngracias', 'Luis Ángel', 'Ramírez'],
    ['sacame el rfc de roberto mendez', 'Roberto', 'Mendez'],
  ]) {
    const r = parseFreeText(text)
    assert.equal(r.values.nombre, nombre, text)
    assert.equal(r.values.primerApellido, apellido, text)
  }
  assert.equal(parseFreeText('necesito una CURP de maria jose lopez de la cruz 3/02/1999 jalisco').values.segundoApellido, 'de la Cruz')
})

test('formatos de fecha variados', () => {
  for (const [text, iso] of [
    ['Ana Ruiz 12-mar-1985', '1985-03-12'],
    ['Ana Ruiz abril 14, 1999', '1999-04-14'],
    ['Ana Ruiz 14 de abril del 2004', '2004-04-14'],
    ['Ana Ruiz 1999/04/14', '1999-04-14'],
    ['Ana Ruiz 14.04.1999', '1999-04-14'],
    ['Ana Ruiz 7 SEPT 2001', '2001-09-07'],
  ]) assert.equal(parseFreeText(text).values.fechaNacimiento, iso, text)
})

test('año de dos dígitos: no se supone el siglo', () => {
  const r = parseFreeText('un acta\nkarla ibarra\n14/04/04')
  assert.equal(r.values.fechaNacimiento, '')
  assert.ok(r.warnings.some((w) => w.includes('dos dígitos')))
})

test('sexo: nombre ambiguo no se sugiere y lo escrito prevalece sobre el nombre', () => {
  const amb = parseFreeText('GUADALUPE TORRES MEJIA\n12-mar-1985\nde michoacan')
  assert.equal(amb.values.sexo, '')
  assert.equal(amb.sexSuggestion, null)
  assert.equal(amb.values.entidad, 'MN')
  const contra = parseFreeText('acta porfa\nana sofia garcia ruiz\nabril 14, 1999\nhombre\nCDMX')
  assert.equal(contra.values.sexo, 'H')
  assert.equal(contra.sexSuggestion, null)
  assert.ok(contra.warnings.some((w) => w.includes('suele ser de mujer')))
  assert.equal(parseFreeText('Ma. Guadalupe Soto Ruiz').values.sexo, 'M')
  assert.equal(parseFreeText('José María Soto Ruiz').values.sexo, 'H')
})

test('datos incompletos o contradictorios: se piden y se conserva lo detectado', () => {
  const two = parseFreeText('constancia de semanas\njuan perez lopez\nmaria hernandez soto\n01/01/1980')
  assert.equal(two.values.nombre, 'Juan')
  assert.ok(two.warnings.some((w) => w.includes('más de un posible nombre')))
  const dates = parseFreeText('pedro de la garza y treviño 7 julio 1977 nuevo leon 31/12/1980')
  assert.equal(dates.values.fechaNacimiento, '')
  assert.equal(dates.values.primerApellido, 'de la Garza')
  assert.ok(dates.warnings.some((w) => w.includes('varias fechas')))
  const partial = parseFreeText('sacame el rfc de roberto mendez')
  assert.deepEqual(missingFields(partial.values, REQUIRED_FOR_RFC), ['fechaNacimiento'])
  assert.equal(partial.values.entidad, '')
})

test('texto vacío', () => {
  const r = parseFreeText('   ')
  assert.equal(r.detected.length, 0)
  assert.ok(r.warnings.length)
})
