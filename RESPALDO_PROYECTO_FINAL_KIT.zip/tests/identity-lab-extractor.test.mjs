import { test } from 'node:test'
import assert from 'node:assert/strict'
import { checkFile, checkSelection, EXTRACT_LIMITS, kindFromBytes } from '../lib/identity-lab/doc-extract/limits.ts'
import {
  compareCurp,
  documentCurp,
  extractRequestSchema,
  formatResults,
  sanitizeResult,
  toCurpInput,
} from '../lib/identity-lab/doc-extract/schema.ts'
import { generateCurp } from '../lib/identity-lab/engine.ts'

const bytes = (...parts) =>
  new Uint8Array(parts.flatMap((p) => (typeof p === 'string' ? [...p].map((c) => c.charCodeAt(0)) : p)))

test('detecta el tipo real por sus primeros bytes', () => {
  assert.equal(kindFromBytes(bytes('%PDF-1.7')), 'pdf')
  assert.equal(kindFromBytes(bytes([0xff, 0xd8, 0xff, 0xe0])), 'image')
  assert.equal(kindFromBytes(bytes([0x89], 'PNG', [13, 10, 26, 10])), 'image')
  assert.equal(kindFromBytes(bytes('RIFF', [0, 0, 0, 0], 'WEBP')), 'image')
  assert.equal(kindFromBytes(bytes([0x50, 0x4b, 0x03, 0x04])), 'docx')
  assert.equal(kindFromBytes(bytes('Nombre: Ana')), 'text-like')
  assert.equal(kindFromBytes(bytes([0x4d, 0x5a, 0x00, 0x90])), null)
})

test('rechaza formatos no admitidos, vacíos, grandes y renombrados', () => {
  assert.match(checkFile('virus.exe', 10, bytes('MZ')).error, /formato no admitido/)
  assert.match(checkFile('foto.heic', 10, bytes('x')).error, /formato no admitido/)
  assert.match(checkFile('a.pdf', 0, bytes()).error, /vacío/)
  assert.match(checkFile('a.pdf', EXTRACT_LIMITS.maxFileBytes + 1, bytes('%PDF-')).error, /supera/)
  assert.match(checkFile('error.pdf', 100, bytes('<!DOCTYPE html>')).error, /no corresponde/)
  assert.match(checkFile('foto.jpg', 100, bytes('%PDF-1.4')).error, /no corresponde/)
  assert.deepEqual(checkFile('acta.pdf', 100, bytes('%PDF-1.4')), { kind: 'pdf' })
  assert.deepEqual(checkFile('CURP.JPEG', 100, bytes([0xff, 0xd8, 0xff])), { kind: 'image' })
  assert.deepEqual(checkFile('notas.txt', 5, bytes('hola')), { kind: 'txt' })
})

test('limita cantidad y tamaño total de la selección', () => {
  assert.equal(checkSelection([1, 2, 3]), null)
  assert.match(checkSelection(Array(EXTRACT_LIMITS.maxFiles + 1).fill(1)), /Máximo/)
  assert.match(checkSelection([EXTRACT_LIMITS.maxTotalBytes, 1]), /suman/)
})

test('valida la solicitud en el servidor', () => {
  const ok = { mode: 'curp', segments: [{ file: 'a.txt', page: null, method: 'txt', text: 'CURP X' }], images: [] }
  assert.equal(extractRequestSchema.safeParse(ok).success, true)
  assert.equal(extractRequestSchema.safeParse({ ...ok, mode: 'libre' }).success, false)
  assert.equal(
    extractRequestSchema.safeParse({ ...ok, images: [{ file: 'b.jpg', page: null, data: 'QUJD' }] }).success,
    false,
    'una solicitud nunca mezcla archivos',
  )
  assert.equal(extractRequestSchema.safeParse({ ...ok, segments: [{ ...ok.segments[0], text: '  ' }] }).success, false)
  assert.equal(
    extractRequestSchema.safeParse({ ...ok, images: [{ file: 'a.jpg', page: null, data: '<script>' }] }).success,
    false,
  )
  const tooManyImages = Array(EXTRACT_LIMITS.maxModelImages + 1).fill({ file: 'a.jpg', page: 1, data: 'QUJD' })
  assert.equal(extractRequestSchema.safeParse({ ...ok, images: tooManyImages }).success, false)
  const huge = 'A'.repeat(EXTRACT_LIMITS.maxImageBase64Chars / 2 + 10)
  const bigImages = [{ file: 'a', page: 1, data: huge }, { file: 'b', page: 2, data: huge }]
  assert.equal(extractRequestSchema.safeParse({ ...ok, images: bigImages }).success, false)
})

const person = (campos, extra = {}) => ({ etiqueta: '', campos, datosCurp: null, ...extra })
const field = (campo, valor, estado = 'ENCONTRADO') => ({ campo, valor, estado, archivo: 'acta.pdf', pagina: 1 })

test('sanea la salida: estados NO ENCONTRADO / NO LEGIBLE y mayúsculas', () => {
  const out = sanitizeResult({
    personas: [
      person([
        field('nombre completo', ' María José Pérez Núñez '),
        field('curp', ''),
        field('fecha de registro', 'algo', 'NO LEGIBLE'),
        field('domicilio', 'inventado', 'NO ENCONTRADO'),
      ]),
    ],
    contradicciones: [' ', 'Fecha distinta en p. 1 y p. 2'],
  })
  const c = out.personas[0].campos
  assert.deepEqual(
    c.map((x) => [x.campo, x.valor, x.estado]),
    [
      ['NOMBRE COMPLETO', 'María José Pérez Núñez', 'ENCONTRADO'],
      ['CURP', 'NO ENCONTRADO', 'NO ENCONTRADO'],
      ['FECHA DE REGISTRO', 'NO LEGIBLE', 'NO LEGIBLE'],
      ['DOMICILIO', 'NO ENCONTRADO', 'NO ENCONTRADO'],
    ],
  )
  assert.deepEqual(out.contradicciones, ['Fecha distinta en p. 1 y p. 2'])
})

test('un único dato se copia solo; varias personas van en bloques', () => {
  assert.equal(formatResults({ personas: [person([field('CURP', 'GODE561231MDFMZM01')])], contradicciones: [] }), 'GODE561231MDFMZM01')
  const two = formatResults({
    personas: [
      person([field('NOMBRE COMPLETO', 'JUAN PÉREZ'), field('FECHA DE NACIMIENTO', '01/02/1990')], { etiqueta: 'CÓNYUGE 1' }),
      person([field('NOMBRE COMPLETO', 'ANA LÓPEZ'), field('FECHA DE NACIMIENTO', 'NO LEGIBLE', 'NO LEGIBLE')], { etiqueta: 'CÓNYUGE 2' }),
    ],
    contradicciones: [],
  })
  assert.equal(
    two,
    'CÓNYUGE 1\nNOMBRE COMPLETO: JUAN PÉREZ\nFECHA DE NACIMIENTO: 01/02/1990\n\nCÓNYUGE 2\nNOMBRE COMPLETO: ANA LÓPEZ\nFECHA DE NACIMIENTO: NO LEGIBLE',
  )
})

test('datos extraídos alimentan el algoritmo CURP existente sin inventar', () => {
  const input = toCurpInput({
    nombre: 'Emma',
    primerApellido: 'Gómez',
    segundoApellido: 'Díaz',
    fechaNacimiento: '1956-12-31',
    sexo: 'M',
    entidadNacimiento: 'Ciudad de México',
  })
  assert.deepEqual(input, { nombre: 'Emma', primerApellido: 'Gómez', segundoApellido: 'Díaz', fechaNacimiento: '1956-12-31', sexo: 'M', entidad: 'DF' })
  assert.equal(generateCurp(input, 1).candidates[0].id, 'GODE561231MDFMZM01')

  const partial = toCurpInput({ nombre: 'Ana', primerApellido: 'Ruiz', segundoApellido: '', fechaNacimiento: '14 abril 2004', sexo: '', entidadNacimiento: 'Atlantis' })
  assert.equal(partial.fechaNacimiento, '')
  assert.equal(partial.sexo, '')
  assert.equal(partial.entidad, '')
  assert.equal(generateCurp(partial, 1).ok, false)
})

test('compara la CURP del documento con la candidata', () => {
  const p = person([field('CURP', 'gode 561231 mdfmzm01')])
  assert.equal(documentCurp(p), 'GODE561231MDFMZM01')
  assert.equal(documentCurp(person([field('CURP', 'NO ENCONTRADO', 'NO ENCONTRADO')])), null)
  assert.deepEqual(compareCurp('GODE561231MDFMZM01', 'GODE561231MDFMZM01'), [])
  assert.deepEqual(compareCurp('GODE561231MDFMZM01', 'GODE561231HDFMZM01'), [11])
})
