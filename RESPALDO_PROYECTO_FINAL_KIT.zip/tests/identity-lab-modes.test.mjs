import { test } from 'node:test'
import assert from 'node:assert/strict'
import { decodeCurp, evaluate, listText } from '../lib/identity-lab/doc-extract/modes.ts'
import { canonicalField, sanitizeCfe, sanitizeFiscal } from '../lib/identity-lab/doc-extract/schema.ts'

test('nombres de campo con acentos dañados se restauran', () => {
  assert.equal(canonicalField('N\u0013MERO DE SERVICIO CFE'), 'NÚMERO DE SERVICIO CFE')
  assert.equal(canonicalField(' nombre completo '), 'NOMBRE COMPLETO')
  assert.equal(canonicalField('OTRO DATO'), 'OTRO DATO')
})

const field = (campo, valor, estado = 'ENCONTRADO') => ({ campo, valor, estado, archivo: 'a.pdf', pagina: 1 })
const person = (extra = {}) => ({ etiqueta: '', campos: [], curpImpresa: '', rfcImpreso: '', tipoPersona: '', datosCurp: null, ...extra })
const datos = (extra = {}) => ({ nombre: 'Emma', primerApellido: 'Gómez', segundoApellido: 'Díaz', fechaNacimiento: '1956-12-31', sexo: 'M', entidadNacimiento: 'Ciudad de México', ...extra })
const people = (mode, personas) => evaluate({ mode, data: { personas, contradicciones: [] } })

test('CURP impresa: se valida y se derivan fecha, sexo y entidad, marcados como derivados', () => {
  assert.deepEqual(decodeCurp('GODE561231MDFMZM01'), { fecha: '31/12/1956', sexo: 'MUJER', entidad: 'CIUDAD DE MÉXICO' })
  const ev = people('curp', [person({ curpImpresa: 'GODE561231MDFMZM01', campos: [field('NOMBRE COMPLETO', 'EMMA GÓMEZ DÍAZ')] })])
  assert.equal(ev.status, 'COMPLETADO')
  assert.deepEqual(ev.people[0].line, { value: 'GODE561231MDFMZM01', condition: 'EXTRAÍDO' })
  const derived = ev.people[0].fields.filter((f) => f.origin === 'DE LA CURP').map((f) => f.campo)
  assert.deepEqual(derived, ['FECHA DE NACIMIENTO', 'SEXO', 'ENTIDAD DE NACIMIENTO'])
})

test('acta sin CURP: candidata calculada con el motor existente; datos faltantes = incompleto', () => {
  const ok = people('curp', [person({ datosCurp: datos() })])
  assert.deepEqual(ok.people[0].line, { value: 'GODE561231MDFMZM01', condition: 'CANDIDATA' })
  assert.match(ok.people[0].notes.join(' '), /PENDIENTE DE VERIFICACIÓN OFICIAL/)

  const marriage = people('curp', [
    person({ etiqueta: 'CÓNYUGE 1', datosCurp: datos() }),
    person({ etiqueta: 'CÓNYUGE 2', datosCurp: datos({ nombre: 'Ana', fechaNacimiento: '' }) }),
  ])
  assert.equal(marriage.status, 'INCOMPLETO')
  assert.ok(marriage.people[0].line)
  assert.equal(marriage.people[1].line, null)
  assert.match(marriage.people[1].notes[0], /Cálculo incompleto/)
})

test('CURP impresa con estructura inválida no se presenta como extraída', () => {
  const ev = people('curp', [person({ curpImpresa: 'GODE561231MDFMZM0' })])
  assert.equal(ev.status, 'INCOMPLETO')
  assert.equal(ev.people[0].line, null)
})

test('RFC: impreso se valida; si falta se calcula candidato; moral sin RFC = incompleto', () => {
  const printed = people('rfc', [person({ rfcImpreso: 'GODE561231GR8' })])
  assert.deepEqual(printed.people[0].line, { value: 'GODE561231GR8', condition: 'EXTRAÍDO' })
  const calc = people('rfc', [person({ tipoPersona: 'FISICA', datosCurp: datos() })])
  assert.equal(calc.people[0].line.condition, 'CANDIDATA')
  assert.equal(calc.people[0].line.value, 'GODE561231GR8')
  const fromCurp = people('rfc', [person({ curpImpresa: 'GODE561231MDFMZM01', datosCurp: datos({ fechaNacimiento: '' }) })])
  assert.equal(fromCurp.people[0].line.value.slice(0, 10), 'GODE561231')
  const moral = people('rfc', [person({ tipoPersona: 'MORAL' })])
  assert.equal(moral.status, 'INCOMPLETO')
})

test('RFC + IDCIF: una línea limpia solo con ambos valores válidos', () => {
  const both = evaluate({ mode: 'fiscal', data: sanitizeFiscal({ rfc: 'gode561231 gr8', rfcEstado: 'ENCONTRADO', idcif: '12345678901', idcifEstado: 'ENCONTRADO', pagina: 1 }) })
  assert.equal(both.status, 'COMPLETADO')
  assert.equal(both.people[0].line.value, 'GODE561231GR8 12345678901')
  const onlyRfc = evaluate({ mode: 'fiscal', data: sanitizeFiscal({ rfc: 'GODE561231GR8', rfcEstado: 'ENCONTRADO', idcif: '', idcifEstado: 'ENCONTRADO', pagina: 1 }) })
  assert.equal(onlyRfc.status, 'INCOMPLETO')
  assert.equal(onlyRfc.people[0].line, null)
  assert.match(onlyRfc.people[0].notes.join(), /Falta el IDCIF/)
  const shortId = evaluate({ mode: 'fiscal', data: { rfc: 'GODE561231GR8', rfcEstado: 'ENCONTRADO', idcif: '1234', idcifEstado: 'ENCONTRADO', pagina: 1 } })
  assert.equal(shortId.status, 'INCOMPLETO')
  assert.equal(listText('fiscal', [{ fileName: 'a', evaluation: both }, { fileName: 'b', evaluation: onlyRfc }]), 'GODE561231GR8 12345678901')
})

test('CFE: 12 dígitos junto a su etiqueta; otros números = revisión necesaria', () => {
  const ok = evaluate({ mode: 'cfe', data: sanitizeCfe({ numeroServicio: '547 090 300 123', estado: 'ENCONTRADO', etiqueta: 'NO. DE SERVICIO', pagina: 1 }) })
  assert.equal(ok.status, 'COMPLETADO')
  assert.equal(ok.people[0].line.value, '547090300123')
  const noLabel = evaluate({ mode: 'cfe', data: sanitizeCfe({ numeroServicio: '547090300123', estado: 'ENCONTRADO', etiqueta: 'MEDIDOR', pagina: 1 }) })
  assert.equal(noLabel.status, 'INCOMPLETO')
  assert.match(noLabel.people[0].notes[0], /REVISIÓN NECESARIA/)
  const short = evaluate({ mode: 'cfe', data: sanitizeCfe({ numeroServicio: '12345', estado: 'ENCONTRADO', etiqueta: 'NO. DE SERVICIO', pagina: 1 }) })
  assert.equal(short.status, 'INCOMPLETO')
  assert.equal(listText('cfe', [{ fileName: 'a', evaluation: ok }, { fileName: 'b', evaluation: short }, { fileName: 'c', evaluation: ok }]), '547090300123\n547090300123')
})

test('lista CURP/RFC marca candidatas y respeta el orden', () => {
  const a = people('curp', [person({ curpImpresa: 'GODE561231MDFMZM01' })])
  const b = people('curp', [person({ datosCurp: datos() })])
  assert.equal(listText('curp', [{ fileName: 'a', evaluation: a }, { fileName: 'b', evaluation: null }, { fileName: 'c', evaluation: b }]), 'GODE561231MDFMZM01\nGODE561231MDFMZM01 (CANDIDATA)')
})
