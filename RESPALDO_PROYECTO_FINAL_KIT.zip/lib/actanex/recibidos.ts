import 'server-only'
import { get, put } from '@vercel/blob'
import type { Solicitud } from './goat'

/**
 * GOAT reports when an acta was requested but not when its PDF became ready, so TRAMIX records the
 * first time it sees each PDF available. Ids already ready when tracking began are stored as null
 * (unknown) instead of being given a made-up time.
 */
const PATH = 'actanex/recibidos.json'

type Mapa = Record<string, string | null>

let cache: Mapa | null = null
let queue: Promise<unknown> = Promise.resolve()

async function leer(): Promise<Mapa | null> {
  const result = await get(PATH, { access: 'private', useCache: false }).catch(() => null)
  if (result && result.statusCode === 200 && result.stream) {
    try {
      return JSON.parse(await new Response(result.stream).text()) as Mapa
    } catch {}
  }
  return null
}

async function escribir(mapa: Mapa) {
  await put(PATH, JSON.stringify(mapa), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

async function actualizar(registros: Solicitud[]): Promise<Mapa> {
  const listos = registros.filter((r) => r.RutaEncriptada).map((r) => String(r.id))
  if (cache && listos.every((id) => id in cache!)) return cache

  const guardado = await leer()
  const primeraVez = guardado === null
  const mapa: Mapa = { ...(guardado ?? {}), ...(cache ?? {}) }
  // Keep the earliest time if another instance recorded the same id.
  if (guardado) for (const [id, t] of Object.entries(guardado)) if (t === null || (mapa[id] && t < mapa[id]!)) mapa[id] = t

  const ahora = new Date().toISOString()
  let cambios = false
  for (const id of listos) {
    if (!(id in mapa)) {
      mapa[id] = primeraVez ? null : ahora
      cambios = true
    }
  }
  if (cambios) await escribir(mapa)
  cache = mapa
  return mapa
}

export async function conHoraDeRecepcion(registros: Solicitud[]): Promise<Solicitud[]> {
  try {
    const run = queue.then(() => actualizar(registros))
    queue = run.catch(() => {})
    const mapa = await run
    return registros.map((r) => (r.RutaEncriptada ? { ...r, recibido: mapa[String(r.id)] ?? null } : r))
  } catch (error) {
    console.error('[actanex] recibidos', error)
    return registros
  }
}
