const BASE = 'https://tramitesyserviciosgoat.com'
const WS_URL = 'wss://tramitesyserviciosgoat.com/wscliente/'
const SESSION_TTL_MS = 20 * 60 * 1000

export class GoatError extends Error {}

type Session = { cookie: string; usuario: string; token: string; createdAt: number }

export type Solicitud = {
  id: number
  tipo: string
  curp: string | null
  CurpOpcional: string | null
  cadena: string | null
  fecha: string | null
  hora: string | null
  folio: number | boolean
  status: string
  RutaEncriptada: string | null
  Descargado: string | null
  OpcionesPDF?: string | null
  recibido?: string | null
}

export type NuevaSolicitud = {
  curp: string | null
  CurpOpcional: string | null
  cadena: string | null
}

let cached: Session | null = null
let loggingIn: Promise<Session> | null = null

function storeCookies(jar: Map<string, string>, res: Response) {
  for (const raw of res.headers.getSetCookie()) {
    const pair = raw.split(';')[0]
    const eq = pair.indexOf('=')
    if (eq > 0) jar.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim())
  }
}

const cookieHeader = (jar: Map<string, string>) =>
  [...jar].map(([k, v]) => `${k}=${v}`).join('; ')

async function login(): Promise<Session> {
  const username = process.env.GOAT_USER
  const password = process.env.GOAT_PASSWORD
  if (!username || !password) throw new GoatError('Faltan las variables GOAT_USER y GOAT_PASSWORD.')

  const jar = new Map<string, string>()
  const first = await fetch(`${BASE}/servicios/index.php`, { redirect: 'manual', cache: 'no-store' })
  storeCookies(jar, first)

  const post = await fetch(`${BASE}/servicios/index.php`, {
    method: 'POST',
    redirect: 'manual',
    cache: 'no-store',
    headers: { 'content-type': 'application/x-www-form-urlencoded', cookie: cookieHeader(jar) },
    body: new URLSearchParams({ username, password }),
  })
  storeCookies(jar, post)

  const panel = await fetch(`${BASE}/servicios/cliente/cliente.php`, {
    redirect: 'manual',
    cache: 'no-store',
    headers: { cookie: cookieHeader(jar) },
  })
  storeCookies(jar, panel)
  if (panel.status !== 200) throw new GoatError('No se pudo iniciar sesión: revisa usuario y contraseña.')

  const html = await panel.text()
  const token = html.match(/token:\s*"([a-f0-9]+)"/)?.[1]
  const usuario = html.match(/usuarioLogueado\s*=\s*"([^"]+)"/)?.[1]
  if (!token || !usuario) throw new GoatError('El panel cambió y no se encontró el token de sesión.')

  return { cookie: cookieHeader(jar), token, usuario, createdAt: Date.now() }
}

async function getSession(force = false): Promise<Session> {
  if (!force && cached && Date.now() - cached.createdAt < SESSION_TTL_MS) return cached
  if (!loggingIn) {
    loggingIn = login()
      .then((s) => (cached = s))
      .finally(() => (loggingIn = null))
  }
  return loggingIn
}

export async function listarSolicitudes(): Promise<Solicitud[]> {
  for (const force of [false, true]) {
    const session = await getSession(force)
    const res = await fetch(`${BASE}/servicios/cliente/cliente.php?solicitudes_json=1`, {
      redirect: 'manual',
      cache: 'no-store',
      headers: { cookie: session.cookie },
    })
    if (res.status === 200 && res.headers.get('content-type')?.includes('json')) {
      const data = await res.json()
      if (data?.ok && Array.isArray(data.registros)) return data.registros
    }
    cached = null
  }
  throw new GoatError('No se pudieron obtener las solicitudes.')
}

type WsMessage = { action?: string; [key: string]: unknown }

async function conWebSocket(acciones: (send: (data: object) => void) => void, esperaMs: number) {
  const session = await getSession()
  return new Promise<WsMessage[]>((resolve, reject) => {
    const ws = new WebSocket(WS_URL)
    const recibidos: WsMessage[] = []
    let autenticado = false
    const fail = setTimeout(() => {
      ws.close()
      reject(new GoatError('El servidor de GOAT no respondió a tiempo.'))
    }, 15000)

    ws.onopen = () => {
      ws.send(JSON.stringify({ action: 'loginCliente', usuario: session.usuario, token: session.token }))
    }
    ws.onmessage = (event) => {
      let data: WsMessage
      try {
        data = JSON.parse(String(event.data))
      } catch {
        return
      }
      recibidos.push(data)
      if (data.action === 'forzarLogout') {
        cached = null
        clearTimeout(fail)
        ws.close()
        reject(new GoatError('La sesión se cerró porque se inició en otro dispositivo. Intenta de nuevo.'))
        return
      }
      if (!autenticado && data.action === 'updateTable') {
        autenticado = true
        acciones((payload) => ws.send(JSON.stringify(payload)))
        setTimeout(() => {
          clearTimeout(fail)
          ws.close()
          resolve(recibidos)
        }, esperaMs)
      }
    }
    ws.onerror = () => {
      cached = null
      clearTimeout(fail)
      reject(new GoatError('No se pudo conectar al servidor de GOAT.'))
    }
  })
}

export async function crearSolicitudes(tipo: string, folio: boolean, items: NuevaSolicitud[]) {
  const session = await getSession()
  await conWebSocket((send) => {
    for (const item of items) {
      send({ action: 'nuevoRegistro', usuario: session.usuario, tipo, folio, ...item })
    }
  }, 1500 + items.length * 150)
}

export async function marcarDescargados(ids: number[]) {
  if (ids.length === 0) return
  const session = await getSession()
  await conWebSocket((send) => {
    for (const id of ids) send({ action: 'marcarDescargado', id: String(id), usuario: session.usuario })
  }, 800)
}

export async function descargarArchivo(ruta: string) {
  if (!/^[a-f0-9]{16,64}$/.test(ruta)) throw new GoatError('Archivo inválido.')
  const session = await getSession()
  const res = await fetch(`${BASE}/descargar/${ruta}`, { cache: 'no-store', headers: { cookie: session.cookie } })
  if (!res.ok || !res.body) throw new GoatError('No se pudo descargar el archivo.')
  const disposition = res.headers.get('content-disposition') ?? ''
  const nombre = disposition.match(/filename="?([^";]+)"?/)?.[1] ?? `${ruta}.pdf`
  return { res, nombre }
}
