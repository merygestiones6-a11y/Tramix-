export const TIPOS = ['NACIMIENTO', 'MATRIMONIO', 'DIVORCIO', 'DEFUNCION'] as const
export type Tipo = (typeof TIPOS)[number]

const CURP_RE =
  /^([A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[HM](?:AS|B[CS]|C[CLMSH]|D[FG]|G[TR]|HG|JC|M[CNS]|N[ETL]|OC|PL|Q[TR]|S[PLR]|T[CSL]|VZ|YN|ZS)[B-DF-HJ-NP-TV-Z]{3}[A-Z\d])(\d)$/
const PARECE_CURP = /^[A-Z]{4}\d{6}[A-Z0-9]{8}$/

export function curpValida(curp: string) {
  const match = curp.match(CURP_RE)
  if (!match) return false
  const dic = '0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ'
  let suma = 0
  for (let i = 0; i < 17; i++) suma += dic.indexOf(match[1].charAt(i)) * (18 - i)
  const digito = (10 - (suma % 10)) % 10
  return Number(match[2]) === digito
}

export const usaSegundaCurp = (tipo: string) => tipo === 'MATRIMONIO' || tipo === 'DIVORCIO'

export type LineaParseada = {
  linea: string
  curp: string | null
  CurpOpcional: string | null
  cadena: string | null
  error: string | null
}

export function parsearLineas(texto: string, tipo: string): LineaParseada[] {
  const vistos = new Set<string>()
  return texto
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((linea) => {
      const partes = linea.toUpperCase().split(/[\s,;|]+/).filter(Boolean)
      const curps = partes.filter((p) => PARECE_CURP.test(p))
      const base = { linea, curp: null, CurpOpcional: null, cadena: null, error: null }

      if (curps.length === 0) {
        const cadena = linea.slice(0, 50)
        const key = `C:${cadena}`
        if (vistos.has(key)) return { ...base, cadena, error: 'Repetida' }
        vistos.add(key)
        return { ...base, cadena }
      }

      const [curp, segunda] = curps
      if (!curpValida(curp)) return { ...base, curp, error: 'CURP inválida' }
      const CurpOpcional = usaSegundaCurp(tipo) && segunda ? segunda : null
      if (CurpOpcional && !curpValida(CurpOpcional)) return { ...base, curp, CurpOpcional, error: 'Segunda CURP inválida' }
      const key = `P:${curp}:${CurpOpcional ?? ''}`
      if (vistos.has(key)) return { ...base, curp, CurpOpcional, error: 'Repetida' }
      vistos.add(key)
      return { ...base, curp, CurpOpcional }
    })
}
