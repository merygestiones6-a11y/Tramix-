import { downloadPdf } from '@/lib/download'

function hasNativeSaver() {
  const bridge = (window as unknown as { TramixAndroid?: { saveDataUrl?: unknown } }).TramixAndroid
  return Boolean(bridge && typeof bridge.saveDataUrl === 'function')
}

/**
 * Saves a stamped PDF with exactly `fileName`.
 *
 * Android browsers outside the TRAMIX app (Chrome in some versions, Samsung Internet, Firefox,
 * in-app browsers) name blob downloads after the blob URL's UUID and ignore `download`. There the
 * file is served once from a short-lived HTTPS URL that ends in the name and carries a matching
 * Content-Disposition, which every Android downloader honours.
 */
export async function saveFoliado(bytes: Uint8Array, fileName: string): Promise<void> {
  if (hasNativeSaver() || !/Android/i.test(navigator.userAgent)) {
    downloadPdf(bytes, fileName)
    return
  }

  try {
    const form = new FormData()
    form.append('file', new Blob([bytes as BlobPart], { type: 'application/pdf' }), fileName)
    form.append('name', fileName)
    const res = await fetch('/api/foliador/download', { method: 'POST', body: form, cache: 'no-store' })
    if (!res.ok) throw new Error(String(res.status))
    const { url } = (await res.json()) as { url: string }

    const link = document.createElement('a')
    link.href = url
    link.download = fileName
    link.rel = 'noopener'
    link.style.display = 'none'
    document.body.appendChild(link)
    link.click()
    link.remove()
  } catch {
    downloadPdf(bytes, fileName)
  }
}
