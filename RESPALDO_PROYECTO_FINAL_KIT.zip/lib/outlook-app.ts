'use client'

import { useEffect, useState } from 'react'
import { accessFetch } from '@/lib/outlook/client'

export type SessionStatus = 'available' | 'in_use' | 'error' | 'login_required'

export interface AppSession {
  email: string
  status: SessionStatus
  message: string
  updatedAt: number
}

export type RunStatus = 'running' | 'manual' | 'uploading' | 'done' | 'error' | 'cancelled'

export interface AppRun {
  id: string
  email: string
  curp: string
  status: RunStatus
  step: string
  message: string
  docs: { id: string; name: string; uploaded: boolean }[]
  startedAt: number
  updatedAt: number
  /** Which route the mail took: PDF attachments, or the trámite link to the IMSS portal. */
  path?: 'attachments' | 'link'
  /** Documents detected; the run only completes once all of them are saved. */
  expected?: number
  reached?: string[]
  lastUrl?: string
  /** End of the 10-minute intervention window. */
  holdUntil?: number
  trashed?: boolean
  trashedAt?: number
}

interface OutlookBridge {
  outlookSupported(): boolean
  outlookAccounts(): string
  outlookAdd(email: string): boolean
  outlookLogin(email: string): boolean
  outlookTest(email: string): boolean
  outlookRemove(email: string): boolean
  outlookRun(email: string, curp: string): string
  outlookRuns(): string
  outlookIntervene(runId: string): boolean
  outlookCancel(runId: string): boolean
  outlookUploaded(runId: string, docId: string): boolean
  outlookDeleteRun?(runId: string): boolean
  outlookRetry?(runId: string): boolean
  outlookRetryNext?(runId: string): boolean
  outlookEmptyTrash?(): number
  readDocument(id: string): string
  previewDocument(name: string, base64: string): boolean
}

function bridge(): OutlookBridge | null {
  if (typeof window === 'undefined') return null
  const b = (window as unknown as { TramixAndroid?: OutlookBridge }).TramixAndroid
  return b && typeof b.outlookAccounts === 'function' ? b : null
}

function parse<T>(raw: string | undefined, fallback: T): T {
  try {
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export const outlookApp = {
  available: () => !!bridge(),
  supported: () => bridge()?.outlookSupported() ?? false,
  accounts: () => parse<AppSession[]>(bridge()?.outlookAccounts(), []),
  runs: () => parse<AppRun[]>(bridge()?.outlookRuns(), []),
  add: (email: string) => bridge()?.outlookAdd(email) ?? false,
  login: (email: string) => bridge()?.outlookLogin(email) ?? false,
  test: (email: string) => bridge()?.outlookTest(email) ?? false,
  remove: (email: string) => bridge()?.outlookRemove(email) ?? false,
  /** Returns the run id, or an error code starting with "!". */
  run: (email: string, curp: string) => bridge()?.outlookRun(email, curp) ?? '!unsupported',
  intervene: (id: string) => bridge()?.outlookIntervene(id) ?? false,
  cancel: (id: string) => bridge()?.outlookCancel(id) ?? false,
  preview: (name: string, base64: string) => bridge()?.previewDocument(name, base64) ?? false,
  /** Deletes a TRAMIX record from the trash. Never deletes Outlook mail. */
  deleteRun: (id: string) => bridge()?.outlookDeleteRun?.(id) ?? false,
  emptyTrash: () => bridge()?.outlookEmptyTrash?.() ?? 0,
  /** "Revisar ahora": re-runs the real browser flow (mail → link → portal → download) for this run. */
  retry: (id: string) => bridge()?.outlookRetry?.(id) ?? false,
  /** REINTENTAR: keeps the run and continues searching the IMSS mail/PDF in the next linked Outlook account. */
  retryNext: (id: string) => bridge()?.outlookRetryNext?.(id) ?? false,
}

export type RunStep = { key: string; label: string }

const COMMON_STEPS: RunStep[] = [
  { key: 'outlook', label: 'ACCESO A OUTLOOK' },
  { key: 'mail_found', label: 'CORREO DEL IMSS ENCONTRADO' },
  { key: 'mail', label: 'CORREO ABIERTO' },
]

const ATTACHMENT_STEPS: RunStep[] = [
  { key: 'attachments', label: 'DOCUMENTOS ADJUNTOS DETECTADOS' },
  { key: 'pdf', label: 'PDF DESCARGADOS' },
]

const LINK_STEPS: RunStep[] = [
  { key: 'link', label: 'ENLACE DEL TRÁMITE DETECTADO' },
  { key: 'portal', label: 'PORTAL DEL IMSS' },
  { key: 'documents', label: 'DOCUMENTOS DETECTADOS' },
  { key: 'pdf', label: 'PDF DESCARGADOS' },
]

/** Steps shown for a run, depending on whether the mail brought attachments or the trámite link. */
export function runSteps(run: AppRun): RunStep[] {
  if (run.path === 'attachments') return [...COMMON_STEPS, ...ATTACHMENT_STEPS]
  if (run.path === 'link') return [...COMMON_STEPS, ...LINK_STEPS]
  return COMMON_STEPS
}

export const ACTIVE_RUN = new Set<RunStatus>(['running', 'manual', 'uploading'])

/** A run can be intervened while active, or during its 10-minute window afterwards. */
export function canIntervene(run: AppRun, now = Date.now()) {
  if (run.trashed) return false
  return ACTIVE_RUN.has(run.status) || (run.holdUntil ?? 0) > now
}

export const SESSION_LABEL: Record<SessionStatus, string> = {
  available: 'DISPONIBLE',
  in_use: 'EN USO',
  error: 'ERROR',
  login_required: 'REQUIERE INICIO DE SESIÓN',
}

const uploading = new Set<string>()

async function uploadPending(runs: AppRun[]) {
  const b = bridge()
  if (!b) return
  for (const run of runs) {
    if (run.trashed || !ACTIVE_RUN.has(run.status)) continue
    for (const doc of run.docs) {
      if (doc.uploaded || uploading.has(doc.id)) continue
      uploading.add(doc.id)
      try {
        const base64 = b.readDocument(doc.id)
        if (!base64) continue
        const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
        const res = await accessFetch('/api/validar-nss/document', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/pdf',
            'x-curp': run.curp,
            'x-email': encodeURIComponent(run.email),
            'x-file-name': encodeURIComponent(doc.name),
            'x-origin': 'outlook',
          },
          body: bytes,
        })
        if (res.ok) b.outlookUploaded(run.id, doc.id)
      } catch {
        // Retried on the next poll.
      } finally {
        uploading.delete(doc.id)
      }
    }
  }
}

/** Polls the app's Outlook sessions and runs, and pushes finished PDFs into DESCARGAR. */
export function useOutlookApp(intervalMs = 2500) {
  const [state, setState] = useState<{ ready: boolean; supported: boolean; accounts: AppSession[]; runs: AppRun[] }>({
    ready: false,
    supported: false,
    accounts: [],
    runs: [],
  })

  useEffect(() => {
    if (!outlookApp.available()) {
      setState((s) => ({ ...s, ready: true }))
      return
    }
    const tick = () => {
      const runs = outlookApp.runs()
      setState({ ready: true, supported: outlookApp.supported(), accounts: outlookApp.accounts(), runs })
      void uploadPending(runs)
    }
    tick()
    const id = setInterval(tick, intervalMs)
    window.addEventListener('tramix-android', tick)
    return () => {
      clearInterval(id)
      window.removeEventListener('tramix-android', tick)
    }
  }, [intervalMs])

  return { ...state, inApp: outlookApp.available() }
}
