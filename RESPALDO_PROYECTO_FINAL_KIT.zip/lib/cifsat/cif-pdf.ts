import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { PDFArray, PDFDict, PDFDocument, PDFName, StandardFonts, rgb, type PDFFont } from 'pdf-lib'
import QRCode from 'qrcode'
import { buildSatValidatorUrl } from '@/lib/cifsat/sat-qr'

const TEMPLATE_PATH = path.join(process.cwd(), 'assets/cifsat/templates/cif-template.pdf')

// Coordinates measured from the original template's variable-data overlay stream.
const TEXT_CENTER_X = 274.2
const TEXT_COLOR = rgb(0.5098, 0.5098, 0.5098)
const FONT_SIZE = 8
const NAME_MAX_WIDTH = 140
const QR_BOX = { x: 65, y: 485, size: 100 }
const VARIABLE_OVERLAY_INDEX = 3
const TEMPLATE_QR_XOBJECT = 'Image-9742682568'

export type CifData = {
  rfc: string
  idCif: string
  nombre: string
}

function wrapText(text: string, font: PDFFont, size: number, maxWidth: number) {
  const words = text.split(/\s+/).filter(Boolean)
  const lines: string[] = []
  let current = ''
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word
    if (font.widthOfTextAtSize(candidate, size) <= maxWidth || !current) {
      current = candidate
    } else {
      lines.push(current)
      current = word
    }
  }
  if (current) lines.push(current)
  return lines
}

export async function generateCifPdf({ rfc, idCif, nombre }: CifData) {
  const template = await readFile(TEMPLATE_PATH)
  const pdf = await PDFDocument.load(template)
  const page = pdf.getPage(0)

  // Drop only the overlay stream holding the template's personal data and QR.
  // Institutional streams (logos, frame, headers, footer) remain untouched.
  const contents = page.node.Contents()
  if (contents instanceof PDFArray && contents.size() > VARIABLE_OVERLAY_INDEX) {
    contents.remove(VARIABLE_OVERLAY_INDEX)
  }
  const xObjects = page.node.Resources()?.lookupMaybe(PDFName.of('XObject'), PDFDict)
  xObjects?.delete(PDFName.of(TEMPLATE_QR_XOBJECT))

  const font = await pdf.embedFont(StandardFonts.Helvetica)

  const drawCentered = (text: string, y: number, size = FONT_SIZE) => {
    const width = font.widthOfTextAtSize(text, size)
    page.drawText(text, { x: TEXT_CENTER_X - width / 2, y, size, font, color: TEXT_COLOR })
  }

  drawCentered(rfc, 575)
  drawCentered('Registro Federal de Contribuyentes', 565)

  let nameSize = FONT_SIZE
  let nameLines = wrapText(nombre, font, nameSize, NAME_MAX_WIDTH)
  while (nameLines.length > 3 && nameSize > 6) {
    nameSize -= 0.5
    nameLines = wrapText(nombre, font, nameSize, NAME_MAX_WIDTH + 20)
  }
  const lineHeight = nameLines.length > 2 ? 9 : 10
  const startY = nameLines.length > 2 ? 548 : 540
  nameLines.slice(0, 3).forEach((line, i) => drawCentered(line, startY - i * lineHeight, nameSize))

  drawCentered('Nombre, denominación o razón social', 510)
  drawCentered(`idCIF: ${idCif}`, 500)

  const qrPng = await QRCode.toBuffer(buildSatValidatorUrl(idCif, rfc), {
    type: 'png',
    errorCorrectionLevel: 'M',
    margin: 1,
    width: 600,
    color: { dark: '#000000', light: '#ffffff' },
  })
  const qrImage = await pdf.embedPng(qrPng)
  page.drawImage(qrImage, { x: QR_BOX.x, y: QR_BOX.y, width: QR_BOX.size, height: QR_BOX.size })

  pdf.setTitle(`Cédula de Identificación Fiscal ${rfc}`)
  pdf.setModificationDate(new Date())

  return pdf.save()
}
