export const SAT_VALIDATOR_BASE_URL =
  'https://siat.sat.gob.mx/app/qr/faces/pages/mobile/validadorqr.jsf?D1=10&D2=1&D3='

export function normalizeRfc(value: string) {
  return value.toUpperCase().replace(/[^A-Z0-9Ñ&]/g, '').slice(0, 13)
}

export function normalizeIdCif(value: string) {
  return value.replace(/\D/g, '').slice(0, 20)
}

export function isValidRfc(rfc: string) {
  return /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/.test(rfc)
}

export function isValidIdCif(idCif: string) {
  return /^\d{6,20}$/.test(idCif)
}

export function normalizeNombre(value: string) {
  return value
    .toUpperCase()
    .replace(/[^A-ZÁÉÍÓÚÜÑ0-9 .,&'\-]/g, '')
    .replace(/\s{2,}/g, ' ')
    .slice(0, 150)
}

export function isValidNombre(nombre: string) {
  return nombre.trim().length >= 3
}

export function buildSatValidatorUrl(idCif: string, rfc: string) {
  return `${SAT_VALIDATOR_BASE_URL}${idCif}_${rfc}`
}
