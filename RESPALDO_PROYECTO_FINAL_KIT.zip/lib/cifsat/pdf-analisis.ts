import { PDFDocument, PDFName, degrees } from 'pdf-lib'
import { extractText, getDocumentProxy } from 'unpdf'
import { buildSatValidatorUrl } from '@/lib/cifsat/sat-qr'

export type Severidad = 'ok' | 'aviso' | 'alerta'

export type Hallazgo = {
  categoria: 'visualizacion' | 'integridad'
  severidad: Severidad
  titulo: string
  detalle: string
  corregible: boolean
}

export type PaginaInfo = {
  numero: number
  ancho: number
  alto: number
  rotacion: number
  recorte: boolean
}

export type Analisis = {
  paginas: PaginaInfo[]
  hallazgos: Hallazgo[]
  productor: string
  rfc: string | null
  idCif: string | null
  urlVerificacion: string | null
  correccionSegura: boolean
  hayCorrecciones: boolean
}

const LETTER = { w: 612, h: 792 }
const TOLERANCIA = 2

const EDITORES = [
  'ilovepdf',
  'smallpdf',
  'sejda',
  'pdfescape',
  'pdf-xchange',
  'foxit',
  'nitro',
  'canva',
  'photoshop',
  'microsoft',
  'word',
  'libreoffice',
  'openoffice',
  'pdfelement',
  'wondershare',
  'acrobat pro',
  'pdffiller',
  'docfly',
  'sodapdf',
]

const SECCIONES = ['CÉDULA DE IDENTIFICACIÓN FISCAL', 'CADENA ORIGINAL', 'SELLO DIGITAL']

function contarOcurrencias(texto: string, patron: string) {
  let n = 0
  let i = texto.indexOf(patron)
  while (i !== -1) {
    n++
    i = texto.indexOf(patron, i + patron.length)
  }
  return n
}

function normaliza(t: string) {
  return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase()
}

function tieneFirmaDigital(raw: string) {
  return /\/ByteRange\s*\[/.test(raw) || /\/Type\s*\/Sig\b/.test(raw)
}

export async function analizarPdf(bytes: Uint8Array): Promise<Analisis> {
  const raw = Buffer.from(bytes).toString('latin1')
  const hallazgos: Hallazgo[] = []

  let doc: PDFDocument
  try {
    doc = await PDFDocument.load(bytes, { updateMetadata: false })
  } catch {
    throw new Error('El archivo no es un PDF válido o está dañado.')
  }
  if (doc.isEncrypted) throw new Error('El PDF está cifrado y no puede analizarse.')

  let pages: ReturnType<PDFDocument['getPages']>
  try {
    pages = doc.getPages()
  } catch {
    throw new Error(
      'La estructura interna del PDF está dañada o fue alterada. Vuelve a descargar la constancia desde el SAT.',
    )
  }

  const paginas: PaginaInfo[] = pages.map((page, idx) => {
    const media = page.getMediaBox()
    const crop = page.getCropBox()
    const rotacion = ((page.getRotation().angle % 360) + 360) % 360
    const recorte =
      Math.abs(crop.x - media.x) > TOLERANCIA ||
      Math.abs(crop.y - media.y) > TOLERANCIA ||
      Math.abs(crop.width - media.width) > TOLERANCIA ||
      Math.abs(crop.height - media.height) > TOLERANCIA
    return { numero: idx + 1, ancho: Math.round(media.width), alto: Math.round(media.height), rotacion, recorte }
  })

  for (const p of paginas) {
    if (p.rotacion !== 0) {
      hallazgos.push({
        categoria: 'visualizacion',
        severidad: 'aviso',
        titulo: `Página ${p.numero} rotada ${p.rotacion}°`,
        detalle: 'El visor la muestra girada. Se puede restablecer a 0° sin tocar el contenido.',
        corregible: true,
      })
    }
    if (p.recorte) {
      hallazgos.push({
        categoria: 'visualizacion',
        severidad: 'aviso',
        titulo: `Página ${p.numero} con área visible recortada`,
        detalle: 'El área de recorte no coincide con la página y oculta o desplaza parte del contenido. Se puede restablecer.',
        corregible: true,
      })
    }
    if (Math.abs(p.ancho - LETTER.w) > TOLERANCIA || Math.abs(p.alto - LETTER.h) > TOLERANCIA) {
      hallazgos.push({
        categoria: 'visualizacion',
        severidad: 'aviso',
        titulo: `Página ${p.numero} con tamaño ${p.ancho} × ${p.alto} pt`,
        detalle:
          'No es tamaño carta (612 × 792 pt). Reescalar implicaría modificar el contenido, por lo que se conserva tal cual. Si se ve mal, vuelve a descargarla del SAT.',
        corregible: false,
      })
    }
  }

  if (paginas.length !== 2) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'alerta',
      titulo: `El documento tiene ${paginas.length} página(s)`,
      detalle: 'La Constancia de Situación Fiscal del SAT tiene 2 páginas.',
      corregible: false,
    })
  }

  const actualizaciones = contarOcurrencias(raw, '%%EOF')
  if (actualizaciones > 1) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'alerta',
      titulo: `El archivo fue guardado ${actualizaciones} veces`,
      detalle: 'Contiene actualizaciones incrementales posteriores a su creación, lo que indica que fue modificado después de emitirse.',
      corregible: false,
    })
  }

  const productor = [doc.getProducer(), doc.getCreator()].filter(Boolean).join(' · ')
  const editor = EDITORES.find((e) => productor.toLowerCase().includes(e))
  if (editor) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'alerta',
      titulo: 'Generado o editado con un programa externo',
      detalle: `Los metadatos indican «${productor}». Las constancias del SAT no se producen con este software.`,
      corregible: false,
    })
  }

  const creado = doc.getCreationDate()
  const modificado = doc.getModificationDate()
  if (creado && modificado && modificado.getTime() - creado.getTime() > 60_000) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'alerta',
      titulo: 'Fecha de modificación posterior a la de creación',
      detalle: `Creado ${creado.toLocaleString('es-MX')}, modificado ${modificado.toLocaleString('es-MX')}.`,
      corregible: false,
    })
  }

  if (tieneFirmaDigital(raw)) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'aviso',
      titulo: 'Contiene una firma digital incrustada',
      detalle: 'Cualquier cambio al archivo invalidaría la firma, así que no se genera versión corregida.',
      corregible: false,
    })
  }

  let texto = ''
  try {
    const proxy = await getDocumentProxy(new Uint8Array(bytes))
    const { text } = await extractText(proxy, { mergePages: true })
    texto = text
  } catch {
    texto = ''
  }
  const textoN = normaliza(texto)

  if (!textoN.trim()) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'alerta',
      titulo: 'Sin texto seleccionable',
      detalle: 'El documento parece ser una imagen o escaneo. Una constancia original del SAT contiene texto digital.',
      corregible: false,
    })
  } else {
    const faltantes = SECCIONES.filter((s) => !textoN.includes(normaliza(s)))
    if (faltantes.length > 0) {
      hallazgos.push({
        categoria: 'integridad',
        severidad: 'alerta',
        titulo: 'Faltan secciones esperadas',
        detalle: `No se encontró: ${faltantes.join(', ')}.`,
        corregible: false,
      })
    }
  }

  const rfc = textoN.match(/\b([A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3})\b/)?.[1] ?? null
  const idCif = textoN.match(/IDCIF\s*:?\s*(\d{8,14})/)?.[1] ?? null
  const urlVerificacion = rfc && idCif ? buildSatValidatorUrl(idCif, rfc) : null

  if (!urlVerificacion) {
    hallazgos.push({
      categoria: 'integridad',
      severidad: 'aviso',
      titulo: 'No se pudo leer RFC e idCIF',
      detalle: 'Sin estos datos no es posible enlazar la verificación en el validador del SAT.',
      corregible: false,
    })
  }

  const hayAlertas = hallazgos.some((h) => h.severidad === 'alerta')
  const correccionSegura = !hayAlertas && !tieneFirmaDigital(raw)
  const hayCorrecciones = hallazgos.some((h) => h.corregible)

  if (hallazgos.length === 0) {
    hallazgos.push({
      categoria: 'visualizacion',
      severidad: 'ok',
      titulo: 'Sin problemas detectados',
      detalle: 'Rotación, área visible y tamaño de página son correctos.',
      corregible: false,
    })
  }

  return { paginas, hallazgos, productor, rfc, idCif, urlVerificacion, correccionSegura, hayCorrecciones }
}

/**
 * Only page-level display attributes are touched (Rotate and the page boxes).
 * Content streams, text, images, QR, seal and original string are never rewritten.
 */
export async function corregirVisualizacion(bytes: Uint8Array) {
  const doc = await PDFDocument.load(bytes, { updateMetadata: false })
  for (const page of doc.getPages()) {
    page.setRotation(degrees(0))
    const m = page.getMediaBox()
    page.setCropBox(m.x, m.y, m.width, m.height)
    for (const box of ['TrimBox', 'BleedBox', 'ArtBox']) page.node.delete(PDFName.of(box))
  }
  return doc.save({ useObjectStreams: false })
}
