import { downloadPdf as saveWithName } from '@/lib/download'

export function rfcFileName(rfc: string) {
  const clean = rfc.trim().toUpperCase().replace(/[^A-ZÑ&0-9]/g, '')
  return `CIF_${clean}.pdf`
}

export function hasNativeSaver() {
  if (typeof window === 'undefined') return false
  const bridge = (window as unknown as { TramixAndroid?: { saveDataUrl?: unknown } }).TramixAndroid
  return Boolean(bridge && typeof bridge.saveDataUrl === 'function')
}

// The TRAMIX Android app names blob: downloads after the URL's UUID, so there the bytes go to its native saver.
export async function downloadPdfFromUrl(url: string, fileName: string) {
  const res = await fetch(url)
  downloadPdf(await res.blob(), fileName)
}

// The anchor gets its name at the moment the download is created, so the file never lands with the blob's UUID.
export function downloadPdf(data: Blob | Uint8Array, fileName: string) {
  if (hasNativeSaver()) {
    saveWithName(data, fileName)
    return
  }
  const file = new File([data as BlobPart], fileName, { type: 'application/pdf' })
  const url = URL.createObjectURL(file)
  const link = document.createElement('a')
  link.href = url
  link.download = fileName
  link.rel = 'noopener'
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(url), 60_000)
}

// Hides the built-in viewer toolbar (Chrome/Edge), whose download button would save the blob under a random UUID.
export const PREVIEW_HASH = '#toolbar=0&navpanes=0'
