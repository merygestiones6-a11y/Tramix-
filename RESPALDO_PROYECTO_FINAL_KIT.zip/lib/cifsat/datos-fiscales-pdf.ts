import { readFile } from 'node:fs/promises'
import path from 'node:path'
import fontkit from '@pdf-lib/fontkit'
import { PDFDocument, rgb, type PDFFont, type PDFPage } from 'pdf-lib'
import QRCode from 'qrcode'
import type { DatosFiscales } from '@/lib/cifsat/sat-datos-fiscales'

const TEMPLATE_PATH = path.join(process.cwd(), 'assets/cifsat/templates/datos-fiscales-template.pdf')
const FONT_PATH = path.join(process.cwd(), 'assets/cifsat/fonts/Montserrat-Regular.ttf')

const VALUE_SIZE = 9
const VALUE_LINE_HEIGHT = 10.5
const VALUE_MAX_WIDTH = 132
// Template label baselines are evenly spaced (35.43pt) and share a center at x≈204.9.
// A 9.5pt drop below each label puts the block's vertical center at y≈150, the QR's center.
const LABEL_CENTER_X = 204.9
const VALUE_DROP = 9.5
const VALUE_BASELINES = {
  name: 205.82 - VALUE_DROP,
  rfc: 170.39 - VALUE_DROP,
  regimen: 134.96 - VALUE_DROP,
  cp: 99.52 - VALUE_DROP,
}
const REGIMEN_LABEL_BASELINE = 134.957
const QR = { x: 10, y: 95, size: 110 }
const SAT_MARK = { cx: 65, cy: 150, white: 17.5, dot: 6.7, offset: 7.3 }
const SAT_BLUE = rgb(0, 0.353, 0.655)

function wrap(text: string, font: PDFFont, size: number, maxWidth: number) {
  const lines: string[] = []
  let line = ''
  for (const word of text.split(/\s+/).filter(Boolean)) {
    const candidate = line ? `${line} ${word}` : word
    if (!line || font.widthOfTextAtSize(candidate, size) <= maxWidth) line = candidate
    else {
      lines.push(line)
      line = word
    }
  }
  if (line) lines.push(line)
  return lines
}

function drawValue(page: PDFPage, font: PDFFont, text: string, baseline: number, centerX: number) {
  let size = VALUE_SIZE
  let lines = wrap(text, font, size, VALUE_MAX_WIDTH)
  while ((lines.length > 2 || lines.some((l) => font.widthOfTextAtSize(l, size) > VALUE_MAX_WIDTH)) && size > 6) {
    size -= 0.5
    lines = wrap(text, font, size, VALUE_MAX_WIDTH)
  }
  lines.forEach((line, i) => {
    page.drawText(line, {
      x: centerX - font.widthOfTextAtSize(line, size) / 2,
      y: baseline - i * (VALUE_LINE_HEIGHT * (size / VALUE_SIZE)),
      size,
      font,
      color: rgb(0, 0, 0),
    })
  })
}

function drawSatMark(page: PDFPage) {
  const { cx, cy, white, dot, offset } = SAT_MARK
  page.drawCircle({ x: cx, y: cy, size: white, color: rgb(1, 1, 1) })
  for (const [dx, dy] of [[-offset, offset], [offset, -offset], [offset, offset], [-offset, -offset]]) {
    page.drawCircle({ x: cx + dx, y: cy + dy, size: dot, color: SAT_BLUE })
  }
}

export async function generateDatosFiscalesPdf(data: DatosFiscales, validationUrl: string) {
  const [templateBytes, fontBytes] = await Promise.all([readFile(TEMPLATE_PATH), readFile(FONT_PATH)])
  const template = await PDFDocument.load(templateBytes)
  const doc = await PDFDocument.create()
  doc.registerFontkit(fontkit)
  const [page] = await doc.copyPages(template, [0])
  doc.addPage(page)

  const font = await doc.embedFont(fontBytes, { subset: true })
  const centerX = LABEL_CENTER_X
  const regimenCodes = data.regimen.split('|')

  if (regimenCodes.length > 1) {
    const label = 'Regímenes fiscales:'
    page.drawRectangle({ x: 150, y: REGIMEN_LABEL_BASELINE - 2.5, width: 110, height: 9.5, color: rgb(1, 1, 1) })
    page.drawText(label, {
      x: centerX - font.widthOfTextAtSize(label, 7) / 2,
      y: REGIMEN_LABEL_BASELINE,
      size: 7,
      font,
      color: rgb(0, 0, 0),
    })
  }

  drawValue(page, font, data.name, VALUE_BASELINES.name, centerX)
  drawValue(page, font, data.rfc, VALUE_BASELINES.rfc, centerX)
  drawValue(page, font, regimenCodes.join(', '), VALUE_BASELINES.regimen, centerX)
  drawValue(page, font, data.cp, VALUE_BASELINES.cp, centerX)

  const qrPng = await QRCode.toBuffer(validationUrl, { errorCorrectionLevel: 'H', margin: 1, width: 600 })
  const qrImage = await doc.embedPng(qrPng)
  page.drawImage(qrImage, { x: QR.x, y: QR.y, width: QR.size, height: QR.size })
  drawSatMark(page)

  doc.setTitle(`Datos fiscales ${data.rfc}`)
  return doc.save()
}
