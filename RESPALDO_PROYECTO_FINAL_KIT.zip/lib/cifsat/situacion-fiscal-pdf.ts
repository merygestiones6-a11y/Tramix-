import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib'
import QRCode from 'qrcode'
import type { SatValidacion360 } from '@/lib/cifsat/sat-lookup'

const PAGE_W = 612
const PAGE_H = 792
const MARGIN = 48
const CONTENT_W = PAGE_W - MARGIN * 2
const FOOTER_H = 70

const GUINDA = rgb(0.384, 0.067, 0.196)
const DORADO = rgb(0.647, 0.498, 0.173)
const TEXT = rgb(0.13, 0.13, 0.13)
const MUTED = rgb(0.42, 0.42, 0.42)
const LINE = rgb(0.85, 0.85, 0.85)
const BAND = rgb(0.96, 0.95, 0.94)

const MESES = [
  'ENERO', 'FEBRERO', 'MARZO', 'ABRIL', 'MAYO', 'JUNIO',
  'JULIO', 'AGOSTO', 'SEPTIEMBRE', 'OCTUBRE', 'NOVIEMBRE', 'DICIEMBRE',
]

// Standard fonts only support WinAnsi; drop anything outside it so drawText never throws.
function safe(text: string) {
  return text.replace(/[^\x20-\x7E\u00A0-\u00FF]/g, '').trim()
}

function wrap(text: string, font: PDFFont, size: number, width: number) {
  const words = safe(text).split(/\s+/).filter(Boolean)
  const lines: string[] = []
  let line = ''
  for (const word of words) {
    const next = line ? `${line} ${word}` : word
    if (font.widthOfTextAtSize(next, size) <= width) line = next
    else {
      if (line) lines.push(line)
      line = word
    }
  }
  if (line) lines.push(line)
  return lines.length ? lines : ['']
}

function formatFechaHora(date: Date) {
  const parts = new Intl.DateTimeFormat('es-MX', {
    timeZone: 'America/Mexico_City',
    day: '2-digit',
    month: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(date)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? ''
  return `${get('day')} DE ${MESES[Number(get('month')) - 1]} DE ${get('year')}, ${get('hour')}:${get('minute')} H`
}

export async function generateSituacionFiscalPdf(data: SatValidacion360, validatorUrl: string, now = new Date()) {
  const pdf = await PDFDocument.create()
  pdf.setTitle(`Copia informativa de situación fiscal - ${data.rfc}`)
  pdf.setSubject('Datos consultados en el validador público del SAT')
  pdf.setProducer('SAT QR (herramienta independiente)')

  const regular = await pdf.embedFont(StandardFonts.Helvetica)
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold)
  const qrPng = await QRCode.toBuffer(validatorUrl, { errorCorrectionLevel: 'M', margin: 1, width: 360 })
  const qrImage = await pdf.embedPng(qrPng)
  const consultado = formatFechaHora(now)

  const pages: PDFPage[] = []
  let page!: PDFPage
  let y = 0

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H])
    pages.push(page)
    page.drawRectangle({ x: 0, y: PAGE_H - 8, width: PAGE_W, height: 8, color: GUINDA })
    page.drawRectangle({ x: 0, y: PAGE_H - 10, width: PAGE_W, height: 2, color: DORADO })
    y = PAGE_H - 44
  }

  const ensure = (needed: number) => {
    if (y - needed < MARGIN + FOOTER_H) newPage()
  }

  const section = (title: string) => {
    ensure(48)
    y -= 10
    page.drawRectangle({ x: MARGIN, y: y - 20, width: CONTENT_W, height: 22, color: BAND })
    page.drawRectangle({ x: MARGIN, y: y - 20, width: 3, height: 22, color: GUINDA })
    page.drawText(safe(title.toUpperCase()), { x: MARGIN + 12, y: y - 13, size: 9.5, font: bold, color: GUINDA })
    y -= 30
  }

  const LABEL_W = 170
  const row = (label: string, value: string) => {
    if (!value) return
    const lines = wrap(value, regular, 10, CONTENT_W - LABEL_W - 12)
    const h = lines.length * 13 + 8
    ensure(h)
    page.drawText(safe(label), { x: MARGIN + 12, y: y - 10, size: 8.5, font: bold, color: MUTED })
    lines.forEach((l, i) => page.drawText(l, { x: MARGIN + LABEL_W, y: y - 10 - i * 13, size: 10, font: regular, color: TEXT }))
    y -= h
    page.drawLine({ start: { x: MARGIN + 12, y: y + 3 }, end: { x: MARGIN + CONTENT_W, y: y + 3 }, thickness: 0.5, color: LINE })
  }

  newPage()

  page.drawText('COPIA INFORMATIVA DE SITUACIÓN FISCAL', { x: MARGIN, y, size: 16, font: bold, color: GUINDA })
  y -= 18
  page.drawText('Datos consultados en el validador público del SAT mediante RFC e idCIF', {
    x: MARGIN, y, size: 9.5, font: regular, color: MUTED,
  })
  y -= 22

  const qrSize = 112
  const boxTop = y
  const boxH = qrSize + 24
  page.drawRectangle({ x: MARGIN, y: boxTop - boxH, width: CONTENT_W, height: boxH, borderColor: LINE, borderWidth: 1 })
  page.drawImage(qrImage, { x: MARGIN + 12, y: boxTop - 12 - qrSize, width: qrSize, height: qrSize })

  const idX = MARGIN + 12 + qrSize + 20
  const idW = PAGE_W - MARGIN - 12 - idX
  const nameLines = wrap(data.nombre, bold, 13, idW).slice(0, 3)
  const idItems: [string, string][] = [
    ['RFC', data.rfc],
    ['idCIF', data.idCif],
    ...(data.curp ? [['CURP', data.curp] as [string, string]] : []),
  ]
  const blockH = 10 + nameLines.length * 16 + idItems.length * 15
  let iy = boxTop - boxH / 2 + blockH / 2
  page.drawText('NOMBRE, DENOMINACIÓN O RAZÓN SOCIAL', { x: idX, y: iy - 8, size: 7.5, font: bold, color: MUTED })
  iy -= 10
  for (const l of nameLines) {
    iy -= 16
    page.drawText(l, { x: idX, y: iy + 3, size: 13, font: bold, color: TEXT })
  }
  for (const [label, value] of idItems) {
    iy -= 15
    page.drawText(`${label}:`, { x: idX, y: iy, size: 9, font: bold, color: MUTED })
    page.drawText(safe(value), { x: idX + 42, y: iy, size: 10, font: regular, color: TEXT })
  }
  y = boxTop - boxH - 6

  section('Datos de identificación')
  row('RFC', data.rfc)
  row('CURP', data.curp)
  row('Nombre o razón social', data.nombre)
  row('Fecha de inicio de operaciones', data.inicioOperaciones)
  row('Situación del contribuyente', data.estatus)
  row('Fecha del último cambio de situación', data.ultimoCambio)

  const d = data.domicilio
  section('Datos de ubicación')
  row('Entidad federativa', d.entidad)
  row('Municipio o delegación', d.municipio)
  row('Colonia', d.colonia)
  row('Vialidad', d.vialidad)
  row('Número exterior', d.numeroExterior)
  row('Número interior', d.numeroInterior)
  row('Código postal', d.codigoPostal)

  if (data.regimenes.length) {
    section('Régimen fiscal')
    for (const r of data.regimenes) row(r.fechaAlta ? `Alta: ${r.fechaAlta}` : 'Régimen', r.regimen)
  }

  section('Consulta')
  row('Fecha y hora de consulta', consultado)
  row('Verificación', 'Escanee el código QR para consultar estos datos directamente en el validador del SAT.')

  pages.forEach((p, i) => {
    const fy = MARGIN + FOOTER_H - 14
    p.drawLine({ start: { x: MARGIN, y: fy }, end: { x: PAGE_W - MARGIN, y: fy }, thickness: 0.75, color: DORADO })
    const note =
      'Documento informativo elaborado por una herramienta independiente con los datos que muestra el validador público del SAT. ' +
      'No es emitido por el SAT, no contiene sello digital, cadena original ni firma, y no sustituye a la Constancia de Situación Fiscal oficial.'
    wrap(note, regular, 7.5, CONTENT_W).forEach((l, li) =>
      p.drawText(l, { x: MARGIN, y: fy - 12 - li * 10, size: 7.5, font: regular, color: MUTED }),
    )
    const pageLabel = `Página ${i + 1} de ${pages.length}`
    p.drawText(pageLabel, {
      x: PAGE_W - MARGIN - regular.widthOfTextAtSize(pageLabel, 7.5),
      y: MARGIN - 6,
      size: 7.5,
      font: regular,
      color: MUTED,
    })
    p.drawText(`RFC ${data.rfc}`, { x: MARGIN, y: MARGIN - 6, size: 7.5, font: regular, color: MUTED })
  })

  return pdf.save()
}
