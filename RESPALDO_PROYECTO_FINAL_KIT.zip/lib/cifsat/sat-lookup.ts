import https from 'node:https'
import { buildSatValidatorUrl } from '@/lib/cifsat/sat-qr'

export class SatLookupError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message)
  }
}

// siat.sat.gob.mx negotiates a legacy Diffie-Hellman key that OpenSSL 3 rejects by default.
const legacyTlsAgent = new https.Agent({
  ciphers: 'DEFAULT@SECLEVEL=0',
  minDHSize: 512,
  keepAlive: false,
})

function fetchSatHtml(url: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      {
        agent: legacyTlsAgent,
        timeout: 20000,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',
          Accept: 'text/html',
        },
      },
      (res) => {
        if (!res.statusCode || res.statusCode >= 400) {
          res.resume()
          reject(new SatLookupError('El validador del SAT no respondió correctamente.', 502))
          return
        }
        const chunks: Buffer[] = []
        res.on('data', (chunk: Buffer) => chunks.push(chunk))
        res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
        res.on('error', reject)
      },
    )
    req.on('timeout', () => req.destroy(new SatLookupError('El validador del SAT tardó demasiado en responder.', 504)))
    req.on('error', (err) =>
      reject(err instanceof SatLookupError ? err : new SatLookupError('No se pudo conectar con el validador del SAT.', 502)),
    )
  })
}

const ENTITIES: Record<string, string> = {
  amp: '&',
  lt: '<',
  gt: '>',
  quot: '"',
  apos: "'",
  nbsp: ' ',
  aacute: 'á',
  eacute: 'é',
  iacute: 'í',
  oacute: 'ó',
  uacute: 'ú',
  Aacute: 'Á',
  Eacute: 'É',
  Iacute: 'Í',
  Oacute: 'Ó',
  Uacute: 'Ú',
  ntilde: 'ñ',
  Ntilde: 'Ñ',
  uuml: 'ü',
  Uuml: 'Ü',
}

function decodeHtml(text: string) {
  return text
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([\da-f]+);/gi, (_, code) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&([a-z]+);/gi, (match, name) => ENTITIES[name] ?? match)
    .replace(/\s+/g, ' ')
    .trim()
}

function normalizeLabel(label: string) {
  return label
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/:$/, '')
    .trim()
    .toLowerCase()
}

function parseFields(html: string) {
  const fields = new Map<string, string>()
  const rowPattern =
    /<span[^>]*font-weight:\s*bold[^>]*>([^<]+)<\/span>\s*<\/td>\s*<td[^>]*>([^<]*)<\/td>/gi
  for (const [, label, value] of html.matchAll(rowPattern)) {
    const key = normalizeLabel(decodeHtml(label))
    if (!fields.has(key)) fields.set(key, decodeHtml(value))
  }
  return fields
}

function pickName(fields: Map<string, string>) {
  for (const [key, value] of fields) {
    if (value && (key.includes('razon social') || key.includes('denominacion'))) return value
  }
  const parts = [
    fields.get('nombre'),
    fields.get('apellido paterno'),
    fields.get('apellido materno'),
  ].filter(Boolean)
  return parts.join(' ')
}

export type SatRegimen = { regimen: string; fechaAlta: string }

export type SatProfile = {
  rfc: string
  idCif: string
  curp: string
  nombre: string
  inicioOperaciones: string
  estatus: string
  ultimoCambio: string
  domicilio: string
  regimenes: SatRegimen[]
}

function parseOrderedFields(html: string) {
  const rowPattern =
    /<span[^>]*font-weight:\s*bold[^>]*>([^<]+)<\/span>\s*<\/td>\s*<td[^>]*>([^<]*)<\/td>/gi
  return [...html.matchAll(rowPattern)].map(([, label, value]) => ({
    key: normalizeLabel(decodeHtml(label)),
    value: decodeHtml(value),
  }))
}

function findValue(fields: Map<string, string>, ...needles: string[]) {
  for (const [key, value] of fields) {
    if (value && needles.some((needle) => key.includes(needle))) return value
  }
  return ''
}

function buildDomicilio(fields: Map<string, string>) {
  const vialidad = [fields.get('tipo de vialidad'), fields.get('nombre de la vialidad')]
    .filter(Boolean)
    .join(' ')
  const numExt = fields.get('numero exterior')
  const numInt = fields.get('numero interior')
  const parts = [
    [vialidad, numExt && `NO. EXT. ${numExt}`, numInt && `NO. INT. ${numInt}`].filter(Boolean).join(' '),
    fields.get('colonia') && `COL. ${fields.get('colonia')}`,
    fields.get('cp') && `C.P. ${fields.get('cp')}`,
    fields.get('municipio o delegacion'),
    fields.get('entidad federativa'),
  ]
  return parts.filter(Boolean).join(', ').toUpperCase()
}

async function fetchSatRecord(idCif: string, rfc: string) {
  const html = await fetchSatHtml(buildSatValidatorUrl(idCif, rfc))
  if (!/tiene asociada la siguiente informaci/i.test(html)) {
    throw new SatLookupError(
      'El SAT no encontró información para ese RFC e idCIF. Verifica los datos.',
      404,
    )
  }
  return html
}

export async function lookupSatProfile(idCif: string, rfc: string): Promise<SatProfile> {
  return parseProfile(await fetchSatRecord(idCif, rfc), idCif, rfc)
}

function parseProfile(html: string, idCif: string, rfc: string): SatProfile {
  const fields = parseFields(html)
  const ordered = parseOrderedFields(html)

  const regimenes: SatRegimen[] = []
  for (const { key, value } of ordered) {
    if (key === 'regimen' && value) regimenes.push({ regimen: value, fechaAlta: '' })
    else if (key === 'fecha de alta' && regimenes.length && !regimenes.at(-1)!.fechaAlta) {
      regimenes.at(-1)!.fechaAlta = value
    }
  }

  const nombre = pickName(fields).toUpperCase()
  if (!nombre) {
    throw new SatLookupError('No se pudo obtener la información desde el validador del SAT.', 502)
  }

  return {
    rfc,
    idCif,
    curp: fields.get('curp') ?? '',
    nombre,
    inicioOperaciones: findValue(fields, 'inicio de operaciones', 'fecha de constitucion'),
    estatus: findValue(fields, 'situacion del contribuyente'),
    ultimoCambio: findValue(fields, 'ultimo cambio'),
    domicilio: buildDomicilio(fields),
    regimenes,
  }
}

export type SatDomicilioDetalle = {
  entidad: string
  municipio: string
  colonia: string
  vialidad: string
  numeroExterior: string
  numeroInterior: string
  codigoPostal: string
}

export type SatValidacion360 = Omit<SatProfile, 'domicilio'> & { domicilio: SatDomicilioDetalle }

export async function lookupSatValidacion360(idCif: string, rfc: string): Promise<SatValidacion360> {
  const html = await fetchSatRecord(idCif, rfc)
  const profile = parseProfile(html, idCif, rfc)
  const fields = parseFields(html)
  const upper = (value?: string) => (value ?? '').toUpperCase()

  return {
    ...profile,
    domicilio: {
      entidad: upper(fields.get('entidad federativa')),
      municipio: upper(fields.get('municipio o delegacion')),
      colonia: upper(fields.get('colonia')),
      vialidad: upper(
        [fields.get('tipo de vialidad'), fields.get('nombre de la vialidad')].filter(Boolean).join(' '),
      ),
      numeroExterior: upper(fields.get('numero exterior')),
      numeroInterior: upper(fields.get('numero interior')),
      codigoPostal: upper(fields.get('cp')),
    },
  }
}

export async function lookupSatName(idCif: string, rfc: string) {
  const html = await fetchSatHtml(buildSatValidatorUrl(idCif, rfc))

  if (!/tiene asociada la siguiente informaci/i.test(html)) {
    throw new SatLookupError(
      'El SAT no encontró información para ese RFC e idCIF. Verifica los datos.',
      404,
    )
  }

  const nombre = pickName(parseFields(html)).toUpperCase()
  if (!nombre) {
    throw new SatLookupError('No se pudo obtener el nombre desde el validador del SAT.', 502)
  }
  return nombre
}
