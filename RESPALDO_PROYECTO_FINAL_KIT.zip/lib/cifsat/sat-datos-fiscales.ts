import { SatLookupError } from '@/lib/cifsat/sat-lookup'

const DATOS_FISCALES_BASE = 'https://www.cloudb.sat.gob.mx/datos_fiscales'
const CATALOG_SOURCE = `${DATOS_FISCALES_BASE}/bundle.js`
const CATALOG_TTL_MS = 6 * 60 * 60 * 1000

export type RegimenCatalogEntry = { code: string; description: string }

let catalogCache: { entries: RegimenCatalogEntry[]; fetchedAt: number } | null = null

async function fetchWithTimeout(url: string, ms: number) {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(ms), cache: 'no-store' })
  } catch {
    throw new SatLookupError('No se pudo conectar con el servicio Datos Fiscales del SAT.', 502)
  }
}

// The official regime catalog shown at /datos_fiscales/regimen ships inside SAT's own app bundle.
export async function getRegimenCatalog(): Promise<RegimenCatalogEntry[]> {
  if (catalogCache && Date.now() - catalogCache.fetchedAt < CATALOG_TTL_MS) return catalogCache.entries

  const res = await fetchWithTimeout(CATALOG_SOURCE, 30000)
  if (!res.ok) throw new SatLookupError('El catálogo de regímenes del SAT no respondió.', 502)
  const source = await res.text()

  const entries = new Map<string, RegimenCatalogEntry>()
  for (const [, code, description] of source.matchAll(/code_number:"(\d{3})",description:"([^"]+)"/g)) {
    entries.set(code, { code, description })
  }
  if (!entries.size) throw new SatLookupError('No se pudo leer el catálogo oficial de regímenes del SAT.', 502)

  catalogCache = { entries: [...entries.values()], fetchedAt: Date.now() }
  return catalogCache.entries
}

function normalizeRegimen(value: string) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9 ]/g, ' ')
    .replace(/^\s*REGIMEN\s+(DE\s+(LAS?\s+|LOS\s+)?)?/, '')
    .replace(/\s+/g, ' ')
    .trim()
}

export type RegimenMatch = { description: string; code: string; catalogDescription: string }

export function matchRegimenes(descriptions: string[], catalog: RegimenCatalogEntry[]): RegimenMatch[] {
  return descriptions.map((description) => {
    const direct = description.trim().match(/^\d{3}$/)
    const entry = direct
      ? catalog.find((c) => c.code === direct[0])
      : catalog.find((c) => normalizeRegimen(c.description) === normalizeRegimen(description))
    if (!entry) {
      throw new SatLookupError(`El régimen "${description}" no aparece en el catálogo oficial del SAT.`, 422)
    }
    return { description, code: entry.code, catalogDescription: entry.description }
  })
}

export type DatosFiscales = { name: string; rfc: string; regimen: string; cp: string }

export function buildDatosFiscalesUrl({ name, rfc, regimen, cp }: DatosFiscales) {
  const query = [
    `name=${encodeURIComponent(name)}`,
    `rfc=${encodeURIComponent(rfc)}`,
    `regimen=${encodeURIComponent(regimen)}`,
    `cp=${encodeURIComponent(cp)}`,
  ].join('&')
  return `${DATOS_FISCALES_BASE}/validar?${query}`
}

export async function validateDatosFiscales(data: DatosFiscales): Promise<boolean> {
  const url = buildDatosFiscalesUrl(data).replace('/validar?', '/apiv1/idcard/validate?')
  const res = await fetchWithTimeout(url, 20000)
  if (!res.ok) throw new SatLookupError('El SAT no pudo validar los datos fiscales.', 502)
  const body = (await res.json().catch(() => null)) as { equal?: unknown } | null
  if (typeof body?.equal !== 'boolean') throw new SatLookupError('Respuesta inesperada del SAT al validar.', 502)
  return body.equal
}
