import { randomBytes } from 'node:crypto'
import { del, get, list, put } from '@vercel/blob'

const ROOT = 'foliador-tmp/'
const TTL_MS = 10 * 60 * 1000
export const MAX_HANDOFF_BYTES = 4 * 1024 * 1024

const TOKEN = /^[0-9a-f]{32}$/

export function isValidToken(token: string) {
  return TOKEN.test(token)
}

/** Accepts the on-screen name only when it can be used verbatim as a file name. */
export function isSafePdfName(name: string) {
  return (
    name.length > 4 &&
    name.length <= 150 &&
    name.toLowerCase().endsWith('.pdf') &&
    !/[\\/:*?"<>|\u0000-\u001f]/.test(name) &&
    name.trim() === name
  )
}

export async function storeHandoff(bytes: ArrayBuffer, name: string) {
  const token = randomBytes(16).toString('hex')
  await put(`${ROOT}${token}/${encodeURIComponent(name)}`, bytes, {
    access: 'private',
    contentType: 'application/pdf',
    addRandomSuffix: false,
  })
  return token
}

export async function openHandoff(token: string) {
  const { blobs } = await list({ prefix: `${ROOT}${token}/`, limit: 1 })
  const blob = blobs[0]
  if (!blob || Date.now() - new Date(blob.uploadedAt).getTime() > TTL_MS) return null
  const result = await get(blob.pathname, { access: 'private' })
  if (!result || result.statusCode !== 200) return null
  return {
    pathname: blob.pathname,
    name: decodeURIComponent(blob.pathname.split('/').pop() ?? ''),
    size: blob.size,
    stream: result.stream,
  }
}

export async function deleteHandoff(pathname: string) {
  await del(pathname).catch(() => {})
}

/** Hand-offs are single-use; this sweeps any that were never fetched. */
export async function sweepExpiredHandoffs() {
  const { blobs } = await list({ prefix: ROOT, limit: 200 })
  const stale = blobs.filter((b) => Date.now() - new Date(b.uploadedAt).getTime() > TTL_MS)
  if (stale.length > 0) await del(stale.map((b) => b.pathname)).catch(() => {})
}
