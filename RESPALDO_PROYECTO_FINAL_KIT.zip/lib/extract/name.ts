import { NON_NAME_PHRASES, NON_NAME_WORDS, TECHNICAL_MARKERS } from './name-exclusions'

export type NameConfidence = 'high' | 'medium' | 'low'

export interface NameDetection {
  value: string
  confidence: NameConfidence
}

interface DetectNameOptions {
  curp?: string | null
  nss?: string | null
}

const stripAccents = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')

/** Labels compared against accent-free, uppercase text. Longest first so the most specific wins. */
const NAME_LABELS = [
  'NOMBRE COMPLETO DEL ASEGURADO',
  'NOMBRE DEL DERECHOHABIENTE',
  'NOMBRE DEL BENEFICIARIO',
  'NOMBRE DEL ASEGURADO',
  'NOMBRE DEL TRABAJADOR',
  'NOMBRE DEL SOLICITANTE',
  'NOMBRE DEL PACIENTE',
  'NOMBRE DEL TITULAR',
  'DATOS DEL DERECHOHABIENTE',
  'DATOS DEL ASEGURADO',
  'DATOS DEL TRABAJADOR',
  'DATOS PERSONALES',
  'NOMBRE COMPLETO',
  'NOMBRE\\(S\\)',
  'DERECHOHABIENTE',
  'BENEFICIARIO\\(A\\)',
  'BENEFICIARIO',
  'ASEGURADO\\(A\\)',
  'ASEGURADO',
  'TRABAJADOR\\(A\\)',
  'TRABAJADOR',
  'TITULAR',
  'NOMBRE',
]

const LABEL_SOURCE = `(${NAME_LABELS.join('|')})`
/**
 * A label only counts in a "field" position: at the start of a cell or followed
 * by a colon. Prose such as "...los datos del asegurado conforme a la Ley del
 * Seguro Social" is therefore never treated as a field label.
 */
const LABEL_AT_START = new RegExp(`^${LABEL_SOURCE}\\b\\s*[:.\\-]?\\s*(.*)$`)
const LABEL_WITH_COLON = new RegExp(`(?:^|[^A-Z])${LABEL_SOURCE}\\s*:\\s*(.*)$`)

/** Name connectors allowed inside compound names ("DE LA CRUZ", "DEL RIO"). */
const CONNECTORS = new Set(['DE', 'LA', 'LAS', 'LOS', 'DEL', 'Y', 'SAN', 'SANTA', 'MC', 'VAN', 'VON', 'DA', 'DI'])

/** Tokens that end a name inside a cell ("JUAN PEREZ CURP: ...", "MARIA LOPEZ 12345"). */
const HARD_STOP = /\b(?:CURP|NSS|RFC|FECHA|SEXO|EDAD|DOMICILIO|NUM|NO\.|FOLIO|UMF|CLAVE)\b|[:|\d@#/\\_=*]/

const CURP_LIKE = /[A-Z][A-Z0-9]{3}\d{6}[A-Z0-9]{6}[A-Z0-9]{2}/g
const NSS_LIKE = /\b\d[\d\s-]{9,13}\d\b/g

const VOWEL = /[AEIOUÜ]/

function tokenize(segment: string): string[] {
  return segment
    .replace(/[^A-ZÑÜ\s'.-]/g, ' ')
    .split(/\s+/)
    .map((w) => w.replace(/^[.'-]+|[.'-]+$/g, ''))
    .filter(Boolean)
}

/**
 * Validates that a segment looks like a real person's name (given names and
 * surnames). When `allowTrailingCut` is true (text right after a label), any
 * trailing non-name words are dropped; otherwise the whole segment must be a name.
 */
export function toNameCandidate(segment: string, allowTrailingCut: boolean): string | null {
  const head = segment.split(HARD_STOP)[0] ?? ''
  const words = tokenize(head)
  if (words.length === 0) return null

  const kept: string[] = []
  for (const word of words) {
    if (NON_NAME_WORDS.has(word) && !CONNECTORS.has(word)) {
      if (kept.length === 0 || !allowTrailingCut) return null
      break
    }
    kept.push(word)
  }

  while (kept.length > 0 && CONNECTORS.has(kept[kept.length - 1])) kept.pop()
  if (kept.length === 0 || kept[0] === 'Y') return null

  const meaningful = kept.filter((w) => !CONNECTORS.has(w))
  if (meaningful.length < 2 || meaningful.length > 6 || kept.length > 9) return null
  if (meaningful.some((w) => w.length < 2 || w.length > 16 || !VOWEL.test(w))) return null
  if (meaningful.some((w) => /(.)\1\1/.test(w))) return null
  if (new Set(meaningful).size < meaningful.length - 1) return null

  const value = kept.join(' ')
  if (NON_NAME_PHRASES.some((phrase) => value === phrase || value.startsWith(`${phrase} `))) return null
  return value
}

const COMMON_FIRST_GIVEN = new Set(['MARIA', 'MA', 'JOSE', 'J'])

function firstInternalVowel(word: string): string {
  return word.slice(1).match(/[AEIOU]/)?.[0] ?? 'X'
}

function matchesCurpInitials(keys: string[], curp: string, givenFirst: boolean): boolean {
  if (keys.length < 2) return false
  const options: { paternal: string; maternal: string | null; given: string[] }[] = []
  if (givenFirst) {
    if (keys.length >= 3) options.push({ given: keys.slice(0, -2), paternal: keys[keys.length - 2], maternal: keys[keys.length - 1] })
    options.push({ given: keys.slice(0, -1), paternal: keys[keys.length - 1], maternal: null })
  } else {
    if (keys.length >= 3) options.push({ paternal: keys[0], maternal: keys[1], given: keys.slice(2) })
    options.push({ paternal: keys[0], maternal: null, given: keys.slice(1) })
  }

  return options.some(({ paternal, maternal, given }) => {
    if (given.length === 0) return false
    const givenInitials = new Set([given[0][0]])
    if (given.length > 1 && COMMON_FIRST_GIVEN.has(given[0])) givenInitials.add(given[1][0])
    return (
      curp[0] === paternal[0] &&
      (curp[1] === firstInternalVowel(paternal) || curp[1] === 'X') &&
      curp[2] === (maternal ? maternal[0] : 'X') &&
      givenInitials.has(curp[3])
    )
  })
}

/** True when the CURP's first four letters are consistent with the name in either order. */
export function nameMatchesCurp(name: string, curp: string | null | undefined): boolean {
  if (!curp || curp.length < 4) return false
  const keys = stripAccents(name.toUpperCase())
    .split(' ')
    .filter((w) => w && !CONNECTORS.has(w))
    .map((w) => w.replace(/Ñ/g, 'X'))
  return matchesCurpInitials(keys, curp, true) || matchesCurpInitials(keys, curp, false)
}

interface Line {
  cells: string[]
  text: string
  /** Part of a digital seal / original string / QR block: never a source of names. */
  technical: boolean
  /** The CURP or NSS appears in this line. */
  anchor: boolean
}

/** Encoded data (base64, hashes, "||1.0|...|" strings) as found in seals and original strings. */
function looksEncoded(raw: string): boolean {
  return /\|\|/.test(raw) || (raw.match(/\|/g)?.length ?? 0) >= 4 || /[A-Z0-9+/=]{28,}/.test(raw.replace(/\s/g, ''))
}

function buildLines(texts: string[], curp?: string | null, nss?: string | null): Line[] {
  const rawLines = stripAccents(texts.join('\n').toUpperCase())
    .split(/\r?\n/)
    .map((l) => l.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)

  let technicalTail = 0
  return rawLines.map((raw) => {
    const marker = TECHNICAL_MARKERS.test(raw)
    const encoded = looksEncoded(raw)
    if (marker) technicalTail = 4
    const technical = marker || encoded || (technicalTail > 0 && !labelInLine(raw))
    if (!marker && technicalTail > 0) technicalTail--

    const compact = raw.replace(/[\s-]/g, '')
    const anchor =
      !technical && Boolean((curp && compact.includes(curp)) || (nss && raw.replace(/\D/g, '').includes(nss)))

    // CURP/NSS values are field boundaries: "BENITO ROJO GUAL011010..." → two cells.
    const separated = raw.replace(CURP_LIKE, ' | ').replace(NSS_LIKE, ' | ')
    const cells = separated
      .split(/\s*\|\s*/)
      .map((c) => c.trim())
      .filter(Boolean)
    return { cells, text: cells.join(' | '), technical, anchor }
  })
}

function labelInCell(cell: string): { rest: string } | null {
  const match = cell.match(LABEL_AT_START) ?? cell.match(LABEL_WITH_COLON)
  return match ? { rest: match[2] ?? '' } : null
}

function labelInLine(raw: string): boolean {
  return raw.split(/\s*\|\s*/).some((cell) => labelInCell(cell) !== null)
}

const onlyHeaderWords = (segment: string) =>
  tokenize(segment.split(HARD_STOP)[0] ?? '').every((w) => NON_NAME_WORDS.has(w) || CONNECTORS.has(w))

type Source = 'label' | 'proximity' | 'loose'

interface Candidate {
  value: string
  source: Source
  score: number
}

function collectCandidates(lines: Line[]): Candidate[] {
  const found: Candidate[] = []
  const anchors = lines.flatMap((line, i) => (line.anchor ? [i] : []))
  const push = (value: string | null, source: Source, base: number, lineIndex: number) => {
    if (!value) return
    const nearest = anchors.length ? Math.min(...anchors.map((a) => Math.abs(a - lineIndex))) : Infinity
    const proximityBonus = nearest <= 4 ? 12 - nearest * 2 : 0
    found.push({ value, source, score: base + proximityBonus })
  }

  // 1. Field labels: value in the same cell, the next cell, or the row(s) below.
  lines.forEach((line, i) => {
    if (line.technical) return
    line.cells.forEach((cell, column) => {
      const label = labelInCell(cell)
      if (!label) return

      const sameCell = toNameCandidate(label.rest, true)
      if (sameCell) return push(sameCell, 'label', 60, i)
      if (!onlyHeaderWords(label.rest)) return

      const nextCell = line.cells[column + 1]
      if (nextCell && !labelInCell(nextCell)) {
        const value = toNameCandidate(nextCell, true)
        if (value) return push(value, 'label', 58, i)
      }

      let offset = 0
      for (let j = i + 1; j < lines.length && offset < 3; j++) {
        const below = lines[j]
        if (below.technical) continue
        offset++
        // Table layout: header row "NOMBRE | CURP | NSS" with values in the same column below.
        const sameColumn = below.cells.length === line.cells.length ? below.cells[column] : undefined
        const ordered = sameColumn ? [sameColumn] : below.cells
        const hit = ordered
          .filter((c) => !labelInCell(c))
          .map((c) => toNameCandidate(c, true))
          .find(Boolean)
        if (hit) {
          push(hit, 'label', 54 - offset * 4, j)
          return
        }
        if (below.cells.some((c) => labelInCell(c))) return
      }
    })
  })

  // 2. Personal-data block around the CURP/NSS (excluding seals and original strings).
  for (const anchor of anchors) {
    for (let i = Math.max(0, anchor - 4); i <= Math.min(lines.length - 1, anchor + 4); i++) {
      if (lines[i].technical) continue
      for (const cell of lines[i].cells) {
        if (labelInCell(cell)) continue
        push(toNameCandidate(cell, false), 'proximity', 30, i)
      }
    }
  }

  // 3. Anywhere else in the document: only accepted later if the CURP confirms it.
  lines.forEach((line, i) => {
    if (line.technical) return
    for (const cell of line.cells) push(toNameCandidate(cell, false), 'loose', 8, i)
  })

  const split = findSplitName(lines)
  if (split) found.push({ value: split, source: 'label', score: 58 })

  return found
}

function confidenceFor(source: Source, curpMatch: boolean, hasCurp: boolean): NameConfidence {
  if (curpMatch) return source === 'loose' ? 'medium' : 'high'
  if (source === 'label') return hasCurp ? 'medium' : 'high'
  return 'low'
}

/**
 * Finds the person's full name across every page using, in order: field labels
 * (same cell, next cell, table column, line below), the personal-data block
 * around the CURP/NSS, and a document-wide scan confirmed by the CURP initials.
 * Seals, original strings, titles and institutions are excluded. The CURP only
 * validates names that appear in the document; it never constructs one.
 */
export function detectName(texts: string[], { curp, nss }: DetectNameOptions = {}): NameDetection | null {
  const lines = buildLines(texts, curp, nss)
  const hasCurp = Boolean(curp && curp.length >= 4)

  const ranked = collectCandidates(lines)
    .map((candidate) => {
      const curpMatch = nameMatchesCurp(candidate.value, curp)
      const wordCount = candidate.value.split(' ').filter((w) => !CONNECTORS.has(w)).length
      let score = candidate.score
      if (curpMatch) score += 45
      else if (hasCurp) score -= 15
      if (wordCount >= 3 && wordCount <= 5) score += 8
      return { ...candidate, score, curpMatch }
    })
    // A name found only by scanning the page needs the CURP's confirmation.
    .filter((c) => c.source !== 'loose' || c.curpMatch)
    .sort((a, b) => b.score - a.score)

  const best = ranked[0]
  if (!best) return null
  return { value: best.value, confidence: confidenceFor(best.source, best.curpMatch, hasCurp) }
}

/** Handles forms that split the name into "Nombre(s) / Primer apellido / Segundo apellido". */
function findSplitName(lines: Line[]): string | null {
  const texts = lines.filter((l) => !l.technical).map((l) => l.text)
  const grab = (label: RegExp) => {
    for (let i = 0; i < texts.length; i++) {
      const m = texts[i].match(label)
      if (!m) continue
      const rest = texts[i].slice((m.index ?? 0) + m[0].length).replace(/^[\s:.\-|]+/, '')
      const value = (rest || texts[i + 1] || '').split(HARD_STOP)[0] ?? ''
      const words = tokenize(value)
      if (words.length === 0 || words.length > 3) continue
      if (words.some((w) => NON_NAME_WORDS.has(w) && !CONNECTORS.has(w))) continue
      if (words.some((w) => !CONNECTORS.has(w) && !VOWEL.test(w))) continue
      return words.join(' ')
    }
    return null
  }

  const paternal = grab(/(?:PRIMER\s+APELLIDO|APELLIDO\s+PATERNO)/)
  const maternal = grab(/(?:SEGUNDO\s+APELLIDO|APELLIDO\s+MATERNO)/)
  const given = grab(/^NOMBRE\(S\)|^NOMBRES?(?=\s*[:]|$)/)
  if (given && paternal) return [given, paternal, maternal].filter(Boolean).join(' ')
  return null
}

export function normalizeName(value: string): string {
  return value.toUpperCase().replace(/\s+/g, ' ').trimStart()
}
