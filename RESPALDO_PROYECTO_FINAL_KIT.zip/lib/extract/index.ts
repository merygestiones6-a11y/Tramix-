import { findCurp } from './curp'
import { extractDocumentFacts, type DocumentFacts } from './demographics'
import { detectName, nameMatchesCurp, type NameConfidence } from './name'
import { findNss } from './nss'
import { detectNameUniversal, pickPrimaryCurp } from './universal'

interface IdentityData {
  name: string | null
  nameConfidence: NameConfidence | null
  curp: string | null
  nss: string | null
  /** Which layer produced the final name/CURP. */
  source: 'imss' | 'universal' | 'mixed' | null
}

export interface DetectedData extends IdentityData {
  /** Birth date, sex and state as written in the document; cross-checked against the CURP in the UI. */
  documentFacts?: DocumentFacts
}

export function detectPersonalData(texts: string[]): DetectedData {
  return { ...detectIdentity(texts), documentFacts: extractDocumentFacts(texts) }
}

const RANK: Record<NameConfidence, number> = { high: 3, medium: 2, low: 1 }

function rankName(confidence: NameConfidence | null, name: string | null): number {
  return name && confidence ? RANK[confidence] : 0
}

/**
 * 1. IMSS extractor (unchanged). If it confirms name + CURP, its result is kept as-is.
 * 2. Otherwise the universal analyzer fills whatever is missing or improves a weak name.
 */
function detectIdentity(texts: string[]): IdentityData {
  const joined = texts.join('\n')
  const curp = findCurp(joined)
  const nss = findNss(joined)
  const name = detectName(texts, { curp, nss })
  const imss: IdentityData = {
    name: name?.value ?? null,
    nameConfidence: name?.confidence ?? null,
    curp,
    nss,
    source: name || curp ? 'imss' : null,
  }

  const confirmed = imss.name && imss.nameConfidence !== 'low' && imss.curp
  if (confirmed) {
    if (nameMatchesCurp(imss.name!, imss.curp)) return imss
    // The name is solid but the first CURP is someone else's: look for the one that belongs to this person.
    const alternative = pickPrimaryCurp(texts, imss.name)
    if (alternative && alternative !== imss.curp && nameMatchesCurp(imss.name!, alternative)) {
      return { ...imss, curp: alternative, nameConfidence: 'high', source: 'mixed' }
    }
    return imss
  }

  const universalCurp = pickPrimaryCurp(texts, imss.name) ?? imss.curp
  const universalName = detectNameUniversal(texts, universalCurp)

  let finalCurp = imss.curp ?? universalCurp
  let finalName = imss.name
  let finalConfidence = imss.nameConfidence
  let usedUniversal = !imss.curp && Boolean(universalCurp)

  if (universalName && rankName(universalName.confidence, universalName.value) > rankName(imss.nameConfidence, imss.name)) {
    finalName = universalName.value
    finalConfidence = universalName.confidence
    usedUniversal = true
  }

  // With several CURPs, prefer the one that agrees with the chosen name.
  if (finalName && universalCurp && universalCurp !== finalCurp && nameMatchesCurp(finalName, universalCurp)) {
    finalCurp = universalCurp
    usedUniversal = true
  }

  return {
    name: finalName,
    nameConfidence: finalConfidence,
    curp: finalCurp,
    nss,
    source: usedUniversal ? (imss.source ? 'mixed' : 'universal') : imss.source,
  }
}

export * from './curp'
export * from './demographics'
export * from './name'
export * from './nss'
export * from './universal'
