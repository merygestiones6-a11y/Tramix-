import { STATE_NAMES, validateCurp } from '@/lib/curp-validator'

/** Values read directly from the document's labelled fields (never from the CURP). */
export interface DocumentFacts {
  /** DD/MM/AAAA */
  birthDates: string[]
  /** HOMBRE | MUJER */
  sexes: string[]
  /** CURP state codes (DF, JC, NE…) */
  states: string[]
}

export const EMPTY_FACTS: DocumentFacts = { birthDates: [], sexes: [], states: [] }

export type CrossSource = 'both' | 'curp' | 'document' | 'conflict' | 'none'

export interface CrossField {
  /** Agreed value, or null when missing or in conflict. */
  value: string | null
  source: CrossSource
  /** Distinct candidate values; more than one only when in conflict. */
  options: string[]
}

export interface Demographics {
  birthDate: CrossField
  sex: CrossField
  state: CrossField
}

const stripAccents = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')

const MONTHS: Record<string, number> = {
  ENERO: 1, ENE: 1,
  FEBRERO: 2, FEB: 2,
  MARZO: 3, MAR: 3,
  ABRIL: 4, ABR: 4,
  MAYO: 5, MAY: 5,
  JUNIO: 6, JUN: 6,
  JULIO: 7, JUL: 7,
  AGOSTO: 8, AGO: 8,
  SEPTIEMBRE: 9, SETIEMBRE: 9, SEPT: 9, SEP: 9, SET: 9,
  OCTUBRE: 10, OCT: 10,
  NOVIEMBRE: 11, NOV: 11,
  DICIEMBRE: 12, DIC: 12,
}
const MONTH_PATTERN = Object.keys(MONTHS).sort((a, b) => b.length - a.length).join('|')

const DATE_DMY = /\b(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{4})\b/
const DATE_YMD = /\b(\d{4})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})\b/
const DATE_TEXT = new RegExp(
  `\\b(\\d{1,2})\\s*(?:[/\\-.]|\\s)\\s*(?:DE\\s+)?(${MONTH_PATTERN})\\.?\\s*(?:[/\\-.]|\\s)\\s*(?:DEL?\\s+)?(\\d{4})\\b`,
)

const DATE_LABEL = /\bF(?:ECHA)?\.?\s*(?:DE\s+)?NAC(?:IMIENTO)?\b\.?|\bNACIO\s+EL\b/
const SEX_LABEL = /\b(?:SEXO|GENERO)\b/
const STATE_LABEL = /\b(?:ENTIDAD|ESTADO|LUGAR)(?:\s+FEDERATIVA)?\s+DE\s+NAC(?:IMIENTO)?\b\.?/

/** Accent-free aliases → CURP state code. Matched longest first so the most specific wins. */
const STATE_ALIASES: [string, string][] = (
  [
    ['NACIDO EN EL EXTRANJERO', 'NE'],
    ['EXTRANJERO', 'NE'],
    ['BAJA CALIFORNIA SUR', 'BS'],
    ['BAJA CALIFORNIA', 'BC'],
    ['CIUDAD DE MEXICO', 'DF'],
    ['DISTRITO FEDERAL', 'DF'],
    ['CDMX', 'DF'],
    ['D.F.', 'DF'],
    ['ESTADO DE MEXICO', 'MC'],
    ['EDO. DE MEXICO', 'MC'],
    ['EDO DE MEXICO', 'MC'],
    ['EDO. MEX', 'MC'],
    ['MEXICO', 'MC'],
    ['AGUASCALIENTES', 'AS'],
    ['CAMPECHE', 'CC'],
    ['COAHUILA', 'CL'],
    ['COLIMA', 'CM'],
    ['CHIAPAS', 'CS'],
    ['CHIHUAHUA', 'CH'],
    ['DURANGO', 'DG'],
    ['GUANAJUATO', 'GT'],
    ['GUERRERO', 'GR'],
    ['HIDALGO', 'HG'],
    ['JALISCO', 'JC'],
    ['MICHOACAN', 'MN'],
    ['MORELOS', 'MS'],
    ['NAYARIT', 'NT'],
    ['NUEVO LEON', 'NL'],
    ['OAXACA', 'OC'],
    ['PUEBLA', 'PL'],
    ['QUERETARO', 'QT'],
    ['QUINTANA ROO', 'QR'],
    ['SAN LUIS POTOSI', 'SP'],
    ['SINALOA', 'SL'],
    ['SONORA', 'SR'],
    ['TABASCO', 'TC'],
    ['TAMAULIPAS', 'TS'],
    ['TLAXCALA', 'TL'],
    ['VERACRUZ', 'VZ'],
    ['YUCATAN', 'YN'],
    ['ZACATECAS', 'ZS'],
  ] as [string, string][]
).sort((a, b) => b[0].length - a[0].length)

const escapeRegex = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const STATE_MATCHERS = STATE_ALIASES.map(
  ([alias, code]) => [new RegExp(`(?<![A-Z])${escapeRegex(alias)}(?![A-Z])`, 'g'), code] as const,
)

function isRealPastDate(year: number, month: number, day: number): boolean {
  if (year < 1900) return false
  const date = new Date(Date.UTC(year, month - 1, day))
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day &&
    date.getTime() <= Date.now()
  )
}

function formatDate(day: number, month: number, year: number): string | null {
  if (!isRealPastDate(year, month, day)) return null
  return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`
}

export function parseDate(fragment: string): string | null {
  const text = stripAccents(fragment.toUpperCase())
  const dmy = text.match(DATE_DMY)
  if (dmy) return formatDate(Number(dmy[1]), Number(dmy[2]), Number(dmy[3]))
  const ymd = text.match(DATE_YMD)
  if (ymd) return formatDate(Number(ymd[3]), Number(ymd[2]), Number(ymd[1]))
  const written = text.match(DATE_TEXT)
  if (written) return formatDate(Number(written[1]), MONTHS[written[2]], Number(written[3]))
  return null
}

function parseSex(fragment: string, allowLetter: boolean): string | null {
  const text = fragment.trim()
  if (/\b(?:MUJER|FEMENINO)\b/.test(text)) return 'MUJER'
  if (/\b(?:HOMBRE|MASCULINO)\b/.test(text)) return 'HOMBRE'
  if (allowLetter) {
    const letter = text.match(/^[:.\-\s]*([HMF])\b/)
    if (letter) return letter[1] === 'H' ? 'HOMBRE' : 'MUJER'
  }
  return null
}

export function parseState(fragment: string): string | null {
  let text = stripAccents(fragment.toUpperCase())
  const found: { code: string; index: number }[] = []
  for (const [pattern, code] of STATE_MATCHERS) {
    text = text.replace(pattern, (match, index: number) => {
      found.push({ code, index })
      return ' '.repeat(match.length)
    })
  }
  if (found.length === 0) return null
  // "TOLUCA, ESTADO DE MÉXICO": the state is usually written after the municipality.
  return found.sort((a, b) => a.index - b.index)[found.length - 1].code
}

/** Text after the label on the same line, or the next line when the label stands alone (table headers). */
function valuesAfterLabel(lines: string[], label: RegExp): { sameLine: string; nextLine: string }[] {
  const hits: { sameLine: string; nextLine: string }[] = []
  lines.forEach((line, index) => {
    const match = line.match(label)
    if (!match || match.index === undefined) return
    hits.push({
      sameLine: line.slice(match.index + match[0].length),
      nextLine: lines[index + 1] ?? '',
    })
  })
  return hits
}

const unique = (values: (string | null)[]) => [...new Set(values.filter((value): value is string => Boolean(value)))]

/** Reads birth date, sex and birth state from labelled fields in the document text. */
export function extractDocumentFacts(texts: string[]): DocumentFacts {
  const lines = stripAccents(texts.join('\n').toUpperCase())
    .split(/\r?\n/)
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean)

  const birthDates = valuesAfterLabel(lines, DATE_LABEL).map(
    ({ sameLine, nextLine }) => parseDate(sameLine) ?? parseDate(nextLine),
  )
  const sexes = valuesAfterLabel(lines, SEX_LABEL).map(
    ({ sameLine, nextLine }) => parseSex(sameLine, true) ?? parseSex(nextLine, /^[HMF]$/.test(nextLine.trim())),
  )
  const states = valuesAfterLabel(lines, STATE_LABEL).map(({ sameLine, nextLine }) => {
    const rest = sameLine.replace(/^[\s:.\-]+/, '')
    // Stop at the next label in the same line ("ENTIDAD DE NACIMIENTO: JALISCO SEXO: H").
    const own = rest.split(/\b(?:SEXO|GENERO|FECHA|CURP|NSS|NOMBRE)\b/)[0]
    return parseState(own) ?? parseState(nextLine)
  })

  return { birthDates: unique(birthDates), sexes: unique(sexes), states: unique(states) }
}

export interface CurpFacts {
  birthDate: string
  sex: string
  /** CURP state code */
  state: string
}

/** Structural data encoded in a fully valid CURP (date, sex, state). Never a name. */
export function factsFromCurp(curp: string): CurpFacts | null {
  const validation = validateCurp(curp)
  if (!validation.valid) return null
  return {
    birthDate: validation.details.birthDate,
    sex: validation.details.sex.toUpperCase(),
    state: validation.details.curp.slice(11, 13),
  }
}

function cross(curpValue: string | null, documentValues: string[]): CrossField {
  const options = unique([curpValue, ...documentValues])
  if (options.length === 0) return { value: null, source: 'none', options }
  if (options.length > 1) return { value: null, source: 'conflict', options }
  if (curpValue && documentValues.length > 0) return { value: curpValue, source: 'both', options }
  return { value: options[0], source: curpValue ? 'curp' : 'document', options }
}

/**
 * Cross-checks the CURP-derived values with the ones written in the document.
 * Same value → high confidence; one source → use it; disagreement → no guess.
 * The state is returned as a CURP code.
 */
export function crossCheckDemographics(curp: string, facts: DocumentFacts | null | undefined): Demographics {
  const fromCurp = factsFromCurp(curp)
  const doc = facts ?? EMPTY_FACTS
  return {
    birthDate: cross(fromCurp?.birthDate ?? null, doc.birthDates),
    sex: cross(fromCurp?.sex ?? null, doc.sexes),
    state: cross(fromCurp?.state ?? null, doc.states),
  }
}

export function stateLabel(code: string): string {
  return STATE_NAMES[code]?.toUpperCase() ?? code
}

export const STATE_OPTIONS = Object.keys(STATE_NAMES).map((code) => ({ code, label: stateLabel(code) }))

export function isBirthDateFormatValid(value: string): boolean {
  const match = value.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  return Boolean(match && isRealPastDate(Number(match[3]), Number(match[2]), Number(match[1])))
}
