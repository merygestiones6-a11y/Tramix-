export const NSS_LENGTH = 11

export function normalizeNss(value: string): string {
  return value.replace(/\D/g, '').slice(0, NSS_LENGTH)
}

export function isNssFormatValid(value: string): boolean {
  return /^\d{11}$/.test(value)
}

/** NSS uses a Luhn check digit on its first 10 digits. */
export function hasValidNssCheckDigit(nss: string): boolean {
  if (!isNssFormatValid(nss)) return false
  let total = 0
  for (let i = 0; i < 10; i++) {
    const doubled = Number(nss[i]) * (i % 2 === 1 ? 2 : 1)
    total += Math.floor(doubled / 10) + (doubled % 10)
  }
  return String((10 - (total % 10)) % 10) === nss[10]
}

const NSS_LABEL =
  /(?:\bN\.?\s?S\.?\s?S\.?\b|N[UÚ]MERO\s+DE\s+SEGURIDAD\s+SOCIAL|SEGURIDAD\s+SOCIAL|\bNO\.?\s+DE\s+AFILIACI[OÓ]N|\bAFILIACI[OÓ]N)/g

// 11 digits that may be grouped with spaces or hyphens (e.g. "9288-70-8511-3").
const GROUPED_DIGITS = /(?<![\d])(\d[\d\s\-]{9,18}\d)(?![\d])/g

function digitRuns(text: string): string[] {
  const results: string[] = []
  for (const match of text.matchAll(GROUPED_DIGITS)) {
    const digits = match[1].replace(/\D/g, '')
    if (digits.length === NSS_LENGTH) results.push(digits)
  }
  for (const match of text.matchAll(/(?<!\d)\d{11}(?!\d)/g)) {
    results.push(match[0])
  }
  return results
}

export function findNss(rawText: string): string | null {
  const text = rawText.toUpperCase()

  const labelled: string[] = []
  for (const match of text.matchAll(NSS_LABEL)) {
    const start = (match.index ?? 0) + match[0].length
    labelled.push(...digitRuns(text.slice(start, start + 80)))
  }

  const pick = (list: string[]) => list.find(hasValidNssCheckDigit) ?? list[0] ?? null

  if (labelled.length > 0) return pick(labelled)

  // Without a label, only trust standalone numbers that pass the check digit.
  const loose = Array.from(text.matchAll(/(?<![\d\-])\d{11}(?![\d\-])/g), (m) => m[0])
  return loose.find(hasValidNssCheckDigit) ?? null
}
