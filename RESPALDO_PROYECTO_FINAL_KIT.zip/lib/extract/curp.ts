const STATE_CODES =
  'AS|BC|BS|CC|CL|CM|CS|CH|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE'

const CURP_PATTERN = new RegExp(
  `[A-Z][AEIOUX][A-Z]{2}\\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\\d|3[01])[HMX](?:${STATE_CODES})[B-DF-HJ-NP-TV-Z]{3}[A-Z\\d]\\d`,
)
const CURP_STRICT = new RegExp(`^${CURP_PATTERN.source}$`)
const CURP_GLOBAL = new RegExp(`(?<![A-Z0-9])${CURP_PATTERN.source}(?![A-Z0-9])`, 'g')

const CHECK_DICTIONARY = '0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ'

export const CURP_LENGTH = 18

export function normalizeCurp(value: string): string {
  return value.toUpperCase().replace(/[^A-Z0-9Ñ]/g, '').slice(0, CURP_LENGTH)
}

export function isCurpFormatValid(value: string): boolean {
  return value.length === CURP_LENGTH && CURP_STRICT.test(value)
}

export function hasValidCurpCheckDigit(curp: string): boolean {
  if (curp.length !== CURP_LENGTH) return false
  let sum = 0
  for (let i = 0; i < 17; i++) {
    const value = CHECK_DICTIONARY.indexOf(curp[i])
    if (value < 0) return false
    sum += value * (18 - i)
  }
  const expected = (10 - (sum % 10)) % 10
  return String(expected) === curp[17]
}

const LETTER_FIXES: Record<string, string> = { '0': 'O', '1': 'I', '5': 'S', '8': 'B', '2': 'Z', '6': 'G' }
const DIGIT_FIXES: Record<string, string> = { O: '0', Q: '0', D: '0', I: '1', L: '1', Z: '2', S: '5', B: '8', G: '6' }

// Each position of a CURP is either a letter (L), a digit (D) or either (X).
const CURP_SHAPE = 'LLLLDDDDDDLLLLLLXD'

function repairOcrCandidate(candidate: string): string {
  return candidate
    .split('')
    .map((char, index) => {
      const kind = CURP_SHAPE[index]
      if (kind === 'L') return LETTER_FIXES[char] ?? char
      if (kind === 'D') return DIGIT_FIXES[char] ?? char
      return char
    })
    .join('')
}

function collectStrict(text: string): string[] {
  return Array.from(text.matchAll(CURP_GLOBAL), (m) => m[0])
}

/**
 * Finds the most likely CURP in a block of text. Candidates with a valid
 * check digit are preferred; OCR noise (spaces, 0/O swaps) is repaired as a
 * fallback, never inventing characters that are not in the source.
 */
export function findCurp(rawText: string): string | null {
  const text = rawText.toUpperCase()
  const candidates: string[] = [...collectStrict(text)]

  if (candidates.length === 0) {
    const compact = text.replace(/[\s\-.]/g, '')
    candidates.push(...collectStrict(compact))
  }

  if (candidates.length === 0) {
    const tokens = text.replace(/[\s\-.]/g, '').match(/[A-Z0-9]{18,}/g) ?? []
    for (const token of tokens) {
      for (let i = 0; i + CURP_LENGTH <= token.length; i++) {
        const repaired = repairOcrCandidate(token.slice(i, i + CURP_LENGTH))
        if (isCurpFormatValid(repaired) && hasValidCurpCheckDigit(repaired)) {
          candidates.push(repaired)
        }
      }
    }
  }

  if (candidates.length === 0) return null
  return candidates.find(hasValidCurpCheckDigit) ?? candidates[0]
}

/** Every CURP-shaped string in the text, in reading order (duplicates kept so repetition can be scored). */
export function findCurpCandidates(rawText: string): string[] {
  const text = rawText.toUpperCase()
  const strict = collectStrict(text)
  if (strict.length > 0) return strict
  const compact = collectStrict(text.replace(/[\s\-.]/g, ''))
  if (compact.length > 0) return compact
  const single = findCurp(rawText)
  return single ? [single] : []
}
