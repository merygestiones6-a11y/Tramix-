import { findCurpCandidates, hasValidCurpCheckDigit } from './curp'
import { nameMatchesCurp, toNameCandidate, type NameDetection } from './name'
import { NON_NAME_WORDS } from './name-exclusions'

/**
 * Format-agnostic layer. It does not know any document type: it reads every
 * line and table cell, pairs labels with their values, and cross-checks the
 * name against the CURP. Runs after the IMSS extractor when that one could
 * not confirm a name or a CURP.
 */

const stripAccents = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')

const PERSON_LABELS = [
  'NOMBRE COMPLETO DEL ASEGURADO',
  'NOMBRE DEL DERECHOHABIENTE',
  'NOMBRE DEL BENEFICIARIO',
  'NOMBRE DEL SOLICITANTE',
  'NOMBRE DEL INTERESADO',
  'NOMBRE DEL ASEGURADO',
  'NOMBRE DEL TRABAJADOR',
  'NOMBRE DEL PACIENTE',
  'NOMBRE DEL TITULAR',
  'NOMBRE DE LA PERSONA',
  'PERSONA REGISTRADA',
  'NOMBRE COMPLETO',
  'DERECHOHABIENTE',
  'BENEFICIARIO\\(A\\)',
  'BENEFICIARIO',
  'SOLICITANTE',
  'INTERESADO\\(A\\)',
  'INTERESADO',
  'ASEGURADO\\(A\\)',
  'ASEGURADO',
  'TRABAJADOR\\(A\\)',
  'TRABAJADOR',
  'REGISTRADO\\(A\\)',
  'TITULAR',
  'NOMBRE',
]

const GIVEN_LABEL = 'NOMBRE\\s?\\(S\\)|NOMBRES|NOMBRE\\(S\\) DEL? [A-Z]+'
const PATERNAL_LABEL = 'PRIMER APELLIDO|APELLIDO PATERNO|1ER\\.? APELLIDO|PATERNO'
const MATERNAL_LABEL = 'SEGUNDO APELLIDO|APELLIDO MATERNO|2DO\\.? APELLIDO|MATERNO'

const anchored = (source: string) => new RegExp(`^(?:${source})(?![A-ZÑ])\\s*[:.\\-]?\\s*(.*)$`)
const PERSON_RE = anchored(PERSON_LABELS.join('|'))
const GIVEN_RE = anchored(GIVEN_LABEL)
const PATERNAL_RE = anchored(PATERNAL_LABEL)
const MATERNAL_RE = anchored(MATERNAL_LABEL)
const CURP_LABEL_RE = /CURP|CLAVE UNICA(?: DE REGISTRO DE POBLACION)?/

type Grid = string[][]

function toGrid(texts: string[]): Grid {
  return texts
    .flatMap((page) => page.split('\n'))
    .map((line) =>
      stripAccents(line)
        .toUpperCase()
        .split(/\s\|\s|\t|\s{3,}/)
        .map((cell) => cell.replace(/\s+/g, ' ').trim())
        .filter(Boolean),
    )
    .filter((row) => row.length > 0)
}

function isAnyLabel(cell: string): boolean {
  return [PERSON_RE, GIVEN_RE, PATERNAL_RE, MATERNAL_RE].some((re) => {
    const match = cell.match(re)
    return Boolean(match) && !match![1]
  })
}

/** Value for the label at grid[r][c]: same cell, next cell, or the cell below. */
function valueFor(grid: Grid, r: number, c: number, inline: string, columnar: boolean): string {
  if (inline) return inline
  const next = grid[r][c + 1]
  if (next && !isAnyLabel(next)) return next
  const below = grid[r + 1]
  if (!below) return ''
  const cell = columnar && below.length === grid[r].length ? below[c] : below[0]
  return cell && !isAnyLabel(cell) ? cell : ''
}

function cleanPart(value: string): string | null {
  const words = value
    .replace(/[^A-ZÑÜ\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
  if (words.length === 0 || words.length > 4) return null
  if (words.some((w) => NON_NAME_WORDS.has(w) && !['DE', 'LA', 'DEL', 'LOS', 'LAS', 'Y'].includes(w))) return null
  if (words.every((w) => w.length < 2)) return null
  return words.join(' ')
}

/** "NOMBRE(S): SURIANI / PRIMER APELLIDO: MARQUEZ / SEGUNDO APELLIDO: LOZADA" → "SURIANI MARQUEZ LOZADA". */
function findSplitFields(grid: Grid): string[] {
  const results: string[] = []
  const parts: { given?: string; paternal?: string; maternal?: string } = {}
  const flush = () => {
    if (parts.given && parts.paternal) {
      const full = toNameCandidate([parts.given, parts.paternal, parts.maternal].filter(Boolean).join(' '), false)
      if (full) results.push(full)
    }
    delete parts.given
    delete parts.paternal
    delete parts.maternal
  }

  grid.forEach((row, r) => {
    const labelCells = row.filter(isAnyLabel).length
    const columnar = labelCells >= 2
    row.forEach((cell, c) => {
      for (const [key, re] of [
        ['given', GIVEN_RE],
        ['paternal', PATERNAL_RE],
        ['maternal', MATERNAL_RE],
      ] as const) {
        const match = cell.match(re)
        if (!match) continue
        const value = cleanPart(valueFor(grid, r, c, match[1] ?? '', columnar))
        if (!value) continue
        if (parts[key]) flush()
        parts[key] = value
        break
      }
    })
    if (parts.given && parts.paternal && parts.maternal) flush()
  })
  flush()
  return results
}

function findLabelled(grid: Grid): string[] {
  const results: string[] = []
  grid.forEach((row, r) => {
    const columnar = row.filter(isAnyLabel).length >= 2
    row.forEach((cell, c) => {
      const match = cell.match(PERSON_RE)
      if (!match) return
      const value = toNameCandidate(valueFor(grid, r, c, match[1] ?? '', columnar), true)
      if (value) results.push(value)
    })
  })
  return results
}

/** Any cell that is a valid name AND agrees with the CURP initials, wherever it is. */
function findByCurp(grid: Grid, curp: string): string[] {
  const results: string[] = []
  for (const row of grid) {
    for (const cell of row) {
      const value = toNameCandidate(cell, false)
      if (value && nameMatchesCurp(value, curp)) results.push(value)
    }
  }
  return results
}

export function detectNameUniversal(texts: string[], curp: string | null): NameDetection | null {
  const grid = toGrid(texts)
  const scores = new Map<string, number>()
  const add = (values: string[], weight: number) =>
    values.forEach((value) => scores.set(value, (scores.get(value) ?? 0) + weight))

  add(findSplitFields(grid), 5)
  add(findLabelled(grid), 3)
  if (curp) add(findByCurp(grid, curp), 2)

  let best: { value: string; score: number; matches: boolean } | null = null
  for (const [value, base] of scores) {
    const matches = Boolean(curp && nameMatchesCurp(value, curp))
    const score = base + (matches ? 6 : 0)
    if (!best || score > best.score) best = { value, score, matches }
  }
  if (!best) return null
  return { value: best.value, confidence: best.matches || !curp ? 'high' : 'medium' }
}

/**
 * Chooses the CURP of the main person when the document has several:
 * labelled, repeated, valid check digit and consistent with the name win.
 */
export function pickPrimaryCurp(texts: string[], name: string | null): string | null {
  const joined = stripAccents(texts.join('\n')).toUpperCase()
  const candidates = findCurpCandidates(joined)
  if (candidates.length === 0) return null
  const unique = [...new Set(candidates)]
  if (unique.length === 1) return unique[0]

  const ranked = unique.map((curp, order) => {
    let score = candidates.filter((c) => c === curp).length
    if (hasValidCurpCheckDigit(curp)) score += 2
    if (name && nameMatchesCurp(name, curp)) score += 6
    const index = joined.indexOf(curp)
    if (CURP_LABEL_RE.test(joined.slice(Math.max(0, index - 60), index))) score += 3
    score -= order * 0.1
    return { curp, score }
  })
  ranked.sort((a, b) => b.score - a.score)
  return ranked[0].curp
}
