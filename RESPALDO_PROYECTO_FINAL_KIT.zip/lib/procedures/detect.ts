import { PROCEDURE_RULES } from './rules'
import type { ProcedureMatch, ProcedureRule } from './types'

export function normalizeForMatching(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9Ñ\n ]+/g, ' ')
    .replace(/[ \t]+/g, ' ')
}

function countOccurrences(haystack: string, needle: string): number {
  let count = 0
  let index = haystack.indexOf(needle)
  while (index !== -1) {
    count++
    index = haystack.indexOf(needle, index + needle.length)
  }
  return count
}

/** Signals near the top of a page (titles) count double. */
function scoreRule(rule: ProcedureRule, pages: string[]): number {
  let score = 0
  for (const page of pages) {
    const heading = page.split('\n').slice(0, 8).join('\n')
    for (const keyword of rule.keywords) {
      const hits = Math.min(countOccurrences(page, keyword), 3)
      const headingHits = countOccurrences(heading, keyword) > 0 ? 1 : 0
      score += (hits + headingHits) * (rule.keywordWeight ?? 1)
    }
    for (const { pattern, weight } of rule.patterns) {
      if (pattern.test(page)) score += weight
      if (pattern.test(heading)) score += weight
    }
  }
  return score
}

export function detectProcedure(texts: string[], rules: ProcedureRule[] = PROCEDURE_RULES): ProcedureMatch | null {
  const pages = texts.map(normalizeForMatching)
  const matches = rules
    .map((rule) => ({ rule, score: scoreRule(rule, pages) }))
    .filter((match) => match.score >= match.rule.minScore)
    .sort((a, b) => b.score - a.score || b.rule.priority - a.rule.priority)
  return matches[0] ?? null
}
