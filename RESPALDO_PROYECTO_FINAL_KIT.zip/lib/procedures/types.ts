export interface ProcedurePattern {
  /** Matched against normalized text: uppercase, no accents, single spaces. */
  pattern: RegExp
  weight: number
}

export interface ProcedureRule {
  id: string
  /** Label shown to the user. */
  name: string
  /** Prepended to the CURP in the suggested file name, e.g. "NSS_". */
  prefix: string
  /** Plain keywords; each occurrence adds `keywordWeight`. */
  keywords: string[]
  keywordWeight?: number
  /** Stronger signals such as document titles. */
  patterns: ProcedurePattern[]
  /** Breaks ties between rules with the same score (higher wins). */
  priority: number
  /** Minimum score required to accept the detection. */
  minScore: number
}

export interface ProcedureMatch {
  rule: ProcedureRule
  score: number
}
