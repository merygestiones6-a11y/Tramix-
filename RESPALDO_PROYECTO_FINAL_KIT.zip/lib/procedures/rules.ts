import type { ProcedureRule } from './types'

/**
 * Registry of known procedures. To support a new one, add an entry here —
 * detection, the procedure selector and file naming pick it up automatically.
 */
export const PROCEDURE_RULES: ProcedureRule[] = [
  {
    id: 'semanas-cotizadas',
    name: 'Semanas cotizadas',
    prefix: 'SISEC_',
    keywords: ['SEMANAS COTIZADAS', 'SEMANAS RECONOCIDAS', 'SEMANAS DESCONTADAS', 'SEMANAS REINTEGRADAS'],
    keywordWeight: 3,
    patterns: [
      { pattern: /CONSTANCIA DE SEMANAS COTIZADAS/, weight: 10 },
      { pattern: /REPORTE DE SEMANAS COTIZADAS/, weight: 10 },
      { pattern: /TOTAL DE SEMANAS (?:COTIZADAS|RECONOCIDAS)/, weight: 6 },
    ],
    priority: 30,
    minScore: 3,
  },
  {
    id: 'vigencia',
    name: 'Vigencia de derechos',
    prefix: 'VD_',
    keywords: ['VIGENCIA DE DERECHOS', 'CONSTANCIA DE VIGENCIA', 'DERECHO A LOS SERVICIOS MEDICOS'],
    keywordWeight: 4,
    patterns: [
      { pattern: /CONSTANCIA DE VIGENCIA DE DERECHOS/, weight: 10 },
      { pattern: /VIGENCIA DE DERECHOS/, weight: 6 },
      { pattern: /\bVIGENTE\b/, weight: 2 },
      { pattern: /\bVIGENCIA\b/, weight: 2 },
    ],
    priority: 20,
    minScore: 4,
  },
  {
    id: 'nss',
    name: 'NSS',
    prefix: 'NSS_',
    keywords: ['NUMERO DE SEGURIDAD SOCIAL', 'ASIGNACION DE NSS', 'LOCALIZACION DE NSS'],
    keywordWeight: 2,
    patterns: [
      { pattern: /ASIGNACION (?:O LOCALIZACION )?(?:DEL? )?(?:NUMERO DE SEGURIDAD SOCIAL|NSS)/, weight: 10 },
      { pattern: /CONSTANCIA DE (?:ASIGNACION DE )?(?:NUMERO DE SEGURIDAD SOCIAL|NSS)/, weight: 10 },
      { pattern: /TU NUMERO DE SEGURIDAD SOCIAL ES/, weight: 8 },
    ],
    priority: 10,
    minScore: 2,
  },
]

export function getProcedureById(id: string): ProcedureRule | undefined {
  return PROCEDURE_RULES.find((rule) => rule.id === id)
}
