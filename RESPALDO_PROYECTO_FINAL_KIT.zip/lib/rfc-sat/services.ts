export type Service = {
  id: string
  name: string
  cost: number
  fields: string[]
  desc: string
  native: boolean
}

export const SYSTEM_SERVICES: Service[] = [
  {
    id: 'idcifv1',
    name: 'IDCIF',
    cost: 1,
    fields: ['rfc', 'idcif', 'lugar'],
    desc: 'Constancia de situación fiscal oficial.',
    native: true,
  },
  {
    id: 'idcifv2',
    name: 'IDCIF (SAT) QR 2',
    cost: 1,
    fields: ['rfc', 'idcif', 'lugar'],
    desc: 'Constancia de situación fiscal (sitio alterno QR 2).',
    native: true,
  },
]

export type Account = {
  username: string
  credits: number
  services: Service[]
}

export type HistoryLog = {
  id: number
  service: string
  cost: number
  status: string
  created_at: string
  result_url: string | null
}
