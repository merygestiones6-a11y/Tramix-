import { downloadPdf } from '@/lib/download'

export function cleanPdfName(source?: string | null, fallback = 'documento') {
  const last = (source ?? '').split('?')[0].split('/').pop() ?? ''
  let base = decodeURIComponent(last).replace(/\.pdf$/i, '')
  base = base.replace(/^\d{10,}_+/, '').replace(/^_+|_+$/g, '').replace(/[^\w.-]+/g, '_')
  return `${base || fallback}.pdf`
}

function hasNativeSaver() {
  if (typeof window === 'undefined') return false
  const bridge = (window as unknown as { TramixAndroid?: { saveDataUrl?: unknown } }).TramixAndroid
  return Boolean(bridge && typeof bridge.saveDataUrl === 'function')
}

// The TRAMIX Android app names blob: downloads after the URL's UUID, so there the PDF goes to its native saver.
export function saveBlob(blob: Blob, filename: string) {
  if (hasNativeSaver()) {
    downloadPdf(blob, filename)
    return
  }
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 60000)
}

export async function downloadPdfFromUrl(url: string, filename = cleanPdfName(url)) {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) throw new Error(`No se pudo descargar (${res.status})`)
  const blob = await res.blob()
  saveBlob(new Blob([blob], { type: 'application/pdf' }), filename)
}
