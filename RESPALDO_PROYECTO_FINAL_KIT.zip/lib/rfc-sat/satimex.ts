import 'server-only'

export const SATIMEX_ORIGIN = 'https://satimex.uk'
const API = `${SATIMEX_ORIGIN}/api`

let cachedToken: string | null = null

async function login(): Promise<string> {
  const username = process.env.SATIMEX_USER
  const password = process.env.SATIMEX_PASSWORD
  if (!username || !password) {
    throw new SatimexError('Faltan SATIMEX_USER y SATIMEX_PASSWORD en las variables del proyecto.', 500)
  }
  const res = await fetch(`${API}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
    cache: 'no-store',
  })
  const data = await res.json().catch(() => ({}))
  if (!data.ok || !data.token) {
    throw new SatimexError(data.message || 'No se pudo iniciar sesión en Satimex', 401)
  }
  cachedToken = data.token as string
  return cachedToken
}

export class SatimexError extends Error {
  constructor(
    message: string,
    public status = 500,
  ) {
    super(message)
  }
}

export async function satimexFetch(path: string, init: RequestInit = {}, retried = false): Promise<any> {
  const token = cachedToken ?? (await login())
  const res = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...init.headers,
      Authorization: `Bearer ${token}`,
    },
    cache: 'no-store',
  })

  if ((res.status === 401 || res.status === 403) && !retried) {
    cachedToken = null
    return satimexFetch(path, init, true)
  }

  const data = await res.json().catch(() => null)
  if (!data) throw new SatimexError('Respuesta inválida de Satimex', 502)
  return data
}

export function absoluteUrl(path?: string | null) {
  if (!path) return null
  return path.startsWith('http') ? path : `${SATIMEX_ORIGIN}${path.startsWith('/') ? '' : '/'}${path}`
}
