import { isBirthDateFormatValid, isNssFormatValid } from '@/lib/extract'

export interface DeliveryMessageData {
  name: string
  curp: string
  nss?: string | null
  /** DD/MM/AAAA */
  birthDate?: string | null
  /** HOMBRE | MUJER */
  sex?: string | null
  /** State name, e.g. CIUDAD DE MÉXICO */
  state?: string | null
}

/**
 * Plain-text message with literal asterisks so WhatsApp renders them as bold.
 * It must never be passed through a markdown/HTML renderer.
 * NSS, date, sex and state are optional: each line is only added when a validated value exists.
 */
export function buildDeliveryMessage({ name, curp, nss, birthDate, sex, state }: DeliveryMessageData): string {
  const lines = [name.trim().toUpperCase(), `*CURP:* ${curp.trim().toUpperCase()}`]
  const cleanNss = nss?.trim() ?? ''
  if (isNssFormatValid(cleanNss)) lines.push(`*NSS:* ${cleanNss}`)
  const cleanDate = birthDate?.trim() ?? ''
  if (isBirthDateFormatValid(cleanDate)) lines.push(`*FECHA:* ${cleanDate}`)
  const cleanSex = sex?.trim().toUpperCase() ?? ''
  if (cleanSex) lines.push(`*SEXO:* ${cleanSex}`)
  const cleanState = state?.trim().toUpperCase() ?? ''
  if (cleanState) lines.push(`*ENTIDAD:* ${cleanState}`)
  return lines.join('\n')
}
