/**
 * Free-text extraction of personal data for IDENTITY LAB.
 *
 * Pure and dependency-free (besides the engine normalizers) so it can be unit-tested.
 * It only fills what can be read from the text: when a value is ambiguous it is left
 * empty and reported, never guessed.
 */
import { normalizeEntity, normalizeSex, normalizeText, parseBirthDate, STATES, type CurpInput, type Sex } from './engine'

export type NameOrder = 'nombre-primero' | 'apellidos-primero'
export type FieldKey = keyof CurpInput

export interface DetectedField {
  field: FieldKey
  value: string
  /** «sugerencia» = inferred (e.g. sex from the first name), never a confirmed value. */
  source: 'etiqueta' | 'texto' | 'sugerencia'
}

export interface AutofillResult {
  values: CurpInput
  detected: DetectedField[]
  warnings: string[]
  /** Set when the sex was not written in the text and was suggested from the first name. */
  sexSuggestion: { sexo: Sex; basedOn: string } | null
  /** True when names were split by position (no labels), so the order can be switched. */
  orderAssumed: boolean
}

const FIELD_LABELS: Record<FieldKey, string> = {
  nombre: 'Nombre(s)',
  primerApellido: 'Primer apellido',
  segundoApellido: 'Segundo apellido',
  fechaNacimiento: 'Fecha de nacimiento',
  sexo: 'Sexo',
  entidad: 'Entidad de nacimiento',
}

export function fieldLabel(field: FieldKey): string {
  return FIELD_LABELS[field]
}

/** Fields each generator needs. The second surname is optional by rule. */
export const REQUIRED_FOR_CURP: FieldKey[] = ['nombre', 'primerApellido', 'fechaNacimiento', 'sexo', 'entidad']
export const REQUIRED_FOR_RFC: FieldKey[] = ['nombre', 'primerApellido', 'fechaNacimiento']

export function missingFields(values: CurpInput, required: FieldKey[]): FieldKey[] {
  return required.filter((k) => !String(values[k] ?? '').trim())
}

type LabelKey = FieldKey | 'apellidos' | 'nombreCompleto' | 'clave'

/** Order matters: longer labels first so «apellido paterno» wins over «apellido». */
const LABELS: Array<{ key: LabelKey; pattern: string }> = [
  { key: 'nombreCompleto', pattern: 'NOMBRE COMPLETO' },
  { key: 'primerApellido', pattern: 'PRIMER APELLIDO|APELLIDO PATERNO|PATERNO' },
  { key: 'segundoApellido', pattern: 'SEGUNDO APELLIDO|APELLIDO MATERNO|MATERNO' },
  { key: 'apellidos', pattern: 'APELLIDOS' },
  { key: 'nombre', pattern: 'NOMBRE\\(S\\)|NOMBRES|NOMBRE' },
  { key: 'fechaNacimiento', pattern: 'FECHA DE NACIMIENTO|FECHA NACIMIENTO|F\\. ?NAC\\.?|NACIMIENTO|FECHA' },
  { key: 'sexo', pattern: 'SEXO|GENERO' },
  { key: 'entidad', pattern: 'ENTIDAD FEDERATIVA DE NACIMIENTO|ENTIDAD DE NACIMIENTO|ENTIDAD FEDERATIVA|ENTIDAD|ESTADO DE NACIMIENTO|LUGAR DE NACIMIENTO|ESTADO' },
  { key: 'clave', pattern: 'CURP|RFC|NSS' },
]

const MONTHS: Record<string, number> = {
  ENERO: 1, FEBRERO: 2, MARZO: 3, ABRIL: 4, MAYO: 5, JUNIO: 6, JULIO: 7, AGOSTO: 8,
  SEPTIEMBRE: 9, SETIEMBRE: 9, OCTUBRE: 10, NOVIEMBRE: 11, DICIEMBRE: 12,
  ENE: 1, FEB: 2, MAR: 3, ABR: 4, MAY: 5, JUN: 6, JUL: 7, AGO: 8, SEPT: 9, SEP: 9, SET: 9, OCT: 10, NOV: 11, DIC: 12,
}
/** Longest first so «SEPTIEMBRE» wins over «SEPT» and «SEP». */
const MONTH_RE = Object.keys(MONTHS)
  .sort((a, b) => b.length - a.length)
  .join('|')

/**
 * Words that only appear in the request around the data («un acta porfa», «sácame el RFC»).
 * A run of these, together with the articles and particles around it, is dropped; they are
 * never read as names.
 */
const REQUEST_WORDS = new Set([
  'ACTA', 'ACTAS', 'CURP', 'CURPS', 'RFC', 'NSS', 'IMSS', 'ISSSTE', 'INFONAVIT', 'SAT', 'RENAPO', 'CONSTANCIA', 'CONSTANCIAS',
  'SEMANAS', 'COTIZADAS', 'VIGENCIA', 'DERECHOS', 'NUMERO', 'SEGURO', 'SOCIAL', 'TRAMITE', 'TRAMITES', 'DOCUMENTO', 'DOCUMENTOS',
  'NACIMIENTO', 'MATRIMONIO', 'DEFUNCION', 'COPIA', 'CERTIFICADA', 'IMPRESION', 'FORMATO',
  'PORFA', 'PORFAS', 'PORFIS', 'PORFAVOR', 'FAVOR', 'PLIS', 'PLIZ', 'PLS', 'PLEASE', 'XFA', 'XFAVOR', 'URGENTE', 'GRACIAS',
  'HOLA', 'BUEN', 'BUENOS', 'BUENAS', 'DIAS', 'TARDES', 'NOCHES', 'SALUDOS', 'OYE', 'OIGA', 'OK', 'OKEY', 'AMIGO', 'AMIGA', 'JOVEN', 'LIC',
  'NECESITO', 'NECESITA', 'NECESITAMOS', 'OCUPO', 'OCUPA', 'OCUPAMOS', 'QUIERO', 'QUISIERA', 'PUEDES', 'PUEDE', 'PODRIAS', 'PODRIA',
  'SACA', 'SACAS', 'SACAME', 'SACARME', 'SACAR', 'SACALE', 'GENERA', 'GENERAME', 'GENERAR', 'HAZME', 'HACER', 'TRAMITAR', 'TRAMITAME',
  'BUSCA', 'BUSCAME', 'BUSCAR', 'CHECA', 'CHECAME', 'CHECAR', 'CONSIGUE', 'CONSIGUEME', 'DAME', 'MANDA', 'MANDAME', 'ENVIA', 'ENVIAME',
  'AYUDA', 'AYUDAS', 'AYUDE', 'AYUDAME', 'AYUDARME', 'APOYA', 'APOYAS', 'APOYAME', 'APOYO', 'REGALAS', 'REGALA', 'PASAS', 'PASA', 'PASAME',
  'MANDO', 'PASO', 'ENVIO', 'DEJO', 'AQUI', 'ESTOS', 'ESTAS', 'SON', 'DATOS', 'INFO', 'INFORMACION',
  'HIJO', 'HIJA', 'ESPOSO', 'ESPOSA', 'MAMA', 'PAPA', 'HERMANO', 'HERMANA', 'SR', 'SRA', 'SENOR', 'SENORA', 'SEÑOR', 'SEÑORA',
])
/** Short words that may surround a request («una», «el», «de», «para mi»). */
const REQUEST_GLUE = new Set(['UN', 'UNA', 'UNO', 'UNOS', 'EL', 'LA', 'LOS', 'LAS', 'LO', 'DE', 'DEL', 'PARA', 'POR', 'MI', 'MIS', 'SU', 'TU',
  'ME', 'TE', 'LE', 'SE', 'NOS', 'QUE', 'SI', 'Y', 'O', 'A', 'AL', 'CON', 'ES', 'MAS', 'TAMBIEN', 'EN'])

function wordKey(word: string): string {
  return normalizeText(word).replace(/[^A-ZÑ]/g, '')
}

/** Drops runs of request words (and the glue around them), keeping everything else. */
function stripRequestWords(value: string): string {
  const tokens = value.split(/\s+/).filter(Boolean)
  const kept: string[] = []
  let run: string[] = []
  let runHasRequest = false
  const flush = () => {
    if (!runHasRequest) kept.push(...run)
    run = []
    runHasRequest = false
  }
  for (const t of tokens) {
    const key = wordKey(t)
    if (REQUEST_WORDS.has(key)) {
      run.push(t)
      runHasRequest = true
    } else if (REQUEST_GLUE.has(key) || !key) {
      run.push(t)
    } else {
      flush()
      kept.push(t)
    }
  }
  flush()
  return kept.join(' ').trim()
}

/**
 * First names whose sex is clear in Mexican usage. Only these produce a suggestion; any
 * other name, or one used for both sexes (Guadalupe, Trinidad, Rosario, Cruz…), gives none.
 */
const MALE_NAMES = new Set([
  'AARON', 'ABEL', 'ABRAHAM', 'ADAN', 'ADOLFO', 'ADRIAN', 'AGUSTIN', 'ALAN', 'ALBERTO', 'ALEJANDRO', 'ALFONSO', 'ALFREDO', 'ALONSO',
  'ALVARO', 'ANGEL', 'ANTONIO', 'ARMANDO', 'ARTURO', 'AURELIO', 'BENITO', 'BENJAMIN', 'BERNARDO', 'BRAULIO', 'BRAYAN', 'BRIAN', 'BRUNO',
  'CARLOS', 'CESAR', 'CHRISTIAN', 'CRISTIAN', 'CRISTOBAL', 'DAMIAN', 'DANIEL', 'DARIO', 'DAVID', 'DIEGO', 'DOMINGO', 'EDGAR', 'EDUARDO',
  'EFRAIN', 'EFREN', 'ELIAS', 'EMILIANO', 'EMILIO', 'ENRIQUE', 'ERICK', 'ERIK', 'ERNESTO', 'ESTEBAN', 'EUGENIO', 'EZEQUIEL', 'FABIAN',
  'FAUSTO', 'FELIPE', 'FELIX', 'FERNANDO', 'FIDEL', 'FLORENCIO', 'FRANCISCO', 'GABRIEL', 'GERARDO', 'GERMAN', 'GILBERTO', 'GONZALO',
  'GREGORIO', 'GUILLERMO', 'GUSTAVO', 'HECTOR', 'HERIBERTO', 'HORACIO', 'HUGO', 'HUMBERTO', 'IGNACIO', 'ISAAC', 'ISMAEL', 'ISRAEL',
  'IVAN', 'JAIME', 'JAVIER', 'JESUS', 'JOAQUIN', 'JONATHAN', 'JORGE', 'JOSE', 'JUAN', 'JULIAN', 'JULIO', 'LEONARDO', 'LEOPOLDO', 'LORENZO',
  'LUIS', 'MANUEL', 'MARCO', 'MARCOS', 'MARIO', 'MARTIN', 'MATEO', 'MAURICIO', 'MAXIMILIANO', 'MIGUEL', 'MOISES', 'NICOLAS', 'NOE',
  'OCTAVIO', 'OMAR', 'OSCAR', 'OSVALDO', 'PABLO', 'PATRICIO', 'PEDRO', 'RAFAEL', 'RAMIRO', 'RAMON', 'RAUL', 'RENE', 'REYNALDO', 'RICARDO',
  'ROBERTO', 'RODOLFO', 'RODRIGO', 'ROGELIO', 'ROLANDO', 'ROMAN', 'RUBEN', 'SALVADOR', 'SAMUEL', 'SANTIAGO', 'SAUL', 'SEBASTIAN',
  'SERGIO', 'SILVESTRE', 'TOMAS', 'ULISES', 'URIEL', 'VALENTIN', 'VICENTE', 'VICTOR', 'XAVIER', 'YAHIR',
])
const FEMALE_NAMES = new Set([
  'ABIGAIL', 'ADRIANA', 'AIDE', 'ALEJANDRA', 'ALICIA', 'ALMA', 'AMPARO', 'ANA', 'ANDREA', 'ANGELA', 'ANGELICA', 'ARACELI', 'BEATRIZ',
  'BERENICE', 'BLANCA', 'BRENDA', 'CAMILA', 'CAROLINA', 'CECILIA', 'CINTHIA', 'CLAUDIA', 'CONCEPCION', 'CRISTINA', 'DANIELA', 'DIANA',
  'DOLORES', 'ELENA', 'ELIZABETH', 'EMMA', 'ESMERALDA', 'ESPERANZA', 'ESTEFANIA', 'ESTHER', 'EVA', 'FABIOLA', 'FERNANDA', 'FRANCISCA',
  'GABRIELA', 'GLORIA', 'GRACIELA', 'GUILLERMINA', 'HILDA', 'IRENE', 'ISABEL', 'ITZEL', 'IVONNE', 'JACQUELINE', 'JESSICA', 'JIMENA',
  'JOSEFINA', 'JUANA', 'JULIA', 'KAREN', 'KARINA', 'LAURA', 'LETICIA', 'LILIANA', 'LORENA', 'LOURDES', 'LUCIA', 'LUISA', 'LUZ',
  'MAGDALENA', 'MARCELA', 'MARGARITA', 'MARIA', 'MARIANA', 'MARISOL', 'MARTHA', 'MARTA', 'MELISSA', 'MERCEDES', 'MIRIAM', 'MONICA',
  'NANCY', 'NATALIA', 'NAYELI', 'NOEMI', 'NORMA', 'OFELIA', 'OLGA', 'PALOMA', 'PAOLA', 'PATRICIA', 'PAULA', 'PERLA', 'RAQUEL',
  'REBECA', 'REGINA', 'ROCIO', 'ROSA', 'ROSALBA', 'RUTH', 'SANDRA', 'SARA', 'SILVIA', 'SOFIA', 'SONIA', 'SUSANA',
  'TERESA', 'VALERIA', 'VANESSA', 'VERONICA', 'VICTORIA', 'VIRGINIA', 'XIMENA', 'YESENIA', 'YOLANDA', 'ZOILA',
  'KARLA', 'CARLA', 'LIZBETH', 'ARELI', 'MAYRA', 'DULCE', 'FATIMA', 'GISELA', 'IRMA', 'ISELA', 'JANET', 'JAZMIN', 'YAZMIN', 'JENNIFER',
  'LIDIA', 'LILIA', 'MARIBEL', 'MIREYA', 'MIRNA', 'NADIA', 'NORA', 'ROSALIA', 'SELENE', 'TANIA', 'VIVIANA', 'WENDY', 'YADIRA',
])
for (const n of ['AXEL', 'BRANDON', 'KEVIN', 'JAIR', 'LUCIANO', 'IKER', 'LEONEL', 'MARCELO', 'NESTOR', 'EVERARDO', 'GAEL', 'ALDO']) MALE_NAMES.add(n)

/** Suggests H or M from the first given name; '' when the name is unknown or used for both. */
export function suggestSexFromName(nombre: string): { sexo: Sex | ''; basedOn: string } {
  const first = nombre
    .split(/\s+/)
    .map(wordKey)
    .find((w) => w && !NAME_PARTICLES.has(w))
  if (!first) return { sexo: '', basedOn: '' }
  // «Ma.» is the usual abbreviation of María.
  const key = first === 'MA' ? 'MARIA' : first
  if (MALE_NAMES.has(key)) return { sexo: 'H', basedOn: first }
  if (FEMALE_NAMES.has(key)) return { sexo: 'M', basedOn: first }
  return { sexo: '', basedOn: first }
}

const NAME_PARTICLES = new Set(['DA', 'DAS', 'DE', 'DEL', 'DER', 'DI', 'DIE', 'DOS', 'DU', 'LA', 'LAS', 'LOS', 'LE', 'MAC', 'MC', 'VAN', 'VON', 'Y'])

/** Words that introduce data in prose and are never part of a name. */
const FILLER = new Set([
  'ME', 'LLAMO', 'MI', 'SU', 'ES', 'SOY', 'SE', 'LLAMA', 'NOMBRE', 'NOMBRES', 'NACI', 'NACIO', 'NACIDO', 'NACIDA', 'EL', 'DIA',
  'EN', 'FECHA', 'SEXO', 'HOMBRE', 'MUJER', 'MASCULINO', 'FEMENINO', 'ORIGINARIO', 'ORIGINARIA', 'DATOS', 'PERSONALES',
  'CON', 'Y', 'A',
])

/**
 * Uppercase copy without accents and with the same length as the source, so a match
 * position in the folded text maps 1:1 to the original text.
 */
function fold(text: string): string {
  return text
    .split('')
    .map((ch) => (ch === 'ñ' || ch === 'Ñ' ? 'Ñ' : ch.normalize('NFD')[0] ?? ch).toUpperCase().slice(0, 1) || ch)
    .join('')
}

function iso(year: number, month: number, day: number): string {
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

interface DateHit {
  iso: string
  start: number
  end: number
}

function findDates(folded: string): DateHit[] {
  const hits: DateHit[] = []
  const add = (re: RegExp, toIso: (m: RegExpExecArray) => string | null) => {
    for (const m of folded.matchAll(re)) {
      const value = toIso(m as RegExpExecArray)
      if (value && !hits.some((h) => m.index! < h.end && m.index! + m[0].length > h.start)) {
        hits.push({ iso: value, start: m.index!, end: m.index! + m[0].length })
      }
    }
  }
  // «14 abril 2004», «14 de abril del 2004», «14-abr-2004», «14/ABR/2004».
  add(new RegExp(`\\b(\\d{1,2})[\\s/.-]*(?:DE\\s+)?(${MONTH_RE})(?![A-Z])\\.?[\\s/.-]*(?:DE(?:L)?\\s+)?(\\d{4})\\b`, 'g'), (m) =>
    iso(Number(m[3]), MONTHS[m[2]], Number(m[1])),
  )
  // «abril 14, 2004», «abril 14 del 2004».
  add(new RegExp(`\\b(${MONTH_RE})(?![A-Z])\\.?\\s+(\\d{1,2})\\s*,?\\s*(?:DE(?:L)?\\s+)?(\\d{4})\\b`, 'g'), (m) =>
    iso(Number(m[3]), MONTHS[m[1]], Number(m[2])),
  )
  add(/\b(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\b/g, (m) => iso(Number(m[1]), Number(m[2]), Number(m[3])))
  add(/\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})\b/g, (m) => iso(Number(m[3]), Number(m[2]), Number(m[1])))
  return hits.sort((a, b) => a.start - b.start)
}

/** Longest state name or alias at the start of a phrase (e.g. «Jalisco, México»). */
function matchEntity(phrase: string, allowCodes: boolean): string {
  const list = normalizeText(phrase).replace(/[.,;:]/g, ' ').split(' ').filter(Boolean)
  for (let n = Math.min(list.length, 5); n >= 1; n--) {
    const candidate = list.slice(0, n).join(' ')
    if (!allowCodes && candidate.length <= 2) continue
    // A bare «México» could mean the country or the state, so it is not resolved.
    if (candidate === 'MEXICO') continue
    const code = normalizeEntity(candidate)
    if (STATES.some((s) => s.code === code)) return code
  }
  return ''
}

/** Groups particles with the word that follows them: «de la Cruz» is one surname. */
function nameUnits(text: string): string[] {
  const tokens = text.split(/\s+/).filter(Boolean)
  const units: string[] = []
  let pending: string[] = []
  for (const t of tokens) {
    if (NAME_PARTICLES.has(normalizeText(t))) {
      pending.push(t)
      continue
    }
    units.push([...pending, t].join(' '))
    pending = []
  }
  if (pending.length && units.length) units[units.length - 1] += ' ' + pending.join(' ')
  return units
}

function titleCase(value: string): string {
  return value
    .toLowerCase()
    .replace(/(^|[\s'-])(\p{L})/gu, (_, sep: string, ch: string) => sep + ch.toUpperCase())
    .replace(/(^|\s)(De|Del|La|Las|Los|Y|Van|Von|Da|Di|Du)(?=\s)/g, (_, sep: string, w: string) => sep + w.toLowerCase())
}

function cleanNameText(value: string): string {
  return value
    .replace(/[^\p{L}\s.'-]/gu, ' ')
    .split(/\s+/)
    .filter((w) => w && !FILLER.has(normalizeText(w).replace(/\./g, '')))
    .join(' ')
    .trim()
}

export function parseFreeText(text: string, order: NameOrder = 'nombre-primero'): AutofillResult {
  const values: CurpInput = { nombre: '', primerApellido: '', segundoApellido: '', fechaNacimiento: '', sexo: '', entidad: '' }
  const detected: DetectedField[] = []
  const warnings: string[] = []
  let orderAssumed = false

  const set = (field: FieldKey, value: string, source: DetectedField['source']) => {
    const v = value.trim()
    if (!v || values[field]) return
    ;(values as Record<FieldKey, string>)[field] = v
    detected.push({ field, value: v, source })
  }

  if (!text.trim()) return { values, detected, warnings: ['Pega primero el texto con los datos.'], orderAssumed, sexSuggestion: null }

  let source = text.replace(/\r/g, '')
  let folded = fold(source)
  /** Blanks a range in both copies so later steps do not read it again. */
  const consume = (start: number, end: number) => {
    const blank = ' '.repeat(end - start)
    source = source.slice(0, start) + blank + source.slice(end)
    folded = folded.slice(0, start) + blank + folded.slice(end)
  }

  /* 1. Labeled values: «Nombre: …», «Fecha de nacimiento: …». */
  const labelRe = new RegExp(`(^|[\\n,;|]|\\s)(${LABELS.map((l) => l.pattern).join('|')})\\s*[:=]\\s*`, 'g')
  const marks = [...folded.matchAll(labelRe)].map((m) => {
    const word = m[2]
    const key = LABELS.find((l) => new RegExp(`^(?:${l.pattern})$`).test(word))!.key
    const labelStart = m.index! + m[1].length
    return { key, labelStart, valueStart: m.index! + m[0].length }
  })
  const labeled: Array<{ key: LabelKey; value: string }> = []
  marks.forEach((mark, i) => {
    const next = marks[i + 1]?.labelStart ?? source.length
    const lineEnd = source.indexOf('\n', mark.valueStart)
    const end = Math.min(next, lineEnd === -1 ? source.length : lineEnd)
    labeled.push({ key: mark.key, value: source.slice(mark.valueStart, end).replace(/[,;|]+\s*$/, '').trim() })
  })
  for (let i = marks.length - 1; i >= 0; i--) {
    const next = marks[i + 1]?.labelStart ?? source.length
    const lineEnd = source.indexOf('\n', marks[i].valueStart)
    consume(marks[i].labelStart, Math.min(next, lineEnd === -1 ? source.length : lineEnd))
  }

  for (const { key, value } of labeled) {
    if (!value) continue
    switch (key) {
      case 'clave':
        warnings.push('Se ignoró una clave (CURP, RFC o NSS) incluida en el texto: no se usa para rellenar campos.')
        break
      case 'fechaNacimiento': {
        const hit = findDates(fold(value))[0]
        if (hit) set('fechaNacimiento', hit.iso, 'etiqueta')
        else warnings.push(`No se reconoció la fecha «${value}». Usa DD/MM/AAAA o AAAA-MM-DD.`)
        break
      }
      case 'sexo': {
        const sex = normalizeSex(value)
        if (sex) set('sexo', sex, 'etiqueta')
        else warnings.push(`No se reconoció el sexo «${value}».`)
        break
      }
      case 'entidad': {
        const code = matchEntity(value, true)
        if (code) set('entidad', code, 'etiqueta')
        else warnings.push(`No se reconoció la entidad «${value}». Selecciónala manualmente.`)
        break
      }
      case 'apellidos': {
        const units = nameUnits(cleanNameText(value))
        set('primerApellido', titleCase(units[0] ?? ''), 'etiqueta')
        set('segundoApellido', titleCase(units.slice(1).join(' ')), 'etiqueta')
        if (units.length > 2) warnings.push('Los apellidos tienen más de dos palabras: revisa cómo se dividieron.')
        break
      }
      case 'nombreCompleto':
        consumeFullName(cleanNameText(value), 'etiqueta')
        break
      default:
        set(key, titleCase(cleanNameText(value)), 'etiqueta')
    }
  }

  /* 2. Keys and numbers that must never become names. */
  for (const m of [...folded.matchAll(/\b[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{2,8}\b/g)].reverse()) {
    consume(m.index!, m.index! + m[0].length)
    warnings.push('Se ignoró una clave CURP o RFC incluida en el texto: no se usa para rellenar campos.')
  }
  for (const m of [...folded.matchAll(/\S+@\S+/g)].reverse()) consume(m.index!, m.index! + m[0].length)

  /* 3. Unlabeled date. */
  if (!values.fechaNacimiento) {
    const dates = findDates(folded)
    const distinct = [...new Set(dates.map((d) => d.iso))]
    if (distinct.length === 1) set('fechaNacimiento', distinct[0], 'texto')
    else if (distinct.length > 1) warnings.push(`Se encontraron varias fechas (${distinct.join(', ')}); selecciona la de nacimiento manualmente.`)
    for (const d of [...dates].reverse()) consume(d.start, d.end)
  }
  for (const m of [...folded.matchAll(/\d+/g)].reverse()) consume(m.index!, m.index! + m[0].length)

  /* 4. Unlabeled sex: only full words, never a lone letter. */
  const sexHits = [...folded.matchAll(/\b(HOMBRE|MUJER|MASCULINO|FEMENINO|NO BINARI[OAE])\b/g)]
  if (!values.sexo) {
    const sexes = [...new Set(sexHits.map((m) => normalizeSex(m[1].replace(/NO BINARI[AE]/, 'NO BINARIO'))))].filter(Boolean) as Sex[]
    if (sexes.length === 1) set('sexo', sexes[0], 'texto')
    else if (sexes.length > 1) warnings.push('El texto indica sexos distintos; selecciónalo manualmente.')
  }
  for (const m of sexHits.reverse()) consume(m.index!, m.index! + m[0].length)

  /* 5. Unlabeled entity: «nacido en X» or a segment that is exactly a state name. */
  const bornIn = /\b(?:NACID[OA]|NACI[OÓ]?|ORIGINARI[OA]|NATURAL)\s+(?:EN|DE)\s+(?:EL\s+)?([^,\n;|]+)/g
  for (const m of [...folded.matchAll(bornIn)].reverse()) {
    const code = matchEntity(source.slice(m.index! + m[0].length - m[1].length, m.index! + m[0].length), false)
    if (code) {
      set('entidad', code, 'texto')
      consume(m.index!, m.index! + m[0].length)
    }
  }
  // Blank runs left by removed dates/keys also separate data written on a single line.
  const segments = source.split(/[\n,;|]+| {3,}/)
  const nameSegments: string[] = []
  for (const seg of segments) {
    const trimmed = stripRequestWords(seg.trim())
    if (!trimmed) continue
    const place = normalizeText(trimmed)
      .replace(/[.,;:]/g, ' ')
      .replace(/^(?:(?:ESTADO|EDO|ENTIDAD|NACIDO|NACIDA|NACIO|ORIGINARIO|ORIGINARIA)\s+)?(?:DE|DEL|EN)\s+/, '')
      .trim()
    const code = matchEntity(place, false)
    if (code && place.split(' ').length <= 4 && normalizeEntity(place) === code) {
      if (!values.entidad) set('entidad', code, 'texto')
      else if (values.entidad !== code) warnings.push(`El texto menciona entidades distintas; se conservó la primera. Revisa la entidad.`)
      continue
    }
    if (/^[A-ZÑ]$/.test(fold(trimmed))) {
      warnings.push(`Se ignoró la letra suelta «${trimmed}»: puede ser sexo o inicial. Complétalo manualmente.`)
      continue
    }
    if (/^\s*MEXICO\s*$/.test(fold(trimmed))) {
      warnings.push('«México» puede referirse al país o al Estado de México; selecciona la entidad manualmente.')
      continue
    }
    const clean = cleanNameText(trimmed)
    if (clean) nameSegments.push(clean)
  }

  /* 6. Remaining words are the name. */
  const needsNames = !values.nombre && !values.primerApellido
  if (needsNames && nameSegments.length) {
    // «Pérez López, Juan»: before the comma are surnames.
    if (nameSegments.length === 2 && segments.filter((s) => s.trim()).length >= 2 && /,/.test(text) && order === 'nombre-primero') {
      const surnames = nameUnits(nameSegments[0])
      const names = nameSegments[1]
      if (surnames.length <= 2 && names.split(' ').length <= 3) {
        set('primerApellido', titleCase(surnames[0] ?? ''), 'texto')
        set('segundoApellido', titleCase(surnames[1] ?? ''), 'texto')
        set('nombre', titleCase(names), 'texto')
        orderAssumed = true
        warnings.push('Se interpretó «apellidos, nombre» por la coma. Revisa la división.')
      } else {
        consumeFullName(nameSegments.join(' '), 'texto')
      }
    } else {
      // The line with the most name words is the name; leftovers are reported, not used.
      let best = 0
      nameSegments.forEach((s, i) => {
        if (nameUnits(s).length > nameUnits(nameSegments[best]).length) best = i
      })
      const others = nameSegments.filter((_, i) => i !== best)
      const rivals = others.filter((s) => nameUnits(s).length >= 2)
      if (rivals.length) {
        warnings.push(`Hay más de un posible nombre (${[nameSegments[best], ...rivals].map((s) => `«${s}»`).join(', ')}). Se usó «${nameSegments[best]}»; confirma que es el correcto.`)
      } else if (others.length) {
        warnings.push(`Se ignoró texto adicional: «${others.join(' · ')}».`)
      }
      consumeFullName(nameSegments[best], 'texto')
    }
  }

  function consumeFullName(full: string, src: DetectedField['source']) {
    const units = nameUnits(full)
    if (!units.length) return
    orderAssumed = true
    if (order === 'apellidos-primero') {
      set('primerApellido', titleCase(units[0]), src)
      if (units.length >= 3) {
        set('segundoApellido', titleCase(units[1]), src)
        set('nombre', titleCase(units.slice(2).join(' ')), src)
      } else if (units.length === 2) {
        set('nombre', titleCase(units[1]), src)
      }
    } else if (units.length >= 3) {
      set('nombre', titleCase(units.slice(0, -2).join(' ')), src)
      set('primerApellido', titleCase(units[units.length - 2]), src)
      set('segundoApellido', titleCase(units[units.length - 1]), src)
    } else if (units.length === 2) {
      set('nombre', titleCase(units[0]), src)
      set('primerApellido', titleCase(units[1]), src)
    } else {
      set('nombre', titleCase(units[0]), src)
    }
    warnings.push(
      order === 'apellidos-primero'
        ? 'Orden supuesto: apellidos y después nombre(s). Revisa la división; los apellidos compuestos sin partícula no pueden distinguirse automáticamente.'
        : 'Orden supuesto: nombre(s) y después apellidos. Revisa la división; los apellidos compuestos sin partícula no pueden distinguirse automáticamente.',
    )
  }

  if (values.fechaNacimiento) {
    const check = parseBirthDate(values.fechaNacimiento)
    if (typeof check === 'string') warnings.push(`Fecha detectada ${values.fechaNacimiento}: ${check}`)
  } else if (/\b\d{1,2}[\s/.-]+(?:\d{1,2}|[A-Z]{3,10})[\s/.-]+\d{2}\b/.test(fold(text))) {
    warnings.push('La fecha parece tener el año con dos dígitos; escríbela con el año completo (AAAA) para no suponer el siglo.')
  }

  let sexSuggestion: AutofillResult['sexSuggestion'] = null
  if (values.sexo && values.nombre) {
    const s = suggestSexFromName(values.nombre)
    if (s.sexo && (values.sexo === 'H' || values.sexo === 'M') && s.sexo !== values.sexo) {
      warnings.push(
        `El texto indica «${values.sexo === 'H' ? 'hombre' : 'mujer'}», pero el nombre «${titleCase(s.basedOn)}» suele ser de ${s.sexo === 'H' ? 'hombre' : 'mujer'}. Se conservó lo escrito; confírmalo.`,
      )
    }
  } else if (values.nombre) {
    const s = suggestSexFromName(values.nombre)
    if (s.sexo) {
      set('sexo', s.sexo, 'sugerencia')
      sexSuggestion = { sexo: s.sexo, basedOn: s.basedOn }
    } else {
      warnings.push(`No se puede sugerir el sexo a partir del nombre «${titleCase(s.basedOn)}». Selecciónalo manualmente.`)
    }
  }

  return { values, detected, warnings: [...new Set(warnings)], orderAssumed, sexSuggestion }
}
