'use client'

import { useSyncExternalStore } from 'react'

export type HistoryTool = 'RFC POR DATOS' | 'RFC POR CURP' | 'CURP POR DATOS' | 'VALIDADOR' | 'MASIVO'

export interface HistoryEntry {
  id: string
  at: number
  tool: HistoryTool
  query: string
  results: string[]
}

/** Kept only in this browser: nothing here is sent to a server or a third party. */
const KEY = 'identity-lab:history:v1'
const MAX_ENTRIES = 200
const EMPTY: HistoryEntry[] = []

let cache: HistoryEntry[] | null = null
const listeners = new Set<() => void>()

function read(): HistoryEntry[] {
  if (cache) return cache
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) ?? '[]')
    cache = Array.isArray(parsed) ? (parsed as HistoryEntry[]) : []
  } catch {
    cache = []
  }
  return cache
}

function write(next: HistoryEntry[]): void {
  cache = next
  try {
    localStorage.setItem(KEY, JSON.stringify(next))
  } catch {
    // Storage full or blocked (private mode): history stays in memory for this session.
  }
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) {
      cache = null
      listener()
    }
  }
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.delete(listener)
    window.removeEventListener('storage', onStorage)
  }
}

export function useHistory(): HistoryEntry[] {
  return useSyncExternalStore(subscribe, read, () => EMPTY)
}

export function addHistory(tool: HistoryTool, query: string, results: string[]): void {
  if (!results.length) return
  const entry: HistoryEntry = { id: crypto.randomUUID(), at: Date.now(), tool, query, results }
  write([entry, ...read()].slice(0, MAX_ENTRIES))
}

export function removeHistory(id: string): void {
  write(read().filter((e) => e.id !== id))
}

export function clearHistory(): void {
  write([])
}
