/**
 * IDENTITY LAB calculation engine. Pure functions with no imports so they run
 * in the browser and in `node --test` unchanged.
 *
 * CURP: Instructivo Normativo para la Asignación de la CURP (DOF) and its 2021
 * modification (sexo "X"). RFC (persona física): SAT formation rules for the
 * initial key, plus the publicly documented homoclave / check-digit procedure.
 *
 * Nothing here can confirm that a key is registered: RENAPO assigns CURP
 * position 17 and SAT assigns the RFC homoclave. Results are structures.
 */

export type Sex = 'H' | 'M' | 'X'
export type Status = 'valida' | 'invalida' | 'verificar'

export interface PersonInput {
  nombre: string
  primerApellido: string
  segundoApellido: string
  /** ISO date: AAAA-MM-DD */
  fechaNacimiento: string
}

export interface CurpInput extends PersonInput {
  sexo: Sex | ''
  entidad: string
}

export interface Candidate {
  id: string
  rank: number
  status: 'estructura-valida' | 'parcial' | 'verificar'
  statusLabel: string
  reason: string
}

export interface GenerationResult {
  ok: boolean
  errors: string[]
  candidates: Candidate[]
  /** Rules and exceptions applied, in plain language. */
  notes: string[]
}

export interface Check {
  label: string
  ok: boolean | null
  detail: string
}

export interface ValidationResult {
  kind: 'CURP' | 'RFC física' | 'RFC moral' | 'RFC genérico' | 'Desconocido'
  value: string
  status: Status
  summary: string
  checks: Check[]
}

export const STATES: ReadonlyArray<{ code: string; name: string }> = [
  { code: 'AS', name: 'Aguascalientes' },
  { code: 'BC', name: 'Baja California' },
  { code: 'BS', name: 'Baja California Sur' },
  { code: 'CC', name: 'Campeche' },
  { code: 'CL', name: 'Coahuila' },
  { code: 'CM', name: 'Colima' },
  { code: 'CS', name: 'Chiapas' },
  { code: 'CH', name: 'Chihuahua' },
  { code: 'DF', name: 'Ciudad de México' },
  { code: 'DG', name: 'Durango' },
  { code: 'GT', name: 'Guanajuato' },
  { code: 'GR', name: 'Guerrero' },
  { code: 'HG', name: 'Hidalgo' },
  { code: 'JC', name: 'Jalisco' },
  { code: 'MC', name: 'Estado de México' },
  { code: 'MN', name: 'Michoacán' },
  { code: 'MS', name: 'Morelos' },
  { code: 'NT', name: 'Nayarit' },
  { code: 'NL', name: 'Nuevo León' },
  { code: 'OC', name: 'Oaxaca' },
  { code: 'PL', name: 'Puebla' },
  { code: 'QT', name: 'Querétaro' },
  { code: 'QR', name: 'Quintana Roo' },
  { code: 'SP', name: 'San Luis Potosí' },
  { code: 'SL', name: 'Sinaloa' },
  { code: 'SR', name: 'Sonora' },
  { code: 'TC', name: 'Tabasco' },
  { code: 'TS', name: 'Tamaulipas' },
  { code: 'TL', name: 'Tlaxcala' },
  { code: 'VZ', name: 'Veracruz' },
  { code: 'YN', name: 'Yucatán' },
  { code: 'ZS', name: 'Zacatecas' },
  { code: 'NE', name: 'Nacido en el extranjero' },
]

const STATE_CODES = new Set(STATES.map((s) => s.code))

/** Articles, prepositions and contractions excluded from both keys. */
const PARTICLES = new Set([
  'DA', 'DAS', 'DE', 'DEL', 'DER', 'DI', 'DIE', 'DD', 'EL', 'LA', 'LOS', 'LAS', 'LE', 'LES', 'MAC', 'MC', 'VAN', 'VON', 'Y',
])

/** First names skipped when another name follows (MARÍA / JOSÉ and abbreviations). */
const SKIPPABLE_FIRST_NAMES = new Set(['MARIA', 'MA', 'MA.', 'M.', 'JOSE', 'J', 'J.'])

/** Instructivo Normativo CURP, Anexo 2: the 2nd character is replaced by X. */
const CURP_INCONVENIENT = new Set([
  'BACA', 'BAKA', 'BUEI', 'BUEY', 'CACA', 'CACO', 'CAGA', 'CAGO', 'CAKA', 'CAKO', 'COGE', 'COGI', 'COJA', 'COJE', 'COJI', 'COJO',
  'COLA', 'CULO', 'FALO', 'FETO', 'GETA', 'GUEI', 'GUEY', 'JETA', 'JOTO', 'KACA', 'KACO', 'KAGA', 'KAGO', 'KAKA', 'KAKO', 'KOGE',
  'KOGI', 'KOJA', 'KOJE', 'KOJI', 'KOJO', 'KOLA', 'KULO', 'LILO', 'LOCA', 'LOCO', 'LOKA', 'LOKO', 'MAME', 'MAMO', 'MEAR', 'MEAS',
  'MEON', 'MIAR', 'MION', 'MOCO', 'MOKO', 'MULA', 'MULO', 'NACA', 'NACO', 'PEDA', 'PEDO', 'PENE', 'PIPI', 'PITO', 'POPO', 'PUTA',
  'PUTO', 'QULO', 'RATA', 'ROBA', 'ROBE', 'ROBO', 'RUIN', 'SENO', 'TETA', 'VACA', 'VAGA', 'VAGO', 'VAKA', 'VUEI', 'VUEY', 'WUEI',
  'WUEY',
])

/** SAT RFC list of inconvenient words: the 4th character is replaced by X. */
const RFC_INCONVENIENT = new Set([
  'BUEI', 'BUEY', 'CACA', 'CACO', 'CAGA', 'CAGO', 'CAKA', 'CAKO', 'COGE', 'COJA', 'COJE', 'COJI', 'COJO', 'CULO', 'FETO', 'GUEY',
  'JOTO', 'KACA', 'KACO', 'KAGA', 'KAGO', 'KAKA', 'KOGE', 'KOJO', 'KULO', 'MAME', 'MAMO', 'MEAR', 'MEAS', 'MEON', 'MION', 'MOCO',
  'MULA', 'PEDA', 'PEDO', 'PENE', 'PUTA', 'PUTO', 'QULO', 'RATA', 'RUIN',
])

const VOWELS = 'AEIOU'
const CURP_DICT = '0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ'
const HOMOCLAVE_TABLE = '123456789ABCDEFGHIJKLMNPQRSTUVWXYZ'
const NAME_CHARS = /^[A-ZÑ .'\-/]*$/

/* ------------------------------------------------------------------ */
/* Normalization                                                       */
/* ------------------------------------------------------------------ */

/** Uppercases, removes accents (keeps Ñ) and collapses spaces. */
export function normalizeText(value: string): string {
  return value
    .toUpperCase()
    .replace(/Ñ/g, '\u0001')
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .replace(/\u0001/g, 'Ñ')
    .replace(/\s+/g, ' ')
    .trim()
}

function words(value: string): string[] {
  return normalizeText(value).split(' ').filter(Boolean)
}

function stripParticles(list: string[]): { kept: string[]; removed: string[] } {
  const kept = list.filter((w) => !PARTICLES.has(w.replace(/\./g, '')))
  const removed = list.filter((w) => PARTICLES.has(w.replace(/\./g, '')))
  // A surname made only of particles keeps its original words.
  return kept.length ? { kept, removed } : { kept: list, removed: [] }
}

interface Part {
  word: string
  notes: string[]
}

function significantSurname(value: string, label: string): Part | null {
  const list = words(value)
  if (!list.length) return null
  const { kept, removed } = stripParticles(list)
  const notes = removed.length ? [`${label}: se omitió ${removed.join(', ')} (partícula).`] : []
  if (kept.length > 1) notes.push(`${label} compuesto: se usa la primera palabra «${kept[0]}».`)
  return { word: kept[0], notes }
}

function significantName(value: string): Part | null {
  const list = words(value)
  if (!list.length) return null
  const { kept, removed } = stripParticles(list)
  const notes = removed.length ? [`Nombre: se omitió ${removed.join(', ')} (partícula).`] : []
  if (kept.length > 1 && SKIPPABLE_FIRST_NAMES.has(kept[0])) {
    notes.push(`Nombre compuesto: se omite «${kept[0]}» y se usa «${kept[1]}».`)
    return { word: kept[1], notes }
  }
  return { word: kept[0], notes }
}

function isRealDate(year: number, month: number, day: number): boolean {
  const d = new Date(Date.UTC(year, month - 1, day))
  return d.getUTCFullYear() === year && d.getUTCMonth() === month - 1 && d.getUTCDate() === day
}

export interface ParsedDate {
  year: number
  month: number
  day: number
  yymmdd: string
}

export function parseBirthDate(iso: string, now = new Date()): ParsedDate | string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim())
  if (!m) return 'La fecha de nacimiento debe tener el formato AAAA-MM-DD.'
  const [year, month, day] = [Number(m[1]), Number(m[2]), Number(m[3])]
  if (!isRealDate(year, month, day)) return 'La fecha de nacimiento no existe en el calendario.'
  if (year < 1900) return 'La fecha de nacimiento debe ser posterior a 1899.'
  if (Date.UTC(year, month - 1, day) > now.getTime()) return 'La fecha de nacimiento está en el futuro.'
  return { year, month, day, yymmdd: m[1].slice(2) + m[2] + m[3] }
}

function validatePersonFields(input: PersonInput): string[] {
  const errors: string[] = []
  const fields: [string, string][] = [
    ['Nombre(s)', input.nombre],
    ['Primer apellido', input.primerApellido],
    ['Segundo apellido', input.segundoApellido],
  ]
  for (const [label, value] of fields) {
    const v = normalizeText(value)
    if (!NAME_CHARS.test(v)) errors.push(`${label}: solo se permiten letras, espacios y los signos . ' - /`)
    else if (v && !/[A-ZÑ]/.test(v)) errors.push(`${label}: debe contener al menos una letra.`)
    if (value.length > 80) errors.push(`${label}: es demasiado largo.`)
  }
  if (!normalizeText(input.nombre)) errors.push('Escribe el nombre o nombres.')
  if (!normalizeText(input.primerApellido) && !normalizeText(input.segundoApellido)) {
    errors.push('Escribe al menos un apellido.')
  }
  return errors
}

/* ------------------------------------------------------------------ */
/* CURP                                                                */
/* ------------------------------------------------------------------ */

function curpLetter(word: string, index: number): string {
  const c = word[index]
  if (!c) return 'X'
  if (c === 'Ñ') return 'X'
  return /[A-Z]/.test(c) ? c : 'X'
}

function curpInternalVowel(word: string): string {
  for (let i = 1; i < word.length; i++) if (VOWELS.includes(word[i])) return word[i]
  return 'X'
}

function curpInternalConsonant(word: string): string {
  for (let i = 1; i < word.length; i++) {
    const c = word[i]
    if (c === 'Ñ') return 'X'
    if (/[A-Z]/.test(c) && !VOWELS.includes(c)) return c
  }
  return 'X'
}

/** Position 18: weighted sum of the first 17 characters, modulo 10. */
export function curpCheckDigit(first17: string): string {
  let sum = 0
  for (let i = 0; i < 17; i++) {
    const v = CURP_DICT.indexOf(first17[i])
    if (v < 0) return '?'
    sum += v * (18 - i)
  }
  return String((10 - (sum % 10)) % 10)
}

export interface CurpBase {
  base16: string
  notes: string[]
  century: 1900 | 2000
}

export function buildCurpBase(input: CurpInput): { base: CurpBase | null; errors: string[] } {
  const errors = validatePersonFields(input)
  const date = parseBirthDate(input.fechaNacimiento)
  if (typeof date === 'string') errors.push(date)
  if (input.sexo !== 'H' && input.sexo !== 'M' && input.sexo !== 'X') errors.push('Selecciona el sexo.')
  if (!STATE_CODES.has(input.entidad)) errors.push('Selecciona la entidad de nacimiento.')
  if (errors.length || typeof date === 'string') return { base: null, errors }

  const notes: string[] = []
  let first = significantSurname(input.primerApellido, 'Primer apellido')
  let second = significantSurname(input.segundoApellido, 'Segundo apellido')
  if (!first && second) {
    first = { word: second.word, notes: second.notes.map((n) => n.replace('Segundo apellido', 'Apellido')) }
    second = null
    notes.push('Un solo apellido: se usa como primer apellido.')
  }
  const name = significantName(input.nombre)!
  notes.push(...first!.notes, ...(second?.notes ?? []), ...name.notes)

  const p = first!.word
  const m = second?.word ?? ''
  if (!second) notes.push('Sin segundo apellido: las posiciones 3 y 15 llevan X.')

  let four = curpLetter(p, 0) + curpInternalVowel(p) + (m ? curpLetter(m, 0) : 'X') + curpLetter(name.word, 0)
  if (curpInternalVowel(p) === 'X') notes.push('El primer apellido no tiene vocal interna: posición 2 = X.')
  if (CURP_INCONVENIENT.has(four)) {
    const fixed = four[0] + 'X' + four.slice(2)
    notes.push(`Palabra inconveniente «${four}»: se sustituye la 2.ª letra → ${fixed}.`)
    four = fixed
  }
  if (/Ñ/.test(p + m + name.word)) notes.push('La Ñ se sustituye por X en la clave.')
  if (/[^A-ZÑ]/.test(p + m + name.word)) notes.push('Los caracteres especiales en posiciones de la clave se sustituyen por X.')
  if (input.entidad === 'NE') notes.push('Nacido en el extranjero: entidad NE.')
  if (input.sexo === 'X') notes.push('Sexo X (no binario), conforme a la modificación de 2021.')

  const base16 =
    four +
    date.yymmdd +
    input.sexo +
    input.entidad +
    curpInternalConsonant(p) +
    (m ? curpInternalConsonant(m) : 'X') +
    curpInternalConsonant(name.word)

  return { base: { base16, notes, century: date.year < 2000 ? 1900 : 2000 }, errors: [] }
}

/** Up to 5 CURP candidates: the 17th character in RENAPO's assignment order. */
export function generateCurp(input: CurpInput, limit = 5): GenerationResult {
  const { base, errors } = buildCurpBase(input)
  if (!base) return { ok: false, errors, candidates: [], notes: [] }

  const series = base.century === 1900 ? '0123456789' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const candidates: Candidate[] = []
  for (let i = 0; i < Math.min(limit, series.length); i++) {
    const first17 = base.base16 + series[i]
    candidates.push({
      id: first17 + curpCheckDigit(first17),
      rank: i + 1,
      status: 'estructura-valida',
      statusLabel: 'Estructura válida',
      reason:
        i === 0
          ? `Diferenciador «${series[i]}»: primera asignación de RENAPO (sin homónimos previos).`
          : `Diferenciador «${series[i]}»: asignación n.º ${i + 1}, solo si existen ${i} homónimo(s) anteriores.`,
    })
  }
  return {
    ok: true,
    errors: [],
    candidates,
    notes: [
      ...base.notes,
      `Posiciones 1 a 16 calculadas: ${base.base16}.`,
      `Posición 17 (diferenciador) la asigna RENAPO: ${base.century === 1900 ? 'dígito 0-9 para nacidos antes de 2000' : 'letra A-Z para nacidos desde 2000'}.`,
      'Posición 18: dígito verificador calculado con el algoritmo oficial de módulo 10.',
    ],
  }
}

/* ------------------------------------------------------------------ */
/* RFC persona física                                                  */
/* ------------------------------------------------------------------ */

function rfcClean(word: string): string {
  return word.replace(/[^A-ZÑ]/g, '')
}

function rfcInternalVowel(word: string): string | null {
  for (let i = 1; i < word.length; i++) if (VOWELS.includes(word[i])) return word[i]
  return null
}

const HOMOCLAVE_CODES: Record<string, string> = (() => {
  const map: Record<string, string> = { ' ': '00', '&': '10', Ñ: '40' }
  for (let d = 0; d <= 9; d++) map[String(d)] = `0${d}`
  'ABCDEFGHI'.split('').forEach((c, i) => (map[c] = String(11 + i)))
  'JKLMNOPQR'.split('').forEach((c, i) => (map[c] = String(21 + i)))
  'STUVWXYZ'.split('').forEach((c, i) => (map[c] = String(32 + i)))
  return map
})()

/** Two homoclave characters from the full name (publicly documented SAT procedure). */
export function rfcHomoclave(fullName: string): string {
  const digits = '0' + fullName.split('').map((c) => HOMOCLAVE_CODES[c] ?? '00').join('')
  let sum = 0
  for (let i = 0; i < digits.length - 1; i++) {
    sum += Number(digits[i] + digits[i + 1]) * Number(digits[i + 1])
  }
  const last3 = sum % 1000
  return HOMOCLAVE_TABLE[Math.floor(last3 / 34)] + HOMOCLAVE_TABLE[last3 % 34]
}

const RFC_DV_VALUES = '0123456789ABCDEFGHIJKLMN&OPQRSTUVWXYZ Ñ'

/** Check digit (13th char física / 12th moral). Moral keys are padded with a leading space. */
export function rfcCheckDigit(withoutDigit: string): string {
  const s = withoutDigit.length === 11 ? ' ' + withoutDigit : withoutDigit
  if (s.length !== 12) return '?'
  let sum = 0
  for (let i = 0; i < 12; i++) {
    const v = RFC_DV_VALUES.indexOf(s[i])
    if (v < 0) return '?'
    sum += v * (13 - i)
  }
  const r = sum % 11
  if (r === 0) return '0'
  const d = 11 - r
  return d === 10 ? 'A' : String(d)
}

export interface RfcBase {
  base10: string
  fullName: string
  notes: string[]
}

export function buildRfcBase(input: PersonInput): { base: RfcBase | null; errors: string[] } {
  const errors = validatePersonFields(input)
  const date = parseBirthDate(input.fechaNacimiento)
  if (typeof date === 'string') errors.push(date)
  if (errors.length || typeof date === 'string') return { base: null, errors }

  const notes: string[] = []
  const first = significantSurname(input.primerApellido, 'Apellido paterno')
  const second = significantSurname(input.segundoApellido, 'Apellido materno')
  const name = significantName(input.nombre)!
  notes.push(...(first?.notes ?? []), ...(second?.notes ?? []), ...name.notes)

  const p = first ? rfcClean(first.word) : ''
  const m = second ? rfcClean(second.word) : ''
  const n = rfcClean(name.word)
  if (!n) return { base: null, errors: ['El nombre no contiene letras utilizables.'] }

  let four: string
  if (!p || !m) {
    const only = p || m
    four = (only.slice(0, 2) + n.slice(0, 2)).padEnd(4, 'X')
    notes.push('Un solo apellido: 1.ª y 2.ª letras del apellido + 1.ª y 2.ª letras del nombre.')
  } else if (p.length <= 2) {
    four = (p[0] + m[0] + n.slice(0, 2)).padEnd(4, 'X')
    notes.push('Apellido paterno de 1 o 2 letras: 1.ª letra de cada apellido + 2 primeras del nombre.')
  } else {
    const vowel = rfcInternalVowel(p)
    if (!vowel) notes.push('El apellido paterno no tiene vocal interna: se usa X (requiere verificación).')
    four = p[0] + (vowel ?? 'X') + m[0] + n[0]
  }
  if (RFC_INCONVENIENT.has(four)) {
    const fixed = four.slice(0, 3) + 'X'
    notes.push(`Palabra inconveniente «${four}»: se sustituye la última letra → ${fixed}.`)
    four = fixed
  }

  const fullName = [input.primerApellido, input.segundoApellido, input.nombre]
    .map((v) => normalizeText(v).replace(/[^A-ZÑ& ]/g, ''))
    .filter(Boolean)
    .join(' ')

  return { base: { base10: four + date.yymmdd, fullName, notes }, errors: [] }
}

const HOMOCLAVE_DISCLAIMER =
  'La homoclave (posiciones 11-12) se calcula con el procedimiento público del SAT; el SAT puede asignar otra en caso de homonimia. Solo el SAT confirma un RFC.'

export function generateRfcFromData(input: PersonInput): GenerationResult {
  const { base, errors } = buildRfcBase(input)
  if (!base) return { ok: false, errors, candidates: [], notes: [] }
  const first12 = base.base10 + rfcHomoclave(base.fullName)
  const uncertain = base.notes.some((n) => n.includes('requiere verificación'))
  const candidates: Candidate[] = [
    {
      id: first12 + rfcCheckDigit(first12),
      rank: 1,
      status: uncertain ? 'verificar' : 'estructura-valida',
      statusLabel: uncertain ? 'Requiere verificación' : 'Estructura válida',
      reason: 'Clave inicial y fecha conforme a las reglas del SAT; homoclave y dígito verificador calculados.',
    },
  ]
  const alternatives = rfcAlternativeCandidates(input, base, candidates[0].id)
  candidates.push(...alternatives)
  return {
    ok: true,
    errors: [],
    candidates,
    notes: [
      ...base.notes,
      `Clave inicial y fecha (AAMMDD): ${base.base10}.`,
      HOMOCLAVE_DISCLAIMER,
      alternatives.length
        ? 'Los resultados adicionales solo aplican una interpretación alternativa documentada de la regla de nombres compuestos; no son homoclaves por homonimia.'
        : 'Solo existe un resultado justificable: los datos no activan ninguna interpretación alternativa documentada y no se generan homoclaves inventadas.',
    ],
  }
}

/**
 * Extra candidates only when the input activates a documented alternative reading
 * of the SAT rules. Today that is a compound first name starting with MARÍA / JOSÉ
 * (or MA. / J.): SAT skips it, but keys registered with that first name exist.
 * The homoclave is computed from the same full name, so only positions 1-4 and the
 * check digit change. The primary candidate is never recomputed here.
 */
function rfcAlternativeCandidates(input: PersonInput, base: RfcBase, primaryId: string): Candidate[] {
  const nameWords = stripParticles(words(input.nombre)).kept
  if (nameWords.length < 2 || !SKIPPABLE_FIRST_NAMES.has(nameWords[0])) return []

  const alt = buildRfcBase({ ...input, nombre: nameWords[0] }).base
  if (!alt) return []
  const first12 = alt.base10 + rfcHomoclave(base.fullName)
  const id = first12 + rfcCheckDigit(first12)
  if (id === primaryId) return []
  return [
    {
      id,
      rank: 2,
      status: 'verificar',
      statusLabel: 'Requiere verificación',
      reason: `Interpretación alternativa: se conserva «${nameWords[0]}» como nombre en la clave inicial (la regla del SAT lo omite). Homoclave del nombre completo.`,
    },
  ]
}

export function cleanKey(value: string): string {
  return normalizeText(value).replace(/[\s\-_.]/g, '')
}

/**
 * RFC from a CURP. Positions 1-10 usually coincide; the CURP alone cannot
 * produce the homoclave, so it is only computed when the full name is given.
 */
export function generateRfcFromCurp(curpInput: string, names?: Partial<PersonInput>): GenerationResult {
  const curp = cleanKey(curpInput)
  const validation = validateCurp(curp)
  if (validation.status === 'invalida') {
    return { ok: false, errors: [`La CURP no es válida: ${validation.summary}`], candidates: [], notes: [] }
  }

  const yy = Number(curp.slice(4, 6))
  const century = /[A-Z]/.test(curp[16]) ? 2000 : 1900
  const iso = `${century + yy}-${curp.slice(6, 8)}-${curp.slice(8, 10)}`
  const curpBase10 = curp.slice(0, 10)

  const notes: string[] = [`De la CURP se toman la clave inicial y la fecha: ${curpBase10}.`]
  const ambiguities: string[] = []
  if (curp[2] === 'X') ambiguities.push('La posición 3 es X: si la persona no tiene segundo apellido, el RFC usa otra regla (2 letras del apellido y 2 del nombre).')
  if (curp[1] === 'X') ambiguities.push('La posición 2 es X: puede deberse a una palabra inconveniente de la CURP; el SAT usa otra lista y otra sustitución.')
  if (/X/.test(curp.slice(0, 4)) && !ambiguities.length) ambiguities.push('Hay una X en la clave inicial: puede sustituir a una Ñ o a un carácter especial, que el RFC trata distinto.')
  notes.push(...ambiguities)

  const hasNames = Boolean(names?.nombre?.trim() && (names?.primerApellido?.trim() || names?.segundoApellido?.trim()))
  if (!hasNames) {
    return {
      ok: true,
      errors: [],
      candidates: [
        {
          id: curpBase10,
          rank: 1,
          status: ambiguities.length ? 'verificar' : 'parcial',
          statusLabel: ambiguities.length ? 'Parcial · requiere verificación' : 'Parcial · sin homoclave',
          reason: 'Clave inicial y fecha derivadas de la CURP. La homoclave no puede determinarse sin el nombre completo.',
        },
      ],
      notes: [...notes, 'Escribe el nombre y apellidos para calcular la homoclave y el dígito verificador.'],
    }
  }

  const fromData = generateRfcFromData({
    nombre: names!.nombre ?? '',
    primerApellido: names!.primerApellido ?? '',
    segundoApellido: names!.segundoApellido ?? '',
    fechaNacimiento: iso,
  })
  if (!fromData.ok) return fromData

  const rfc = fromData.candidates[0]
  const curpCheck = buildCurpBase({
    nombre: names!.nombre ?? '',
    primerApellido: names!.primerApellido ?? '',
    segundoApellido: names!.segundoApellido ?? '',
    fechaNacimiento: iso,
    sexo: curp[10] as Sex,
    entidad: curp.slice(11, 13),
  })
  const namesMatch = curpCheck.base?.base16 === curp.slice(0, 16)
  const consistent = rfc.id.slice(0, 10) === curpBase10

  const extra: string[] = []
  if (!namesMatch) extra.push('El nombre escrito no reproduce las posiciones 1-16 de la CURP: revisa los datos.')
  if (!consistent) extra.push(`La clave inicial del RFC (${rfc.id.slice(0, 10)}) difiere de la CURP (${curpBase10}) por las reglas propias del SAT.`)

  return {
    ok: true,
    errors: [],
    candidates: [
      {
        ...rfc,
        status: namesMatch ? rfc.status : 'verificar',
        statusLabel: namesMatch ? rfc.statusLabel : 'Requiere verificación',
        reason: namesMatch
          ? 'Nombre coherente con la CURP; homoclave y dígito verificador calculados.'
          : 'Calculado con el nombre escrito, que no coincide con la CURP.',
      },
    ],
    notes: [...notes, ...extra, ...fromData.notes],
  }
}

/* ------------------------------------------------------------------ */
/* Validator                                                           */
/* ------------------------------------------------------------------ */

function summarize(checks: Check[]): { status: Status; summary: string } {
  const failed = checks.filter((c) => c.ok === false)
  const unsure = checks.filter((c) => c.ok === null)
  if (failed.length) return { status: 'invalida', summary: failed.map((c) => c.detail).join(' ') }
  if (unsure.length) return { status: 'verificar', summary: unsure.map((c) => c.detail).join(' ') }
  return { status: 'valida', summary: 'La estructura cumple todas las reglas verificables.' }
}

export function validateCurp(input: string): ValidationResult {
  const curp = cleanKey(input)
  const checks: Check[] = []
  const lengthOk = curp.length === 18
  checks.push({ label: 'Longitud', ok: lengthOk, detail: lengthOk ? '18 caracteres.' : `Debe tener 18 caracteres (tiene ${curp.length}).` })
  if (!lengthOk) return { kind: 'CURP', value: curp, ...summarize(checks), checks }

  const letters = /^[A-Z][AEIOUX][A-Z]{2}$/.test(curp.slice(0, 4))
  checks.push({
    label: 'Posiciones 1-4',
    ok: letters,
    detail: letters ? 'Letras de apellidos y nombre; la 2.ª es vocal o X.' : 'Deben ser 4 letras y la 2.ª una vocal o X.',
  })
  if (letters) {
    const bad = CURP_INCONVENIENT.has(curp.slice(0, 4))
    checks.push({
      label: 'Palabra inconveniente',
      ok: !bad,
      detail: bad ? `«${curp.slice(0, 4)}» está en el Anexo 2: la 2.ª letra debía ser X.` : 'No forma una palabra inconveniente.',
    })
  }

  const diff = curp[16]
  const diffOk = /[A-Z0-9]/.test(diff)
  const century = /[A-Z]/.test(diff) ? 2000 : 1900
  const dateDigits = curp.slice(4, 10)
  let dateOk = false
  if (/^\d{6}$/.test(dateDigits)) {
    const y = century + Number(dateDigits.slice(0, 2))
    const mo = Number(dateDigits.slice(2, 4))
    const d = Number(dateDigits.slice(4, 6))
    dateOk = isRealDate(y, mo, d) && Date.UTC(y, mo - 1, d) <= Date.now()
    checks.push({
      label: 'Fecha (5-10)',
      ok: dateOk,
      detail: dateOk ? `${String(d).padStart(2, '0')}/${String(mo).padStart(2, '0')}/${y}.` : 'La fecha no existe o está en el futuro.',
    })
  } else {
    checks.push({ label: 'Fecha (5-10)', ok: false, detail: 'Las posiciones 5-10 deben ser dígitos AAMMDD.' })
  }

  const sexOk = /[HMX]/.test(curp[10])
  checks.push({ label: 'Sexo (11)', ok: sexOk, detail: sexOk ? { H: 'Hombre.', M: 'Mujer.', X: 'No binario.' }[curp[10]]! : 'Debe ser H, M o X.' })

  const state = STATES.find((s) => s.code === curp.slice(11, 13))
  checks.push({ label: 'Entidad (12-13)', ok: Boolean(state), detail: state ? `${state.name}.` : `«${curp.slice(11, 13)}» no es una entidad válida.` })

  const consOk = /^[B-DF-HJ-NP-TV-Z]{3}$/.test(curp.slice(13, 16))
  checks.push({ label: 'Consonantes (14-16)', ok: consOk, detail: consOk ? 'Consonantes internas o X.' : 'Deben ser consonantes (o X).' })

  checks.push({
    label: 'Diferenciador (17)',
    ok: diffOk,
    detail: diffOk ? `«${diff}»: asignado por RENAPO (${century === 1900 ? 'nacido antes de 2000' : 'nacido desde 2000'}).` : 'Debe ser letra o dígito.',
  })

  const expected = curpCheckDigit(curp.slice(0, 17))
  const dvOk = /\d/.test(curp[17]) && expected === curp[17]
  checks.push({ label: 'Dígito verificador (18)', ok: dvOk, detail: dvOk ? `Correcto (${expected}).` : `No coincide: se esperaba ${expected}.` })

  checks.push({ label: 'Existencia oficial', ok: null, detail: 'La validez estructural no confirma que la CURP esté registrada; solo RENAPO lo confirma.' })

  const s = summarize(checks.slice(0, -1))
  return {
    kind: 'CURP',
    value: curp,
    status: s.status,
    summary: s.status === 'valida' ? 'Estructura válida. Su registro solo puede confirmarlo RENAPO.' : s.summary,
    checks,
  }
}

const GENERIC_RFC: Record<string, string> = {
  XAXX010101000: 'RFC genérico nacional (público en general).',
  XEXX010101000: 'RFC genérico para residentes en el extranjero.',
}

export function validateRfc(input: string): ValidationResult {
  const rfc = cleanKey(input)
  if (GENERIC_RFC[rfc]) {
    return {
      kind: 'RFC genérico',
      value: rfc,
      status: 'valida',
      summary: GENERIC_RFC[rfc],
      checks: [{ label: 'Tipo', ok: true, detail: GENERIC_RFC[rfc] }],
    }
  }
  const checks: Check[] = []
  const kind = rfc.length === 13 ? 'RFC física' : rfc.length === 12 ? 'RFC moral' : 'Desconocido'
  checks.push({
    label: 'Longitud',
    ok: kind !== 'Desconocido',
    detail:
      kind === 'RFC física'
        ? '13 caracteres: persona física.'
        : kind === 'RFC moral'
          ? '12 caracteres: persona moral.'
          : `Debe tener 13 (física) o 12 (moral) caracteres; tiene ${rfc.length}.`,
  })
  if (kind === 'Desconocido') return { kind, value: rfc, ...summarize(checks), checks }

  const letterCount = kind === 'RFC física' ? 4 : 3
  const head = rfc.slice(0, letterCount)
  const headOk = new RegExp(`^[A-ZÑ&]{${letterCount}}$`).test(head)
  checks.push({ label: `Clave inicial (1-${letterCount})`, ok: headOk, detail: headOk ? `${letterCount} letras.` : `Deben ser ${letterCount} letras (se permiten Ñ y &).` })
  if (headOk && kind === 'RFC física') {
    const bad = RFC_INCONVENIENT.has(head)
    checks.push({ label: 'Palabra inconveniente', ok: !bad, detail: bad ? `«${head}» es inconveniente: la última letra debía ser X.` : 'No forma una palabra inconveniente.' })
  }

  const date = rfc.slice(letterCount, letterCount + 6)
  let dateOk = false
  if (/^\d{6}$/.test(date)) {
    const yy = Number(date.slice(0, 2))
    const mo = Number(date.slice(2, 4))
    const d = Number(date.slice(4, 6))
    dateOk = isRealDate(1900 + yy, mo, d) || isRealDate(2000 + yy, mo, d)
  }
  checks.push({
    label: 'Fecha AAMMDD',
    ok: dateOk,
    detail: dateOk ? `${date}: ${kind === 'RFC física' ? 'nacimiento' : 'constitución'} válida.` : `«${date}» no es una fecha AAMMDD válida.`,
  })

  const hc = rfc.slice(letterCount + 6, letterCount + 8)
  const hcOk = /^[A-Z0-9]{2}$/.test(hc)
  checks.push({ label: 'Homoclave', ok: hcOk, detail: hcOk ? `«${hc}»: asignada por el SAT.` : 'Deben ser 2 letras o dígitos.' })

  const dv = rfc[rfc.length - 1]
  const expected = rfcCheckDigit(rfc.slice(0, -1))
  if (!/[0-9A]/.test(dv)) {
    checks.push({ label: 'Dígito verificador', ok: false, detail: 'Debe ser un dígito o la letra A.' })
  } else {
    checks.push({
      label: 'Dígito verificador',
      ok: expected === dv ? true : null,
      detail: expected === dv ? `Correcto (${dv}).` : `No coincide con el cálculo público (${expected}); algunos RFC antiguos difieren: verifica con el SAT.`,
    })
  }

  const s = summarize(checks)
  return {
    kind,
    value: rfc,
    status: s.status,
    summary: s.status === 'valida' ? 'Estructura válida. Su registro solo puede confirmarlo el SAT.' : s.summary,
    checks: [...checks, { label: 'Existencia oficial', ok: null, detail: 'La validez estructural no confirma que el RFC esté registrado; solo el SAT lo confirma.' }],
  }
}

/** Detects whether the key looks like a CURP or an RFC and validates it. */
export function validateKey(input: string): ValidationResult {
  const value = cleanKey(input)
  if (!value) {
    return { kind: 'Desconocido', value, status: 'invalida', summary: 'Escribe una CURP o un RFC.', checks: [] }
  }
  if (value.length === 18) return validateCurp(value)
  if (value.length === 12 || value.length === 13) return validateRfc(value)
  return {
    kind: 'Desconocido',
    value,
    status: 'invalida',
    summary: `Longitud ${value.length}: una CURP tiene 18 caracteres y un RFC 13 (física) o 12 (moral).`,
    checks: [],
  }
}

/* ------------------------------------------------------------------ */
/* CSV batch                                                           */
/* ------------------------------------------------------------------ */

export function parseCsv(text: string): string[][] {
  const src = text.replace(/^\uFEFF/, '')
  const firstLine = src.split(/\r?\n/, 1)[0] ?? ''
  const delimiter = (firstLine.match(/;/g)?.length ?? 0) > (firstLine.match(/,/g)?.length ?? 0) ? ';' : ','
  const rows: string[][] = []
  let row: string[] = []
  let cell = ''
  let quoted = false
  for (let i = 0; i < src.length; i++) {
    const c = src[i]
    if (quoted) {
      if (c === '"' && src[i + 1] === '"') {
        cell += '"'
        i++
      } else if (c === '"') quoted = false
      else cell += c
    } else if (c === '"') quoted = true
    else if (c === delimiter) {
      row.push(cell)
      cell = ''
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++
      row.push(cell)
      rows.push(row)
      row = []
      cell = ''
    } else cell += c
  }
  if (cell || row.length) {
    row.push(cell)
    rows.push(row)
  }
  return rows.filter((r) => r.some((c) => c.trim()))
}

function csvCell(value: string): string {
  const safe = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value
  return /[",;\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe
}

export function toCsv(rows: string[][]): string {
  return '\uFEFF' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n'
}

const HEADER_ALIASES: Record<keyof CurpInput, string[]> = {
  nombre: ['NOMBRE', 'NOMBRES', 'NOMBRE(S)'],
  primerApellido: ['PRIMER_APELLIDO', 'PRIMER APELLIDO', 'APELLIDO_PATERNO', 'APELLIDO PATERNO', 'PATERNO'],
  segundoApellido: ['SEGUNDO_APELLIDO', 'SEGUNDO APELLIDO', 'APELLIDO_MATERNO', 'APELLIDO MATERNO', 'MATERNO'],
  fechaNacimiento: ['FECHA_NACIMIENTO', 'FECHA DE NACIMIENTO', 'FECHA NACIMIENTO', 'FECHA', 'NACIMIENTO'],
  sexo: ['SEXO'],
  entidad: ['ENTIDAD', 'ENTIDAD_NACIMIENTO', 'ENTIDAD DE NACIMIENTO', 'ESTADO', 'ESTADO_NACIMIENTO'],
}

export const CSV_TEMPLATE =
  'nombre,primer_apellido,segundo_apellido,fecha_nacimiento,sexo,entidad\r\nEMMA,GOMEZ,DIAZ,1956-12-31,M,DF\r\n'

export function normalizeCsvDate(value: string): string {
  const v = value.trim()
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v
  const m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/.exec(v)
  return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : v
}

export function normalizeSex(value: string): Sex | '' {
  const v = normalizeText(value)
  if (['H', 'HOMBRE', 'MASCULINO'].includes(v)) return 'H'
  if (['M', 'MUJER', 'FEMENINO'].includes(v)) return 'M'
  if (['X', 'NO BINARIO', 'NO BINARIE'].includes(v)) return 'X'
  return ''
}

export function normalizeEntity(value: string): string {
  const v = normalizeText(value)
  if (STATE_CODES.has(v)) return v
  const byName = STATES.find((s) => normalizeText(s.name) === v)
  if (byName) return byName.code
  if (['CDMX', 'DISTRITO FEDERAL', 'CIUDAD DE MEXICO'].includes(v)) return 'DF'
  if (['MEXICO', 'EDOMEX', 'ESTADO DE MEXICO'].includes(v)) return 'MC'
  if (['EXTRANJERO', 'NACIDO EN EL EXTRANJERO'].includes(v)) return 'NE'
  return v
}

export interface BatchRow {
  row: number
  input: CurpInput
  curp: string
  curpBase: string
  rfc: string
  status: 'ok' | 'error' | 'duplicado'
  message: string
}

export const MAX_BATCH_ROWS = 5000

export function processBatch(text: string): { rows: BatchRow[]; error: string | null } {
  const table = parseCsv(text)
  if (table.length < 2) return { rows: [], error: 'El CSV debe tener una fila de encabezados y al menos un registro.' }
  const header = table[0].map((h) => normalizeText(h))
  const index = {} as Record<keyof CurpInput, number>
  const missing: string[] = []
  for (const key of Object.keys(HEADER_ALIASES) as (keyof CurpInput)[]) {
    index[key] = header.findIndex((h) => HEADER_ALIASES[key].includes(h))
    if (index[key] < 0 && key !== 'segundoApellido') missing.push(HEADER_ALIASES[key][0].toLowerCase())
  }
  if (missing.length) return { rows: [], error: `Faltan columnas: ${missing.join(', ')}.` }
  if (table.length - 1 > MAX_BATCH_ROWS) return { rows: [], error: `Máximo ${MAX_BATCH_ROWS} registros por archivo.` }

  const seen = new Map<string, number>()
  const rows: BatchRow[] = []
  for (let r = 1; r < table.length; r++) {
    const cells = table[r]
    const get = (k: keyof CurpInput) => (index[k] >= 0 ? (cells[index[k]] ?? '').trim() : '')
    const input: CurpInput = {
      nombre: get('nombre'),
      primerApellido: get('primerApellido'),
      segundoApellido: get('segundoApellido'),
      fechaNacimiento: normalizeCsvDate(get('fechaNacimiento')),
      sexo: normalizeSex(get('sexo')),
      entidad: normalizeEntity(get('entidad')),
    }
    const rowNumber = r + 1
    const key = [input.nombre, input.primerApellido, input.segundoApellido].map(normalizeText).join('|') +
      `|${input.fechaNacimiento}|${input.sexo}|${input.entidad}`
    const dup = seen.get(key)
    if (dup) {
      rows.push({ row: rowNumber, input, curp: '', curpBase: '', rfc: '', status: 'duplicado', message: `Duplicado de la fila ${dup}.` })
      continue
    }
    seen.set(key, rowNumber)

    const curp = generateCurp(input, 1)
    const rfc = generateRfcFromData(input)
    if (!curp.ok) {
      rows.push({ row: rowNumber, input, curp: '', curpBase: '', rfc: '', status: 'error', message: curp.errors.join(' ') })
      continue
    }
    rows.push({
      row: rowNumber,
      input,
      curp: curp.candidates[0].id,
      curpBase: curp.candidates[0].id.slice(0, 16),
      rfc: rfc.ok ? rfc.candidates[0].id : '',
      status: 'ok',
      message: 'Estructura calculada; no confirma registro oficial.',
    })
  }
  return { rows, error: null }
}

export interface CurpListRow {
  line: number
  input: string
  curp: string
  status: 'valida' | 'invalida' | 'duplicada'
  detail: string
}

/** Splits pasted text into CURP entries: one per line, or separated by commas, semicolons or tabs. */
export function splitCurpList(text: string): { line: number; raw: string }[] {
  const out: { line: number; raw: string }[] = []
  text.split(/\r\n|\r|\n/).forEach((lineText, i) => {
    for (const part of lineText.split(/[,;\t|]+/)) {
      const raw = part.trim().replace(/^["']|["']$/g, '').trim()
      if (!raw) continue
      const words = raw.split(/\s+/)
      // A line may hold several space-separated CURPs (e.g. pasted from a cell range).
      if (words.length > 1 && words.every((w) => cleanKey(w).length === 18)) words.forEach((w) => out.push({ line: i + 1, raw: w }))
      else out.push({ line: i + 1, raw })
    }
  })
  return out
}

export function validateCurpList(text: string): { rows: CurpListRow[]; error: string | null } {
  const entries = splitCurpList(text)
  if (!entries.length) return { rows: [], error: 'Pega al menos una CURP.' }
  if (entries.length > MAX_BATCH_ROWS) return { rows: [], error: `Máximo ${MAX_BATCH_ROWS} CURP por lista.` }
  const seen = new Map<string, number>()
  const rows: CurpListRow[] = []
  for (const { line, raw } of entries) {
    const curp = cleanKey(raw)
    const dup = seen.get(curp)
    if (dup) {
      rows.push({ line, input: raw, curp, status: 'duplicada', detail: `Repetida (línea ${dup}).` })
      continue
    }
    seen.set(curp, line)
    const r = validateCurp(raw)
    rows.push({
      line,
      input: raw,
      curp,
      status: r.status === 'valida' ? 'valida' : 'invalida',
      detail: r.status === 'valida' ? 'Estructura correcta.' : r.summary,
    })
  }
  return { rows, error: null }
}

export function curpListToCsv(rows: CurpListRow[]): string {
  return toCsv([
    ['linea', 'curp', 'estado', 'detalle'],
    ...rows.map((r) => [String(r.line), r.curp, r.status, r.detail]),
  ])
}

export function batchToCsv(rows: BatchRow[]): string {
  return toCsv([
    ['fila_origen', 'nombre', 'primer_apellido', 'segundo_apellido', 'fecha_nacimiento', 'sexo', 'entidad', 'curp_posiciones_1_16', 'curp_candidato_1', 'rfc_calculado', 'estado', 'detalle'],
    ...rows.map((r) => [
      String(r.row),
      r.input.nombre,
      r.input.primerApellido,
      r.input.segundoApellido,
      r.input.fechaNacimiento,
      r.input.sexo,
      r.input.entidad,
      r.curpBase,
      r.curp,
      r.rfc,
      r.status,
      r.message,
    ]),
  ])
}

/* ------------------------------------------------------------------ */
/* CURP correction suggestions                                         */
/* ------------------------------------------------------------------ */

export interface CurpCorrection {
  value: string
  kind: 'matematica' | 'estructural' | 'probable'
  reason: string
}

const CURP_LETTER_POSITIONS = [0, 1, 2, 3, 11, 12, 13, 14, 15]
const CURP_DIGIT_POSITIONS = [4, 5, 6, 7, 8, 9, 17]
const DIGIT_TO_LETTER: Record<string, string> = { '0': 'O', '1': 'I', '2': 'Z', '5': 'S', '6': 'G', '8': 'B' }
const LETTER_TO_DIGIT: Record<string, string> = { O: '0', Q: '0', D: '0', I: '1', L: '1', Z: '2', S: '5', G: '6', B: '8' }
const MAX_CURP_CORRECTIONS = 6

function curpFirst17Ok(first17: string): boolean {
  if (!/^[A-Z][AEIOUX][A-Z]{2}\d{6}[HMX][A-Z]{2}[B-DF-HJ-NP-TV-Z]{3}[A-Z0-9]$/.test(first17)) return false
  if (CURP_INCONVENIENT.has(first17.slice(0, 4))) return false
  if (!STATES.some((s) => s.code === first17.slice(11, 13))) return false
  const century = /[A-Z]/.test(first17[16]) ? 2000 : 1900
  const y = century + Number(first17.slice(4, 6))
  const mo = Number(first17.slice(6, 8))
  const d = Number(first17.slice(8, 10))
  return isRealDate(y, mo, d) && Date.UTC(y, mo - 1, d) <= Date.now()
}

function curpFullyValid(curp: string): boolean {
  return curp.length === 18 && curpFirst17Ok(curp.slice(0, 17)) && curpCheckDigit(curp.slice(0, 17)) === curp[17]
}

/** Only swaps letters/digits that are commonly confused, and only where the position requires the other type. */
function fixCurpCharTypes(curp: string): { fixed: string; notes: string[] } {
  const chars = curp.split('')
  const notes: string[] = []
  for (const p of CURP_LETTER_POSITIONS) {
    const to = DIGIT_TO_LETTER[chars[p]]
    if (to) {
      notes.push(`Posición ${p + 1}: «${chars[p]}» → «${to}» (número en lugar de letra).`)
      chars[p] = to
    }
  }
  for (const p of CURP_DIGIT_POSITIONS) {
    const to = LETTER_TO_DIGIT[chars[p]]
    if (to) {
      notes.push(`Posición ${p + 1}: «${chars[p]}» → «${to}» (letra en lugar de número).`)
      chars[p] = to
    }
  }
  const head = chars.slice(0, 4).join('')
  if (CURP_INCONVENIENT.has(head)) {
    notes.push(`«${head}» es palabra inconveniente (Anexo 2): la 2.ª letra se sustituye por X.`)
    chars[1] = 'X'
  }
  return { fixed: chars.join(''), notes }
}

/**
 * Corrections that can be derived from the key itself. Every suggestion passes
 * the full structural validation; none adds personal data that is not already
 * in the key, and none confirms registration with RENAPO.
 */
export function suggestCurpCorrections(input: string): CurpCorrection[] {
  const curp = cleanKey(input)
  if (!curp || curpFullyValid(curp)) return []
  const found = new Map<string, CurpCorrection>()
  const add = (value: string, kind: CurpCorrection['kind'], reason: string) => {
    if (value !== curp && !found.has(value) && curpFullyValid(value)) found.set(value, { value, kind, reason })
  }

  if (curp.length === 18) {
    const first17 = curp.slice(0, 17)
    if (curpFirst17Ok(first17)) {
      const dv = curpCheckDigit(first17)
      add(first17 + dv, 'matematica', `Dígito verificador recalculado: «${curp[17]}» → «${dv}». Las posiciones 1-17 no cambian.`)
    } else {
      const { fixed, notes } = fixCurpCharTypes(curp)
      if (notes.length && curpFirst17Ok(fixed.slice(0, 17))) {
        const dv = curpCheckDigit(fixed.slice(0, 17))
        if (dv === fixed[17]) {
          add(fixed, 'estructural', `${notes.join(' ')} El dígito verificador coincide con la corrección.`)
        } else {
          add(fixed.slice(0, 17) + dv, 'probable', `${notes.join(' ')} También se recalculó el dígito verificador: «${fixed[17]}» → «${dv}».`)
        }
      }
    }
    for (let i = 0; i < 17; i++) {
      if (curp[i] === curp[i + 1]) continue
      const swapped = curp.slice(0, i) + curp[i + 1] + curp[i] + curp.slice(i + 2)
      add(swapped, 'probable', `Caracteres invertidos: se intercambian las posiciones ${i + 1} y ${i + 2} («${curp[i]}${curp[i + 1]}» → «${curp[i + 1]}${curp[i]}»).`)
    }
  } else if (curp.length === 17) {
    if (curpFirst17Ok(curp)) {
      const dv = curpCheckDigit(curp)
      add(curp + dv, 'matematica', `Falta el dígito verificador (posición 18): se calcula «${dv}».`)
    }
  } else if (curp.length === 19) {
    for (let i = 0; i < 19; i++) {
      add(curp.slice(0, i) + curp.slice(i + 1), 'probable', `Sobra un carácter: se elimina «${curp[i]}» de la posición ${i + 1}.`)
    }
  }

  const order = { matematica: 0, estructural: 1, probable: 2 }
  return [...found.values()].sort((a, b) => order[a.kind] - order[b.kind]).slice(0, MAX_CURP_CORRECTIONS)
}

export type DiffPart = { type: 'same' | 'removed' | 'added'; text: string }

/** Character-level LCS diff between two short keys. */
export function diffKeys(from: string, to: string): { original: DiffPart[]; proposed: DiffPart[] } {
  const n = from.length
  const m = to.length
  const lcs: number[][] = Array.from({ length: n + 1 }, () => new Array<number>(m + 1).fill(0))
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      lcs[i][j] = from[i] === to[j] ? lcs[i + 1][j + 1] + 1 : Math.max(lcs[i + 1][j], lcs[i][j + 1])
    }
  }
  const original: DiffPart[] = []
  const proposed: DiffPart[] = []
  const push = (list: DiffPart[], type: DiffPart['type'], ch: string) => {
    const last = list[list.length - 1]
    if (last && last.type === type) last.text += ch
    else list.push({ type, text: ch })
  }
  let i = 0
  let j = 0
  while (i < n || j < m) {
    if (i < n && j < m && from[i] === to[j]) {
      push(original, 'same', from[i++])
      push(proposed, 'same', to[j++])
    } else if (j < m && (i >= n || lcs[i][j + 1] >= lcs[i + 1][j])) {
      push(proposed, 'added', to[j++])
    } else {
      push(original, 'removed', from[i++])
    }
  }
  return { original, proposed }
}
