import { recognizeImage } from '@/lib/ocr/tesseract'
import { itemsToLines, MIN_TEXT_CHARS, type TextItemLike } from '@/lib/pdf/extract-text'
import { openPdfDocument } from '@/lib/pdf/pdfjs'
import { checkFile, EXTRACT_LIMITS, type DocKind } from './limits'
import type { ErrorCode } from './modes'
import type { PageImage, Segment } from './schema'

export interface ReadOutput {
  segments: Segment[]
  images: PageImage[]
  warnings: string[]
  errors: string[]
  errorCode?: ErrorCode
}

class ReadError extends Error {
  constructor(
    readonly code: ErrorCode,
    message: string,
  ) {
    super(message)
  }
}

/** Validates name, size and real content type (magic bytes) of a picked file. */
export async function inspectFile(file: File): Promise<{ kind: DocKind } | { error: string }> {
  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer())
  return checkFile(file.name, file.size, head)
}

function releaseCanvas(canvas: HTMLCanvasElement) {
  canvas.width = 0
  canvas.height = 0
}

function scaledCanvas(source: CanvasImageSource, width: number, height: number, maxSide: number): HTMLCanvasElement {
  const scale = Math.min(1, maxSide / Math.max(width, height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(width * scale))
  canvas.height = Math.max(1, Math.round(height * scale))
  const ctx = canvas.getContext('2d')
  if (ctx) {
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height)
  }
  return canvas
}

function toJpegBase64(source: HTMLCanvasElement): string {
  const canvas = scaledCanvas(source, source.width, source.height, EXTRACT_LIMITS.maxImageSide)
  try {
    return canvas.toDataURL('image/jpeg', 0.82).split(',')[1] ?? ''
  } finally {
    releaseCanvas(canvas)
  }
}

/** Small first-page or image preview for the file list. Returns null when not renderable. */
export async function renderPreview(file: File, kind: DocKind): Promise<string | null> {
  try {
    if (kind === 'image') {
      const bitmap = await createImageBitmap(file)
      const canvas = scaledCanvas(bitmap, bitmap.width, bitmap.height, 160)
      bitmap.close()
      const url = canvas.toDataURL('image/jpeg', 0.7)
      releaseCanvas(canvas)
      return url
    }
    if (kind === 'pdf') {
      const { doc, close } = await openPdfDocument(new Uint8Array(await file.arrayBuffer()))
      try {
        const page = await doc.getPage(1)
        const base = page.getViewport({ scale: 1 })
        const viewport = page.getViewport({ scale: 160 / Math.max(base.width, base.height) })
        const canvas = document.createElement('canvas')
        canvas.width = Math.floor(viewport.width)
        canvas.height = Math.floor(viewport.height)
        const ctx = canvas.getContext('2d')
        if (!ctx) return null
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(0, 0, canvas.width, canvas.height)
        await page.render({ canvas, canvasContext: ctx, viewport }).promise
        const url = canvas.toDataURL('image/jpeg', 0.7)
        releaseCanvas(canvas)
        return url
      } finally {
        await close()
      }
    }
  } catch {
    return null
  }
  return null
}

export interface ReadTimings {
  /** Opening the file and extracting digital text / rendering pages. */
  readMs: number
  /** Local OCR; only runs for scanned pages beyond the image budget. */
  ocrMs: number
  imageBytes: number
}

/**
 * Reads one file on the device using the cheapest path:
 * - PDF with digital text, DOCX, TXT: text only.
 * - Photos and scanned PDF pages: one downscaled JPEG each, read directly by the
 *   vision model. Local OCR (2-15 s per page on a phone) only runs for scanned
 *   pages that do not fit in the image budget.
 */
export async function readDocument(
  file: File,
  kind: DocKind,
  onProgress: (fraction: number, label: string) => void,
  signal: AbortSignal,
): Promise<ReadOutput & { timings: ReadTimings }> {
  const out: ReadOutput = { segments: [], images: [], warnings: [], errors: [] }
  const t0 = performance.now()
  let ocrMs = 0
  let imageChars = 0

  const keepImage = (canvas: HTMLCanvasElement, page: number | null): boolean => {
    if (out.images.length >= EXTRACT_LIMITS.maxModelImages) return false
    const data = toJpegBase64(canvas)
    if (!data || imageChars + data.length > EXTRACT_LIMITS.maxImageBase64Chars) return false
    imageChars += data.length
    out.images.push({ file: file.name, page, data })
    return true
  }

  const finish = () => ({
    ...out,
    timings: { readMs: Math.round(performance.now() - t0 - ocrMs), ocrMs: Math.round(ocrMs), imageBytes: Math.round((imageChars * 3) / 4) },
  })

  try {
    if (kind === 'txt') {
      onProgress(0, `Leyendo ${file.name}`)
      out.segments.push({ file: file.name, page: null, method: 'txt', text: (await file.text()).slice(0, 60_000) })
    } else if (kind === 'docx') {
      onProgress(0, `Leyendo ${file.name}`)
      const mammoth = await import('mammoth')
      // extractRawText only reads document text; macros and embedded objects are never executed.
      const { value } = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })
      out.segments.push({ file: file.name, page: null, method: 'docx', text: value.slice(0, 60_000) })
      if (!value.trim()) out.warnings.push(`${file.name}: el documento no contiene texto.`)
    } else if (kind === 'image') {
      onProgress(0, `Preparando ${file.name}`)
      let bitmap: ImageBitmap
      try {
        bitmap = await createImageBitmap(file)
      } catch {
        throw new ReadError('ILEGIBLE', 'la imagen está dañada o no se puede abrir.')
      }
      const canvas = scaledCanvas(bitmap, bitmap.width, bitmap.height, EXTRACT_LIMITS.maxImageSide)
      bitmap.close()
      try {
        if (!keepImage(canvas, null)) throw new ReadError('LIMITE', 'la imagen supera el tamaño permitido.')
      } finally {
        releaseCanvas(canvas)
      }
    } else {
      let opened: Awaited<ReturnType<typeof openPdfDocument>>
      try {
        opened = await openPdfDocument(new Uint8Array(await file.arrayBuffer()))
      } catch {
        throw new ReadError('TEXTO', 'el PDF está dañado o protegido con contraseña.')
      }
      const { doc, close } = opened
      let ocrPages = 0
      try {
        const total = Math.min(doc.numPages, EXTRACT_LIMITS.maxPdfPages)
        if (doc.numPages > total) {
          out.warnings.push(`${file.name}: solo se procesaron las primeras ${total} de ${doc.numPages} páginas.`)
        }
        for (let n = 1; n <= total; n++) {
          if (signal.aborted) throw new DOMException('Cancelado', 'AbortError')
          onProgress((n - 1) / total, `${file.name} · página ${n} de ${total}`)
          const page = await doc.getPage(n)
          const content = await page.getTextContent()
          const text = itemsToLines(content.items as TextItemLike[])
          if (text.replace(/\s/g, '').length >= MIN_TEXT_CHARS) {
            out.segments.push({ file: file.name, page: n, method: 'texto', text })
          } else {
            const base = page.getViewport({ scale: 1 })
            // Render straight at the size the model receives, so the page is rasterized once.
            const scale = Math.min(2, EXTRACT_LIMITS.maxImageSide / Math.max(base.width, base.height))
            const viewport = page.getViewport({ scale })
            const canvas = document.createElement('canvas')
            canvas.width = Math.floor(viewport.width)
            canvas.height = Math.floor(viewport.height)
            const ctx = canvas.getContext('2d')
            try {
              if (ctx) {
                ctx.fillStyle = '#ffffff'
                ctx.fillRect(0, 0, canvas.width, canvas.height)
                await page.render({ canvas, canvasContext: ctx, viewport }).promise
                if (!keepImage(canvas, n)) {
                  const tOcr = performance.now()
                  const ocr = await recognizeImage(canvas, (p) => onProgress((n - 1 + p) / total, `OCR de ${file.name} · página ${n}`)).catch(() => {
                    throw new ReadError('OCR', `falló el OCR de la página ${n}.`)
                  })
                  ocrMs += performance.now() - tOcr
                  ocrPages++
                  out.segments.push({ file: file.name, page: n, method: 'ocr', text: `${text}\n${ocr}`.trim() })
                } else if (text.trim()) {
                  out.segments.push({ file: file.name, page: n, method: 'texto', text })
                }
              }
            } finally {
              releaseCanvas(canvas)
            }
          }
          page.cleanup()
        }
      } finally {
        await close()
      }
      if (ocrPages > 0) {
        out.warnings.push(`${file.name}: ${ocrPages} página(s) escaneada(s) se interpretaron solo con OCR por el límite de imágenes.`)
      }
    }
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error
    out.errorCode = error instanceof ReadError ? error.code : kind === 'docx' || kind === 'txt' ? 'TEXTO' : 'ILEGIBLE'
    out.errors.push(`${file.name}: ${error instanceof Error ? error.message : 'no se pudo leer.'}`)
  }
  onProgress(1, `${file.name} leído`)
  return finish()
}
