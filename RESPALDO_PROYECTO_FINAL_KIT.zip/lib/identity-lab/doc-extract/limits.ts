export type DocKind = 'pdf' | 'image' | 'docx' | 'txt'

/**
 * Technical limits, not product limits. Files are only held as browser `File`
 * references until their turn, so a large batch costs little memory; each file is
 * read and sent on its own request.
 */
export const EXTRACT_LIMITS = {
  maxFiles: 300,
  maxFileBytes: 15 * 1024 * 1024,
  maxTotalBytes: 600 * 1024 * 1024,
  /** Files read and analyzed at the same time (phone CPU for PDF rendering, provider rate limits). */
  concurrency: 4,
  /** Read results (text + prepared images) kept in memory to switch modes without re-reading. */
  readCacheEntries: 40,
  /** Client-side cap for one file's analysis request. */
  requestTimeoutMs: 60_000,
  maxPdfPages: 20,
  maxModelImages: 8,
  /** Base64 budget for page images sent to the model (Vercel bodies max out at 4.5 MB). */
  maxImageBase64Chars: 3_000_000,
  maxImageSide: 1600,
  maxTextChars: 200_000,
  maxInstructionChars: 1500,
} as const

export const ACCEPT_ATTR =
  '.pdf,.jpg,.jpeg,.png,.webp,.txt,.docx,application/pdf,image/jpeg,image/png,image/webp,text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document'

export const SUPPORTED_LABEL = 'PDF, JPG, PNG, WEBP, DOCX o TXT'

function extensionOf(name: string): string {
  const dot = name.lastIndexOf('.')
  return dot === -1 ? '' : name.slice(dot + 1).toLowerCase()
}

/** Expected kind from the file name, before reading its bytes. */
export function kindFromName(name: string): DocKind | null {
  const ext = extensionOf(name)
  if (ext === 'pdf') return 'pdf'
  if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) return 'image'
  if (ext === 'docx') return 'docx'
  if (ext === 'txt') return 'txt'
  return null
}

/**
 * Confirms the real content type from the first bytes, so a renamed file
 * (an HTML page saved as .pdf, an .exe renamed to .jpg) is rejected.
 */
export function kindFromBytes(head: Uint8Array): DocKind | 'text-like' | null {
  const b = head
  const ascii = (from: number, to: number) => String.fromCharCode(...b.slice(from, to))
  if (b.length >= 5 && ascii(0, 5) === '%PDF-') return 'pdf'
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image'
  if (b.length >= 8 && b[0] === 0x89 && ascii(1, 4) === 'PNG') return 'image'
  if (b.length >= 12 && ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP') return 'image'
  if (b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04) return 'docx'
  if (b.length > 0 && !b.includes(0)) return 'text-like'
  return null
}

/** Returns the confirmed kind, or the reason the file cannot be processed. */
export function checkFile(name: string, size: number, head: Uint8Array): { kind: DocKind } | { error: string } {
  const expected = kindFromName(name)
  if (!expected) return { error: `${name}: formato no admitido. Usa ${SUPPORTED_LABEL}.` }
  if (size === 0) return { error: `${name}: el archivo está vacío.` }
  if (size > EXTRACT_LIMITS.maxFileBytes) {
    return { error: `${name}: supera ${EXTRACT_LIMITS.maxFileBytes / 1024 / 1024} MB.` }
  }
  const actual = kindFromBytes(head)
  const matches = expected === 'txt' ? actual === 'text-like' : actual === expected
  if (!matches) return { error: `${name}: el contenido no corresponde a un archivo ${expected.toUpperCase()} válido.` }
  return { kind: expected }
}

/** Checks the whole selection against the count and total-size limits. */
export function checkSelection(sizes: number[]): string | null {
  if (sizes.length > EXTRACT_LIMITS.maxFiles) return `Máximo ${EXTRACT_LIMITS.maxFiles} archivos por operación.`
  const total = sizes.reduce((a, b) => a + b, 0)
  if (total > EXTRACT_LIMITS.maxTotalBytes) {
    return `Los archivos suman más de ${EXTRACT_LIMITS.maxTotalBytes / 1024 / 1024} MB.`
  }
  return null
}
