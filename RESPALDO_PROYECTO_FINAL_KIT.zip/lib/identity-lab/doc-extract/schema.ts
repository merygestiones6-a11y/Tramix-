import { z } from 'zod'
import { normalizeEntity, normalizeSex, type CurpInput } from '../engine'
import { EXTRACT_LIMITS } from './limits'

/** `general` is the automatic detection that runs when no button is selected. */
export const EXTRACT_MODES = ['general', 'curp', 'rfc', 'fiscal', 'cfe'] as const
export type ExtractMode = (typeof EXTRACT_MODES)[number]

export const segmentSchema = z.object({
  file: z.string().min(1).max(200),
  page: z.number().int().positive().nullable(),
  method: z.enum(['texto', 'ocr', 'docx', 'txt']),
  text: z.string().max(EXTRACT_LIMITS.maxTextChars),
})

export const imageSchema = z.object({
  file: z.string().min(1).max(200),
  page: z.number().int().positive().nullable(),
  data: z.string().regex(/^[A-Za-z0-9+/=]+$/, 'Imagen no válida'),
})

/** One file per request: results of different files can never be mixed by the model. */
export const extractRequestSchema = z
  .object({
    mode: z.enum(EXTRACT_MODES),
    segments: z.array(segmentSchema).max(EXTRACT_LIMITS.maxPdfPages),
    images: z.array(imageSchema).max(EXTRACT_LIMITS.maxModelImages),
  })
  .superRefine((req, ctx) => {
    const textChars = req.segments.reduce((n, s) => n + s.text.length, 0)
    if (textChars > EXTRACT_LIMITS.maxTextChars) {
      ctx.addIssue({ code: 'custom', message: 'El documento contiene demasiado texto.' })
    }
    const imageChars = req.images.reduce((n, i) => n + i.data.length, 0)
    if (imageChars > EXTRACT_LIMITS.maxImageBase64Chars) {
      ctx.addIssue({ code: 'custom', message: 'Las imágenes superan el tamaño permitido.' })
    }
    if (new Set([...req.segments, ...req.images].map((x) => x.file)).size > 1) {
      ctx.addIssue({ code: 'custom', message: 'Cada solicitud debe contener un solo archivo.' })
    }
    const hasText = req.segments.some((s) => s.text.trim().length > 0)
    if (!hasText && req.images.length === 0) {
      ctx.addIssue({ code: 'custom', message: 'No se encontró contenido legible en el archivo.' })
    }
  })

export type ExtractRequest = z.infer<typeof extractRequestSchema>
export type Segment = z.infer<typeof segmentSchema>
export type PageImage = z.infer<typeof imageSchema>

export const NOT_LEGIBLE = 'NO LEGIBLE'
export const NOT_FOUND = 'NO ENCONTRADO'
const estado = z.enum(['ENCONTRADO', NOT_LEGIBLE, NOT_FOUND])
export type FieldState = z.infer<typeof estado>

export const extractResultSchema = z.object({
  personas: z.array(
    z.object({
      etiqueta: z.string().describe('Rol de la persona en el documento, p. ej. TITULAR, CÓNYUGE 1, PADRE. Vacío si solo hay una persona.'),
      campos: z.array(
        z.object({
          campo: z.string().describe('Nombre del dato, en mayúsculas.'),
          valor: z.string().describe('Valor tal como aparece en el documento. Vacío si no aparece o no se lee.'),
          estado,
          archivo: z.string().nullable(),
          pagina: z.number().int().nullable(),
        }),
      ),
      curpImpresa: z.string().describe('CURP impresa de esta persona, tal como aparece. Vacío si no aparece.'),
      rfcImpreso: z.string().describe('RFC impreso de esta persona, tal como aparece. Vacío si no aparece.'),
      tipoPersona: z.enum(['FISICA', 'MORAL', '']).describe('MORAL solo para empresas o sociedades.'),
      datosCurp: z
        .object({
          nombre: z.string(),
          primerApellido: z.string(),
          segundoApellido: z.string(),
          fechaNacimiento: z.string().describe('AAAA-MM-DD, o vacío si no aparece.'),
          sexo: z.enum(['H', 'M', '']).describe('Solo si el documento lo indica expresamente.'),
          entidadNacimiento: z.string().describe('Entidad de NACIMIENTO, nunca la de registro. Vacío si no aparece.'),
        })
        .nullable(),
    }),
  ),
  contradicciones: z.array(z.string()),
})

export const fiscalResultSchema = z.object({
  rfc: z.string().describe('RFC tal como aparece, sin etiquetas. Vacío si no aparece.'),
  rfcEstado: estado,
  idcif: z.string().describe('idCIF tal como aparece (solo el valor). Vacío si no aparece.'),
  idcifEstado: estado,
  pagina: z.number().int().nullable(),
})

export const cfeResultSchema = z.object({
  numeroServicio: z.string().describe('Dígitos del número de servicio, exactamente como aparecen. Vacío si no aparece.'),
  estado,
  etiqueta: z.string().describe('Texto impreso o escrito junto al número, p. ej. "NO. DE SERVICIO". Vacío si no tiene etiqueta.'),
  pagina: z.number().int().nullable(),
})

export type ExtractResult = z.infer<typeof extractResultSchema>
export type ExtractedPerson = ExtractResult['personas'][number]
export type ExtractedField = ExtractedPerson['campos'][number]
export type FiscalResult = z.infer<typeof fiscalResultSchema>
export type CfeResult = z.infer<typeof cfeResultSchema>

export type ModeData =
  | { mode: 'general' | 'curp' | 'rfc'; data: ExtractResult }
  | { mode: 'fiscal'; data: FiscalResult }
  | { mode: 'cfe'; data: CfeResult }

const compact = (value: string) => value.toUpperCase().replace(/[\s\-.]/g, '')
// eslint-disable-next-line no-control-regex -- PDF fonts without a Unicode map can leak control bytes into model output.
const clean = (value: string) => value.replace(/[\u0000-\u001f\u007f]/g, '').trim()

const KNOWN_FIELDS = [
  'TIPO DE DOCUMENTO', 'NOMBRE COMPLETO', 'RAZÓN SOCIAL', 'CURP', 'RFC', 'IDCIF', 'NÚMERO DE SERVICIO CFE',
  'FECHA DE NACIMIENTO', 'ENTIDAD DE NACIMIENTO', 'FECHA DE REGISTRO', 'ENTIDAD DE REGISTRO', 'SEXO',
]
const asciiKey = (value: string) => value.toUpperCase().replace(/[^A-Z]/g, '')
const FIELD_BY_KEY = new Map(KNOWN_FIELDS.map((f) => [asciiKey(f), f]))

/** Restores known field names when accented letters arrive garbled (e.g. "N\u0013MERO"). */
export const canonicalField = (campo: string) => {
  const name = clean(campo).toUpperCase()
  return FIELD_BY_KEY.get(asciiKey(name)) ?? name
}

/** Enforces the output contract regardless of what the model returned. */
export function sanitizeResult(result: ExtractResult): ExtractResult {
  return {
    contradicciones: result.contradicciones.map((c) => c.trim()).filter(Boolean),
    personas: result.personas.map((p) => ({
      etiqueta: p.etiqueta.trim().toUpperCase(),
      curpImpresa: compact(p.curpImpresa ?? ''),
      rfcImpreso: compact(p.rfcImpreso ?? ''),
      tipoPersona: p.tipoPersona ?? '',
      datosCurp: p.datosCurp,
      campos: p.campos.map((c) => {
        const valor = clean(c.valor)
        const state = c.estado === 'ENCONTRADO' && !valor ? NOT_FOUND : c.estado
        return {
          campo: canonicalField(c.campo),
          valor: state === 'ENCONTRADO' ? valor : state,
          estado: state,
          archivo: c.archivo,
          pagina: c.pagina,
        }
      }),
    })),
  }
}

const settle = (value: string, state: FieldState): [string, FieldState] =>
  state === 'ENCONTRADO' && !value ? ['', NOT_FOUND] : [state === 'ENCONTRADO' ? value : '', state]

export function sanitizeFiscal(r: FiscalResult): FiscalResult {
  const [rfc, rfcEstado] = settle(compact(r.rfc), r.rfcEstado)
  const [idcif, idcifEstado] = settle(r.idcif.replace(/\s/g, ''), r.idcifEstado)
  return { rfc, rfcEstado, idcif, idcifEstado, pagina: r.pagina }
}

export function sanitizeCfe(r: CfeResult): CfeResult {
  const [numeroServicio, state] = settle(r.numeroServicio.replace(/[\s\-.]/g, ''), r.estado)
  return { numeroServicio, estado: state, etiqueta: r.etiqueta.trim(), pagina: r.pagina }
}

/** Plain-text copy of a person-based result. A single requested value is copied alone, without labels. */
export function formatResults(result: ExtractResult): string {
  const people = result.personas
  if (people.length === 1 && people[0].campos.length === 1) return people[0].campos[0].valor
  return people
    .map((p, i) => {
      const header = p.etiqueta || (people.length > 1 ? `PERSONA ${i + 1}` : '')
      const lines = p.campos.map((c) => `${c.campo}: ${c.valor}`)
      return (header ? [header, ...lines] : lines).join('\n')
    })
    .join('\n\n')
}

export function toCurpInput(data: NonNullable<ExtractedPerson['datosCurp']>): CurpInput {
  const fecha = /^\d{4}-\d{2}-\d{2}$/.test(data.fechaNacimiento.trim()) ? data.fechaNacimiento.trim() : ''
  const entidad = data.entidadNacimiento.trim() ? normalizeEntity(data.entidadNacimiento) : ''
  return {
    nombre: data.nombre.trim(),
    primerApellido: data.primerApellido.trim(),
    segundoApellido: data.segundoApellido.trim(),
    fechaNacimiento: fecha,
    sexo: normalizeSex(data.sexo),
    entidad: entidad.length === 2 ? entidad : '',
  }
}

const CURP_PATTERN = /[A-Z]{4}\d{6}[HMX][A-Z]{5}[A-Z0-9]\d/

/** The CURP printed for the person, from the dedicated key or from its fields. */
export function documentCurp(person: Pick<ExtractedPerson, 'campos'> & { curpImpresa?: string }): string | null {
  const direct = CURP_PATTERN.exec(compact(person.curpImpresa ?? ''))
  if (direct) return direct[0]
  for (const c of person.campos) {
    if (c.estado !== 'ENCONTRADO' || !/CURP/.test(c.campo)) continue
    const match = CURP_PATTERN.exec(c.valor.toUpperCase().replace(/\s/g, ''))
    if (match) return match[0]
  }
  return null
}

/** 1-based positions where two CURPs differ. */
export function compareCurp(a: string, b: string): number[] {
  const diff: number[] = []
  for (let i = 0; i < Math.max(a.length, b.length); i++) if (a[i] !== b[i]) diff.push(i + 1)
  return diff
}
