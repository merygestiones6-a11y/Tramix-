import { generateCurp, generateRfcFromData, STATES, validateCurp, validateRfc } from '../engine'
import {
  documentCurp,
  formatResults,
  toCurpInput,
  type CfeResult,
  type ExtractedPerson,
  type ExtractMode,
  type ExtractResult,
  type FiscalResult,
  type ModeData,
} from './schema'

export const MODE_LABEL: Record<ExtractMode, string> = {
  general: 'DETECCIÓN AUTOMÁTICA',
  curp: 'CURP',
  rfc: 'RFC',
  fiscal: 'RFC + IDCIF',
  cfe: 'NÚMERO DE SERVICIO CFE',
}

/** idCIF of the Constancia de Situación Fiscal. */
export const IDCIF_PATTERN = /^\d{11}$/
/** CFE "No. de servicio" (RPU). */
export const CFE_SERVICE_PATTERN = /^\d{12}$/
const CFE_LABEL = /SERVICIO|\bRPU\b/i

export type FileStatus = 'PENDIENTE' | 'PROCESANDO' | 'COMPLETADO' | 'INCOMPLETO' | 'ERROR'

export type Origin = 'DOCUMENTO' | 'DE LA CURP'

export interface ViewField {
  campo: string
  valor: string
  missing: boolean
  origin: Origin
  archivo?: string | null
  pagina?: number | null
}

export interface OutputLine {
  value: string
  condition: 'EXTRAÍDO' | 'CANDIDATA'
}

export interface PersonView {
  label: string
  fields: ViewField[]
  line: OutputLine | null
  notes: string[]
  /** Raw extraction, kept for the editable CURP candidate block. */
  person: ExtractedPerson | null
}

export interface Evaluation {
  status: 'COMPLETADO' | 'INCOMPLETO'
  people: PersonView[]
  notes: string[]
  contradicciones: string[]
  /** Copy text for detection mode, where there is no single value. */
  block?: string
}

const fromDoc = (c: ExtractedPerson['campos'][number]): ViewField => ({
  campo: c.campo,
  valor: c.valor,
  missing: c.estado !== 'ENCONTRADO',
  origin: 'DOCUMENTO',
  archivo: c.archivo,
  pagina: c.pagina,
})

const labelOf = (p: ExtractedPerson, i: number, total: number) => p.etiqueta || (total > 1 ? `PERSONA ${i + 1}` : '')

/** Birth date, sex and state encoded in a structurally valid CURP. */
export function decodeCurp(curp: string): { fecha: string; sexo: string; entidad: string } | null {
  if (validateCurp(curp).status === 'invalida') return null
  const century = /[A-Z]/.test(curp[16]) ? 2000 : 1900
  const fecha = `${curp.slice(8, 10)}/${curp.slice(6, 8)}/${century + Number(curp.slice(4, 6))}`
  const sexo = { H: 'HOMBRE', M: 'MUJER', X: 'NO BINARIO' }[curp[10]] ?? curp[10]
  const entidad = curp.slice(11, 13) === 'NE' ? 'NACIDO EN EL EXTRANJERO' : (STATES.find((s) => s.code === curp.slice(11, 13))?.name.toUpperCase() ?? curp.slice(11, 13))
  return { fecha, sexo, entidad }
}

function curpPerson(p: ExtractedPerson, label: string): PersonView {
  const fields = p.campos.map(fromDoc)
  const notes: string[] = []
  const printed = documentCurp(p) ?? (p.curpImpresa || null)
  let line: OutputLine | null = null

  if (printed) {
    const check = validateCurp(printed)
    if (check.status === 'invalida') {
      notes.push(`La CURP del documento (${printed}) no tiene estructura válida: ${check.summary}`)
    } else {
      line = { value: check.value, condition: 'EXTRAÍDO' }
      const decoded = decodeCurp(check.value)!
      fields.push(
        { campo: 'FECHA DE NACIMIENTO', valor: decoded.fecha, missing: false, origin: 'DE LA CURP' },
        { campo: 'SEXO', valor: decoded.sexo, missing: false, origin: 'DE LA CURP' },
        { campo: 'ENTIDAD DE NACIMIENTO', valor: decoded.entidad, missing: false, origin: 'DE LA CURP' },
      )
      notes.push('Estructura válida. Solo RENAPO confirma su registro.')
    }
  }

  if (!line) {
    if (!p.datosCurp) {
      notes.push('Cálculo incompleto: el documento no contiene datos de identidad suficientes.')
    } else {
      const generated = generateCurp(toCurpInput(p.datosCurp), 1)
      const candidate = generated.ok ? generated.candidates[0]?.id : undefined
      if (candidate) {
        line = { value: candidate, condition: 'CANDIDATA' }
        notes.push('CURP CANDIDATA PENDIENTE DE VERIFICACIÓN OFICIAL: calculada con los datos del documento; RENAPO no la ha confirmado.')
      } else {
        notes.push(`Cálculo incompleto: ${generated.errors.join(' ')}`)
      }
    }
  }
  return { label, fields, line, notes, person: p }
}

function rfcPerson(p: ExtractedPerson, label: string): PersonView {
  const fields = p.campos.map(fromDoc)
  const notes: string[] = []
  let line: OutputLine | null = null

  if (p.rfcImpreso) {
    const check = validateRfc(p.rfcImpreso)
    if (check.status === 'invalida') {
      notes.push(`El RFC del documento (${p.rfcImpreso}) no tiene estructura válida: ${check.summary}`)
    } else {
      line = { value: check.value, condition: 'EXTRAÍDO' }
      notes.push(`${check.kind === 'RFC moral' ? 'Persona moral (12 caracteres)' : check.kind === 'RFC física' ? 'Persona física (13 caracteres)' : check.kind}. Solo el SAT confirma su registro.`)
    }
  }

  if (!line) {
    if (p.tipoPersona === 'MORAL') {
      notes.push('Cálculo incompleto: el cálculo de RFC de persona moral no está disponible; se necesita el RFC impreso.')
    } else if (!p.datosCurp) {
      notes.push('Cálculo incompleto: el documento no contiene nombre y fecha de nacimiento.')
    } else {
      const input = toCurpInput(p.datosCurp)
      const curp = documentCurp(p)
      const decoded = curp ? decodeCurp(curp) : null
      if (!input.fechaNacimiento && curp && decoded) {
        const [d, m, y] = decoded.fecha.split('/')
        input.fechaNacimiento = `${y}-${m}-${d}`
        fields.push({ campo: 'FECHA DE NACIMIENTO', valor: decoded.fecha, missing: false, origin: 'DE LA CURP' })
      }
      const generated = generateRfcFromData(input)
      const candidate = generated.ok ? generated.candidates[0] : undefined
      if (candidate) {
        line = { value: candidate.id, condition: 'CANDIDATA' }
        notes.push('RFC CANDIDATO PENDIENTE DE VERIFICACIÓN OFICIAL: el SAT puede asignar otra homoclave.')
        if (generated.candidates.length > 1) {
          notes.push(`Interpretación alternativa: ${generated.candidates.slice(1).map((c) => c.id).join(', ')}.`)
        }
      } else {
        notes.push(`Cálculo incompleto: ${generated.errors.join(' ')}`)
      }
    }
  }
  return { label, fields, line, notes, person: p }
}

function evaluatePeople(mode: 'general' | 'curp' | 'rfc', data: ExtractResult): Evaluation {
  const total = data.personas.length
  if (mode === 'general') {
    const people = data.personas.map((p, i) => ({ label: labelOf(p, i, total), fields: p.campos.map(fromDoc), line: null, notes: [], person: p }))
    const found = people.some((p) => p.fields.some((f) => !f.missing))
    return {
      status: found ? 'COMPLETADO' : 'INCOMPLETO',
      people,
      notes: found ? [] : ['No se identificaron datos de forma confiable.'],
      contradicciones: data.contradicciones,
      block: found ? formatResults(data) : undefined,
    }
  }
  const build = mode === 'curp' ? curpPerson : rfcPerson
  const people = data.personas.map((p, i) => build(p, labelOf(p, i, total)))
  const complete = people.length > 0 && people.every((p) => p.line)
  return {
    status: complete ? 'COMPLETADO' : 'INCOMPLETO',
    people,
    notes: people.length ? [] : ['No se encontró ninguna persona en el documento.'],
    contradicciones: data.contradicciones,
  }
}

function evaluateFiscal(r: FiscalResult): Evaluation {
  const missing: string[] = []
  let rfc: string | null = null
  if (r.rfcEstado === 'NO LEGIBLE') missing.push('El RFC aparece pero no es legible.')
  else if (!r.rfc) missing.push('Falta el RFC.')
  else {
    const check = validateRfc(r.rfc)
    if (check.status === 'invalida') missing.push(`El RFC leído (${r.rfc}) no tiene estructura válida.`)
    else rfc = check.value
  }
  let idcif: string | null = null
  if (r.idcifEstado === 'NO LEGIBLE') missing.push('El IDCIF aparece pero no es legible.')
  else if (!r.idcif) missing.push('Falta el IDCIF.')
  else if (!IDCIF_PATTERN.test(r.idcif)) missing.push(`El IDCIF leído (${r.idcif}) no tiene 11 dígitos; revisa el documento.`)
  else idcif = r.idcif

  const fields: ViewField[] = [
    { campo: 'RFC', valor: rfc ?? (r.rfc || r.rfcEstado), missing: !rfc, origin: 'DOCUMENTO', pagina: r.pagina },
    { campo: 'IDCIF', valor: idcif ?? (r.idcif || r.idcifEstado), missing: !idcif, origin: 'DOCUMENTO', pagina: r.pagina },
  ]
  const line = rfc && idcif ? { value: `${rfc} ${idcif}`, condition: 'EXTRAÍDO' as const } : null
  return { status: line ? 'COMPLETADO' : 'INCOMPLETO', people: [{ label: '', fields, line, notes: missing, person: null }], notes: [], contradicciones: [] }
}

function evaluateCfe(r: CfeResult): Evaluation {
  const notes: string[] = []
  const digits = r.numeroServicio
  if (r.estado === 'NO LEGIBLE') notes.push('REVISIÓN NECESARIA: el número de servicio aparece pero no es legible.')
  else if (!digits) notes.push('No se encontró el número de servicio.')
  else if (!CFE_SERVICE_PATTERN.test(digits)) notes.push(`REVISIÓN NECESARIA: el número leído (${digits}) no tiene los 12 dígitos de un número de servicio.`)
  else if (!CFE_LABEL.test(r.etiqueta)) notes.push('REVISIÓN NECESARIA: el número no aparece junto a la etiqueta «número de servicio»; podría ser otro identificador.')
  const ok = notes.length === 0
  const fields: ViewField[] = [
    { campo: 'NÚMERO DE SERVICIO', valor: digits || r.estado, missing: !ok, origin: 'DOCUMENTO', pagina: r.pagina },
  ]
  return {
    status: ok ? 'COMPLETADO' : 'INCOMPLETO',
    people: [{ label: '', fields, line: ok ? { value: digits, condition: 'EXTRAÍDO' } : null, notes, person: null }],
    notes: [],
    contradicciones: [],
  }
}

export function evaluate(md: ModeData): Evaluation {
  if (md.mode === 'fiscal') return evaluateFiscal(md.data)
  if (md.mode === 'cfe') return evaluateCfe(md.data)
  return evaluatePeople(md.mode, md.data)
}

/** Text of one line in a list: candidates are always marked, clean-value modes never get labels. */
export function listLine(line: OutputLine): string {
  return line.condition === 'CANDIDATA' ? `${line.value} (CANDIDATA)` : line.value
}

/**
 * Copy / TXT content for the active mode, in file order.
 * RFC + IDCIF and CFE only include complete files; CURP and RFC include every person
 * with a value, marking candidates.
 */
export function listText(mode: ExtractMode, entries: { fileName: string; evaluation: Evaluation | null }[]): string {
  if (mode === 'general') {
    return entries
      .filter((e) => e.evaluation?.block)
      .map((e) => `== ${e.fileName} ==\n${e.evaluation!.block}`)
      .join('\n\n')
  }
  const lines: string[] = []
  for (const { evaluation } of entries) {
    if (!evaluation) continue
    if ((mode === 'fiscal' || mode === 'cfe') && evaluation.status !== 'COMPLETADO') continue
    for (const p of evaluation.people) if (p.line) lines.push(listLine(p.line))
  }
  return lines.join('\n')
}

export type ErrorCode =
  | 'FORMATO'
  | 'ILEGIBLE'
  | 'TEXTO'
  | 'OCR'
  | 'MODELO'
  | 'PROVEEDOR'
  | 'LIMITE'
  | 'TIEMPO'
  | 'RESPUESTA'
  | 'RED'
  | 'SOLICITUD'

export const ERROR_MESSAGE: Record<ErrorCode, string> = {
  FORMATO: 'Formato no compatible.',
  ILEGIBLE: 'El archivo no tiene contenido legible.',
  TEXTO: 'No se pudo extraer el texto (archivo dañado o protegido).',
  OCR: 'Falló el reconocimiento de texto (OCR).',
  MODELO: 'El modelo de IA configurado no admite este contenido.',
  PROVEEDOR: 'El servicio de IA no respondió correctamente.',
  LIMITE: 'Se alcanzó un límite de tamaño o de cuota del servicio.',
  TIEMPO: 'Tiempo de espera agotado.',
  RESPUESTA: 'La IA devolvió una respuesta no válida.',
  RED: 'No hay conexión con el servidor.',
  SOLICITUD: 'El servidor rechazó el contenido del archivo.',
}
