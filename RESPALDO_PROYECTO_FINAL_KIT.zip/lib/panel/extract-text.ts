import { nodeEngine, ocrImage } from '@/lib/server/node-engine'

export type ExtractResult = { status: 'ready'; text: string } | { status: 'empty' | 'unsupported' }

const TEXT_EXTENSIONS = /\.(txt|csv|tsv|md|json|xml|html?|log)$/i
const IMAGE_EXTENSIONS = /\.(png|jpe?g|webp|bmp|gif|tiff?)$/i

function finish(text: string): ExtractResult {
  const cleaned = text.replace(/\r\n?/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
  return cleaned ? { status: 'ready', text: cleaned } : { status: 'empty' }
}

export async function extractDocumentText(name: string, type: string, bytes: Uint8Array): Promise<ExtractResult> {
  if (type === 'application/pdf' || /\.pdf$/i.test(name)) {
    const { pages } = await nodeEngine.extractText(bytes)
    return finish(pages.join('\n\n'))
  }
  if (type.startsWith('text/') || TEXT_EXTENSIONS.test(name) || type === 'application/json') {
    return finish(new TextDecoder('utf-8').decode(bytes))
  }
  if (type.startsWith('image/') || IMAGE_EXTENSIONS.test(name)) {
    return finish(await ocrImage(bytes))
  }
  return { status: 'unsupported' }
}
