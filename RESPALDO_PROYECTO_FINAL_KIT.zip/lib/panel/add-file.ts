import { start } from 'workflow/api'
import { expireUpload } from '@/workflows/expire-upload'
import { extractDocumentText } from './extract-text'
import { expiresAtOf, newId, storeOriginal, storeText, storeTextMarker } from './store'

/**
 * Puts a document produced by a trámite into DESCARGAR, the single final repository.
 * Same layout, text extraction and 12-hour expiry as a file uploaded from SUBIR.
 */
export async function addToDownloads(name: string, bytes: Uint8Array, type = 'application/pdf'): Promise<string> {
  const id = newId()
  await storeOriginal(id, new File([Buffer.from(bytes)], name, { type }))

  // The daily cleanup sweep still removes the file if this timer cannot be scheduled from here.
  await start(expireUpload, [id, new Date(expiresAtOf(id)).toISOString()]).catch((error) =>
    console.error('[panel] expiry timer not scheduled', id, error),
  )

  try {
    const result = await extractDocumentText(name, type, bytes)
    if (result.status === 'ready') await storeText(id, result.text)
    else await storeTextMarker(id, result.status)
  } catch (error) {
    console.error('[panel] text extraction failed', id, error)
    await storeTextMarker(id, 'failed').catch(() => {})
  }
  return id
}
