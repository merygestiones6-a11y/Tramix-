export const FILE_TTL_MS = 12 * 60 * 60 * 1000

/** Vercel Functions accept request bodies up to 4.5 MB; keep a margin for multipart overhead. */
export const MAX_UPLOAD_BYTES = 4 * 1024 * 1024

export const MAX_FILES_PER_UPLOAD = 10

export type TextStatus = 'pending' | 'ready' | 'empty' | 'unsupported' | 'failed'

export interface PanelFile {
  id: string
  name: string
  size: number
  uploadedAt: string
  expiresAt: string
  textStatus: TextStatus
}
