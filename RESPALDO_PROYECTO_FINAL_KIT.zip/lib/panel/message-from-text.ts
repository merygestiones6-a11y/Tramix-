import { crossCheckDemographics, detectPersonalData, stateLabel } from '@/lib/extract'
import { type CrossField, factsFromCurp } from '@/lib/extract/demographics'
import { buildDeliveryMessage } from '@/lib/message'

/**
 * On a CURP-vs-document conflict there is no one to ask here, so the value encoded in a
 * check-digit-valid CURP wins. Conflicts between document values alone are left out.
 */
function pick(field: CrossField, curpIsValid: boolean): string | null {
  if (field.value) return field.value
  if (field.source === 'conflict' && curpIsValid) return field.options[0] ?? null
  return null
}

/** Builds the WhatsApp delivery message from a stored document's text, or null without name + CURP. */
export function buildMessageFromText(text: string): string | null {
  const data = detectPersonalData([text])
  if (!data.name || !data.curp) return null

  const curpIsValid = factsFromCurp(data.curp) !== null
  const cross = crossCheckDemographics(data.curp, data.documentFacts)
  const state = pick(cross.state, curpIsValid)

  return buildDeliveryMessage({
    name: data.name,
    curp: data.curp,
    nss: data.nss,
    birthDate: pick(cross.birthDate, curpIsValid),
    sex: pick(cross.sex, curpIsValid),
    state: state ? stateLabel(state) : null,
  })
}
