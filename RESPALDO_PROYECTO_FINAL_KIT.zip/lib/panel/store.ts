import { randomBytes } from 'node:crypto'
import { del, get, list, put } from '@vercel/blob'
import { FILE_TTL_MS, type PanelFile, type TextStatus } from './config'

/**
 * Layout per upload (all private):
 *   panel/<id>/file/<encoded name>   original bytes
 *   panel/<id>/text.txt              extracted text
 *   panel/<id>/text.<status>         marker when no text could be produced
 *
 * <id> starts with the upload timestamp, so the listing alone describes every
 * file without overwriting (and caching) a metadata blob.
 */
const ROOT = 'panel/'
const ID_PATTERN = /^(\d{13})-([a-f0-9]{10})$/
const TEXT_MARKERS: TextStatus[] = ['empty', 'unsupported', 'failed']
const PENDING_GIVE_UP_MS = 5 * 60 * 1000

export function isValidId(id: string): boolean {
  return ID_PATTERN.test(id)
}

export function uploadedAtOf(id: string): number {
  return Number(id.slice(0, 13))
}

export function expiresAtOf(id: string): number {
  return uploadedAtOf(id) + FILE_TTL_MS
}

export function isExpired(id: string, now = Date.now()): boolean {
  return now >= expiresAtOf(id)
}

export function newId(now = Date.now()): string {
  return `${now}-${randomBytes(5).toString('hex')}`
}

function cleanName(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? ''
  // eslint-disable-next-line no-control-regex
  const cleaned = base.replace(/[\u0000-\u001f\u007f]/g, '').trim()
  return cleaned.slice(0, 180) || 'archivo'
}

async function listAll(prefix: string) {
  const blobs: Awaited<ReturnType<typeof list>>['blobs'] = []
  let cursor: string | undefined
  do {
    const page = await list({ prefix, cursor, limit: 1000 })
    blobs.push(...page.blobs)
    cursor = page.hasMore ? page.cursor : undefined
  } while (cursor)
  return blobs
}

export async function storeOriginal(id: string, file: File): Promise<string> {
  const name = cleanName(file.name)
  const blob = await put(`${ROOT}${id}/file/${encodeURIComponent(name)}`, file, {
    access: 'private',
    addRandomSuffix: false,
    contentType: file.type || 'application/octet-stream',
  })
  return blob.pathname
}

export async function storeText(id: string, text: string): Promise<void> {
  await put(`${ROOT}${id}/text.txt`, text, {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'text/plain; charset=utf-8',
  })
}

export async function storeTextMarker(id: string, status: Exclude<TextStatus, 'pending' | 'ready'>) {
  await put(`${ROOT}${id}/text.${status}`, status, {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'text/plain',
  })
}

export async function listActiveFiles(now = Date.now()): Promise<PanelFile[]> {
  const groups = new Map<string, { name?: string; size?: number; text?: TextStatus }>()

  for (const blob of await listAll(ROOT)) {
    const [, id, kind, rest] = blob.pathname.match(/^panel\/([^/]+)\/(file|text)[./](.*)$/) ?? []
    if (!id || !isValidId(id) || isExpired(id, now)) continue
    const entry = groups.get(id) ?? {}
    if (kind === 'file') {
      entry.name = decodeURIComponent(rest)
      entry.size = blob.size
    } else if (rest === 'txt') {
      entry.text = 'ready'
    } else if (TEXT_MARKERS.includes(rest as TextStatus) && entry.text !== 'ready') {
      entry.text = rest as TextStatus
    }
    groups.set(id, entry)
  }

  const files: PanelFile[] = []
  for (const [id, entry] of groups) {
    if (!entry.name) continue
    const stalePending = !entry.text && now - uploadedAtOf(id) > PENDING_GIVE_UP_MS
    files.push({
      id,
      name: entry.name,
      size: entry.size ?? 0,
      uploadedAt: new Date(uploadedAtOf(id)).toISOString(),
      expiresAt: new Date(expiresAtOf(id)).toISOString(),
      textStatus: entry.text ?? (stalePending ? 'failed' : 'pending'),
    })
  }
  return files.sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt))
}

export async function openOriginal(id: string) {
  const [blob] = await listAll(`${ROOT}${id}/file/`)
  if (!blob) return null
  const result = await get(blob.pathname, { access: 'private' })
  if (!result || result.statusCode !== 200) return null
  return {
    name: decodeURIComponent(blob.pathname.split('/').pop() ?? 'archivo'),
    contentType: result.blob.contentType || 'application/octet-stream',
    size: blob.size,
    stream: result.stream,
  }
}

export async function readText(id: string): Promise<string | null> {
  const result = await get(`${ROOT}${id}/text.txt`, { access: 'private' })
  if (!result || result.statusCode !== 200) return null
  return new Response(result.stream).text()
}

/** Removes the original, its text and any marker. Safe to call more than once. */
export async function deleteUpload(id: string): Promise<number> {
  const blobs = await listAll(`${ROOT}${id}/`)
  if (blobs.length > 0) await del(blobs.map((blob) => blob.pathname))
  return blobs.length
}

/** Manual "empty the trash": removes every stored upload and its text right away. */
export async function deleteAllUploads(): Promise<number> {
  const blobs = await listAll(ROOT)
  for (let i = 0; i < blobs.length; i += 500) {
    await del(blobs.slice(i, i + 500).map((blob) => blob.pathname))
  }
  return new Set(blobs.map((blob) => blob.pathname.split('/')[1])).size
}

/** Safety net for the per-file timers: removes anything already past its 12 hours. */
export async function deleteExpiredUploads(now = Date.now()): Promise<number> {
  const expired = new Set<string>()
  for (const blob of await listAll(ROOT)) {
    const id = blob.pathname.split('/')[1]
    if (id && isValidId(id) && isExpired(id, now)) expired.add(id)
  }
  for (const id of expired) await deleteUpload(id)
  return expired.size
}
