export const IMSS_EXTENSION_ZIP = '/tramix-imss-extension.zip'

export type ImssStatus = 'filled' | 'captcha_ready' | 'submitted' | 'fields_not_found' | 'closed'

export interface ImssStatusEvent {
  requestId: string
  status: ImssStatus
  detail?: { fields?: string[]; hasCaptcha?: boolean }
}

type ExtMessage = { source: 'tramix-ext'; type: string; [key: string]: unknown }

function post(message: Record<string, unknown>) {
  window.postMessage({ source: 'tramix-page', ...message }, window.location.origin)
}

function isExtMessage(event: MessageEvent): event is MessageEvent<ExtMessage> {
  return (
    event.source === window &&
    event.origin === window.location.origin &&
    event.data?.source === 'tramix-ext' &&
    typeof event.data.type === 'string'
  )
}

function waitFor<T>(pick: (data: ExtMessage) => T | undefined, timeoutMs: number): Promise<T | null> {
  return new Promise((resolve) => {
    const onMessage = (event: MessageEvent) => {
      if (!isExtMessage(event)) return
      const value = pick(event.data)
      if (value === undefined) return
      cleanup()
      resolve(value)
    }
    const timer = setTimeout(() => {
      cleanup()
      resolve(null)
    }, timeoutMs)
    const cleanup = () => {
      clearTimeout(timer)
      window.removeEventListener('message', onMessage)
    }
    window.addEventListener('message', onMessage)
  })
}

export async function detectExtension(timeoutMs = 700): Promise<string | null> {
  const pong = waitFor((d) => (d.type === 'PONG' ? String(d.version ?? '') : undefined), timeoutMs)
  post({ type: 'PING' })
  return pong
}

export async function startImssAutomation(
  curp: string,
  email: string,
): Promise<{ requestId: string; ok: boolean; error?: string } | null> {
  const requestId = crypto.randomUUID()
  const started = waitFor(
    (d) =>
      d.type === 'IMSS_STARTED' && d.requestId === requestId
        ? { requestId, ok: Boolean(d.ok), error: d.error ? String(d.error) : undefined }
        : undefined,
    5000,
  )
  post({ type: 'IMSS_START', requestId, curp, email })
  return started
}

export function onImssStatus(requestId: string, callback: (event: ImssStatusEvent) => void): () => void {
  const onMessage = (event: MessageEvent) => {
    if (!isExtMessage(event)) return
    const data = event.data
    if (data.type !== 'IMSS_STATUS' || data.requestId !== requestId) return
    callback({
      requestId,
      status: data.status as ImssStatus,
      detail: (data.detail as ImssStatusEvent['detail']) ?? {},
    })
  }
  window.addEventListener('message', onMessage)
  return () => window.removeEventListener('message', onMessage)
}
