import { nssOpenLink, nssShowPortal, nssStart, nssSupport } from '@/lib/validar-nss'

export const CONSTANCIA_URL = 'https://digital.imss.gob.mx/derechohabiencia/tramite/solicitudConstancia'
export const CONSTANCIA_EMAIL_KEY = 'imss-direct:constancia-email'
export const CONSTANCIA_TIMEOUT_MS = 3 * 60 * 1000

type ConstanciaBridge = { constanciaStart?: (email: string) => boolean }

const rawBridge = () =>
  typeof window === 'undefined' ? null : ((window as unknown as { TramixAndroid?: ConstanciaBridge }).TramixAndroid ?? null)

/** The portal automation runs inside the IMSS DIRECT Android app's WebView. */
export const constanciaSupport = (): 'ready' | 'none' => (nssSupport() === 'ready' ? 'ready' : 'none')

/** Opens the official Constancia page in the app's portal WebView (older builds reuse nssOpenLink). */
export function constanciaStart(email: string): boolean {
  const b = rawBridge()
  if (!b) return false
  if (typeof b.constanciaStart === 'function') return b.constanciaStart(email)
  if (!nssStart(email)) return false
  const opened = nssOpenLink(CONSTANCIA_URL)
  nssShowPortal(false)
  return opened
}

/** A real PDF starts with %PDF- and ends with an %%EOF marker. */
export function isValidPdf(bytes: Uint8Array): boolean {
  if (bytes.length < 64) return false
  const head = String.fromCharCode(...bytes.subarray(0, 5))
  if (head !== '%PDF-') return false
  const tail = new TextDecoder('latin1').decode(bytes.subarray(Math.max(0, bytes.length - 2048)))
  return tail.includes('%%EOF')
}
