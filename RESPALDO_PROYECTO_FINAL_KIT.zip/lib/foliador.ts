import { PDFDocument, StandardFonts, degrees, rgb, type PDFFont, type PDFPage } from 'pdf-lib'

export const FOLIO_PATTERN = /^A1[1-9] \d{7}$/
const FOLIO_IN_TEXT = /A1[1-9] \d{7}/

/*
 * Geometry measured from the reference sheet FOLIO.pdf (letter, 612 × 792 pt).
 * Values are points from the visible page's top-left corner. The reference was
 * authored in 96-dpi px (×0.75 → pt), so glyph advances are copied from its
 * content stream instead of using the substitute font's own metrics.
 */
const PX = 0.75
const FONT_SIZE = 14.66 * PX
const LABEL = { text: 'FOLIO', x: 105.05053, baseline: 48.18625 }
const NUMBER = { x: 88.8435, baseline: 60.18625 }
const BARCODE = { x: 75, top: 66, width: 90.01723, height: 14.00025, modules: 112 }
const ADVANCE: Record<string, number> = {
  F: 8.7593994 * PX,
  O: 11.4001007 * PX,
  L: 8.1511078 * PX,
  I: 3.7785645 * PX,
  A: 9.7756042 * PX,
  ' ': 3.578186 * PX,
}
const DIGIT_ADVANCE = 8.1511078 * PX
const BLACK = rgb(0, 0, 0)

const CODE128 =
  '212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 221312 231212 112232 122132 122231 113222 123122 123221 223211 221132 221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 212123 212321 232121 111323 131123 131321 112313 132113 132311 211313 231113 231311 112133 112331 132131 113123 113321 133121 313121 211331 231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 314111 221411 431111 111224 111422 121124 121421 141122 141221 112214 112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 214121 412121 111143 111341 131141 114113 114311 411113 411311 113141 114131 311141 411131 211412 211214 211232 2331112'.split(' ')
const START_B = 104
const CODE_C = 99
const STOP = 106

/**
 * Same encoding as the reference barcode: Code 128 start B, "A1" in set B,
 * then set C for the remaining eight digits (the folio without its space).
 */
export function encodeFolioBarcode(folio: string): number[] {
  if (!FOLIO_PATTERN.test(folio)) throw new Error('Folio con formato inválido')
  const digits = folio.slice(2).replace(' ', '')
  const values = [START_B, 'A'.charCodeAt(0) - 32, '1'.charCodeAt(0) - 32, CODE_C]
  for (let i = 0; i < 8; i += 2) values.push(Number(digits.slice(i, i + 2)))
  const checksum = values.reduce((sum, v, i) => sum + v * (i === 0 ? 1 : i), 0) % 103
  values.push(checksum, STOP)
  const widths = values.flatMap((v) => CODE128[v].split('').map(Number))
  return widths
}

function randomInt(maxExclusive: number): number {
  const limit = Math.floor(0x1_0000_0000 / maxExclusive) * maxExclusive
  const buf = new Uint32Array(1)
  do crypto.getRandomValues(buf)
  while (buf[0] >= limit)
  return buf[0] % maxExclusive
}

export function generateFolio(taken: ReadonlySet<string>): string {
  for (;;) {
    const folio = `A1${1 + randomInt(9)} ${String(randomInt(10_000_000)).padStart(7, '0')}`
    if (!taken.has(folio)) return folio
  }
}

type Placement = { toUser: (u: number, v: number) => { x: number; y: number }; rotate: ReturnType<typeof degrees> }

function placementFor(page: PDFPage): Placement {
  const { x, y, width: w, height: h } = page.getCropBox()
  const angle = (((page.getRotation().angle % 360) + 360) % 360) as 0 | 90 | 180 | 270
  const toUser = {
    0: (u: number, v: number) => ({ x: x + u, y: y + h - v }),
    90: (u: number, v: number) => ({ x: x + v, y: y + u }),
    180: (u: number, v: number) => ({ x: x + w - u, y: y + v }),
    270: (u: number, v: number) => ({ x: x + w - v, y: y + h - u }),
  }[angle]
  return { toUser, rotate: degrees(angle) }
}

function drawSpaced(page: PDFPage, font: PDFFont, place: Placement, text: string, u: number, baseline: number) {
  let cursor = u
  for (const ch of text) {
    if (ch !== ' ') {
      page.drawText(ch, { ...place.toUser(cursor, baseline), size: FONT_SIZE, font, color: BLACK, rotate: place.rotate })
    }
    cursor += ADVANCE[ch] ?? DIGIT_ADVANCE
  }
}

export class FoliadorError extends Error {}

/** Returns a new PDF; the input bytes are never modified. */
export async function stampFolio(original: Uint8Array, folio: string): Promise<Uint8Array> {
  let doc: PDFDocument
  try {
    doc = await PDFDocument.load(original.slice(), { updateMetadata: false })
  } catch (err) {
    const msg = err instanceof Error ? err.message : ''
    throw new FoliadorError(/encrypt/i.test(msg) ? 'El PDF está protegido con contraseña.' : 'El archivo no es un PDF válido o está dañado.')
  }
  const pageCount = doc.getPageCount()
  if (pageCount === 0) throw new FoliadorError('El PDF no tiene páginas.')
  const page = doc.getPage(0)
  const before = page.getSize()
  const font = await doc.embedFont(StandardFonts.Helvetica)
  const place = placementFor(page)

  drawSpaced(page, font, place, LABEL.text, LABEL.x, LABEL.baseline)
  drawSpaced(page, font, place, folio, NUMBER.x, NUMBER.baseline)

  const widths = encodeFolioBarcode(folio)
  const moduleWidth = BARCODE.width / BARCODE.modules
  let cursor = BARCODE.x
  widths.forEach((modules, i) => {
    const width = modules * moduleWidth
    if (i % 2 === 0) {
      page.drawRectangle({
        ...place.toUser(cursor, BARCODE.top + BARCODE.height),
        width,
        height: BARCODE.height,
        color: BLACK,
        borderWidth: 0,
        rotate: place.rotate,
      })
    }
    cursor += width
  })

  const out = await doc.save()
  const check = await PDFDocument.load(out, { updateMetadata: false })
  const after = check.getPage(0).getSize()
  if (check.getPageCount() !== pageCount || after.width !== before.width || after.height !== before.height) {
    throw new FoliadorError('La verificación del PDF resultante falló; no se descargó.')
  }
  return out
}

/** Looks for an existing folio printed on the first page. */
export function findFolioInText(text: string): string | null {
  return text.replace(/\s+/g, ' ').match(FOLIO_IN_TEXT)?.[0] ?? null
}
