import path from 'node:path'
import type { Worker } from 'tesseract.js'
import { itemsToLines, MIN_TEXT_CHARS, type TextItemLike } from '@/lib/pdf/extract-text'
import type { ExtractProgress, TextEngine } from '@/lib/pipeline/core'

type PdfJs = typeof import('pdfjs-dist/legacy/build/pdf.mjs')

const MAX_SERVER_OCR_PAGES = 6
const OCR_SCALE = 2

let pdfjsPromise: Promise<PdfJs> | null = null

function loadPdfJs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    pdfjsPromise = (async () => {
      // Loading the worker module in-process lets pdf.js run without spawning a worker file.
      // @ts-expect-error pdfjs-dist ships no type declarations for the worker entry
      const worker = await import('pdfjs-dist/legacy/build/pdf.worker.mjs')
      ;(globalThis as { pdfjsWorker?: unknown }).pdfjsWorker = worker
      return import('pdfjs-dist/legacy/build/pdf.mjs')
    })()
    pdfjsPromise.catch(() => {
      pdfjsPromise = null
    })
  }
  return pdfjsPromise
}

export async function openPdf(bytes: Uint8Array) {
  const pdfjs = await loadPdfJs()
  const task = pdfjs.getDocument({
    data: bytes.slice(),
    standardFontDataUrl: path.join(process.cwd(), 'node_modules/pdfjs-dist/standard_fonts/'),
  })
  const doc = await task.promise
  return { doc, close: () => task.destroy() }
}

let ocrWorker: Promise<Worker> | null = null

function getOcrWorker(): Promise<Worker> {
  if (!ocrWorker) {
    ocrWorker = import('tesseract.js').then(({ createWorker }) =>
      // Only the language model is cached in /tmp; document images stay in memory.
      createWorker('spa', 1, { cachePath: '/tmp/filekit-ocr' }),
    )
    ocrWorker.catch(() => {
      ocrWorker = null
    })
  }
  return ocrWorker
}

export async function ocrImage(image: Uint8Array): Promise<string> {
  const worker = await getOcrWorker()
  const { data } = await worker.recognize(Buffer.from(image))
  return data.text ?? ''
}

type PdfPage = Awaited<ReturnType<Awaited<ReturnType<typeof openPdf>>['doc']['getPage']>>

async function ocrPage(page: PdfPage): Promise<string> {
  const { createCanvas } = await import('@napi-rs/canvas')
  const viewport = page.getViewport({ scale: OCR_SCALE })
  const canvas = createCanvas(Math.floor(viewport.width), Math.floor(viewport.height))
  const context = canvas.getContext('2d')
  context.fillStyle = '#ffffff'
  context.fillRect(0, 0, canvas.width, canvas.height)
  await page.render({
    canvas: canvas as unknown as HTMLCanvasElement,
    canvasContext: context as unknown as CanvasRenderingContext2D,
    viewport,
  }).promise
  const worker = await getOcrWorker()
  const { data } = await worker.recognize(canvas.toBuffer('image/png'))
  return data.text ?? ''
}

export const nodeEngine: TextEngine = {
  async extractText(bytes, onProgress?: (progress: ExtractProgress) => void) {
    const { doc, close } = await openPdf(bytes)
    const pages: string[] = []
    let usedOcr = false
    let ocrDone = 0
    try {
      for (let n = 1; n <= doc.numPages; n++) {
        onProgress?.({ page: n, totalPages: doc.numPages, mode: 'text' })
        const page = await doc.getPage(n)
        const content = await page.getTextContent()
        let text = itemsToLines(content.items as TextItemLike[])
        if (text.replace(/\s/g, '').length < MIN_TEXT_CHARS && ocrDone < MAX_SERVER_OCR_PAGES) {
          usedOcr = true
          ocrDone++
          text = `${text}\n${await ocrPage(page)}`.trim()
        }
        pages.push(text)
        page.cleanup()
      }
    } finally {
      await close()
    }
    return { pages, usedOcr }
  },

  async ocrPages(bytes, maxPages) {
    const { doc, close } = await openPdf(bytes)
    const pages: string[] = []
    try {
      for (let n = 1; n <= Math.min(doc.numPages, maxPages); n++) {
        const page = await doc.getPage(n)
        pages.push(await ocrPage(page))
        page.cleanup()
      }
    } finally {
      await close()
    }
    return pages
  },
}
