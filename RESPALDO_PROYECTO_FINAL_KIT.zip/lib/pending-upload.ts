// Files picked from another screen (e.g. Descargas) are held in memory across the
// client-side navigation and handed to the home upload flow on arrival.
let pending: File[] | null = null

export function setPendingUpload(files: File[]) {
  pending = files.length ? files : null
}

export function takePendingUpload(): File[] | null {
  const files = pending
  pending = null
  return files
}
