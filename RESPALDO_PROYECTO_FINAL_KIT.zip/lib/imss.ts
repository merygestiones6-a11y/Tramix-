export const IMSS_NSS_PORTAL_URL =
  'https://serviciosdigitales.imss.gob.mx/gestionAsegurados-web-externo/asignacionNSS'

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

export function cleanEmailInput(value: string): string {
  return value.replace(/\s+/g, '').toLowerCase()
}

export function isValidEmail(value: string): boolean {
  return value.length <= 254 && EMAIL_PATTERN.test(value)
}
