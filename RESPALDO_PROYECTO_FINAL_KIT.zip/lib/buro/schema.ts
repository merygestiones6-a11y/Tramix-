import { z } from 'zod'
import { normalizeEntity } from '@/lib/identity-lab/engine'
import { EXTRACT_LIMITS } from '@/lib/identity-lab/doc-extract/limits'
import { imageSchema, segmentSchema } from '@/lib/identity-lab/doc-extract/schema'

export const FOLIO_PATTERN = /^BC-\d{6}-[A-HJ-NP-Z2-9]{8}$/
export const CP_PATTERN = /^\d{5}$/

/** One credential (one file) per request, same limits as the document extractor. */
export const buroRequestSchema = z
  .object({
    segments: z.array(segmentSchema).max(EXTRACT_LIMITS.maxPdfPages),
    images: z.array(imageSchema).max(EXTRACT_LIMITS.maxModelImages),
  })
  .superRefine((req, ctx) => {
    if (req.images.reduce((n, i) => n + i.data.length, 0) > EXTRACT_LIMITS.maxImageBase64Chars) {
      ctx.addIssue({ code: 'custom', message: 'Las imágenes superan el tamaño permitido.' })
    }
    if (new Set([...req.segments, ...req.images].map((x) => x.file)).size > 1) {
      ctx.addIssue({ code: 'custom', message: 'Procesa una credencial a la vez.' })
    }
    if (!req.segments.some((s) => s.text.trim()) && !req.images.length) {
      ctx.addIssue({ code: 'custom', message: 'No se encontró contenido legible en el archivo.' })
    }
  })
export type BuroRequest = z.infer<typeof buroRequestSchema>

const estado = z.enum(['ENCONTRADO', 'NO LEGIBLE', 'NO ENCONTRADO'])

/** What the model returns for a voter ID (INE/IFE). Values are copied as printed. */
export const credentialSchema = z.object({
  esCredencial: z.boolean().describe('true solo si es una credencial para votar del INE o IFE.'),
  nombre: z.string().describe('Nombre(s) de pila, vacío si no aparece.'),
  primerApellido: z.string(),
  segundoApellido: z.string(),
  nombreEstado: estado,
  fechaNacimiento: z.string().describe('AAAA-MM-DD, vacío si no aparece.'),
  sexo: z.enum(['H', 'M', '']),
  curp: z.string().describe('CURP impresa, vacío si no aparece.'),
  rfc: z.string().describe('RFC solo si está impreso; la credencial normalmente no lo tiene.'),
  domicilio: z.string().describe('Renglones del DOMICILIO exactamente como aparecen, separados por " | ".'),
  domicilioEstado: estado,
  calleNumero: z.string().describe('Calle y número exterior/interior del domicilio, tal como aparecen; vacío si no aparece.'),
  colonia: z.string(),
  ciudad: z.string().describe('Ciudad o localidad SOLO si aparece escrita en el domicilio, distinta del municipio; vacío si no aparece.'),
  codigoPostal: z.string().describe('Código postal impreso en el domicilio (5 dígitos), vacío si no aparece.'),
  municipio: z.string(),
  entidad: z.string().describe('Entidad federativa del domicilio.'),
})
export type Credential = z.infer<typeof credentialSchema>

export type GeoStatus = 'OK' | 'SIN_CLAVE' | 'NO_ENCONTRADA' | 'ERROR'
export type MatchResult = 'COINCIDE' | 'COINCIDENCIA PARCIAL' | 'NO COINCIDE' | 'SIN COMPROBAR'

export interface GeoComponents {
  formatted: string
  lat: number
  lng: number
  codigoPostal: string
  municipio: string
  entidad: string
  colonia: string
  aproximada: boolean
}

export interface Comparison {
  result: MatchResult
  details: string[]
}

export interface BuroRecord {
  folio: string
  createdAt: string
  esCredencial: boolean
  nombreCompleto: string
  /** Optional: records saved before the name/address split do not have them. */
  nombre?: string
  primerApellido?: string
  segundoApellido?: string
  domicilio: string
  calleNumero?: string
  colonia: string
  ciudad?: string
  codigoPostal: string
  municipio: string
  entidad: string
  rfc: { value: string | null; condition: 'EXTRAÍDO' | 'CANDIDATO' | null; note: string }
  geo: { status: GeoStatus; place: GeoComponents | null; query: string }
  comparison: Comparison
  warnings: string[]
}

const norm = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, ' ')
    .trim()

const entityCode = (value: string) => {
  if (!value.trim()) return ''
  const n = norm(value)
  if (/^(CDMX|DF|D F|CIUDAD DE MEXICO|DISTRITO FEDERAL)$/.test(n)) return 'DF'
  const code = normalizeEntity(value)
  return code.length === 2 ? code : n
}

const sameMunicipality = (a: string, b: string) => {
  const x = norm(a).replace(/^(MUNICIPIO|ALCALDIA|DELEGACION) /, '')
  const y = norm(b).replace(/^(MUNICIPIO|ALCALDIA|DELEGACION) /, '')
  return Boolean(x && y && (x.includes(y) || y.includes(x)))
}

/** Compares the credential address with the Google geocoder result. Never treated as proof of address. */
export function compareAddress(cred: Pick<BuroRecord, 'codigoPostal' | 'municipio' | 'entidad'>, place: GeoComponents | null): Comparison {
  if (!place) return { result: 'SIN COMPROBAR', details: [] }
  const details: string[] = []
  let mismatch = false
  let unknown = false

  if (!CP_PATTERN.test(cred.codigoPostal)) {
    unknown = true
    details.push('La credencial no tiene un código postal legible para comparar.')
  } else if (!place.codigoPostal) {
    unknown = true
    details.push('Google Maps no devolvió código postal para esta ubicación.')
  } else if (place.codigoPostal !== cred.codigoPostal) {
    mismatch = true
    details.push(`El código postal no coincide: credencial ${cred.codigoPostal}, Google Maps ${place.codigoPostal}.`)
  } else {
    details.push('El código postal coincide.')
  }

  if (cred.entidad && place.entidad) {
    if (entityCode(cred.entidad) !== entityCode(place.entidad)) {
      mismatch = true
      details.push(`La entidad no coincide: credencial ${cred.entidad}, Google Maps ${place.entidad}.`)
    }
  } else unknown = true

  if (cred.municipio && place.municipio) {
    if (!sameMunicipality(cred.municipio, place.municipio)) {
      mismatch = true
      details.push(`El municipio no coincide: credencial ${cred.municipio}, Google Maps ${place.municipio}.`)
    }
  } else unknown = true

  if (place.aproximada) {
    unknown = true
    details.push('Google Maps ubicó la dirección de forma aproximada, no en el número exacto.')
  }
  return { result: mismatch ? 'NO COINCIDE' : unknown ? 'COINCIDENCIA PARCIAL' : 'COINCIDE', details }
}

/**
 * Street line for display. Uses the extracted value; for records saved before the split,
 * falls back to the first printed DOMICILIO line, which on INE credentials is street and number.
 */
export function streetLine(r: Pick<BuroRecord, 'calleNumero' | 'domicilio'>) {
  if (r.calleNumero !== undefined) return r.calleNumero
  return r.domicilio.split('|')[0]?.trim() ?? ''
}

/** Text used both for geocoding and for the keyless map embed. */
export function addressQuery(r: Pick<BuroRecord, 'domicilio' | 'codigoPostal' | 'municipio' | 'entidad'>) {
  const base = r.domicilio.replace(/\s*\|\s*/g, ', ')
  const extras = [r.codigoPostal, r.municipio, r.entidad].filter((x) => x && !norm(base).includes(norm(x)))
  return [base, ...extras, 'México'].filter(Boolean).join(', ')
}
