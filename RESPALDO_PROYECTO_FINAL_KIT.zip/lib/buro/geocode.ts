import 'server-only'
import type { GeoComponents, GeoStatus } from './schema'

interface GoogleComponent {
  long_name: string
  types: string[]
}
interface GoogleResult {
  formatted_address: string
  partial_match?: boolean
  address_components: GoogleComponent[]
  geometry: { location: { lat: number; lng: number }; location_type: string }
}

const pick = (cs: GoogleComponent[], ...types: string[]) => {
  for (const t of types) {
    const hit = cs.find((c) => c.types.includes(t))
    if (hit) return hit.long_name
  }
  return ''
}

/** Google Geocoding API, server-side only. Requires GOOGLE_MAPS_API_KEY. */
export async function geocode(query: string, signal: AbortSignal): Promise<{ status: GeoStatus; place: GeoComponents | null; code: string }> {
  const key = process.env.GOOGLE_MAPS_API_KEY
  if (!key) return { status: 'SIN_CLAVE', place: null, code: 'sin-clave' }
  if (!query.trim()) return { status: 'NO_ENCONTRADA', place: null, code: 'sin-direccion' }

  const url = new URL('https://maps.googleapis.com/maps/api/geocode/json')
  url.searchParams.set('address', query)
  url.searchParams.set('components', 'country:MX')
  url.searchParams.set('language', 'es')
  url.searchParams.set('region', 'mx')
  url.searchParams.set('key', key)
  try {
    const res = await fetch(url, { signal: AbortSignal.any([signal, AbortSignal.timeout(8_000)]), cache: 'no-store' })
    const data = (await res.json()) as { status: string; results?: GoogleResult[] }
    if (data.status === 'ZERO_RESULTS') return { status: 'NO_ENCONTRADA', place: null, code: data.status }
    const first = data.results?.[0]
    if (data.status !== 'OK' || !first) return { status: 'ERROR', place: null, code: data.status || `http-${res.status}` }
    const cs = first.address_components
    return {
      status: 'OK',
      code: 'OK',
      place: {
        formatted: first.formatted_address,
        lat: first.geometry.location.lat,
        lng: first.geometry.location.lng,
        codigoPostal: pick(cs, 'postal_code'),
        municipio: pick(cs, 'locality', 'administrative_area_level_2', 'sublocality'),
        entidad: pick(cs, 'administrative_area_level_1'),
        colonia: pick(cs, 'sublocality_level_1', 'neighborhood', 'sublocality'),
        aproximada: Boolean(first.partial_match) || first.geometry.location_type === 'APPROXIMATE',
      },
    }
  } catch (error) {
    const name = error instanceof Error ? error.name : ''
    return { status: 'ERROR', place: null, code: name === 'TimeoutError' ? 'tiempo' : 'red' }
  }
}
