import 'server-only'
import { randomBytes } from 'node:crypto'
import { get, put } from '@vercel/blob'
import { FOLIO_PATTERN, type BuroRecord } from './schema'

/** Private Blob: one JSON per folio at buro/<folio>.json. Written once, never overwritten. */
const pathOf = (folio: string) => `buro/${folio}.json`
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

export function newFolio(date = new Date()) {
  const ymd = date.toISOString().slice(2, 10).replace(/-/g, '')
  const suffix = Array.from(randomBytes(8), (b) => ALPHABET[b % ALPHABET.length]).join('')
  return `BC-${ymd}-${suffix}`
}

export async function saveRecord(record: BuroRecord) {
  await put(pathOf(record.folio), JSON.stringify(record), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: false,
    contentType: 'application/json',
  })
}

export async function getRecord(folio: string): Promise<BuroRecord | null> {
  if (!FOLIO_PATTERN.test(folio)) return null
  const result = await get(pathOf(folio), { access: 'private', useCache: false }).catch(() => null)
  if (!result || result.statusCode !== 200 || !result.stream) return null
  try {
    return JSON.parse(await new Response(result.stream).text()) as BuroRecord
  } catch {
    return null
  }
}
