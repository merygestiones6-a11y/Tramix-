import type { ImssDocument } from '@/lib/imss-android'

export const DEFAULT_NSS_EMAIL = 'mauriciosantanacano3@gmail.com'
export const CURP_PATTERN = /^[A-Z][AEIOUX][A-Z]{2}\d{6}[HMX][A-Z]{5}[A-Z0-9]\d$/

export type NssResultKind = 'found' | 'not_found' | 'link_sent' | 'error'

export interface NssResult {
  kind: NssResultKind
  curp?: string
  name?: string
  nss?: string
  email?: string
  message?: string
}

export type NssEvent =
  | { jobId: string; status: 'loading'; detail: Record<string, never> }
  | { jobId: string; status: 'captcha'; detail: { image?: string; retry?: boolean; resubmit?: boolean; message?: string } }
  | { jobId: string; status: 'captcha_widget'; detail: { message?: string } }
  | { jobId: string; status: 'submitting'; detail: Record<string, never> }
  | { jobId: string; status: 'result'; detail: NssResult & { hasPdf?: boolean } }
  | { jobId: string; status: 'step'; detail: { reason?: 'incomplete' | 'next' | 'no_button'; missing?: string[]; message?: string } }
  | { jobId: string; status: 'pdf_available'; detail: { curp?: string; name?: string } }
  | { jobId: string; status: 'fields_not_found' | 'load_error'; detail: { message?: string; reason?: string } }
  | { jobId: string; status: 'document'; detail: ImssDocument }
  | { jobId: string; status: 'download_failed'; detail: { reason?: string } }
  | { jobId: string; status: 'documents'; detail: { count?: number } }
  | { jobId: string; status: 'page_message'; detail: { message?: string } }
  | { jobId: string; status: 'manual'; detail: { message?: string } }
  | { jobId: string; status: 'resumed'; detail: Record<string, never> }
  | { jobId: string; status: 'diag'; detail: { stage?: string; [k: string]: unknown } }

interface NssBridge {
  nssStart(email: string): boolean
  nssSubmit(curp: string, email: string, captcha: string): boolean
  nssRefresh(): boolean
  nssShowPortal(show: boolean): void
  nssCancel(): void
  nssTakeEvents(): string
  nssDownload?(): boolean
  nssOpenLink?(url: string): boolean
}

export const IMSS_LINK_PATTERN = /^https:\/\/([a-z0-9-]+\.)*imss\.gob\.mx\//i

type AnyBridge = Partial<NssBridge> & { version?: () => string }

function rawBridge(): AnyBridge | null {
  if (typeof window === 'undefined') return null
  return (window as unknown as { TramixAndroid?: AnyBridge }).TramixAndroid ?? null
}

/** 'ready' = app with NO DERECHO IMSS · 'outdated' = older TRAMIX app · 'none' = regular browser. */
export function nssSupport(): 'ready' | 'outdated' | 'none' {
  const b = rawBridge()
  if (!b) return 'none'
  return typeof b.nssStart === 'function' && typeof b.nssOpenLink === 'function' ? 'ready' : 'outdated'
}

const bridge = () => {
  const b = rawBridge()
  return b && typeof b.nssStart === 'function' ? (b as NssBridge) : null
}

export const nssStart = (email: string) => bridge()?.nssStart(email) ?? false
export const nssSubmit = (curp: string, email: string, captcha: string) => bridge()?.nssSubmit(curp, email, captcha) ?? false
export const nssRefresh = () => bridge()?.nssRefresh() ?? false
export const nssShowPortal = (show: boolean) => bridge()?.nssShowPortal(show)
export const nssCancel = () => bridge()?.nssCancel()
export const nssDownload = () => bridge()?.nssDownload?.() ?? false
export const nssOpenLink = (url: string) => bridge()?.nssOpenLink?.(url) ?? false

export const NSS_PATTERN = /^\d{11}$/

type VigenciaBridge = {
  vigenciaStart?: (email: string) => boolean
  vigenciaSubmit?: (nss: string, curp: string, email: string, captcha: string) => boolean
}
const vigenciaBridge = () => rawBridge() as (AnyBridge & VigenciaBridge) | null

/** VIGENCIA reuses the IMSS DIRECT portal WebView, so the CAPTCHA panel shows whenever the app bridge exists. */
export function vigenciaSupport(): 'ready' | 'outdated' | 'none' {
  return rawBridge() ? 'ready' : 'none'
}
export const VIGENCIA_URL = 'https://serviciosdigitales.imss.gob.mx/gestionAsegurados-web-externo/vigencia'

/** Builds without vigenciaStart open the official Vigencia page in the same portal WebView via nssOpenLink. */
export const vigenciaHasNative = () => typeof vigenciaBridge()?.vigenciaStart === 'function'

export function vigenciaStart(email: string): boolean {
  const b = vigenciaBridge()
  if (!b) return false
  if (typeof b.vigenciaStart === 'function' && b.vigenciaStart(email)) return true
  if (typeof b.nssStart !== 'function' || typeof b.nssOpenLink !== 'function') return false
  if (!b.nssStart(email)) return false
  const opened = b.nssOpenLink(VIGENCIA_URL)
  b.nssShowPortal?.(false)
  return opened
}

export function vigenciaSubmit(nss: string, curp: string, email: string, captcha: string): boolean {
  const b = vigenciaBridge()
  if (!b) return false
  // nssSubmit cannot type the NSS, so it would send Vigencia with required fields empty.
  return typeof b.vigenciaSubmit === 'function' && b.vigenciaSubmit(nss, curp, email, captcha)
}

/** RECEPTOR DE DOCUMENTOS: the TRAMIX app opens the e-mail link in its IMSS WebView and reads the page. */
export const nssCanReceive = () => typeof (rawBridge() as { nssReceive?: unknown } | null)?.nssReceive === 'function'
export const nssReceive = (url: string) =>
  (rawBridge() as { nssReceive?: (url: string) => boolean } | null)?.nssReceive?.(url) ?? false

export function nssTakeEvents(): NssEvent[] {
  try {
    return JSON.parse(bridge()?.nssTakeEvents() || '[]') as NssEvent[]
  } catch {
    return []
  }
}

/** Chrome on Android opens the installed app on this page; without the app it downloads the APK. */
export function buildNssIntentUrl(apkPath: string): string {
  const origin = window.location.origin
  const query = new URLSearchParams({ url: origin, path: '/no-derecho-imss' }).toString()
  const fallback = encodeURIComponent(`${origin}${apkPath}`)
  return `intent://open?${query}#Intent;scheme=tramix;package=mx.tramix.app;S.browser_fallback_url=${fallback};end`
}
