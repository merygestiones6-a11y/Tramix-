import { stripPdfExtension } from './files'

/** Rule: [PREFIX]_[CURP].pdf — falls back to the original name when there is no CURP yet. */
export function buildSuggestedFileName({
  prefix,
  curp,
  fallbackName,
}: {
  prefix: string
  curp: string
  fallbackName: string
}): string {
  const base = curp.trim() ? curp.trim().toUpperCase() : stripPdfExtension(fallbackName)
  return `${prefix}${base}.pdf`
}

/** Turns free text ("acta nacimiento") into a prefix ("ACTA NACIMIENTO_"). */
export function toCustomPrefix(value: string): string {
  const clean = value.trim().toUpperCase()
  return clean ? `${clean}_` : ''
}

/**
 * Keeps the user's name exactly as typed. Only characters that devices
 * reject in file names are removed, and ".pdf" is added if missing.
 */
export function finalizeFileName(value: string): string {
  const clean = value.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').trim()
  if (!clean || /^\.pdf$/i.test(clean)) return ''
  return /\.pdf$/i.test(clean) ? clean : `${clean}.pdf`
}
