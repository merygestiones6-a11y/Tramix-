export const SERVICE_NUMBER = /^\d{11,12}$/
export const SERVICE_MAX_LENGTH = 12
export const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
/** TRAMIX's own cap per account. CFE has not published a per-account limit, so none is claimed as confirmed. */
export const SERVICES_PER_ACCOUNT = 10

/**
 * 'conectada' is reserved for a verified CFE login. No authorized CFE login mechanism exists yet,
 * so nothing can set it: it is excluded from MANUAL_STATUSES and the API rejects it.
 */
export type AccountStatus = 'pendiente' | 'conectada' | 'sesion-vencida' | 'error-auth' | 'deshabilitada'

export const MANUAL_STATUSES: AccountStatus[] = ['pendiente', 'sesion-vencida', 'error-auth', 'deshabilitada']

export const STATUS_LABEL: Record<AccountStatus, string> = {
  pendiente: 'Sin verificar',
  conectada: 'Conectada',
  'sesion-vencida': 'Sesión vencida',
  'error-auth': 'Error de autenticación',
  deshabilitada: 'Deshabilitada',
}

export interface LinkedService {
  number: string
  at: string
}

export interface CfeDirectAccount {
  id: string
  email: string
  status: AccountStatus
  services: LinkedService[]
  createdAt: string
  updatedAt: string
  lastUsedAt?: string
  lastError?: string
}

export type ConsultResult = 'recibo' | 'sin-recibo' | 'sin-cuenta'

export interface Consultation {
  id: string
  serviceNumber: string
  accountId: string | null
  accountEmail: string | null
  receiptId: string | null
  result: ConsultResult
  at: string
}

export interface ReceiptRef {
  id: string
  fileName: string
  createdAt: string
}

export interface ConsultResponse {
  consultation: Consultation
  account: Pick<CfeDirectAccount, 'id' | 'email' | 'status'> | null
  selection: SelectionReason
  receipt: ReceiptRef | null
  /** No official CFE API exists; live retrieval stays pending until an authorized source is connected. */
  integration: 'pendiente'
}

export type SelectionReason = 'asociada' | 'menor-uso' | 'asociada-no-disponible' | 'sin-cuentas'

export type ErrorCode =
  | 'invalid-email'
  | 'duplicate'
  | 'not-found'
  | 'invalid-service'
  | 'invalid-status'
  | 'unauthorized'
  | 'server-error'

export const ERROR_MESSAGE: Record<ErrorCode, string> = {
  'invalid-email': 'Correo no válido.',
  duplicate: 'Ese correo ya está registrado.',
  'not-found': 'La cuenta ya no existe.',
  'invalid-service': 'El número de servicio debe tener 11 o 12 dígitos.',
  'invalid-status': 'Estado no válido.',
  unauthorized: 'Tu sesión del panel venció. Vuelve a iniciar sesión.',
  'server-error': 'No se pudo completar la operación. Intenta de nuevo.',
}
