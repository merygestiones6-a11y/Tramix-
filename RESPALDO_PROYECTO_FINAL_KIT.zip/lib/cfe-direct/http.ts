import 'server-only'
import { CfeDirectError } from './store'
import type { ErrorCode } from './types'

export const NO_STORE = { 'Cache-Control': 'no-store' }

const STATUS: Record<ErrorCode, number> = {
  'invalid-email': 400,
  duplicate: 409,
  'not-found': 404,
  'invalid-service': 400,
  'invalid-status': 400,
  unauthorized: 401,
  'server-error': 500,
}

export function fail(code: ErrorCode) {
  return Response.json({ error: code }, { status: STATUS[code], headers: NO_STORE })
}

export function handle(error: unknown) {
  if (error instanceof CfeDirectError) return fail(error.code)
  console.error('[cfe-direct]', error)
  return fail('server-error')
}
