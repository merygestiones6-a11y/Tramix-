import 'server-only'
import { randomBytes } from 'node:crypto'
import { get, put } from '@vercel/blob'
import { getCfeState } from '@/lib/cfe/store'
import { selectAccount } from './select'
import type {
  AccountStatus,
  CfeDirectAccount,
  Consultation,
  ConsultResponse,
  ErrorCode,
  ReceiptRef,
} from './types'

/**
 * Private Blob: cfe-direct/state.json holds the CFE DIRECT accounts and consultation log.
 * Only e-mail addresses are stored — no passwords — so nothing sensitive sits at rest.
 * Real receipts are read (never written) from the existing receipt store in lib/cfe.
 */
const STATE_PATH = 'cfe-direct/state.json'
const ID = /^[a-f0-9]{24}$/
const MAX_CONSULTATIONS = 200

interface State {
  accounts: CfeDirectAccount[]
  consultations: Consultation[]
}

export class CfeDirectError extends Error {
  constructor(public code: ErrorCode) {
    super(code)
  }
}

export const isAccountId = (id: string) => ID.test(id)
const newId = () => randomBytes(12).toString('hex')
const now = () => new Date().toISOString()

async function readState(): Promise<State> {
  const result = await get(STATE_PATH, { access: 'private', useCache: false }).catch(() => null)
  if (result && result.statusCode === 200 && result.stream) {
    try {
      const parsed = JSON.parse(await new Response(result.stream).text()) as Partial<State>
      // The old manual "Disponible" status was never verified with CFE, so it reads as "Sin verificar".
      const accounts = (parsed.accounts ?? []).map((a) =>
        (a.status as string) === 'disponible' || a.status === 'conectada' ? { ...a, status: 'pendiente' as const } : a,
      )
      return { accounts, consultations: parsed.consultations ?? [] }
    } catch {}
  }
  return { accounts: [], consultations: [] }
}

async function writeState(state: State) {
  state.consultations = state.consultations.slice(0, MAX_CONSULTATIONS)
  await put(STATE_PATH, JSON.stringify(state), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

let queue: Promise<unknown> = Promise.resolve()
function mutate<T>(change: (state: State) => T | Promise<T>): Promise<T> {
  const run = queue.then(async () => {
    const state = await readState()
    const result = await change(state)
    await writeState(state)
    return result
  })
  queue = run.catch(() => undefined)
  return run
}

function findAccount(state: State, id: string): CfeDirectAccount {
  const account = state.accounts.find((a) => a.id === id)
  if (!account) throw new CfeDirectError('not-found')
  return account
}

export const getState = readState

export function addAccount(email: string): Promise<CfeDirectAccount> {
  return mutate((state) => {
    if (state.accounts.some((a) => a.email === email)) throw new CfeDirectError('duplicate')
    const at = now()
    const account: CfeDirectAccount = { id: newId(), email, status: 'pendiente', services: [], createdAt: at, updatedAt: at }
    state.accounts.push(account)
    return account
  })
}

export function deleteAccount(id: string): Promise<void> {
  return mutate((state) => {
    findAccount(state, id)
    state.accounts = state.accounts.filter((a) => a.id !== id)
  })
}

export function setStatus(id: string, status: AccountStatus): Promise<void> {
  return mutate((state) => {
    const account = findAccount(state, id)
    account.status = status
    account.updatedAt = now()
    if (status === 'pendiente') delete account.lastError
  })
}

export function removeService(id: string, serviceNumber: string): Promise<void> {
  return mutate((state) => {
    const account = findAccount(state, id)
    account.services = account.services.filter((s) => s.number !== serviceNumber)
    account.updatedAt = now()
  })
}

/** Most recent real receipt for this service number, from the existing receipt store. */
async function latestReceipt(serviceNumber: string): Promise<ReceiptRef | null> {
  const { receipts } = await getCfeState()
  const match = receipts
    .filter((r) => r.serviceNumber === serviceNumber)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]
  return match ? { id: match.id, fileName: match.fileName, createdAt: match.createdAt } : null
}

export async function consult(serviceNumber: string): Promise<ConsultResponse> {
  const receipt = await latestReceipt(serviceNumber)
  return mutate((state) => {
    const { account, reason } = selectAccount(state.accounts, serviceNumber)
    const at = now()
    if (account) {
      if (!account.services.some((s) => s.number === serviceNumber)) account.services.push({ number: serviceNumber, at })
      account.lastUsedAt = at
      account.updatedAt = at
    }
    const consultation: Consultation = {
      id: newId(),
      serviceNumber,
      accountId: account?.id ?? null,
      accountEmail: account?.email ?? null,
      receiptId: receipt?.id ?? null,
      result: receipt ? 'recibo' : account ? 'sin-recibo' : 'sin-cuenta',
      at,
    }
    state.consultations.unshift(consultation)
    return {
      consultation,
      account: account ? { id: account.id, email: account.email, status: account.status } : null,
      selection: reason,
      receipt,
      integration: 'pendiente' as const,
    }
  })
}
