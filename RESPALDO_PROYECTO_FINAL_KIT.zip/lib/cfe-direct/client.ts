import { AccessError, accessFetch } from '@/lib/outlook/client'
import { ERROR_MESSAGE, type ErrorCode } from './types'

export class CallError extends Error {
  constructor(public code: ErrorCode) {
    super(ERROR_MESSAGE[code])
  }
}

export async function call<T>(url: string, init: RequestInit = {}): Promise<T> {
  let res: Response
  try {
    res = await accessFetch(url, {
      ...init,
      headers: init.body ? { 'Content-Type': 'application/json', ...init.headers } : init.headers,
    })
  } catch (error) {
    throw new CallError(error instanceof AccessError ? 'unauthorized' : 'server-error')
  }
  const data = (await res.json().catch(() => null)) as (T & { error?: ErrorCode }) | null
  if (!res.ok) {
    const code = data?.error && data.error in ERROR_MESSAGE ? data.error : 'server-error'
    throw new CallError(code)
  }
  return data as T
}

export const messageOf = (error: unknown) =>
  error instanceof CallError ? error.message : ERROR_MESSAGE['server-error']
