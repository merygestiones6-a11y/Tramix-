import { SERVICES_PER_ACCOUNT, type AccountStatus, type CfeDirectAccount, type SelectionReason } from './types'

export const isUsable = (status: AccountStatus) => status === 'conectada' || status === 'pendiente'

/**
 * A service number stays on the account it was first linked to. New numbers go to the usable
 * account with the fewest services, breaking ties by the one used longest ago.
 */
export function selectAccount(
  accounts: CfeDirectAccount[],
  serviceNumber: string,
): { account: CfeDirectAccount | null; reason: SelectionReason } {
  const linked = accounts.find((a) => a.services.some((s) => s.number === serviceNumber))
  if (linked) {
    return isUsable(linked.status) ? { account: linked, reason: 'asociada' } : { account: null, reason: 'asociada-no-disponible' }
  }
  const candidates = accounts
    .filter((a) => isUsable(a.status) && a.services.length < SERVICES_PER_ACCOUNT)
    .sort((a, b) => {
      if (a.status !== b.status) return a.status === 'conectada' ? -1 : 1
      if (a.services.length !== b.services.length) return a.services.length - b.services.length
      return (a.lastUsedAt ?? '').localeCompare(b.lastUsedAt ?? '')
    })
  return candidates[0] ? { account: candidates[0], reason: 'menor-uso' } : { account: null, reason: 'sin-cuentas' }
}
