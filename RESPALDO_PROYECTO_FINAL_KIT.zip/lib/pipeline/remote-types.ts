import type { DetectedData } from '@/lib/extract'

export interface RemoteMeta {
  merged: boolean
  pageCount: number
  usedOcr: boolean
  data: DetectedData
  procedureId: string | null
  procedureScore: number
}
