import { detectPersonalData, type DetectedData } from '@/lib/extract'
import { detectProcedure, type ProcedureMatch } from '@/lib/procedures'

export interface ExtractProgress {
  page: number
  totalPages: number
  mode: 'text' | 'ocr'
  ocrProgress?: number
}

/** Text access that differs between the browser (pdf.js worker + canvas) and the server (Node + @napi-rs/canvas). */
export interface TextEngine {
  extractText(
    bytes: Uint8Array,
    onProgress?: (progress: ExtractProgress) => void,
  ): Promise<{ pages: string[]; usedOcr: boolean }>
  ocrPages(bytes: Uint8Array, maxPages: number, onProgress?: (progress: ExtractProgress) => void): Promise<string[]>
}

export interface DetectionOutcome {
  pageCount: number
  usedOcr: boolean
  data: DetectedData
  procedure: ProcedureMatch | null
}

const NAME_OCR_PAGES = 3

function hasConfirmedName(data: DetectedData): boolean {
  return Boolean(data.name) && data.nameConfidence !== 'low'
}

function rankData(data: DetectedData): number {
  const nameRank = { high: 3, medium: 2, low: 1 }[data.nameConfidence ?? 'low'] * (data.name ? 1 : 0)
  return nameRank * 2 + (data.curp ? 1 : 0)
}

/**
 * Universal flow, independent of the document type:
 * read every page → person + CURP (+ NSS) → procedure only as a label.
 * An unknown procedure never stops the analysis.
 */
export async function detectFromBytes(
  bytes: Uint8Array,
  engine: TextEngine,
  onProgress?: (progress: ExtractProgress) => void,
  onSecondPass?: (progress: ExtractProgress) => void,
): Promise<DetectionOutcome> {
  const { pages, usedOcr } = await engine.extractText(bytes, onProgress)
  const procedure = detectProcedure(pages)
  let data = detectPersonalData(pages)
  let ocrUsed = usedOcr

  // Name + CURP are the primary data. If the text layer did not expose them, read the rendered pages.
  if (!usedOcr && (!hasConfirmedName(data) || !data.curp)) {
    try {
      const ocrPages = await engine.ocrPages(bytes, NAME_OCR_PAGES, onSecondPass)
      const retry = detectPersonalData([...pages, ...ocrPages])
      if (rankData(retry) > rankData(data)) {
        data = { ...retry, curp: data.curp ?? retry.curp, nss: data.nss ?? retry.nss }
        ocrUsed = true
      }
    } catch (error) {
      console.error('[FileKit] OCR second pass failed', error)
    }
  }

  return { pageCount: pages.length, usedOcr: ocrUsed, data, procedure }
}
