import type { DetectedData } from '@/lib/extract'
import { assertReadablePdf, extractPdfText, ocrPdfPages } from '@/lib/pdf/extract-text'
import { mergePdfs } from '@/lib/pdf/merge'
import type { ProcedureMatch } from '@/lib/procedures'
import { detectFromBytes, type TextEngine } from './core'

export type AnalysisStage = 'merging' | 'reading' | 'extracting' | 'ocr' | 'detecting' | 'generating'

export interface AnalysisProgress {
  stage: AnalysisStage
  detail: string
  /** 0–1 */
  value: number
}

export interface AnalysisResult {
  /** Final document: the untouched original for one file, the merged PDF for several. */
  bytes: Uint8Array
  pageCount: number
  merged: boolean
  usedOcr: boolean
  data: DetectedData
  procedure: ProcedureMatch | null
  /** Where the analysis ran. */
  engine: 'server' | 'device'
}

export class UnreadablePdfError extends Error {
  constructor(public readonly fileId: string) {
    super('unreadable')
  }
}

export interface AnalysisInput {
  id: string
  file: File
}

const browserEngine: TextEngine = { extractText: extractPdfText, ocrPages: ocrPdfPages }

/** On-device fallback when the server is unreachable or the upload is too large. */
export async function analyzeDocuments(
  inputs: AnalysisInput[],
  onProgress: (progress: AnalysisProgress) => void,
): Promise<AnalysisResult> {
  const merged = inputs.length > 1
  const sources: Uint8Array[] = []
  for (const [index, { id, file }] of inputs.entries()) {
    onProgress({
      stage: merged ? 'merging' : 'reading',
      detail: `Leyendo ${file.name}`,
      value: (0.12 * index) / inputs.length,
    })
    const bytes = new Uint8Array(await file.arrayBuffer())
    try {
      await assertReadablePdf(bytes)
    } catch {
      throw new UnreadablePdfError(id)
    }
    sources.push(bytes)
  }

  let bytes = sources[0]
  if (merged) {
    onProgress({ stage: 'merging', detail: `Uniendo ${sources.length} documentos`, value: 0.15 })
    bytes = await mergePdfs(sources)
  }

  const start = 0.2
  const span = 0.68
  const outcome = await detectFromBytes(
    bytes,
    browserEngine,
    (event) => {
      const fraction = (event.page - 1 + (event.mode === 'ocr' ? (event.ocrProgress ?? 0) : 0.6)) / event.totalPages
      onProgress({
        stage: event.mode === 'ocr' ? 'ocr' : 'extracting',
        detail:
          event.mode === 'ocr'
            ? `Leyendo página escaneada ${event.page} de ${event.totalPages}`
            : `Página ${event.page} de ${event.totalPages}`,
        value: start + span * fraction,
      })
    },
    (event) =>
      onProgress({
        stage: 'ocr',
        detail: `Buscando nombre con OCR · página ${event.page} de ${event.totalPages}`,
        value: 0.88 + 0.08 * ((event.page - 1 + (event.ocrProgress ?? 0)) / event.totalPages),
      }),
  )

  onProgress({ stage: 'generating', detail: 'Preparando el PDF final', value: 0.97 })
  return { bytes, merged, engine: 'device', ...outcome }
}
