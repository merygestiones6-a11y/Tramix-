import { getProcedureById } from '@/lib/procedures'
import {
  UnreadablePdfError,
  type AnalysisInput,
  type AnalysisProgress,
  type AnalysisResult,
  type AnalysisStage,
} from './analyze'
import type { RemoteMeta } from './remote-types'

/** Vercel Functions accept request bodies up to 4.5 MB; larger uploads are analyzed on the device. */
export const REMOTE_MAX_BYTES = 4 * 1024 * 1024
const REMOTE_TIMEOUT_MS = 55_000

export class RemoteUnavailableError extends Error {}

const WAITING_STAGES: { stage: AnalysisStage; detail: string; after: number }[] = [
  { stage: 'merging', detail: 'Enviando y uniendo en el servidor', after: 0 },
  { stage: 'reading', detail: 'Leyendo todas las páginas', after: 900 },
  { stage: 'extracting', detail: 'Buscando nombre, CURP y NSS', after: 2200 },
  { stage: 'ocr', detail: 'Leyendo páginas escaneadas', after: 7000 },
]

export async function analyzeRemote(
  inputs: AnalysisInput[],
  onProgress: (progress: AnalysisProgress) => void,
): Promise<AnalysisResult> {
  const total = inputs.reduce((sum, { file }) => sum + file.size, 0)
  if (total > REMOTE_MAX_BYTES) throw new RemoteUnavailableError('too-large')

  const merging = inputs.length > 1
  const started = Date.now()
  const stages = WAITING_STAGES.filter((s) => merging || s.stage !== 'merging')
  const tick = () => {
    const elapsed = Date.now() - started
    const current = [...stages].reverse().find((s) => elapsed >= s.after) ?? stages[0]
    // Asymptotic so the bar keeps moving without claiming to be finished.
    onProgress({ stage: current.stage, detail: current.detail, value: 0.9 * (1 - Math.exp(-elapsed / 6000)) })
  }
  tick()
  const timer = setInterval(tick, 400)

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), REMOTE_TIMEOUT_MS)

  try {
    const body = new FormData()
    inputs.forEach(({ file }) => body.append('files', file, file.name))

    let response: Response
    try {
      response = await fetch('/api/analyze', { method: 'POST', body, signal: controller.signal, cache: 'no-store' })
    } catch {
      throw new RemoteUnavailableError('network')
    }

    if (response.status === 422) {
      const { index } = (await response.json().catch(() => ({}))) as { index?: number }
      throw new UnreadablePdfError(inputs[index ?? 0]?.id ?? inputs[0].id)
    }
    const rawMeta = response.headers.get('X-FileKit-Meta')
    if (!response.ok || !rawMeta) throw new RemoteUnavailableError(`status-${response.status}`)

    const meta = JSON.parse(decodeURIComponent(rawMeta)) as RemoteMeta
    onProgress({ stage: 'generating', detail: 'Preparando el PDF final', value: 0.96 })

    const bytes = meta.merged
      ? new Uint8Array(await response.arrayBuffer())
      : new Uint8Array(await inputs[0].file.arrayBuffer())
    const rule = meta.procedureId ? getProcedureById(meta.procedureId) : undefined

    return {
      bytes,
      merged: meta.merged,
      pageCount: meta.pageCount,
      usedOcr: meta.usedOcr,
      data: meta.data,
      procedure: rule ? { rule, score: meta.procedureScore } : null,
      engine: 'server',
    }
  } finally {
    clearInterval(timer)
    clearTimeout(timeout)
  }
}
