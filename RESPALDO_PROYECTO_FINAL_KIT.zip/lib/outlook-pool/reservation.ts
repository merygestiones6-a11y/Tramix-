import { AccessError, accessFetch } from '@/lib/outlook/client'
import type { PoolReservation } from './types'

export type ReserveResult = PoolReservation | 'none' | 'locked' | 'error'

export async function reserveAccount(curp: string): Promise<ReserveResult> {
  try {
    const res = await accessFetch('/api/outlook-pool/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ curp }),
    })
    if (res.status === 409) return 'none'
    if (!res.ok) return 'error'
    const body = (await res.json()) as { reservation?: PoolReservation }
    return body.reservation ?? 'error'
  } catch (error) {
    return error instanceof AccessError ? 'locked' : 'error'
  }
}

async function act(reservation: PoolReservation, action: 'release' | 'complete'): Promise<boolean> {
  try {
    const res = await accessFetch(`/api/outlook-pool/reservations/${reservation.accountId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: reservation.token, action }),
      keepalive: true,
    })
    return res.ok
  } catch {
    return false
  }
}

export const releaseAccount = (r: PoolReservation) => act(r, 'release')
export const completeAccount = (r: PoolReservation) => act(r, 'complete')
