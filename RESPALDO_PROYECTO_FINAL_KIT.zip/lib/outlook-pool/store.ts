import 'server-only'
import { randomBytes } from 'node:crypto'
import { del, get, list, put } from '@vercel/blob'
import { seal } from '@/lib/outlook/crypto'
import { accessKey } from '@/lib/outlook/config'
import { hasAccess } from '@/lib/outlook/access'
import { NEXT_STATUS, type PoolAccount, type PoolReservation, type PoolStatus } from './types'

/**
 * Private Blob layout: outlook-pool/accounts/<id>.json
 * The private access field is sealed with AES-256-GCM and never returned to the client.
 * It is kept so the authentication step can be connected later (see `readSecret`).
 */
const ROOT = 'outlook-pool/accounts/'
const ID = /^[a-f0-9]{24}$/
const SEAL_LABEL = 'outlook-pool-secret'

interface StoredPoolAccount extends PoolAccount {
  secret: string
  reservation?: { token: string; at: string; committed: boolean }
}

export const isPoolId = (id: string) => ID.test(id)

function sealKey(): string {
  const key = process.env.ACCOUNTS_ENCRYPTION_KEY?.trim() || accessKey() || process.env.BLOB_READ_WRITE_TOKEN
  if (!key) throw new Error('missing-encryption-key')
  return key
}

/** Same rule as the rest of the panel: open while PANEL_ACCESS_KEY is unset, protected once it is set. */
export function canManage(request: Request): boolean {
  return accessKey() === null || hasAccess(request)
}

function toPublic({ secret: _secret, reservation: _reservation, ...account }: StoredPoolAccount): PoolAccount {
  return account
}

async function readRecord(pathname: string): Promise<StoredPoolAccount | null> {
  const result = await get(pathname, { access: 'private', useCache: false }).catch(() => null)
  if (!result || result.statusCode !== 200 || !result.stream) return null
  try {
    return JSON.parse(await new Response(result.stream).text()) as StoredPoolAccount
  } catch {
    return null
  }
}

async function writeRecord(account: StoredPoolAccount) {
  await put(`${ROOT}${account.id}.json`, JSON.stringify(account), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

async function listRecords(): Promise<StoredPoolAccount[]> {
  const pathnames: string[] = []
  let cursor: string | undefined
  do {
    const page = await list({ prefix: ROOT, cursor, limit: 1000 })
    pathnames.push(...page.blobs.map((b) => b.pathname).filter((p) => p.endsWith('.json')))
    cursor = page.hasMore ? page.cursor : undefined
  } while (cursor)
  const records = await Promise.all(pathnames.map(readRecord))
  return records.filter((r): r is StoredPoolAccount => r !== null)
}

export async function listPoolAccounts(): Promise<PoolAccount[]> {
  const records = await listRecords()
  return records.map(toPublic).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export async function createPoolAccount(email: string, secret: string): Promise<PoolAccount | 'duplicate'> {
  const existing = await listRecords()
  if (existing.some((a) => a.email === email)) return 'duplicate'
  const now = new Date().toISOString()
  const account: StoredPoolAccount = {
    id: randomBytes(12).toString('hex'),
    email,
    status: 'available',
    createdAt: now,
    updatedAt: now,
    secret: seal(secret, SEAL_LABEL, sealKey()),
  }
  await writeRecord(account)
  return toPublic(account)
}

/** Manual changes only move forward; nothing can return an account to available from here. */
export async function setPoolStatus(id: string, status: PoolStatus): Promise<PoolAccount | null | 'invalid'> {
  const account = await readRecord(`${ROOT}${id}.json`)
  if (!account) return null
  if (NEXT_STATUS[account.status] !== status) return 'invalid'
  const now = new Date().toISOString()
  const next: StoredPoolAccount = {
    ...account,
    status,
    updatedAt: now,
    usedAt: status === 'in_use' ? now : account.usedAt,
    completedAt: status === 'used' ? now : account.completedAt,
    reservation: account.reservation ? { ...account.reservation, committed: true } : undefined,
  }
  await writeRecord(next)
  return toPublic(next)
}

/** An unsubmitted IMSS reservation older than this is treated as abandoned and returned to available. */
const RESERVATION_TTL_MS = 30 * 60 * 1000

function isAbandoned(account: StoredPoolAccount, now: number) {
  const r = account.reservation
  return account.status === 'in_use' && r && !r.committed && now - Date.parse(r.at) > RESERVATION_TTL_MS
}

function toAvailable(account: StoredPoolAccount): StoredPoolAccount {
  return {
    ...account,
    status: 'available',
    updatedAt: new Date().toISOString(),
    usedAt: undefined,
    procedureCurp: undefined,
    reservation: undefined,
  }
}

/** Assigns one available account to an IMSS trámite. Returns null when none is available. */
export async function reserveForProcedure(curp: string): Promise<PoolReservation | null> {
  const now = Date.now()
  const records = await listRecords()
  await Promise.all(records.filter((r) => isAbandoned(r, now)).map((r) => writeRecord(toAvailable(r))))

  const candidates = records
    .map((r) => (isAbandoned(r, now) ? toAvailable(r) : r))
    .filter((r) => r.status === 'available')
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt))

  for (const candidate of candidates) {
    const token = randomBytes(16).toString('hex')
    const at = new Date().toISOString()
    await writeRecord({
      ...candidate,
      status: 'in_use',
      updatedAt: at,
      usedAt: at,
      procedureCurp: curp,
      reservation: { token, at, committed: false },
    })
    // Blob has no transactions: re-read so two simultaneous trámites never share an account.
    const check = await readRecord(`${ROOT}${candidate.id}.json`)
    if (check?.reservation?.token === token) return { accountId: candidate.id, token, email: candidate.email }
  }
  return null
}

async function readReservation(id: string, token: string) {
  const account = await readRecord(`${ROOT}${id}.json`)
  if (!account?.reservation || account.reservation.token !== token) return null
  return account
}

/** The trámite failed before submission: give the account back automatically. */
export async function releaseReservation(id: string, token: string): Promise<boolean> {
  const account = await readReservation(id, token)
  if (!account || account.status !== 'in_use' || account.reservation?.committed) return false
  await writeRecord(toAvailable(account))
  return true
}

/** The form reached the IMSS with this email: the account is consumed for good. */
export async function completeReservation(id: string, token: string): Promise<boolean> {
  const account = await readReservation(id, token)
  if (!account) return false
  if (account.status === 'used') return true
  const now = new Date().toISOString()
  await writeRecord({
    ...account,
    status: 'used',
    updatedAt: now,
    completedAt: now,
    reservation: { ...account.reservation!, committed: true },
  })
  return true
}

export async function deletePoolAccount(id: string) {
  await del(`${ROOT}${id}.json`).catch(() => {})
}

/**
 * Removes every account that is no longer needed: consumed ones (used) and abandoned
 * reservations that never reached the IMSS. Available accounts and live trámites stay.
 */
export async function deleteFinishedPoolAccounts(): Promise<string[]> {
  const now = Date.now()
  const finished = (await listRecords()).filter((r) => r.status === 'used' || isAbandoned(r, now))
  if (finished.length) await del(finished.map((r) => `${ROOT}${r.id}.json`))
  return finished.map((r) => r.email)
}
