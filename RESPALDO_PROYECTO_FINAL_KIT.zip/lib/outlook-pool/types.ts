/** One-way lifecycle: available → in_use → used. Only an unsubmitted IMSS reservation can return to available. */
export type PoolStatus = 'available' | 'in_use' | 'used'

export interface PoolAccount {
  id: string
  email: string
  status: PoolStatus
  createdAt: string
  updatedAt: string
  usedAt?: string
  completedAt?: string
  /** CURP of the IMSS trámite the account is assigned to. */
  procedureCurp?: string
}

export interface PoolReservation {
  accountId: string
  token: string
  email: string
}

export const NEXT_STATUS: Partial<Record<PoolStatus, PoolStatus>> = {
  available: 'in_use',
  in_use: 'used',
}

export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function normalizeEmail(value: string): string {
  return value.trim().toLowerCase()
}
