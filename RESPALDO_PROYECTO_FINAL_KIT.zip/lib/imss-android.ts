export const TRAMIX_APK_URL = '/tramix-android.apk'

export interface ImssDocument {
  id: string
  name: string
  mime: string
  size: number
  createdAt: number
  savedTo: string | null
}

export type AndroidImssStatus =
  | 'filled'
  | 'captcha_ready'
  | 'submitted'
  | 'fields_not_found'
  | 'closed'
  | 'download_started'
  | 'download_failed'
  | 'document'
  | 'imss_response'
  | 'document_requested'

export interface AndroidImssEvent {
  jobId: string
  status: AndroidImssStatus
  detail: {
    fields?: string[]
    hasCaptcha?: boolean
    retry?: boolean
    reason?: string
    name?: string
    message?: string
  } & Partial<ImssDocument>
}

/** Bridge injected by the TRAMIX Android app (android/…/MainActivity.kt). */
interface TramixAndroidBridge {
  version(): string
  startImss(curp: string, email: string): boolean
  resumeImss(): boolean
  takePendingJob(): string
  takeEvents(): string
  listDocuments(): string
  readDocument(id: string): string
  openDocument(id: string): boolean
  shareDocument(id: string): boolean
}

function bridge(): TramixAndroidBridge | null {
  if (typeof window === 'undefined') return null
  const candidate = (window as unknown as { TramixAndroid?: TramixAndroidBridge }).TramixAndroid
  return candidate && typeof candidate.startImss === 'function' ? candidate : null
}

function parse<T>(raw: string | undefined, fallback: T): T {
  if (!raw) return fallback
  try {
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

export function androidAppVersion(): string | null {
  return bridge()?.version() || null
}

export function isAndroidBrowser(): boolean {
  return typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent)
}

export function startAndroidImss(curp: string, email: string): boolean {
  return bridge()?.startImss(curp, email) ?? false
}

export function resumeAndroidImss(): boolean {
  return bridge()?.resumeImss() ?? false
}

export function takePendingAndroidJob(): { curp: string; email: string } | null {
  return parse<{ curp: string; email: string } | null>(bridge()?.takePendingJob(), null)
}

export function takeAndroidEvents(): AndroidImssEvent[] {
  return parse<AndroidImssEvent[]>(bridge()?.takeEvents(), [])
}

export function listAndroidDocuments(): ImssDocument[] {
  return parse<ImssDocument[]>(bridge()?.listDocuments(), [])
}

export function readAndroidDocument(id: string): Uint8Array | null {
  const base64 = bridge()?.readDocument(id)
  if (!base64) return null
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)
  return bytes
}

export const openAndroidDocument = (id: string) => bridge()?.openDocument(id) ?? false
export const shareAndroidDocument = (id: string) => bridge()?.shareDocument(id) ?? false

/**
 * Chrome on Android opens the app through an intent link; if the app isn't installed
 * Chrome falls back to downloading the APK from this same TRAMIX deployment.
 */
export function buildAppIntentUrl(curp: string, email: string): string {
  const origin = window.location.origin
  const query = new URLSearchParams({ url: origin, curp, email }).toString()
  const fallback = encodeURIComponent(`${origin}${TRAMIX_APK_URL}`)
  return `intent://open?${query}#Intent;scheme=tramix;package=mx.tramix.app;S.browser_fallback_url=${fallback};end`
}

export function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}
