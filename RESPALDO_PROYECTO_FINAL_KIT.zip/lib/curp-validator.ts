import { CURP_LENGTH, hasValidCurpCheckDigit } from '@/lib/extract/curp'

export const STATE_NAMES: Record<string, string> = {
  AS: 'Aguascalientes',
  BC: 'Baja California',
  BS: 'Baja California Sur',
  CC: 'Campeche',
  CL: 'Coahuila',
  CM: 'Colima',
  CS: 'Chiapas',
  CH: 'Chihuahua',
  DF: 'Ciudad de México',
  DG: 'Durango',
  GT: 'Guanajuato',
  GR: 'Guerrero',
  HG: 'Hidalgo',
  JC: 'Jalisco',
  MC: 'Estado de México',
  MN: 'Michoacán',
  MS: 'Morelos',
  NT: 'Nayarit',
  NL: 'Nuevo León',
  OC: 'Oaxaca',
  PL: 'Puebla',
  QT: 'Querétaro',
  QR: 'Quintana Roo',
  SP: 'San Luis Potosí',
  SL: 'Sinaloa',
  SR: 'Sonora',
  TC: 'Tabasco',
  TS: 'Tamaulipas',
  TL: 'Tlaxcala',
  VZ: 'Veracruz',
  YN: 'Yucatán',
  ZS: 'Zacatecas',
  NE: 'Nacido en el extranjero',
}

const SEX_NAMES: Record<string, string> = { H: 'Hombre', M: 'Mujer', X: 'No binario' }

const LETTER = /^[A-ZÑ]$/
const VOWEL_OR_X = /^[AEIOUX]$/
const DIGIT = /^\d$/
const INTERNAL_CONSONANT = /^[B-DF-HJ-NP-TV-ZÑ]$/

export interface CurpDetails {
  curp: string
  /** DD/MM/AAAA */
  birthDate: string
  sex: string
  state: string
}

export type CurpValidation =
  | { valid: true; details: CurpDetails }
  | { valid: false; reasons: string[] }

export function cleanCurpInput(value: string): string {
  return value.toUpperCase().replace(/[^A-Z0-9Ñ]/g, '').slice(0, CURP_LENGTH)
}

function isRealDate(year: number, month: number, day: number): boolean {
  const date = new Date(Date.UTC(year, month - 1, day))
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day
}

/**
 * Validates a CURP fully offline: structure, birth date, sex, state and
 * check digit. It never derives a person's name.
 */
export function validateCurp(input: string): CurpValidation {
  const curp = cleanCurpInput(input)
  const reasons: string[] = []

  if (curp.length !== CURP_LENGTH) {
    return {
      valid: false,
      reasons: [`Debe tener exactamente 18 caracteres (tiene ${curp.length}).`],
    }
  }

  const c = curp.split('')

  if (!LETTER.test(c[0]) || !VOWEL_OR_X.test(c[1]) || !LETTER.test(c[2]) || !LETTER.test(c[3])) {
    reasons.push('Los primeros 4 caracteres deben ser letras y el segundo una vocal (o X).')
  }

  const dateDigits = curp.slice(4, 10)
  const differentiator = c[16]
  let birthDate: string | null = null

  if (!/^\d{6}$/.test(dateDigits)) {
    reasons.push('Las posiciones 5 a 10 deben ser la fecha de nacimiento en números (AAMMDD).')
  } else {
    const yy = Number(dateDigits.slice(0, 2))
    const month = Number(dateDigits.slice(2, 4))
    const day = Number(dateDigits.slice(4, 6))
    // Position 17 is a digit for people born before 2000 and a letter from 2000 on.
    const century = LETTER.test(differentiator) ? 2000 : 1900
    const year = century + yy

    if (!isRealDate(year, month, day)) {
      reasons.push('La fecha de nacimiento no existe en el calendario.')
    } else if (Date.UTC(year, month - 1, day) > Date.now()) {
      reasons.push('La fecha de nacimiento está en el futuro.')
    } else {
      birthDate = `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`
    }
  }

  const sex = SEX_NAMES[c[10]]
  if (!sex) reasons.push('El carácter 11 debe indicar el sexo: H, M o X.')

  const state = STATE_NAMES[curp.slice(11, 13)]
  if (!state) reasons.push(`"${curp.slice(11, 13)}" no corresponde a ninguna entidad federativa.`)

  if (!INTERNAL_CONSONANT.test(c[13]) || !INTERNAL_CONSONANT.test(c[14]) || !INTERNAL_CONSONANT.test(c[15])) {
    reasons.push('Las posiciones 14 a 16 deben ser consonantes.')
  }

  if (!LETTER.test(differentiator) && !DIGIT.test(differentiator)) {
    reasons.push('El carácter 17 debe ser una letra o un número.')
  }

  if (!DIGIT.test(c[17])) {
    reasons.push('El último carácter (dígito verificador) debe ser un número.')
  } else if (reasons.length === 0 && !hasValidCurpCheckDigit(curp)) {
    reasons.push('El dígito verificador no coincide: la CURP tiene algún carácter incorrecto.')
  }

  if (reasons.length > 0 || !birthDate || !sex || !state) {
    return { valid: false, reasons }
  }

  return { valid: true, details: { curp, birthDate, sex, state } }
}

export function formatCurpDetails(details: CurpDetails): string {
  return [
    `CURP: ${details.curp}`,
    `Fecha de nacimiento: ${details.birthDate}`,
    `Sexo: ${details.sex}`,
    `Entidad federativa: ${details.state}`,
  ].join('\n')
}
