import type { CfeRequest, ReceiptSourceId } from './types'

export interface FetchedReceipt {
  bytes: Uint8Array
  fileName?: string
}

/**
 * Contract for a receipt provider. Two ways an officially authorized CFE source can deliver PDFs:
 *  - Push: the source POSTs the PDF to /api/cfe/ingest (Bearer CFE_INGEST_SECRET).
 *  - Pull: implement `fetchReceipt` here and register it in SOURCES; `pullReceipt` (lib/cfe/pull.ts)
 *    runs it for a pending request.
 * Both paths end in `ingestReceipt`, the same detect → validate → rename → save → DESCARGADO flow.
 * Manual import stays available as the fallback.
 */
export interface ReceiptSource {
  id: ReceiptSourceId
  label: string
  automatic: boolean
  fetchReceipt?: (request: CfeRequest) => Promise<FetchedReceipt | null>
}

// PUNTO DE INTEGRACIÓN (pull): register the authorized CFE source here once it is defined,
// e.g. { id: 'authorized', label: '…', automatic: true, fetchReceipt }. See docs/cfe-integracion.md.
// Push sources need no code change: set CFE_INGEST_SECRET and POST to /api/cfe/ingest.
export const SOURCES: ReceiptSource[] = [{ id: 'manual', label: 'Importación manual de PDF', automatic: false }]

export const DEFAULT_SOURCE: ReceiptSourceId = 'manual'

export const automaticSource = (): ReceiptSource | undefined => SOURCES.find((s) => s.automatic && s.fetchReceipt)
