import 'server-only'
import { randomBytes } from 'node:crypto'
import { del, get, put } from '@vercel/blob'
import { seal } from '@/lib/outlook/crypto'
import { accessKey } from '@/lib/outlook/config'
import { assignService, nextActiveId } from './assign'
import { DEFAULT_SOURCE } from './sources'
import type { CfeAccount, CfeErrorCode, CfeReceipt, CfeRequest, CfeState, ReceiptSourceId } from './types'

/**
 * Private Blob layout:
 *   cfe/state.json            accounts (sealed password), requests, receipts index, active account
 *   cfe/receipts/<id>.pdf     processed receipt PDFs
 */
const STATE_PATH = 'cfe/state.json'
const RECEIPT_ROOT = 'cfe/receipts/'
const SEAL_LABEL = 'cfe-account-secret'
const ID = /^[a-f0-9]{24}$/
const MAX_REQUESTS = 500

interface StoredAccount extends CfeAccount {
  secret: string
}

interface StoredState extends Omit<CfeState, 'accounts'> {
  accounts: StoredAccount[]
}

export class CfeError extends Error {
  constructor(public code: CfeErrorCode) {
    super(code)
  }
}

export const isCfeId = (id: string) => ID.test(id)
const newId = () => randomBytes(12).toString('hex')
const now = () => new Date().toISOString()

function sealKey(): string {
  const key = process.env.ACCOUNTS_ENCRYPTION_KEY?.trim() || accessKey() || process.env.BLOB_READ_WRITE_TOKEN
  if (!key) throw new CfeError('server-error')
  return key
}

async function readState(): Promise<StoredState> {
  const result = await get(STATE_PATH, { access: 'private', useCache: false }).catch(() => null)
  if (result && result.statusCode === 200 && result.stream) {
    try {
      const parsed = JSON.parse(await new Response(result.stream).text()) as Partial<StoredState>
      return {
        accounts: parsed.accounts ?? [],
        requests: parsed.requests ?? [],
        receipts: parsed.receipts ?? [],
        activeAccountId: parsed.activeAccountId ?? null,
      }
    } catch {}
  }
  return { accounts: [], requests: [], receipts: [], activeAccountId: null }
}

async function writeState(state: StoredState) {
  state.activeAccountId = nextActiveId(state.accounts, state.activeAccountId)
  state.requests = state.requests.slice(0, MAX_REQUESTS)
  await put(STATE_PATH, JSON.stringify(state), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

/** Serializes writes inside this instance so two quick actions do not overwrite each other. */
let queue: Promise<unknown> = Promise.resolve()
function mutate<T>(change: (state: StoredState) => T | Promise<T>): Promise<T> {
  const run = queue.then(async () => {
    const state = await readState()
    const result = await change(state)
    await writeState(state)
    return result
  })
  queue = run.catch(() => undefined)
  return run
}

const toPublic = ({ secret: _secret, ...account }: StoredAccount): CfeAccount => account

export async function getCfeState(): Promise<CfeState> {
  const state = await readState()
  return {
    accounts: state.accounts.map(toPublic),
    requests: state.requests,
    receipts: state.receipts,
    activeAccountId: nextActiveId(state.accounts, state.activeAccountId),
  }
}

export function addAccount(email: string, password: string): Promise<CfeAccount> {
  return mutate((state) => {
    if (state.accounts.some((a) => a.email === email)) throw new CfeError('duplicate-account')
    const account: StoredAccount = { id: newId(), email, services: [], createdAt: now(), secret: seal(password, SEAL_LABEL, sealKey()) }
    state.accounts.push(account)
    if (!state.activeAccountId) state.activeAccountId = account.id
    return toPublic(account)
  })
}

export function deleteAccount(id: string): Promise<void> {
  return mutate((state) => {
    if (!state.accounts.some((a) => a.id === id)) throw new CfeError('not-found')
    state.accounts = state.accounts.filter((a) => a.id !== id)
    if (state.activeAccountId === id) state.activeAccountId = null
  })
}

export function activateAccount(id: string): Promise<void> {
  return mutate((state) => {
    if (!state.accounts.some((a) => a.id === id)) throw new CfeError('not-found')
    state.activeAccountId = id
  })
}

export function removeService(id: string, serviceNumber: string): Promise<void> {
  return mutate((state) => {
    const account = state.accounts.find((a) => a.id === id)
    if (!account) throw new CfeError('not-found')
    account.services = account.services.filter((s) => s !== serviceNumber)
  })
}

/** Registers a request: links the service to the active account (or the next one with room). */
export function createRequest(serviceNumber: string): Promise<CfeRequest> {
  return mutate((state) => {
    const assignment = assignService(state.accounts, state.activeAccountId, serviceNumber)
    if (assignment.kind === 'full') throw new CfeError('no-capacity')
    const account = state.accounts.find((a) => a.id === assignment.account.id)!
    if (assignment.kind === 'new') {
      account.services.push(serviceNumber)
      state.activeAccountId = account.id
    }
    const request: CfeRequest = {
      id: newId(),
      serviceNumber,
      accountId: account.id,
      accountEmail: account.email,
      status: 'pendiente',
      source: DEFAULT_SOURCE,
      receiptId: null,
      createdAt: now(),
      updatedAt: now(),
    }
    state.requests.unshift(request)
    return request
  })
}

export function deleteRequest(id: string): Promise<void> {
  return mutate((state) => {
    state.requests = state.requests.filter((r) => r.id !== id)
  })
}

export interface ReceiptInput {
  bytes: Uint8Array
  fileName: string
  holder: string | null
  serviceNumber: string | null
  /** Defaults to manual import. */
  source?: ReceiptSourceId
  /** Request the source was fetching for; used first when it matches the service number. */
  requestId?: string | null
  sha256?: string
}

/** Receipt already stored with this hash (a source delivering the same PDF twice). */
export async function findReceiptByHash(sha256: string): Promise<CfeReceipt | null> {
  const state = await readState()
  return state.receipts.find((r) => r.sha256 === sha256) ?? null
}

/** Saves the PDF and closes the matching pending request (same service number). */
export async function saveReceipt(input: ReceiptInput): Promise<CfeReceipt> {
  const source = input.source ?? DEFAULT_SOURCE
  const id = newId()
  await put(`${RECEIPT_ROOT}${id}.pdf`, Buffer.from(input.bytes), {
    access: 'private',
    addRandomSuffix: false,
    contentType: 'application/pdf',
  })
  try {
    return await mutate((state) => {
      const isOpen = (r: CfeRequest) => r.serviceNumber === input.serviceNumber && r.status === 'pendiente'
      const request = input.serviceNumber
        ? (input.requestId ? state.requests.find((r) => r.id === input.requestId && isOpen(r)) : undefined) ??
          state.requests.find(isOpen)
        : undefined
      const owner = input.serviceNumber ? state.accounts.find((a) => a.services.includes(input.serviceNumber!)) : undefined
      const receipt: CfeReceipt = {
        id,
        fileName: input.fileName,
        holder: input.holder,
        serviceNumber: input.serviceNumber,
        accountId: request?.accountId ?? owner?.id ?? null,
        requestId: request?.id ?? null,
        size: input.bytes.byteLength,
        source,
        ...(input.sha256 ? { sha256: input.sha256 } : {}),
        createdAt: now(),
      }
      if (request) {
        request.status = 'descargado'
        request.source = source
        request.receiptId = id
        request.updatedAt = now()
      }
      state.receipts.unshift(receipt)
      return receipt
    })
  } catch (error) {
    await del(`${RECEIPT_ROOT}${id}.pdf`).catch(() => undefined)
    throw error
  }
}

export async function readReceipt(id: string): Promise<{ receipt: CfeReceipt; stream: ReadableStream<Uint8Array> } | null> {
  const state = await readState()
  const receipt = state.receipts.find((r) => r.id === id)
  if (!receipt) return null
  const result = await get(`${RECEIPT_ROOT}${id}.pdf`, { access: 'private', useCache: false }).catch(() => null)
  if (!result || result.statusCode !== 200 || !result.stream) return null
  return { receipt, stream: result.stream }
}

export async function deleteReceipt(id: string): Promise<void> {
  await mutate((state) => {
    if (!state.receipts.some((r) => r.id === id)) throw new CfeError('not-found')
    state.receipts = state.receipts.filter((r) => r.id !== id)
    for (const request of state.requests) {
      if (request.receiptId === id) {
        request.receiptId = null
        request.status = 'pendiente'
        request.updatedAt = now()
      }
    }
  })
  await del(`${RECEIPT_ROOT}${id}.pdf`).catch(() => undefined)
}
