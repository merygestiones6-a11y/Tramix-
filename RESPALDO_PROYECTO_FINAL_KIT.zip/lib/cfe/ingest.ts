import 'server-only'
import { createHash } from 'node:crypto'
import { nodeEngine } from '@/lib/server/node-engine'
import { detectCfeHolder, detectServiceNumber, receiptFileName } from './holder'
import { CfeError, findReceiptByHash, saveReceipt } from './store'
import { MAX_RECEIPT_BYTES, SERVICE_NUMBER, type CfeErrorCode, type CfeReceipt, type ReceiptSourceId } from './types'

const PDF_MAGIC = [0x25, 0x50, 0x44, 0x46] // %PDF

export interface IngestInput {
  bytes: Uint8Array
  source: Exclude<ReceiptSourceId, 'manual'>
  /** Service number the source says the PDF belongs to; must match the one printed in the PDF. */
  expectedServiceNumber?: string | null
  requestId?: string | null
}

export type IngestResult =
  | { ok: true; receipt: CfeReceipt; duplicate: boolean }
  | { ok: false; error: CfeErrorCode; holder: string | null; serviceNumber: string | null }

const rejected = (error: CfeErrorCode, holder: string | null = null, serviceNumber: string | null = null): IngestResult => ({
  ok: false,
  error,
  holder,
  serviceNumber,
})

/**
 * Automatic path, same steps as the manual import:
 * PDF → detect holder + service number → validate 11 digits → rename → save → request DESCARGADO.
 * Anything uncertain is rejected (not guessed) so the manual import can handle it.
 */
export async function ingestReceipt(input: IngestInput): Promise<IngestResult> {
  const { bytes } = input
  if (bytes.byteLength > MAX_RECEIPT_BYTES) return rejected('too-large')
  if (!PDF_MAGIC.every((b, i) => bytes[i] === b)) return rejected('invalid-pdf')

  const expected = input.expectedServiceNumber?.replace(/\s/g, '') || null
  if (expected && !SERVICE_NUMBER.test(expected)) return rejected('invalid-service')

  const sha256 = createHash('sha256').update(bytes).digest('hex')
  const existing = await findReceiptByHash(sha256)
  if (existing) return { ok: true, receipt: existing, duplicate: true }

  let pages: string[]
  try {
    pages = (await nodeEngine.extractText(bytes)).pages
  } catch {
    return rejected('invalid-pdf')
  }

  const holder = detectCfeHolder(pages)?.replace(/\s+/g, ' ').trim().toUpperCase().slice(0, 120) || null
  const serviceNumber = detectServiceNumber(pages)
  if (!holder || !serviceNumber || !SERVICE_NUMBER.test(serviceNumber)) return rejected('needs-review', holder, serviceNumber)
  if (expected && expected !== serviceNumber) return rejected('service-mismatch', holder, serviceNumber)

  try {
    const receipt = await saveReceipt({
      bytes,
      holder,
      serviceNumber,
      fileName: receiptFileName(holder, serviceNumber),
      source: input.source,
      requestId: input.requestId ?? null,
      sha256,
    })
    return { ok: true, receipt, duplicate: false }
  } catch (error) {
    if (error instanceof CfeError) return rejected(error.code, holder, serviceNumber)
    throw error
  }
}
