export const SERVICES_PER_ACCOUNT = 10
export const SERVICE_NUMBER = /^\d{11}$/
export const MAX_RECEIPT_BYTES = 10 * 1024 * 1024

/** Where a receipt came from: manual import, or an officially authorized CFE source (push or pull). */
export type ReceiptSourceId = 'manual' | 'authorized'

export interface CfeAccount {
  id: string
  email: string
  services: string[]
  createdAt: string
}

export type CfeRequestStatus = 'pendiente' | 'descargado'

export interface CfeRequest {
  id: string
  serviceNumber: string
  accountId: string
  accountEmail: string
  status: CfeRequestStatus
  source: ReceiptSourceId
  receiptId: string | null
  createdAt: string
  updatedAt: string
}

export interface CfeReceipt {
  id: string
  fileName: string
  holder: string | null
  serviceNumber: string | null
  accountId: string | null
  requestId: string | null
  size: number
  source: ReceiptSourceId
  /** SHA-256 of the PDF, used to ignore the same receipt delivered twice by a source. */
  sha256?: string
  createdAt: string
}

export interface CfeState {
  accounts: CfeAccount[]
  requests: CfeRequest[]
  receipts: CfeReceipt[]
  activeAccountId: string | null
}

export type CfeErrorCode =
  | 'invalid-email'
  | 'invalid-password'
  | 'duplicate-account'
  | 'invalid-service'
  | 'no-capacity'
  | 'not-found'
  | 'invalid-pdf'
  | 'too-large'
  | 'unauthorized'
  | 'server-error'
  | 'needs-review'
  | 'service-mismatch'
  | 'not-configured'

export const CFE_ERRORS: Record<CfeErrorCode, string> = {
  'invalid-email': 'Escribe un correo válido.',
  'invalid-password': 'Escribe la contraseña de la cuenta.',
  'duplicate-account': 'Esa cuenta ya está registrada.',
  'invalid-service': 'El número de servicio debe tener 11 dígitos.',
  'no-capacity': 'Todas las cuentas tienen 10/10 servicios. Agrega otra cuenta.',
  'not-found': 'No se encontró el registro.',
  'invalid-pdf': 'El archivo no es un PDF válido.',
  'too-large': 'El PDF supera 10 MB.',
  unauthorized: 'Sesión del panel requerida.',
  'server-error': 'No se pudo guardar. Intenta de nuevo.',
  'needs-review': 'No se detectó el titular o un número de servicio de 11 dígitos. Impórtalo manualmente.',
  'service-mismatch': 'El número de servicio del PDF no coincide con el de la solicitud.',
  'not-configured': 'La fuente automática de recibos no está configurada.',
}
