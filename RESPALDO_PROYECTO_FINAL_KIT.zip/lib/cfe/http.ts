import 'server-only'
import { CfeError } from './store'
import type { CfeErrorCode } from './types'

export const NO_STORE = { 'Cache-Control': 'no-store' }

const STATUS: Partial<Record<CfeErrorCode, number>> = {
  'duplicate-account': 409,
  'no-capacity': 409,
  'not-found': 404,
  'too-large': 413,
  unauthorized: 401,
  'server-error': 500,
  'needs-review': 422,
  'service-mismatch': 422,
  'not-configured': 503,
}

export function fail(code: CfeErrorCode) {
  return Response.json({ error: code }, { status: STATUS[code] ?? 400, headers: NO_STORE })
}

export function handle(error: unknown) {
  if (error instanceof CfeError) return fail(error.code)
  console.error('[cfe]', error)
  return fail('server-error')
}
