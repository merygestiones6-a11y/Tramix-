import 'server-only'
import { safeEqual } from '@/lib/outlook/crypto'
import { authenticateDevice, DeviceError, publicState, type DeviceErrorCode, type DeviceJob } from './device-store'
import { NO_STORE } from './http'

const STATUS: Record<DeviceErrorCode, number> = {
  'not-configured': 503,
  unauthorized: 401,
  'too-many-devices': 409,
  'invalid-name': 400,
  'invalid-state': 400,
  'not-found': 404,
  'lease-lost': 409,
}

export function deviceFail(code: DeviceErrorCode | string, status?: number) {
  return Response.json({ error: code }, { status: status ?? STATUS[code as DeviceErrorCode] ?? 400, headers: NO_STORE })
}

export function deviceHandle(error: unknown) {
  if (error instanceof DeviceError) return deviceFail(error.code)
  console.error('[cfe-device]', error)
  return deviceFail('server-error', 500)
}

const bearer = (request: Request) => request.headers.get('authorization')?.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() ?? ''

/** Enrollment is disabled until CFE_DEVICE_ENROLL_SECRET is set. */
export function enrollmentAllowed(request: Request): Response | null {
  const secret = process.env.CFE_DEVICE_ENROLL_SECRET?.trim()
  if (!secret) return deviceFail('not-configured')
  const token = bearer(request)
  if (!token || !safeEqual(token, secret)) return deviceFail('unauthorized')
  return null
}

/** Resolves the device from its bearer token, or returns the error response. */
export async function requireDevice(request: Request): Promise<{ deviceId: string } | Response> {
  if (!process.env.CFE_DEVICE_ENROLL_SECRET?.trim()) return deviceFail('not-configured')
  const deviceId = await authenticateDevice(bearer(request))
  return deviceId ? { deviceId } : deviceFail('unauthorized')
}

export function jobView(job: DeviceJob) {
  return {
    id: job.id,
    requestId: job.requestId,
    serviceNumber: job.serviceNumber,
    state: publicState(job),
    attempts: job.attempts,
    leaseUntil: job.leaseUntil,
    lastError: job.lastError,
    receiptId: job.receiptId,
  }
}
