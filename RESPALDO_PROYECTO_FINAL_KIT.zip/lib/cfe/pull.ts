import 'server-only'
import { ingestReceipt, type IngestResult } from './ingest'
import { automaticSource } from './sources'
import type { CfeRequest } from './types'

/** Asks the registered authorized source for a request's PDF and runs it through the shared flow. */
export async function pullReceipt(request: CfeRequest): Promise<IngestResult | null> {
  if (request.status !== 'pendiente') return null
  const source = automaticSource()
  if (!source?.fetchReceipt || source.id === 'manual') {
    return { ok: false, error: 'not-configured', holder: null, serviceNumber: null }
  }
  const fetched = await source.fetchReceipt(request)
  if (!fetched) return null
  return ingestReceipt({
    bytes: fetched.bytes,
    source: source.id,
    expectedServiceNumber: request.serviceNumber,
    requestId: request.id,
  })
}
