import 'server-only'
import { createHash, randomBytes } from 'node:crypto'
import { get, put } from '@vercel/blob'
import { safeEqual } from '@/lib/outlook/crypto'
import { getCfeState } from './store'

/**
 * FileKit ↔ Android device channel. Kept in its own private Blob file so the
 * existing CFE state (accounts, requests, receipts) is never rewritten by it.
 *   cfe/devices.json   registered devices (token hash only) + job queue
 * Jobs mirror the CFE requests in "pendiente": one job per request.
 */
const PATH = 'cfe/devices.json'
const ID = /^[a-f0-9]{24}$/
const MAX_DEVICES = 20
const MAX_JOBS = 300

export const LEASE_MS = 5 * 60 * 1000
export const MAX_ATTEMPTS = 3
const BACKOFF_MS = 30 * 1000

/** States reported to / by the device. */
export type DeviceJobState = 'CONECTADO' | 'PROCESANDO' | 'COMPLETADO' | 'ERROR'
type JobStatus = 'queued' | 'connected' | 'processing' | 'completed' | 'error'

export interface DeviceRecord {
  id: string
  name: string
  tokenHash: string
  createdAt: string
  lastSeenAt: string | null
  revokedAt: string | null
}

export interface DeviceJob {
  id: string
  requestId: string
  serviceNumber: string
  status: JobStatus
  deviceId: string | null
  attempts: number
  leaseUntil: string | null
  nextAttemptAt: string | null
  lastError: string | null
  receiptId: string | null
  createdAt: string
  updatedAt: string
}

interface DeviceState {
  devices: DeviceRecord[]
  jobs: DeviceJob[]
}

export class DeviceError extends Error {
  constructor(public code: DeviceErrorCode) {
    super(code)
  }
}

export type DeviceErrorCode =
  | 'not-configured'
  | 'unauthorized'
  | 'too-many-devices'
  | 'invalid-name'
  | 'invalid-state'
  | 'not-found'
  | 'lease-lost'

export const isDeviceId = (id: string) => ID.test(id)
const newId = () => randomBytes(12).toString('hex')
const iso = (ms = Date.now()) => new Date(ms).toISOString()
const hashToken = (secret: string) => createHash('sha256').update(secret).digest('hex')

async function readState(): Promise<DeviceState> {
  const result = await get(PATH, { access: 'private', useCache: false }).catch(() => null)
  if (result && result.statusCode === 200 && result.stream) {
    try {
      const parsed = JSON.parse(await new Response(result.stream).text()) as Partial<DeviceState>
      return { devices: parsed.devices ?? [], jobs: parsed.jobs ?? [] }
    } catch {}
  }
  return { devices: [], jobs: [] }
}

async function writeState(state: DeviceState) {
  state.jobs = state.jobs.slice(0, MAX_JOBS)
  await put(PATH, JSON.stringify(state), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

let queue: Promise<unknown> = Promise.resolve()
function mutate<T>(change: (state: DeviceState) => T | Promise<T>): Promise<T> {
  const run = queue.then(async () => {
    const state = await readState()
    const result = await change(state)
    await writeState(state)
    return result
  })
  queue = run.catch(() => undefined)
  return run
}

/* ---------- devices ---------- */

/** Creates a device and returns its token once: `<deviceId>.<secret>`. Only the hash is stored. */
export function registerDevice(name: string): Promise<{ deviceId: string; token: string }> {
  return mutate((state) => {
    if (state.devices.filter((d) => !d.revokedAt).length >= MAX_DEVICES) throw new DeviceError('too-many-devices')
    const secret = randomBytes(32).toString('base64url')
    const device: DeviceRecord = {
      id: newId(),
      name,
      tokenHash: hashToken(secret),
      createdAt: iso(),
      lastSeenAt: iso(),
      revokedAt: null,
    }
    state.devices.push(device)
    return { deviceId: device.id, token: `${device.id}.${secret}` }
  })
}

/** Validates a device bearer token; returns the device id or null. */
export async function authenticateDevice(token: string): Promise<string | null> {
  const [id, secret] = token.split('.')
  if (!id || !secret || !isDeviceId(id)) return null
  const state = await readState()
  const device = state.devices.find((d) => d.id === id && !d.revokedAt)
  if (!device || !safeEqual(hashToken(secret), device.tokenHash)) return null
  return device.id
}

export function heartbeat(deviceId: string): Promise<void> {
  return mutate((state) => {
    const device = state.devices.find((d) => d.id === deviceId)
    if (device) device.lastSeenAt = iso()
  })
}

export function revokeDevice(deviceId: string): Promise<void> {
  return mutate((state) => {
    const device = state.devices.find((d) => d.id === deviceId)
    if (!device) throw new DeviceError('not-found')
    device.revokedAt = iso()
    for (const job of state.jobs) {
      if (job.deviceId === deviceId && (job.status === 'connected' || job.status === 'processing')) requeue(job, 'device-revoked')
    }
  })
}

export async function listDevices() {
  const state = await readState()
  return {
    devices: state.devices.map(({ tokenHash: _hash, ...d }) => d),
    jobs: state.jobs,
  }
}

/* ---------- queue ---------- */

export function publicState(job: DeviceJob): DeviceJobState | 'EN_COLA' {
  if (job.status === 'connected') return 'CONECTADO'
  if (job.status === 'processing') return 'PROCESANDO'
  if (job.status === 'completed') return 'COMPLETADO'
  if (job.status === 'error') return 'ERROR'
  return 'EN_COLA'
}

function requeue(job: DeviceJob, reason: string) {
  job.lastError = reason
  job.leaseUntil = null
  job.deviceId = null
  job.updatedAt = iso()
  if (job.attempts >= MAX_ATTEMPTS) {
    job.status = 'error'
    job.nextAttemptAt = null
  } else {
    job.status = 'queued'
    job.nextAttemptAt = iso(Date.now() + BACKOFF_MS * 2 ** (job.attempts - 1))
  }
}

/** Keeps the queue in step with CFE requests and expires abandoned leases. */
async function sync(state: DeviceState) {
  const cfe = await getCfeState()
  const byRequest = new Map(cfe.requests.map((r) => [r.id, r]))

  state.jobs = state.jobs.filter((job) => byRequest.has(job.requestId))
  for (const job of state.jobs) {
    const request = byRequest.get(job.requestId)!
    if (request.status === 'descargado' && job.status !== 'completed') {
      job.status = 'completed'
      job.receiptId = request.receiptId
      job.leaseUntil = null
      job.updatedAt = iso()
    }
  }

  const known = new Set(state.jobs.map((j) => j.requestId))
  for (const request of [...cfe.requests].reverse()) {
    if (request.status !== 'pendiente' || known.has(request.id)) continue
    state.jobs.unshift({
      id: newId(),
      requestId: request.id,
      serviceNumber: request.serviceNumber,
      status: 'queued',
      deviceId: null,
      attempts: 0,
      leaseUntil: null,
      nextAttemptAt: null,
      lastError: null,
      receiptId: null,
      createdAt: iso(),
      updatedAt: iso(),
    })
  }

  const now = Date.now()
  for (const job of state.jobs) {
    const active = job.status === 'connected' || job.status === 'processing'
    if (active && job.leaseUntil && Date.parse(job.leaseUntil) < now) requeue(job, 'lease-expired')
  }
}

/** Gives the device its current job, or leases the oldest ready one. Null when the queue is empty. */
export function claimNextJob(deviceId: string): Promise<DeviceJob | null> {
  return mutate(async (state) => {
    await sync(state)
    const device = state.devices.find((d) => d.id === deviceId)
    if (device) device.lastSeenAt = iso()

    const held = state.jobs.find(
      (j) => j.deviceId === deviceId && (j.status === 'connected' || j.status === 'processing'),
    )
    if (held) return held

    const now = Date.now()
    const ready = state.jobs
      .filter((j) => j.status === 'queued' && (!j.nextAttemptAt || Date.parse(j.nextAttemptAt) <= now))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0]
    if (!ready) return null

    ready.status = 'connected'
    ready.deviceId = deviceId
    ready.attempts += 1
    ready.leaseUntil = iso(now + LEASE_MS)
    ready.nextAttemptAt = null
    ready.updatedAt = iso()
    return ready
  })
}

function leased(state: DeviceState, deviceId: string, jobId: string): DeviceJob {
  const job = state.jobs.find((j) => j.id === jobId)
  if (!job) throw new DeviceError('not-found')
  if (job.deviceId !== deviceId || (job.status !== 'connected' && job.status !== 'processing')) {
    throw new DeviceError('lease-lost')
  }
  return job
}

/** CONECTADO / PROCESANDO extend the lease; ERROR retries with backoff (or closes the job if not retryable). */
export function reportJobState(
  deviceId: string,
  jobId: string,
  report: { state: DeviceJobState; message?: string | null; retryable?: boolean },
): Promise<DeviceJob> {
  return mutate((state) => {
    const job = leased(state, deviceId, jobId)
    const message = report.message?.slice(0, 300) || null
    if (report.state === 'CONECTADO' || report.state === 'PROCESANDO') {
      if (report.state === 'PROCESANDO') job.status = 'processing'
      job.leaseUntil = iso(Date.now() + LEASE_MS)
      job.updatedAt = iso()
      return job
    }
    if (report.state === 'ERROR') {
      if (report.retryable === false) {
        job.attempts = MAX_ATTEMPTS
      }
      requeue(job, message ?? 'device-error')
      return job
    }
    // COMPLETADO is only set by FileKit after the PDF passes the CFE flow.
    throw new DeviceError('invalid-state')
  })
}

/** Locks the job for an upload; returns it, or the completed job for an idempotent re-upload. */
export async function jobForUpload(deviceId: string, jobId: string): Promise<DeviceJob> {
  const state = await readState()
  const job = state.jobs.find((j) => j.id === jobId)
  if (!job) throw new DeviceError('not-found')
  if (job.status === 'completed' && job.deviceId === deviceId) return job
  if (job.deviceId !== deviceId || (job.status !== 'connected' && job.status !== 'processing')) {
    throw new DeviceError('lease-lost')
  }
  return job
}

export function completeJob(deviceId: string, jobId: string, receiptId: string): Promise<DeviceJob> {
  return mutate((state) => {
    const job = state.jobs.find((j) => j.id === jobId && j.deviceId === deviceId)
    if (!job) throw new DeviceError('not-found')
    job.status = 'completed'
    job.receiptId = receiptId
    job.leaseUntil = null
    job.lastError = null
    job.updatedAt = iso()
    return job
  })
}

export function failJob(deviceId: string, jobId: string, reason: string, retryable: boolean): Promise<DeviceJob> {
  return reportJobState(deviceId, jobId, { state: 'ERROR', message: reason, retryable })
}
