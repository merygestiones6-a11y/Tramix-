import { SERVICES_PER_ACCOUNT, type CfeAccount } from './types'

export type Assignment =
  | { kind: 'existing'; account: CfeAccount }
  | { kind: 'new'; account: CfeAccount }
  | { kind: 'full' }

const hasRoom = (account: CfeAccount) => account.services.length < SERVICES_PER_ACCOUNT

/** Accounts in the order they were added (the order used to move to "the next" one). */
export function orderedAccounts(accounts: CfeAccount[]): CfeAccount[] {
  return [...accounts].sort((a, b) => a.createdAt.localeCompare(b.createdAt))
}

/**
 * A service already linked to an account stays there (it does not count twice).
 * Otherwise it goes to the active account while it has room; once that one is 10/10,
 * the next account with room (in creation order, wrapping around) is used.
 */
export function assignService(accounts: CfeAccount[], activeId: string | null, serviceNumber: string): Assignment {
  const owner = accounts.find((a) => a.services.includes(serviceNumber))
  if (owner) return { kind: 'existing', account: owner }

  const ordered = orderedAccounts(accounts)
  const active = ordered.find((a) => a.id === activeId)
  if (active && hasRoom(active)) return { kind: 'new', account: active }

  const start = active ? ordered.indexOf(active) + 1 : 0
  for (let i = 0; i < ordered.length; i++) {
    const candidate = ordered[(start + i) % ordered.length]
    if (hasRoom(candidate)) return { kind: 'new', account: candidate }
  }
  return { kind: 'full' }
}

/** Active account to show after a change: the current one while it has room, else the next one with room. */
export function nextActiveId(accounts: CfeAccount[], activeId: string | null): string | null {
  const ordered = orderedAccounts(accounts)
  const active = ordered.find((a) => a.id === activeId)
  if (active && hasRoom(active)) return active.id
  const start = active ? ordered.indexOf(active) + 1 : 0
  for (let i = 0; i < ordered.length; i++) {
    const candidate = ordered[(start + i) % ordered.length]
    if (hasRoom(candidate)) return candidate.id
  }
  return active?.id ?? ordered[0]?.id ?? null
}
