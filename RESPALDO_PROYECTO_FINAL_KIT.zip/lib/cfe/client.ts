import { AccessError, accessFetch } from '@/lib/outlook/client'
import { CFE_ERRORS, type CfeErrorCode } from './types'

export const STATE_KEY = '/api/cfe/state'

export function errorMessage(error: unknown): string {
  if (error instanceof AccessError) return CFE_ERRORS.unauthorized
  const code = error instanceof Error ? (error.message as CfeErrorCode) : 'server-error'
  return CFE_ERRORS[code] ?? CFE_ERRORS['server-error']
}

/** Calls a CFE route and throws the API error code so `errorMessage` can translate it. */
export async function cfeCall<T = unknown>(url: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers)
  if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json')
  const res = await accessFetch(url, { ...init, headers })
  const data = (await res.json().catch(() => ({}))) as { error?: string }
  if (!res.ok) throw new Error(data.error ?? 'server-error')
  return data as T
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('es-MX', { dateStyle: 'short', timeStyle: 'short' })
}
