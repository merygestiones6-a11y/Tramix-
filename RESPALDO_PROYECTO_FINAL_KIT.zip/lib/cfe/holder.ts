import { detectName } from '@/lib/extract/name'

const stripAccents = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')

/** Words that appear in the header of a CFE bill and are never part of the holder's name. */
const NOT_NAME = new Set([
  'CFE', 'COMISION', 'FEDERAL', 'ELECTRICIDAD', 'SUMINISTRADOR', 'SUMINISTRO', 'SERVICIOS', 'BASICOS', 'SERVICIO',
  'TOTAL', 'PAGAR', 'PERIODO', 'FACTURADO', 'LIMITE', 'PAGO', 'CORTE', 'TARIFA', 'MEDIDOR', 'LECTURA', 'CONSUMO',
  'RMU', 'CUENTA', 'AVISO', 'RECIBO', 'MEXICO', 'COL', 'CALLE', 'AV', 'AVENIDA', 'CP', 'C.P.', 'MUNICIPIO', 'ESTADO',
  'DOMICILIO', 'NO', 'NUM', 'KWH', 'IVA', 'PESOS', 'MN', 'IMPORTE', 'FECHA', 'ENERGIA', 'DAP', 'MZ', 'LT', 'INT', 'EXT',
  'BIMESTRAL', 'MENSUAL', 'DOMESTICO', 'CIUDAD', 'CDMX', 'FRACC', 'FRACCIONAMIENTO', 'ESQ', 'ENTRE', 'Y', 'SIN',
])
const CONNECTORS = new Set(['DE', 'DEL', 'LA', 'LAS', 'LOS', 'Y', 'VDA', 'VIUDA', 'MC', 'MAC', 'VAN', 'VON', 'SAN'])
const WORD = /^[A-ZÑ]+$/

function looksLikeName(line: string): string | null {
  const words = stripAccents(line.toUpperCase()).replace(/[|,]/g, ' ').split(/\s+/).filter(Boolean)
  if (words.length < 2 || words.length > 7) return null
  if (!words.every((w) => WORD.test(w))) return null
  const real = words.filter((w) => !CONNECTORS.has(w))
  if (real.length < 2) return null
  if (real.some((w) => NOT_NAME.has(w) || w.length < 2 || !/[AEIOU]/.test(w))) return null
  return words.join(' ')
}

/**
 * CFE bills print the holder's name on its own line in the header, right before the address
 * and the "NO. DE SERVICIO" block. The generic detector is tried first for labeled names.
 */
export function detectCfeHolder(pages: string[]): string | null {
  const labeled = detectName(pages)
  if (labeled && labeled.confidence !== 'low') return labeled.value

  const lines = (pages[0] ?? '').split('\n').flatMap((l) => l.split(' | ')).map((l) => l.trim())
  const serviceAt = lines.findIndex((l) => /SERVICIO/i.test(stripAccents(l)))
  const scope = serviceAt > 0 ? lines.slice(Math.max(0, serviceAt - 12), serviceAt) : lines.slice(0, 25)
  for (const line of scope) {
    const name = looksLikeName(line)
    if (name) return name
  }
  return labeled?.value ?? null
}

/** First 11-digit run near "SERVICIO", else any isolated 11-digit run. */
export function detectServiceNumber(pages: string[]): string | null {
  const text = pages.join('\n')
  const near = stripAccents(text).match(/SERVICIO[^\d]{0,30}(\d[\d\s]{10,16})/i)
  const digits = near?.[1].replace(/\s/g, '')
  if (digits && digits.length === 11) return digits
  return text.match(/(?<!\d)\d{11}(?!\d)/)?.[0] ?? null
}

/** NOMBRE_DEL_TITULAR_12345678901.pdf — accents removed (Ñ kept) so the name is safe on any device. */
export function receiptFileName(holder: string | null, serviceNumber: string | null): string {
  const clean = (holder ?? '')
    .toUpperCase()
    .replace(/Ñ/g, '\u0000')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\u0000/g, 'Ñ')
    .replace(/[^A-ZÑ0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, '_')
  const parts = [clean || 'SIN_TITULAR', serviceNumber].filter(Boolean)
  return `${parts.join('_')}.pdf`
}
