type NativeSaver = { saveDataUrl?: (name: string, mime: string, dataUrl: string) => void }

function nativeSaver(): NativeSaver['saveDataUrl'] | null {
  if (typeof window === 'undefined') return null
  const bridge = (window as unknown as { TramixAndroid?: NativeSaver }).TramixAndroid
  return bridge && typeof bridge.saveDataUrl === 'function' ? bridge.saveDataUrl.bind(bridge) : null
}

/**
 * Downloads the bytes using exactly the given file name. The blob URL is
 * revoked shortly after so the document does not linger in memory.
 */
export function downloadPdf(data: Blob | Uint8Array | ArrayBuffer, fileName: string): void {
  const blob = new Blob([data as BlobPart], { type: 'application/pdf' })

  // The Android WebView names blob downloads after the blob URL's UUID and ignores `download`,
  // so inside the app the bytes go straight to the native saver with the on-screen name.
  const saveDataUrl = nativeSaver()
  if (saveDataUrl) {
    const reader = new FileReader()
    reader.onload = () => saveDataUrl(fileName, 'application/pdf', String(reader.result))
    reader.readAsDataURL(blob)
    return
  }

  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = fileName
  link.rel = 'noopener'
  link.style.display = 'none'
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(url), 30_000)
}
