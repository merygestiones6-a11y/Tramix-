import type { Worker } from 'tesseract.js'

let workerPromise: Promise<Worker> | null = null
let progressListener: ((progress: number) => void) | null = null

async function getWorker(): Promise<Worker> {
  if (!workerPromise) {
    workerPromise = import('tesseract.js').then(({ createWorker }) =>
      createWorker('spa', 1, {
        logger: (message) => {
          if (message.status === 'recognizing text') progressListener?.(message.progress)
        },
      }),
    )
    workerPromise.catch(() => {
      workerPromise = null
    })
  }
  return workerPromise
}

/**
 * Runs OCR entirely in the browser. Only the OCR engine and Spanish language
 * model are downloaded; document images never leave the device.
 */
export async function recognizeImage(
  image: HTMLCanvasElement,
  onProgress?: (progress: number) => void,
): Promise<string> {
  const worker = await getWorker()
  progressListener = onProgress ?? null
  try {
    const { data } = await worker.recognize(image)
    return data.text ?? ''
  } finally {
    progressListener = null
  }
}

export async function terminateOcr(): Promise<void> {
  if (!workerPromise) return
  const worker = await workerPromise.catch(() => null)
  workerPromise = null
  await worker?.terminate()
}
