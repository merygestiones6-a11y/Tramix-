import { recognizeImage } from '@/lib/ocr/tesseract'
import { openPdfDocument } from './pdfjs'

export interface ExtractProgress {
  page: number
  totalPages: number
  mode: 'text' | 'ocr'
  ocrProgress?: number
}

export interface ExtractResult {
  pages: string[]
  usedOcr: boolean
}

export const MIN_TEXT_CHARS = 25
const MAX_OCR_PAGES = 12
const OCR_SCALE = 2

export interface TextItemLike {
  str: string
  transform: number[]
  width?: number
  height?: number
  hasEOL?: boolean
}

/** Separator placed between visually distinct columns of the same row. */
export const COLUMN_SEPARATOR = ' | '

/**
 * Rebuilds visual lines from pdf.js text items using their X/Y positions.
 * Items far apart on the same row are joined with a column separator so the
 * extractor can tell table cells ("NOMBRE | CURP | NSS") apart.
 */
export function itemsToLines(items: TextItemLike[]): string {
  const rows: { y: number; parts: { x: number; end: number; size: number; str: string }[] }[] = []
  for (const item of items) {
    if (!item.str?.trim() || !item.transform) continue
    const x = item.transform[4]
    const y = item.transform[5]
    const size = Math.abs(item.height || item.transform[3] || 10)
    let row = rows.find((r) => Math.abs(r.y - y) < Math.max(3, size * 0.4))
    if (!row) {
      row = { y, parts: [] }
      rows.push(row)
    }
    row.parts.push({ x, end: x + (item.width ?? item.str.length * size * 0.5), size, str: item.str })
  }
  return rows
    .sort((a, b) => b.y - a.y)
    .map((row) => {
      const parts = row.parts.sort((a, b) => a.x - b.x)
      let line = ''
      parts.forEach((part, index) => {
        if (index > 0) {
          const previous = parts[index - 1]
          const gap = part.x - previous.end
          line += gap > Math.max(12, previous.size * 1.6) ? COLUMN_SEPARATOR : ' '
        }
        line += part.str
      })
      return line.replace(/[ \t]+/g, ' ').trim()
    })
    .filter(Boolean)
    .join('\n')
}

async function ocrPage(
  page: Awaited<ReturnType<Awaited<ReturnType<typeof openPdfDocument>>['doc']['getPage']>>,
  onProgress?: (progress: number) => void,
): Promise<string> {
  const viewport = page.getViewport({ scale: OCR_SCALE })
  const canvas = document.createElement('canvas')
  canvas.width = Math.floor(viewport.width)
  canvas.height = Math.floor(viewport.height)
  const context = canvas.getContext('2d')
  if (!context) return ''
  try {
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    await page.render({ canvas, canvasContext: context, viewport }).promise
    return await recognizeImage(canvas, onProgress)
  } finally {
    canvas.width = 0
    canvas.height = 0
  }
}

/**
 * Second-chance OCR over the first pages of a text PDF. Used when the text
 * layer does not expose the person's name (names drawn as images, broken fonts).
 */
export async function ocrPdfPages(
  bytes: Uint8Array,
  maxPages: number,
  onProgress?: (progress: ExtractProgress) => void,
): Promise<string[]> {
  const { doc, close } = await openPdfDocument(bytes)
  const total = Math.min(doc.numPages, maxPages)
  const pages: string[] = []
  try {
    for (let pageNumber = 1; pageNumber <= total; pageNumber++) {
      const page = await doc.getPage(pageNumber)
      pages.push(
        await ocrPage(page, (p) => onProgress?.({ page: pageNumber, totalPages: total, mode: 'ocr', ocrProgress: p })),
      )
      page.cleanup()
    }
  } finally {
    await close()
  }
  return pages
}

/**
 * Extracts text from every page. Pages without selectable text (scans/photos)
 * are rendered to a canvas and read with OCR.
 */
export async function extractPdfText(
  bytes: Uint8Array,
  onProgress?: (progress: ExtractProgress) => void,
): Promise<ExtractResult> {
  const { doc, close } = await openPdfDocument(bytes)
  const pages: string[] = []
  let usedOcr = false
  let ocrPagesDone = 0

  try {
    for (let pageNumber = 1; pageNumber <= doc.numPages; pageNumber++) {
      onProgress?.({ page: pageNumber, totalPages: doc.numPages, mode: 'text' })
      const page = await doc.getPage(pageNumber)
      const content = await page.getTextContent()
      let text = itemsToLines(content.items as TextItemLike[])

      if (text.replace(/\s/g, '').length < MIN_TEXT_CHARS && ocrPagesDone < MAX_OCR_PAGES) {
        usedOcr = true
        ocrPagesDone++
        const ocrText = await ocrPage(page, (p) =>
          onProgress?.({ page: pageNumber, totalPages: doc.numPages, mode: 'ocr', ocrProgress: p }),
        )
        text = `${text}\n${ocrText}`.trim()
      }

      pages.push(text)
      page.cleanup()
    }
  } finally {
    await close()
  }

  return { pages, usedOcr }
}

/** Fails fast with a clear error when a file is not a readable PDF. */
export async function assertReadablePdf(bytes: Uint8Array): Promise<number> {
  const { doc, close } = await openPdfDocument(bytes)
  const count = doc.numPages
  await close()
  return count
}
