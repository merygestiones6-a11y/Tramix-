type PdfJs = typeof import('pdfjs-dist/legacy/build/pdf.mjs')

let pdfjsPromise: Promise<PdfJs> | null = null

/** Lazily loads pdf.js (legacy build for older iOS/Android browsers). */
export function loadPdfJs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    pdfjsPromise = import('pdfjs-dist/legacy/build/pdf.mjs').then((pdfjs) => {
      pdfjs.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.mjs'
      return pdfjs
    })
  }
  return pdfjsPromise
}

export async function openPdfDocument(bytes: Uint8Array) {
  const pdfjs = await loadPdfJs()
  // pdf.js transfers the buffer to its worker, so give it a copy.
  const task = pdfjs.getDocument({ data: bytes.slice() })
  const doc = await task.promise
  return { doc, close: () => task.destroy() }
}
