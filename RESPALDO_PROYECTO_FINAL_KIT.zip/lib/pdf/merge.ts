import { PDFDocument } from 'pdf-lib'

/**
 * Merges PDFs page-by-page. Pages are copied as-is (no re-rendering or
 * re-compression), so the original quality is preserved.
 */
export async function mergePdfs(sources: Uint8Array[]): Promise<Uint8Array> {
  const merged = await PDFDocument.create()
  for (const bytes of sources) {
    const source = await PDFDocument.load(bytes, { ignoreEncryption: true })
    const pages = await merged.copyPages(source, source.getPageIndices())
    pages.forEach((page) => merged.addPage(page))
  }
  return merged.save({ useObjectStreams: true })
}
