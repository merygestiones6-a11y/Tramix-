export const ERRORS = {
  noFiles: 'Selecciona al menos un PDF.',
  notPdf: 'Este archivo no es un PDF válido.',
  unreadable: 'No se pudo leer este archivo.',
  emptyName: 'Escribe un nombre para el archivo.',
} as const

export function isPdfFile(file: File): boolean {
  const byType = file.type === 'application/pdf'
  const byName = /\.pdf$/i.test(file.name)
  return byType || (byName && (file.type === '' || file.type === 'application/octet-stream'))
}

export async function hasPdfSignature(file: File): Promise<boolean> {
  const head = new Uint8Array(await file.slice(0, 1024).arrayBuffer())
  return new TextDecoder('latin1').decode(head).includes('%PDF-')
}

export function stripPdfExtension(fileName: string): string {
  return fileName.replace(/\.pdf$/i, '')
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
