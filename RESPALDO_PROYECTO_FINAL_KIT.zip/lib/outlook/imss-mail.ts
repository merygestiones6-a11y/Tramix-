import { extractDocumentText } from '@/lib/panel/extract-text'
import { buildSuggestedFileName } from '@/lib/naming'
import { shortHash } from './crypto'
import {
  GraphAuthError,
  type GraphMessage,
  accessTokenFor,
  downloadAttachment,
  listMessagesSince,
  listPdfAttachments,
} from './graph'
import {
  type DocumentMeta,
  type MessageResult,
  type StoredAccount,
  type Watch,
  getWatch,
  listAccounts,
  listDocuments,
  listWatches,
  saveAccount,
  saveDocument,
  saveWatch,
} from './store'

const CURP_PATTERN = /[A-Z][AEIOUX][A-Z]{2}\d{6}[HMX][A-Z]{5}[A-Z\d]\d/g
const MAX_PDF_BYTES = 15 * 1024 * 1024
const MAX_LINKS_PER_MESSAGE = 3
/** Mail clocks and the IMSS sender can be slightly ahead of the moment TRAMIX saw the submission. */
const RECEIVED_SLACK_MS = 10 * 60 * 1000
const MIN_CHECK_GAP_MS = 15 * 1000

export function isImssAddress(address: string | undefined): boolean {
  const domain = address?.toLowerCase().split('@')[1]
  return domain === 'imss.gob.mx' || Boolean(domain?.endsWith('.imss.gob.mx'))
}

export function isImssUrl(value: string): boolean {
  try {
    const url = new URL(value)
    return url.protocol === 'https:' && (url.hostname === 'imss.gob.mx' || url.hostname.endsWith('.imss.gob.mx'))
  } catch {
    return false
  }
}

function decodeEntities(text: string): string {
  return text
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
}

export function htmlToText(html: string): string {
  return decodeEntities(
    html
      .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<br\s*\/?>|<\/(p|div|tr|li|h\d)>/gi, '\n')
      .replace(/<[^>]+>/g, ' '),
  )
    .replace(/[ \t]+/g, ' ')
    .trim()
}

const IGNORED_LINK = /privacidad|aviso|baja|unsubscribe|facebook|twitter|instagram|youtube|\.(png|jpe?g|gif|css|js)(\?|$)/i
const PREFERRED_LINK = /pdf|descarg|constancia|comprobante|documento|nss|asignaci|confirm|valid|verific|activ|token/i

/** IMSS links in the e-mail, most promising first. */
export function extractImssLinks(html: string): string[] {
  const found = new Set<string>()
  for (const match of html.matchAll(/href\s*=\s*["']([^"']+)["']/gi)) found.add(decodeEntities(match[1]).trim())
  for (const match of htmlToText(html).matchAll(/https:\/\/[^\s"'<>]+/g)) found.add(match[0].replace(/[).,;]+$/, ''))
  return [...found]
    .filter((url) => isImssUrl(url) && !IGNORED_LINK.test(url))
    .sort((a, b) => Number(PREFERRED_LINK.test(b)) - Number(PREFERRED_LINK.test(a)))
}

function looksLikePdf(bytes: Uint8Array): boolean {
  return bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46
}

async function readCapped(res: Response): Promise<Uint8Array> {
  const length = Number(res.headers.get('content-length') ?? 0)
  if (length > MAX_PDF_BYTES) throw new Error('too-large')
  const bytes = new Uint8Array(await res.arrayBuffer())
  if (bytes.byteLength > MAX_PDF_BYTES) throw new Error('too-large')
  return bytes
}

/** Fetches an IMSS URL following redirects only while they stay on imss.gob.mx. */
async function fetchImss(start: string): Promise<{ res: Response; url: string }> {
  let url = start
  for (let hop = 0; hop < 6; hop++) {
    if (!isImssUrl(url)) throw new Error('off-domain-redirect')
    const res = await fetch(url, {
      redirect: 'manual',
      headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 14) TRAMIX', Accept: 'application/pdf,text/html;q=0.9,*/*;q=0.5' },
      signal: AbortSignal.timeout(25_000),
    })
    const location = res.headers.get('location')
    if (res.status >= 300 && res.status < 400 && location) {
      url = new URL(location, url).toString()
      continue
    }
    return { res, url }
  }
  throw new Error('too-many-redirects')
}

type LinkOutcome =
  | { kind: 'pdf'; bytes: Uint8Array; name: string | null }
  | { kind: 'opened' }
  | { kind: 'failed'; reason: string }

function fileNameFrom(res: Response, url: string): string | null {
  const disposition = res.headers.get('content-disposition') ?? ''
  const star = disposition.match(/filename\*=UTF-8''([^;]+)/i)
  const plain = disposition.match(/filename="?([^";]+)"?/i)
  const raw = star ? decodeURIComponent(star[1]) : plain?.[1]
  if (raw) return raw
  const last = decodeURIComponent(new URL(url).pathname.split('/').pop() ?? '')
  return /\.pdf$/i.test(last) ? last : null
}

/** Opens the e-mail link like a browser would: a PDF is downloaded; an HTML page is scanned for a PDF link. */
export async function processImssLink(link: string): Promise<LinkOutcome> {
  try {
    const { res, url } = await fetchImss(link)
    if (!res.ok) return { kind: 'failed', reason: `HTTP ${res.status}` }
    const type = res.headers.get('content-type') ?? ''
    const bytes = await readCapped(res)
    if (/pdf/i.test(type) || looksLikePdf(bytes)) return { kind: 'pdf', bytes, name: fileNameFrom(res, url) }
    if (/html/i.test(type)) {
      const html = new TextDecoder('utf-8').decode(bytes)
      const inner = [...html.matchAll(/(?:href|src)\s*=\s*["']([^"']+)["']/gi)]
        .map((m) => {
          try {
            return new URL(decodeEntities(m[1]), url).toString()
          } catch {
            return ''
          }
        })
        .filter((u) => isImssUrl(u) && /pdf|descarg|constancia|comprobante/i.test(u))
      for (const candidate of inner.slice(0, 2)) {
        const next = await fetchImss(candidate)
        if (!next.res.ok) continue
        const innerBytes = await readCapped(next.res)
        if (/pdf/i.test(next.res.headers.get('content-type') ?? '') || looksLikePdf(innerBytes)) {
          return { kind: 'pdf', bytes: innerBytes, name: fileNameFrom(next.res, next.url) }
        }
      }
    }
    return { kind: 'opened' }
  } catch (error) {
    return { kind: 'failed', reason: error instanceof Error ? error.message : 'error' }
  }
}

async function pdfCurps(bytes: Uint8Array): Promise<{ text: boolean; curps: Set<string> }> {
  try {
    const result = await extractDocumentText('documento.pdf', 'application/pdf', bytes)
    if (result.status !== 'ready') return { text: false, curps: new Set() }
    return { text: true, curps: new Set(result.text.toUpperCase().match(CURP_PATTERN) ?? []) }
  } catch {
    return { text: false, curps: new Set() }
  }
}

const GENERIC_NAME = /^(att\d*|attachment|adjunto|documento|document|archivo|file|download|descarga)\d*\.pdf$/i

/** Keeps the IMSS name when it already identifies the person; otherwise TRAMIX's NSS_<CURP>.pdf rule. */
export function documentName(original: string | null, curp: string, taken: Set<string>): string {
  const clean = original?.trim() ?? ''
  const keep = /\.pdf$/i.test(clean) && !GENERIC_NAME.test(clean) && clean.toUpperCase().includes(curp)
  const base = keep ? clean : buildSuggestedFileName({ prefix: 'NSS_', curp, fallbackName: clean || 'documento.pdf' })
  let name = base
  for (let n = 2; taken.has(name.toLowerCase()); n++) name = base.replace(/\.pdf$/i, `_${n}.pdf`)
  taken.add(name.toLowerCase())
  return name
}

interface MessageContext {
  watch: Watch
  account: StoredAccount
  message: GraphMessage
  /** Another active trámite uses the same e-mail address, so the address alone cannot identify this one. */
  ambiguous: boolean
  takenNames: Set<string>
}

/** A PDF belongs to the trámite when it shows this CURP, or (without readable text) when the e-mail does. */
function belongs(pdf: { text: boolean; curps: Set<string> }, mailMentionsCurp: boolean, addressed: boolean, ctx: MessageContext) {
  if (pdf.curps.has(ctx.watch.curp)) return true
  if (pdf.curps.size > 0) return false
  return mailMentionsCurp || (addressed && !ctx.ambiguous)
}

async function handleMessage(ctx: MessageContext, token: string): Promise<{ result: MessageResult; docs: DocumentMeta[]; note?: string }> {
  const { watch, account, message } = ctx
  const html = message.body?.content ?? ''
  const text = (message.body?.contentType === 'html' ? htmlToText(html) : html).toUpperCase()
  const otherCurps = new Set((text.match(CURP_PATTERN) ?? []).filter((c) => c !== watch.curp))
  const mentionsCurp = text.includes(watch.curp)
  const email = watch.email.toLowerCase()
  const addressed =
    account.address.toLowerCase() === email ||
    Boolean(message.toRecipients?.some((r) => r.emailAddress?.address?.toLowerCase() === email))

  if (!mentionsCurp && otherCurps.size > 0) return { result: 'other_curp', docs: [] }

  const base = {
    curp: watch.curp,
    watchId: watch.id,
    account: account.address,
    subject: message.subject ?? '',
    receivedAt: message.receivedDateTime,
  }
  const docs: DocumentMeta[] = []
  let rejectedForCurp = false

  if (message.hasAttachments) {
    for (const attachment of await listPdfAttachments(token, message.id)) {
      if (attachment.size > MAX_PDF_BYTES) continue
      const bytes = await downloadAttachment(token, message.id, attachment.id)
      if (!looksLikePdf(bytes)) continue
      if (!belongs(await pdfCurps(bytes), mentionsCurp, addressed, ctx)) {
        rejectedForCurp = true
        continue
      }
      const id = shortHash(`${account.id}:${message.id}:${attachment.id}`, 24)
      const name = documentName(attachment.name, watch.curp, ctx.takenNames)
      docs.push(await saveDocument({ ...base, id, name, originalName: attachment.name, source: 'attachment' }, bytes))
    }
  }
  if (docs.length) return { result: 'pdf', docs }

  if (!(mentionsCurp || (addressed && !ctx.ambiguous))) {
    return { result: rejectedForCurp ? 'other_curp' : 'no_pdf', docs }
  }

  const links = extractImssLinks(html).slice(0, MAX_LINKS_PER_MESSAGE)
  let opened = false
  let lastFailure: string | undefined
  for (const link of links) {
    const outcome = await processImssLink(link)
    if (outcome.kind === 'pdf') {
      if (!belongs(await pdfCurps(outcome.bytes), mentionsCurp, addressed, ctx)) {
        rejectedForCurp = true
        continue
      }
      const id = shortHash(`${account.id}:${message.id}:${link}`, 24)
      const name = documentName(outcome.name, watch.curp, ctx.takenNames)
      const original = outcome.name ?? new URL(link).pathname.split('/').pop() ?? 'documento.pdf'
      docs.push(await saveDocument({ ...base, id, name, originalName: original, source: 'link' }, outcome.bytes))
      return { result: 'link_pdf', docs }
    }
    if (outcome.kind === 'opened') opened = true
    else lastFailure = outcome.reason
  }
  if (opened) return { result: 'link_opened', docs, note: 'Enlace abierto; se espera el PDF en otro correo.' }
  if (links.length && lastFailure) return { result: 'link_failed', docs, note: lastFailure }
  return { result: rejectedForCurp ? 'other_curp' : 'no_pdf', docs }
}

export interface CheckResult {
  done: boolean
  status: Watch['status']
  documents: number
}

/** One pass over every linked mailbox. Safe to run concurrently: documents are keyed by message + attachment. */
export async function checkWatch(watchId: string, options: { finalize?: boolean } = {}): Promise<CheckResult> {
  const watch = await getWatch(watchId)
  if (!watch) return { done: true, status: 'cancelled', documents: 0 }
  const now = Date.now()
  if (watch.status !== 'waiting' && !isCollecting(watch, now)) {
    return { done: true, status: watch.status, documents: watch.documentIds.length }
  }

  if (!options.finalize && watch.lastCheckAt && now - new Date(watch.lastCheckAt).getTime() < MIN_CHECK_GAP_MS) {
    return { done: false, status: watch.status, documents: watch.documentIds.length }
  }

  const accounts = (await listAccounts()).filter((a) => a.status === 'ok' && (!watch.accountId || a.id === watch.accountId))
  const others = (await listWatches()).filter(
    (w) => w.id !== watch.id && w.status === 'waiting' && w.email.toLowerCase() === watch.email.toLowerCase() && w.curp !== watch.curp,
  )
  const takenNames = new Set((await listDocuments()).filter((d) => d.watchId === watch.id).map((d) => d.name.toLowerCase()))
  const processed = new Set(watch.messages.map((m) => m.key))
  const since = new Date(new Date(watch.submittedAt).getTime() - RECEIVED_SLACK_MS).toISOString()
  watch.note = accounts.length ? undefined : 'No hay cuentas Outlook vinculadas.'

  for (const account of accounts) {
    try {
      const token = await accessTokenFor(account)
      const messages = (await listMessagesSince(token, since)).filter((m) => isImssAddress(m.from?.emailAddress?.address))
      // Oldest first, so a first notice is recorded before the follow-up that carries the PDF.
      for (const message of messages.reverse()) {
        const key = `${account.id}:${message.id}`
        if (processed.has(key)) continue
        const outcome = await handleMessage({ watch, account, message, ambiguous: others.length > 0, takenNames }, token)
        processed.add(key)
        watch.messages.push({
          key,
          account: account.address,
          subject: message.subject ?? '(sin asunto)',
          receivedAt: message.receivedDateTime,
          result: outcome.result,
          note: outcome.note,
        })
        for (const doc of outcome.docs) if (!watch.documentIds.includes(doc.id)) watch.documentIds.push(doc.id)
      }
      account.lastCheckAt = new Date().toISOString()
      account.lastError = undefined
      await saveAccount(account)
    } catch (error) {
      const auth = error instanceof GraphAuthError
      console.error('[imss-mail] mailbox check failed', account.address, error)
      account.lastError = auth ? 'Vuelve a vincular esta cuenta.' : 'No se pudo revisar; se reintentará.'
      if (auth && /invalid_grant|interaction_required|token-unreadable/.test(error.message)) account.status = 'reconnect'
      await saveAccount(account).catch(() => {})
    }
  }

  watch.checks += 1
  watch.lastCheckAt = new Date().toISOString()
  if (watch.documentIds.length) {
    watch.status = 'found'
    watch.foundAt ??= watch.lastCheckAt
  } else if (options.finalize) watch.status = 'expired'
  await saveWatch(watch)
  const done = watch.status === 'found' ? options.finalize || !isCollecting(watch, Date.now()) : watch.status !== 'waiting'
  return { done: Boolean(done), status: watch.status, documents: watch.documentIds.length }
}

/** The IMSS often sends several PDFs in separate e-mails: keep collecting for a while after the first. */
export const COLLECT_WINDOW_MS = 20 * 60 * 1000

export function isCollecting(watch: Watch, now = Date.now()): boolean {
  return watch.status === 'found' && Boolean(watch.foundAt) && now - new Date(watch.foundAt as string).getTime() < COLLECT_WINDOW_MS
}
