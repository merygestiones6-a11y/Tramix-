import { accessKey } from './config'
import { safeEqual, sign, verifySigned } from './crypto'

export const ACCESS_HEADER = 'x-tramix-access'
export const ACCESS_COOKIE = 'tramix_access'
export const ACCESS_TTL_MS = 30 * 24 * 60 * 60 * 1000

const SESSION_LABEL = 'panel-session'
const TICKET_LABEL = 'panel-ticket'

export function isAccessConfigured(): boolean {
  return accessKey() !== null
}

export function checkAccessKey(input: string): boolean {
  const key = accessKey()
  return key !== null && safeEqual(input.trim(), key)
}

export function issueAccessToken(now = Date.now()): string {
  return sign(`s.${now + ACCESS_TTL_MS}`, SESSION_LABEL, accessKey() ?? '')
}

function validExpiry(payload: string | null, prefix: string, now: number): boolean {
  if (!payload?.startsWith(prefix)) return false
  const exp = Number(payload.slice(prefix.length))
  return Number.isFinite(exp) && exp > now
}

function readCookie(request: Request, name: string): string | null {
  const header = request.headers.get('cookie')
  if (!header) return null
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=')
    if (k === name) return decodeURIComponent(v.join('='))
  }
  return null
}

/**
 * Same rule as CUENTAS OUTLOOK: open while PANEL_ACCESS_KEY is unset, protected once it is set.
 * Header first (works inside iframes and the Android WebView), cookie as fallback.
 */
export function hasAccess(request: Request, now = Date.now()): boolean {
  const key = accessKey()
  if (!key) return true
  for (const token of [request.headers.get(ACCESS_HEADER), readCookie(request, ACCESS_COOKIE)]) {
    if (token && validExpiry(verifySigned(token, SESSION_LABEL, key), 's.', now)) return true
  }
  return false
}

/** Short-lived ticket so "Vincular Outlook" can open in a new top-level tab without the session header. */
export function issueConnectTicket(now = Date.now()): string {
  return sign(`t.${now + 5 * 60 * 1000}`, TICKET_LABEL, accessKey() ?? '')
}

export function verifyConnectTicket(ticket: string, now = Date.now()): boolean {
  return validExpiry(verifySigned(ticket, TICKET_LABEL, accessKey() ?? ''), 't.', now)
}

export function unauthorized() {
  return Response.json({ error: 'unauthorized' }, { status: 401, headers: { 'Cache-Control': 'no-store' } })
}

export function accessCookie(token: string | null): string {
  const base = `${ACCESS_COOKIE}=${token ? encodeURIComponent(token) : ''}; Path=/api; HttpOnly; Secure; SameSite=None`
  return token ? `${base}; Max-Age=${Math.floor(ACCESS_TTL_MS / 1000)}` : `${base}; Max-Age=0`
}
