import type { ConfirmedReceipt, ReceiverState, StoredAccount, Watch } from './store'

/** An account leaves LECTURA DE CORREOS DEL IMSS this long after its first confirmed IMSS trámite e-mail. */
export const RETIRE_AFTER_MS = 60 * 60 * 1000

export type KeepReason = 'sin-correo-imss' | 'esperando-1h'

export type Decision =
  | { retire: true; confirmedAt: string }
  | { retire: false; reason: KeepReason; confirmedAt?: string }

export interface Evidence {
  receiver: ReceiverState | null
  watches: Watch[]
  receipts: ConfirmedReceipt[]
}

const toTime = (value?: string) => {
  const t = value ? Date.parse(value) : NaN
  return Number.isFinite(t) && t > 0 ? t : NaN
}

/**
 * Earliest real reception of an IMSS trámite e-mail in this inbox, or undefined when none is on record.
 * Evidence: receiver cards and trámite-watch messages addressed to it, the receiver's own `usedAt` mark,
 * and the persisted confirmation (which outlives the receiver's history cleanup).
 * Being red, signing in or having been checked is not evidence.
 */
export function confirmedReceiptAt(account: StoredAccount, evidence: Evidence) {
  const address = account.address.toLowerCase()
  const mine = (value?: string) => Boolean(value) && (value!.toLowerCase() === address || value === account.id)
  const times = [
    ...(evidence.receiver?.items ?? []).filter((i) => mine(i.account)).map((i) => i.receivedAt),
    ...evidence.watches.flatMap((w) => (w.messages ?? []).filter((m) => mine(m.account)).map((m) => m.receivedAt)),
    account.usedAt,
    evidence.receipts.find((r) => r.id === account.id)?.confirmedAt,
  ]
    .map(toTime)
    .filter((t) => Number.isFinite(t))
  return times.length ? new Date(Math.min(...times)).toISOString() : undefined
}

export function decide(account: StoredAccount, evidence: Evidence, now = Date.now()): Decision {
  const confirmedAt = confirmedReceiptAt(account, evidence)
  if (!confirmedAt) return { retire: false, reason: 'sin-correo-imss' }
  if (now - Date.parse(confirmedAt) < RETIRE_AFTER_MS) return { retire: false, reason: 'esperando-1h', confirmedAt }
  return { retire: true, confirmedAt }
}
