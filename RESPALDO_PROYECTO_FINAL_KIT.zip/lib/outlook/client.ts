const STORAGE_KEY = 'tramix-panel-access'
const HEADER = 'x-tramix-access'

export function readAccessToken(): string | null {
  try {
    return sessionStorage.getItem(STORAGE_KEY)
  } catch {
    return null
  }
}

export function storeAccessToken(token: string | null) {
  try {
    if (token) sessionStorage.setItem(STORAGE_KEY, token)
    else sessionStorage.removeItem(STORAGE_KEY)
  } catch {}
}

export class AccessError extends Error {}

/** Sends the panel session as a header, so it also works inside iframes and the Android WebView. */
export async function accessFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers)
  const token = readAccessToken()
  if (token) headers.set(HEADER, token)
  const res = await fetch(url, { ...init, headers, cache: 'no-store', credentials: 'same-origin' })
  if (res.status === 401) throw new AccessError('unauthorized')
  return res
}

export async function accessJson<T>(url: string): Promise<T> {
  const res = await accessFetch(url)
  if (!res.ok) throw new Error(`request-failed-${res.status}`)
  return res.json() as Promise<T>
}

/** Opens a URL in a new tab inside the v0 preview iframe, or in the same tab otherwise. */
export function navigateTop(url: string) {
  if (window.self !== window.top) window.open(url, '_blank', 'noopener,noreferrer')
  else window.location.href = url
}
