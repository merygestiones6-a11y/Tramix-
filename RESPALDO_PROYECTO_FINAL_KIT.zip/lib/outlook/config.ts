/** Read-only mailbox access. `offline_access` yields the refresh token used by the background watcher. */
export const GRAPH_SCOPES = 'offline_access User.Read Mail.Read'

export const CALLBACK_PATH = '/api/outlook/callback'

/** How long TRAMIX keeps looking for the IMSS e-mail after the form is submitted. */
export const WATCH_WINDOW_MS = 24 * 60 * 60 * 1000

/** Trámite records (the PDFs themselves live in DESCARGAR) are removed by the daily cleanup after this. */
export const DOCUMENT_TTL_MS = 30 * 24 * 60 * 60 * 1000

export interface MicrosoftConfig {
  clientId: string
  clientSecret: string
  tenant: string
}

export function microsoftConfig(): MicrosoftConfig | null {
  const clientId = process.env.MICROSOFT_CLIENT_ID?.trim()
  const clientSecret = process.env.MICROSOFT_CLIENT_SECRET?.trim()
  if (!clientId || !clientSecret) return null
  // Always "common": a tenant ID or "organizations" would reject personal Outlook.com / Hotmail accounts.
  return { clientId, clientSecret, tenant: 'common' }
}

export function accessKey(): string | null {
  return process.env.PANEL_ACCESS_KEY?.trim() || null
}

/** Stable public origin, so the redirect URI always matches the one registered in Microsoft Entra. */
export function getOrigin(request: Request): string {
  if (process.env.NODE_ENV !== 'production' && process.env.V0_RUNTIME_URL) {
    return process.env.V0_RUNTIME_URL.replace(/\/+$/, '')
  }
  if (process.env.VERCEL_PROJECT_PRODUCTION_URL) return `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
  if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`
  const host = request.headers.get('x-forwarded-host') ?? request.headers.get('host') ?? 'localhost:3000'
  const proto = request.headers.get('x-forwarded-proto') ?? 'https'
  return `${proto}://${host}`
}

export function requestHost(request: Request): string {
  return request.headers.get('x-forwarded-host') ?? request.headers.get('host') ?? new URL(request.url).host
}
