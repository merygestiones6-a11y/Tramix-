import { createHash, randomBytes } from 'node:crypto'
import { del, get, list, put } from '@vercel/blob'
import { addToDownloads } from '@/lib/panel/add-file'
import { openOriginal } from '@/lib/panel/store'
import { DOCUMENT_TTL_MS } from './config'

/**
 * Private Blob layout:
 *   imss-mail/accounts/<id>.json      linked Outlook account (refresh token encrypted)
 *   imss-mail/watches/<id>.json       one per submitted IMSS trámite
 *   imss-mail/docs/<id>.json          document metadata
 *   imss-mail/files/<id>/<name>       document bytes
 * JSON records are overwritten in place and always read with `useCache: false`.
 */
const ROOT = 'imss-mail/'
const WATCH_ID = /^\d{13}-[a-f0-9]{12}$/
const SAFE_ID = /^[a-f0-9]{16,40}$/

export type AccountStatus = 'ok' | 'reconnect'

export interface StoredAccount {
  id: string
  address: string
  name: string
  refresh: string
  status: AccountStatus
  createdAt: string
  updatedAt: string
  lastCheckAt?: string
  lastError?: string
  /** First time an IMSS e-mail was seen in this inbox. */
  usedAt?: string
}

export type PublicAccount = Omit<StoredAccount, 'refresh'>

export type WatchStatus = 'waiting' | 'found' | 'expired' | 'cancelled'

export type MessageResult = 'pdf' | 'link_pdf' | 'link_opened' | 'link_failed' | 'no_pdf' | 'other_curp'

export interface WatchMessage {
  key: string
  account: string
  subject: string
  receivedAt: string
  result: MessageResult
  note?: string
}

export interface Watch {
  id: string
  curp: string
  email: string
  submittedAt: string
  deadline: string
  status: WatchStatus
  checks: number
  lastCheckAt?: string
  note?: string
  messages: WatchMessage[]
  documentIds: string[]
  /** First PDF saved; the search keeps collecting later PDFs for a short window after this. */
  foundAt?: string
  /** Linked account assigned by ENVIAR IMSS: only that inbox is checked for this trámite. */
  accountId?: string
}

export interface DocumentMeta {
  id: string
  name: string
  originalName: string
  size: number
  curp: string
  watchId: string
  source: 'attachment' | 'link' | 'portal'
  account: string
  subject: string
  receivedAt: string
  createdAt: string
  /** The file in DESCARGAR holding the bytes. Older records kept their own copy instead. */
  panelId?: string
  contentHash?: string
  /** Receiver: ids of every PDF already joined into this file (same CURP), so none is merged twice. */
  parts?: string[]
}

export const isWatchId = (id: string) => WATCH_ID.test(id)
export const isDocumentId = (id: string) => SAFE_ID.test(id)
export const isAccountId = (id: string) => SAFE_ID.test(id)

async function listAll(prefix: string) {
  const blobs: Awaited<ReturnType<typeof list>>['blobs'] = []
  let cursor: string | undefined
  do {
    const page = await list({ prefix, cursor, limit: 1000 })
    blobs.push(...page.blobs)
    cursor = page.hasMore ? page.cursor : undefined
  } while (cursor)
  return blobs
}

async function putJson(pathname: string, value: unknown) {
  await put(pathname, JSON.stringify(value), {
    access: 'private',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
  })
}

async function getJson<T>(pathname: string): Promise<T | null> {
  const result = await get(pathname, { access: 'private', useCache: false }).catch(() => null)
  if (!result || result.statusCode !== 200 || !result.stream) return null
  try {
    return JSON.parse(await new Response(result.stream).text()) as T
  } catch {
    return null
  }
}

async function readAllJson<T>(prefix: string): Promise<T[]> {
  const blobs = (await listAll(prefix)).filter((b) => b.pathname.endsWith('.json'))
  const items: (T | null)[] = await Promise.all(blobs.map((b) => getJson<T>(b.pathname)))
  return items.filter((item): item is T => item !== null)
}

/* Accounts */

export function toPublicAccount({ refresh: _refresh, ...account }: StoredAccount): PublicAccount {
  return account
}

export const listAccounts = () => readAllJson<StoredAccount>(`${ROOT}accounts/`)
export const getAccount = (id: string) => getJson<StoredAccount>(`${ROOT}accounts/${id}.json`)
export const saveAccount = (account: StoredAccount) => putJson(`${ROOT}accounts/${account.id}.json`, account)
export async function deleteAccount(id: string) {
  await del(`${ROOT}accounts/${id}.json`).catch(() => {})
}

/**
 * Permanent record of a used account removed from the list by the automatic cleanup.
 * Never deleted: it keeps that inbox from being assigned to a new trámite if it is linked again.
 */
export interface RetiredAccount {
  id: string
  address: string
  usedAt?: string
  completedAt: string
  retiredAt: string
  curps: string[]
}

export const listRetiredAccounts = () => readAllJson<RetiredAccount>(`${ROOT}retired/`)
export const saveRetiredAccount = (r: RetiredAccount) => putJson(`${ROOT}retired/${r.id}.json`, r)

/**
 * First confirmed reception of an IMSS trámite e-mail in an inbox, kept separately from the account record
 * so it survives the receiver's 2-hour history cleanup and a re-link of the account.
 */
export interface ConfirmedReceipt {
  id: string
  address: string
  confirmedAt: string
  recordedAt: string
}

export const listConfirmedReceipts = () => readAllJson<ConfirmedReceipt>(`${ROOT}confirmed/`)
export const saveConfirmedReceipt = (r: ConfirmedReceipt) => putJson(`${ROOT}confirmed/${r.id}.json`, r)

/* Watches */

export function newWatchId(now = Date.now()) {
  return `${now}-${randomBytes(6).toString('hex')}`
}

export const getWatch = (id: string) => getJson<Watch>(`${ROOT}watches/${id}.json`)
export const saveWatch = (watch: Watch) => putJson(`${ROOT}watches/${watch.id}.json`, watch)

export async function listWatches(): Promise<Watch[]> {
  const watches = await readAllJson<Watch>(`${ROOT}watches/`)
  return watches.sort((a, b) => b.submittedAt.localeCompare(a.submittedAt))
}

/** Deletes every watch that is no longer searching (found, expired or cancelled). PDFs in DESCARGAR stay. */
export async function deleteFinishedWatches(): Promise<number> {
  const finished = (await listWatches()).filter((w) => w.status !== 'waiting')
  if (finished.length) await del(finished.map((w) => `${ROOT}watches/${w.id}.json`))
  return finished.length
}

/* Documents */

function cleanName(name: string): string {
  // eslint-disable-next-line no-control-regex
  const base = (name.split(/[\\/]/).pop() ?? '').replace(/[\u0000-\u001f\u007f:*?"<>|]/g, '').trim()
  return base.slice(0, 160) || 'documento.pdf'
}

export async function listDocuments(): Promise<DocumentMeta[]> {
  const docs = await readAllJson<DocumentMeta>(`${ROOT}docs/`)
  return docs.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export const getDocument = (id: string) => getJson<DocumentMeta>(`${ROOT}docs/${id}.json`)

const SCAN_LOCK = `${ROOT}locks/receiver-scan.json`
/** Longer than the function limit (60 s), so a pass killed mid-way never blocks the next one for long. */
const SCAN_LOCK_STALE_MS = 75 * 1000

/**
 * Only one receiver pass at a time: two overlapping passes would both read the same e-mail and
 * both save its PDF to DESCARGAR. Blob refuses to create an existing path, which makes this atomic.
 */
export async function acquireScanLock(): Promise<string | null> {
  const token = randomBytes(8).toString('hex')
  const body = JSON.stringify({ token, at: Date.now() })
  const create = (allowOverwrite: boolean) =>
    put(SCAN_LOCK, body, { access: 'private', addRandomSuffix: false, allowOverwrite, contentType: 'application/json' })
  try {
    await create(false)
    return token
  } catch {
    const held = await getJson<{ token: string; at: number }>(SCAN_LOCK).catch(() => null)
    if (held && Date.now() - held.at < SCAN_LOCK_STALE_MS) return null
    await create(true)
    return token
  }
}

export async function releaseScanLock(token: string) {
  const held = await getJson<{ token: string }>(SCAN_LOCK).catch(() => null)
  if (held?.token === token) await del(SCAN_LOCK).catch(() => {})
}

/**
 * Idempotent per id: re-processing the same e-mail attachment never duplicates it.
 * The bytes live only in DESCARGAR; this record just links the PDF to its trámite.
 */
export async function saveDocument(
  meta: Omit<DocumentMeta, 'size' | 'createdAt' | 'panelId' | 'contentHash'>,
  bytes: Uint8Array,
) {
  const existing = await getDocument(meta.id)
  if (existing) return existing
  // The same PDF can arrive twice (captured from the portal and received by e-mail): keep one copy in DESCARGAR.
  const contentHash = createHash('sha256').update(bytes).digest('hex')
  const twin = (await listDocuments()).find((d) => d.contentHash === contentHash && d.panelId)
  if (twin) return twin
  const name = cleanName(meta.name)
  const panelId = await addToDownloads(name, bytes)
  const doc: DocumentMeta = {
    ...meta,
    name,
    panelId,
    contentHash,
    size: bytes.byteLength,
    createdAt: new Date().toISOString(),
  }
  await putJson(`${ROOT}docs/${meta.id}.json`, doc)
  return doc
}

export async function openDocumentFile(id: string) {
  const meta = await getDocument(id)
  if (meta?.panelId) {
    const file = await openOriginal(meta.panelId)
    return file?.stream ? { size: file.size, stream: file.stream } : null
  }
  const [blob] = await listAll(`${ROOT}files/${id}/`)
  if (!blob) return null
  const result = await get(blob.pathname, { access: 'private' })
  if (!result || result.statusCode !== 200 || !result.stream) return null
  return { size: blob.size, stream: result.stream }
}

export async function deleteDocument(id: string) {
  const blobs = await listAll(`${ROOT}files/${id}/`)
  await del([...blobs.map((b) => b.pathname), `${ROOT}docs/${id}.json`]).catch(() => {})
}

/* Receptor de documentos: one record, documents themselves live in DESCARGAR */

export interface ReceiverItem {
  id: string
  name: string
  receivedAt: string
  /** listo: name + CURP read and message generated, same as SUBIR. sin_datos: kept in DESCARGAR for review. */
  /** enlace: IMSS link opened, waiting for the PDF. abrir: IMSS refuses server requests, the user opens `link`. */
  /** mensaje: the opened link showed a message instead of documents (shown in `message`). */
  /** accion: the opened page needs a manual step (CAPTCHA/verification); the automatic flow stopped there. */
  status: 'listo' | 'sin_datos' | 'enlace' | 'abrir' | 'mensaje' | 'accion'
  link?: string
  /** Outlook address the e-mail arrived at (cards with a link). */
  account?: string
  /** DESCARGAR file id of a received PDF, for the card's DESCARGAR PDF button. */
  panelId?: string
  message?: string
  /** Set once anyone entered the link successfully; shared by every user and never cleared. */
  attendedAt?: string
  }

export interface ReceiverState {
  since: string
  lastCheckAt?: string
  received: number
  processed: string[]
  items: ReceiverItem[]
  note?: string
  /** Card ids removed from the receiver (only the cards; Outlook mail and DESCARGAR files stay). */
  deleted?: string[]
  /** Last automatic clean-up of the receiver history (every 2 h). */
  historyClearedAt?: string
  /** Last sweep that joined stored PDFs of the same CURP. */
  duplicatesCheckedAt?: string
  /** Timings of the last pass, to spot bottlenecks. */
  metrics?: {
    at: string
    accounts: number
    messages: number
    pdfs: number
    mailboxesMs: number
    totalMs: number
    maxMailToDownloadMs?: number
    pending?: boolean
  }
}

export const getReceiverState = () => getJson<ReceiverState>(`${ROOT}receiver.json`)
export const saveReceiverState = (state: ReceiverState) => putJson(`${ROOT}receiver.json`, state)

/* ENVIAR IMSS: each trámite takes one linked account from LECTURA DE CORREOS DEL IMSS */

/** Kept apart from the account record, which the receiver and token refresh rewrite. */
export interface AccountAssignment {
  accountId: string
  address: string
  curp: string
  token: string
  at: string
  committed: boolean
  completedAt?: string
  watchId?: string
}

export interface AssignmentReservation {
  accountId: string
  token: string
  email: string
}

/** An unsubmitted reservation older than this is treated as abandoned. */
const ASSIGNMENT_TTL_MS = 30 * 60 * 1000

const assignmentPath = (accountId: string) => `${ROOT}assignments/${accountId}.json`
export const getAssignment = (accountId: string) => getJson<AccountAssignment>(assignmentPath(accountId))
export const listAssignments = () => readAllJson<AccountAssignment>(`${ROOT}assignments/`)
const saveAssignment = (a: AccountAssignment) => putJson(assignmentPath(a.accountId), a)

function isLive(a: AccountAssignment, now: number) {
  return a.committed || now - Date.parse(a.at) <= ASSIGNMENT_TTL_MS
}

/** Picks the oldest linked account that never received IMSS mail and isn't tied to another trámite. */
export async function reserveLinkedAccount(curp: string): Promise<AssignmentReservation | null> {
  const now = Date.now()
  const [accounts, assignments, watches, retired] = await Promise.all([
    listAccounts(),
    listAssignments(),
    listWatches(),
    listRetiredAccounts().catch(() => [] as RetiredAccount[]),
  ])
  const taken = new Set(assignments.filter((a) => isLive(a, now)).map((a) => a.accountId))
  const watched = new Set(watches.map((w) => w.email.toLowerCase()))
  const retiredKeys = new Set(retired.flatMap((r) => [r.id, r.address.toLowerCase()]))
  const candidates = accounts
    .filter(
      (a) =>
        a.status === 'ok' &&
        !a.usedAt &&
        !taken.has(a.id) &&
        !watched.has(a.address.toLowerCase()) &&
        !retiredKeys.has(a.id) &&
        !retiredKeys.has(a.address.toLowerCase()),
    )
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt))

  for (const account of candidates) {
    const token = randomBytes(16).toString('hex')
    await saveAssignment({ accountId: account.id, address: account.address, curp, token, at: new Date().toISOString(), committed: false })
    // Blob has no transactions: re-read so two simultaneous trámites never share an account.
    const check = await getAssignment(account.id)
    if (check?.token === token) return { accountId: account.id, token, email: account.address }
  }
  return null
}

/** The trámite failed before reaching the IMSS: the account goes back to the list. */
export async function releaseLinkedAccount(accountId: string, token: string): Promise<boolean> {
  const a = await getAssignment(accountId)
  if (!a || a.token !== token || a.committed) return false
  await del(assignmentPath(accountId)).catch(() => {})
  return true
}

/** The IMSS accepted the form with this address: the account now belongs to that CURP for good. */
export async function completeLinkedAccount(accountId: string, token: string): Promise<AccountAssignment | null> {
  const a = await getAssignment(accountId)
  if (!a || a.token !== token) return null
  if (a.committed) return a
  const done: AccountAssignment = { ...a, committed: true, completedAt: new Date().toISOString() }
  await saveAssignment(done)
  return done
}

export async function linkAssignmentWatch(a: AccountAssignment, watchId: string) {
  await saveAssignment({ ...a, watchId })
}

/** Daily sweep: documents and finished watches older than the retention window. */
export async function deleteOldImssMail(now = Date.now()): Promise<number> {
  let removed = 0
  for (const doc of await listDocuments()) {
    if (now - new Date(doc.createdAt).getTime() > DOCUMENT_TTL_MS) {
      await deleteDocument(doc.id)
      removed++
    }
  }
  for (const watch of await listWatches()) {
    if (watch.status !== 'waiting' && now - new Date(watch.submittedAt).getTime() > DOCUMENT_TTL_MS) {
      await del(`${ROOT}watches/${watch.id}.json`).catch(() => {})
    }
  }
  return removed
}
