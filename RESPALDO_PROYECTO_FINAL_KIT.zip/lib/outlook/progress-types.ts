export type StepState = 'pending' | 'active' | 'done' | 'failed' | 'skipped'

export type WatchStage =
  | 'no_accounts'
  | 'searching'
  | 'mail_found'
  | 'portal_failed'
  | 'waiting_attachments'
  | 'saving'
  | 'collecting'
  | 'completed'
  | 'expired'
  | 'cancelled'

export interface WatchProgress {
  stage: WatchStage
  accounts: number
  accountErrors: { address: string; error: string }[]
  steps: { outlook: StepState; mail: StepState; link: StepState; portal: StepState; downloads: StepState }
  /** Only documents present in DESCARGAR right now. */
  documents: { id: string; name: string; panelId: string; source: 'attachment' | 'link' | 'portal' }[]
}

export const STEP_LABELS: [keyof WatchProgress['steps'], string][] = [
  ['outlook', 'Acceso a Outlook'],
  ['mail', 'Correo del IMSS encontrado'],
  ['link', 'Liga detectada'],
  ['portal', 'Acceso al portal del IMSS'],
  ['downloads', 'PDF en DESCARGAR'],
]

export const STAGE_TEXT: Record<WatchStage, { title: string; note: string }> = {
  no_accounts: { title: 'SIN CUENTAS OUTLOOK', note: 'Vincula una cuenta en CUENTAS OUTLOOK o sube el PDF desde SUBIR.' },
  searching: { title: 'BUSCANDO CORREO DEL IMSS', note: 'Revisando las cuentas Outlook vinculadas.' },
  mail_found: { title: 'CORREO ENCONTRADO', note: 'Llegó un correo del IMSS sin PDF; esperando el siguiente correo.' },
  portal_failed: { title: 'LA LIGA NO RESPONDIÓ', note: 'Buscando los PDF enviados como adjuntos en Outlook.' },
  waiting_attachments: { title: 'BUSCANDO ADJUNTOS', note: 'La liga no entregó el PDF; buscando los PDF adjuntos en correos posteriores.' },
  saving: { title: 'GUARDANDO EN DESCARGAR', note: 'PDF descargado; guardándolo en DESCARGAR.' },
  collecting: { title: 'COMPLETADO', note: 'PDF en DESCARGAR. Se siguen buscando más documentos del IMSS unos minutos.' },
  completed: { title: 'COMPLETADO', note: 'Todos los PDF encontrados están en DESCARGAR.' },
  expired: { title: 'NO LLEGÓ EL PDF', note: 'Pasaron 24 horas sin recibir el PDF. Puedes subirlo desde SUBIR.' },
  cancelled: { title: 'BÚSQUEDA CANCELADA', note: 'Puedes subir el PDF desde SUBIR.' },
}
