import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'

function derive(label: string, secret: string): Buffer {
  return createHash('sha256').update(`tramix:${label}:${secret}`).digest()
}

/** AES-256-GCM. Output: base64url(iv | tag | ciphertext). */
export function seal(plain: string, label: string, secret: string): string {
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', derive(label, secret), iv)
  const body = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()])
  return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64url')
}

export function unseal(sealed: string, label: string, secret: string): string | null {
  try {
    const raw = Buffer.from(sealed, 'base64url')
    const decipher = createDecipheriv('aes-256-gcm', derive(label, secret), raw.subarray(0, 12))
    decipher.setAuthTag(raw.subarray(12, 28))
    return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8')
  } catch {
    return null
  }
}

function mac(payload: string, label: string, secret: string): string {
  return createHmac('sha256', derive(label, secret)).update(payload).digest('base64url')
}

export function sign(payload: string, label: string, secret: string): string {
  return `${payload}.${mac(payload, label, secret)}`
}

/** Returns the payload when the signature matches. */
export function verifySigned(token: string, label: string, secret: string): string | null {
  const dot = token.lastIndexOf('.')
  if (dot <= 0) return null
  const payload = token.slice(0, dot)
  return safeEqual(token.slice(dot + 1), mac(payload, label, secret)) ? payload : null
}

export function safeEqual(a: string, b: string): boolean {
  const left = createHash('sha256').update(a).digest()
  const right = createHash('sha256').update(b).digest()
  return timingSafeEqual(left, right) && a.length === b.length
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString('base64url')
}

export function pkceChallenge(verifier: string): string {
  return createHash('sha256').update(verifier).digest('base64url')
}

export function shortHash(value: string, length = 20): string {
  return createHash('sha256').update(value).digest('hex').slice(0, length)
}
