import {
  getReceiverState,
  listAccounts,
  listConfirmedReceipts,
  listRetiredAccounts,
  listWatches,
  saveConfirmedReceipt,
  saveRetiredAccount,
  type ConfirmedReceipt,
  type RetiredAccount,
  type StoredAccount,
  type Watch,
} from './store'
import { decide, type Evidence, type KeepReason } from './retire-rule'

export { RETIRE_AFTER_MS, decide, confirmedReceiptAt } from './retire-rule'

export interface Snapshot extends Evidence {
  accounts: StoredAccount[]
  retired: RetiredAccount[]
}

export async function loadSnapshot(): Promise<Snapshot> {
  const [accounts, receiver, watches, receipts, retired] = await Promise.all([
    listAccounts(),
    getReceiverState().catch(() => null),
    listWatches().catch(() => [] as Watch[]),
    listConfirmedReceipts().catch(() => [] as ConfirmedReceipt[]),
    listRetiredAccounts().catch(() => [] as RetiredAccount[]),
  ])
  return { accounts, receiver, watches, receipts, retired }
}

export interface RetireSummary {
  checked: number
  retired: number
  alreadyRetired: number
  kept: Partial<Record<KeepReason, number>>
  /** Ids no longer shown in LECTURA DE CORREOS DEL IMSS (retired now or earlier). */
  hiddenIds: string[]
}

/**
 * Hides accounts from LECTURA DE CORREOS DEL IMSS one hour after their first confirmed IMSS trámite e-mail.
 * Only a persisted `retired/` record is written: the account record, its Outlook link, Cuentas Outlook,
 * Outlook mail, DESCARGAR files and receiver history are left untouched.
 */
export async function retireUsedAccounts(
  options: { dryRun?: boolean; now?: number; snapshot?: Snapshot } = {},
): Promise<RetireSummary> {
  const now = options.now ?? Date.now()
  const snap = options.snapshot ?? (await loadSnapshot())
  const retiredIds = new Set(snap.retired.map((r) => r.id))
  const summary: RetireSummary = { checked: snap.accounts.length, retired: 0, alreadyRetired: 0, kept: {}, hiddenIds: [] }

  for (const account of snap.accounts) {
    if (retiredIds.has(account.id)) {
      summary.alreadyRetired++
      summary.hiddenIds.push(account.id)
      continue
    }
    const decision = decide(account, snap, now)

    if (decision.confirmedAt && !options.dryRun && !snap.receipts.some((r) => r.id === account.id)) {
      const receipt = {
        id: account.id,
        address: account.address,
        confirmedAt: decision.confirmedAt,
        recordedAt: new Date(now).toISOString(),
      }
      await saveConfirmedReceipt(receipt).catch((error) => console.error('[imss-mail] receipt save failed', error))
      snap.receipts.push(receipt)
    }

    if (!decision.retire) {
      summary.kept[decision.reason] = (summary.kept[decision.reason] ?? 0) + 1
      continue
    }
    summary.retired++
    summary.hiddenIds.push(account.id)
    if (options.dryRun) continue
    const record: RetiredAccount = {
      id: account.id,
      address: account.address,
      usedAt: account.usedAt,
      completedAt: decision.confirmedAt,
      retiredAt: new Date(now).toISOString(),
      curps: [],
    }
    await saveRetiredAccount(record)
    snap.retired.push(record)
    retiredIds.add(account.id)
  }
  return summary
}
