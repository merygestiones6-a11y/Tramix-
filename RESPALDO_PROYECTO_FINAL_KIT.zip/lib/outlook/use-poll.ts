'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

interface PollOptions<T> {
  refreshInterval?: number | ((latest: T | undefined) => number)
  onError?: (error: unknown) => void
}

/** Minimal SWR-style hook: fetch by key, optional polling, pauses while the tab is hidden. */
export function usePoll<T>(key: string | null, fetcher: (key: string) => Promise<T>, options: PollOptions<T> = {}) {
  const [data, setData] = useState<T | undefined>(undefined)
  const [isValidating, setValidating] = useState(false)
  const latest = useRef({ fetcher, options, data })
  latest.current = { fetcher, options, data }

  const mutate = useCallback(async () => {
    if (!key) return
    setValidating(true)
    try {
      const next = await latest.current.fetcher(key)
      latest.current.data = next
      setData(next)
    } catch (error) {
      latest.current.options.onError?.(error)
    } finally {
      setValidating(false)
    }
  }, [key])

  useEffect(() => {
    if (!key) return
    let timer: ReturnType<typeof setTimeout> | undefined
    let cancelled = false
    const loop = async () => {
      if (document.visibilityState !== 'hidden') await mutate()
      if (cancelled) return
      const { refreshInterval } = latest.current.options
      const ms = typeof refreshInterval === 'function' ? refreshInterval(latest.current.data) : (refreshInterval ?? 0)
      if (ms > 0) timer = setTimeout(loop, ms)
    }
    void loop()
    const onVisible = () => document.visibilityState === 'visible' && void mutate()
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      cancelled = true
      clearTimeout(timer)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [key, mutate])

  return { data, mutate, isValidating }
}
