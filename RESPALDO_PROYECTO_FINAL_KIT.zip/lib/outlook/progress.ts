import 'server-only'
import { listActiveFiles } from '@/lib/panel/store'
import { isCollecting } from './imss-mail'
import { type StoredAccount, type Watch, getDocument } from './store'
import type { StepState, WatchProgress } from './progress-types'

/** Panel ids of the files currently in DESCARGAR, read once per request. */
export async function activeDownloadIds(): Promise<Set<string>> {
  return new Set((await listActiveFiles()).map((f) => f.id))
}

/**
 * What really happened for one trámite, step by step. COMPLETADO only when the PDF
 * is present in DESCARGAR right now, not merely when an e-mail was seen.
 */
export async function watchProgress(watch: Watch, accounts: StoredAccount[], downloads: Set<string>): Promise<WatchProgress> {
  const linked = accounts.filter((a) => a.status === 'ok')
  const reachable = linked.filter((a) => a.lastCheckAt && !a.lastError)
  const imss = watch.messages.filter((m) => m.result !== 'other_curp')
  const results = new Set(imss.map((m) => m.result))
  const linkSeen = results.has('link_pdf') || results.has('link_opened') || results.has('link_failed')
  const portalOpened = results.has('link_pdf') || results.has('link_opened')
  const portalPdf = results.has('link_pdf')
  const attachmentPdf = results.has('pdf')

  const docs = (await Promise.all(watch.documentIds.map(getDocument))).filter((d) => d !== null)
  const available = docs.filter((d) => d.panelId && downloads.has(d.panelId))
  const finished = watch.status === 'expired' || watch.status === 'cancelled'
  const active = (cond: boolean): StepState => (finished ? 'failed' : cond ? 'active' : 'pending')

  const outlook: StepState = !linked.length ? 'failed' : reachable.length ? 'done' : linked.some((a) => a.lastError) ? 'failed' : active(true)
  const mail: StepState = imss.length ? 'done' : active(outlook === 'done')
  const link: StepState = linkSeen ? 'done' : attachmentPdf ? 'skipped' : imss.length ? active(true) : 'pending'
  const portal: StepState = portalPdf ? 'done' : portalOpened ? 'done' : results.has('link_failed') ? 'failed' : attachmentPdf ? 'skipped' : 'pending'
  const downloadsStep: StepState = available.length ? 'done' : docs.length ? 'active' : active(imss.length > 0)

  const stage: WatchProgress['stage'] = available.length
    ? isCollecting(watch) ? 'collecting' : 'completed'
    : watch.status === 'cancelled'
      ? 'cancelled'
      : watch.status === 'expired'
        ? 'expired'
        : !linked.length
          ? 'no_accounts'
          : docs.length
            ? 'saving'
            : portalOpened && !portalPdf
              ? 'waiting_attachments'
              : results.has('link_failed')
                ? 'portal_failed'
                : imss.length
                  ? 'mail_found'
                  : 'searching'

  return {
    stage,
    accounts: linked.length,
    accountErrors: linked.filter((a) => a.lastError).map((a) => ({ address: a.address, error: a.lastError as string })),
    steps: { outlook, mail, link, portal, downloads: downloadsStep },
    documents: available.map((d) => ({ id: d.id, name: d.name, panelId: d.panelId as string, source: d.source })),
  }
}
