import { createHash } from 'node:crypto'
import { detectPersonalData } from '@/lib/extract'
import { extractDocumentText } from '@/lib/panel/extract-text'
import { buildMessageFromText } from '@/lib/panel/message-from-text'
import { PDFDocument } from 'pdf-lib'
import { mergePdfs } from '@/lib/pdf/merge'
import { shortHash } from './crypto'
import { GraphAuthError, accessTokenFor, downloadAttachment, listMessagesSince, listPdfAttachments } from './graph'
import { documentName, extractImssLinks, htmlToText, isImssAddress, isImssUrl } from './imss-mail'
import {
  type ReceiverItem,
  type ReceiverState,
  type StoredAccount,
  acquireScanLock,
  deleteDocument,
  getReceiverState,
  listAccounts,
  listDocuments,
  openDocumentFile,
  releaseScanLock,
  saveAccount,
  saveDocument,
  saveReceiverState,
} from './store'
import { deleteUpload } from '@/lib/panel/store'

const RECEIVER_ID = 'receptor'
const MIN_CHECK_GAP_MS = 15 * 1000
/** ACTUALIZAR RECEPTOR skips the normal gap; this floor only stops repeated taps from piling up passes. */
const FORCED_CHECK_GAP_MS = 3 * 1000
const HISTORY_CLEAR_MS = 2 * 60 * 60 * 1000
const LOOKBACK_MS = 24 * 60 * 60 * 1000
const FIRST_LOOKBACK_MS = LOOKBACK_MS
/** Bumped when the reading rules change, so e-mails skipped by the old rules are read again. */
const PROCESSED_VERSION = 'v3'
const MAX_MESSAGES_PER_PASS = 40
const ACCOUNT_CONCURRENCY = 32
const ATTACHMENT_CONCURRENCY = 4
/** An unchanged account record is rewritten at most this often (it only refreshes "última revisión"). */
const ACCOUNT_SAVE_GAP_MS = 5 * 60 * 1000
/** The repair sweep over every stored document runs after a pass that saved PDFs, or at most this often. */
const DUPLICATE_SWEEP_GAP_MS = 10 * 60 * 1000
/** No new e-mail is started after this point, so a pass always ends well inside the 60 s function limit. */
const PASS_TIME_BUDGET_MS = 40 * 1000

async function forEachLimited<T>(list: T[], limit: number, run: (item: T) => Promise<void>) {
  let next = 0
  const worker = async () => {
    while (next < list.length) await run(list[next++])
  }
  await Promise.all(Array.from({ length: Math.min(limit, list.length) }, worker))
}
const MAX_PDF_BYTES = 15 * 1024 * 1024
const KEEP_PROCESSED = 1000
const KEEP_ITEMS = 100

function looksLikePdf(bytes: Uint8Array) {
  return bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46
}

/** Same reading SUBIR/DESCARGAR use: name + CURP detected and the delivery message buildable. */
async function readPdf(bytes: Uint8Array): Promise<{ curp: string | null; ready: boolean }> {
  try {
    const result = await extractDocumentText('documento.pdf', 'application/pdf', bytes)
    if (result.status !== 'ready') return { curp: null, ready: false }
    return { curp: detectPersonalData([result.text]).curp ?? null, ready: buildMessageFromText(result.text) !== null }
  } catch {
    return { curp: null, ready: false }
  }
}

/**
 * Joins the PDFs of one trámite and proves the result is complete before anything is published:
 * every part must open with pages, and the joined file must hold exactly all of their pages.
 * A failure throws, so the e-mail stays unprocessed and the next pass retries it.
 */
async function mergeVerified(parts: Uint8Array[]): Promise<Uint8Array> {
  let expected = 0
  for (const part of parts) {
    const pages = (await PDFDocument.load(part, { ignoreEncryption: true })).getPageCount()
    if (pages < 1) throw new Error('merge-part-empty')
    expected += pages
  }
  const merged = await mergePdfs(parts)
  const actual = (await PDFDocument.load(merged, { ignoreEncryption: true })).getPageCount()
  if (actual !== expected) throw new Error(`merge-incomplete ${actual}/${expected}`)
  return merged
}

interface Source {
  account: StoredAccount
  messageId: string
  subject: string
  receivedAt: string
  taken: Set<string>
}

interface PdfOrigin {
  /** Stable key: the same PDF always gets the same id, so it is never saved twice. */
  key: string
  address: string
  subject: string
  receivedAt: string
  taken: Set<string>
}

/**
 * A second PDF of the same CURP is joined to the file already in DESCARGAR: one CURP = one file.
 * The earlier file is replaced through DESCARGAR's own delete, and the merged PDF is read again with SUBIR.
 */
async function joinSameCurp(curp: string, partId: string, bytes: Uint8Array): Promise<ReceiverItem | null> {
  const twin = (await listDocuments()).find(
    (d) => d.watchId === RECEIVER_ID && d.curp === curp && d.panelId && d.id !== partId,
  )
  if (!twin?.panelId) return null
  const hash = createHash('sha256').update(bytes).digest('hex')
  if (twin.parts?.includes(partId) || twin.contentHash === hash) {
    return { id: twin.id, name: twin.name, receivedAt: twin.receivedAt, status: 'listo', account: twin.account || undefined, panelId: twin.panelId }
  }
  const file = await openDocumentFile(twin.id)
  const previous = file ? new Uint8Array(await new Response(file.stream).arrayBuffer()) : null
  if (!previous || !looksLikePdf(previous)) return null

  const merged = await mergeVerified([previous, bytes])
  const { ready } = await readPdf(merged)
  await deleteUpload(twin.panelId)
  await deleteDocument(twin.id)
  const doc = await saveDocument(
    {
      id: twin.id,
      name: twin.name,
      originalName: twin.originalName,
      curp,
      watchId: RECEIVER_ID,
      source: twin.source,
      account: twin.account,
      subject: twin.subject,
      receivedAt: twin.receivedAt,
      parts: [...(twin.parts ?? [twin.id]), partId],
    },
    merged,
  )
  return {
    id: doc.id,
    name: doc.name,
    receivedAt: twin.receivedAt,
    status: ready ? 'listo' : 'sin_datos',
    account: doc.account || undefined,
    panelId: doc.panelId,
  }
}

async function receivePdf(
  origin: PdfOrigin,
  original: string | null,
  bytes: Uint8Array,
  kind: 'attachment' | 'link',
  alreadyRead?: { curp: string | null; ready: boolean },
) {
  const { curp, ready } = alreadyRead ?? (await readPdf(bytes))
  if (curp) {
    const joined = await joinSameCurp(curp, shortHash(origin.key, 24), bytes)
    if (joined) return joined
  }
  const fallback = original?.trim() || 'documento.pdf'
  const name = curp ? documentName(original, curp, origin.taken) : fallback
  const doc = await saveDocument(
    {
      id: shortHash(origin.key, 24),
      name,
      originalName: fallback,
      curp: curp ?? '',
      watchId: RECEIVER_ID,
      source: kind,
      account: origin.address,
      subject: origin.subject,
      receivedAt: origin.receivedAt,
      parts: [shortHash(origin.key, 24)],
    },
    bytes,
  )
  const item: ReceiverItem = {
    id: doc.id,
    name: doc.name,
    receivedAt: origin.receivedAt,
    status: ready ? 'listo' : 'sin_datos',
    account: doc.account || origin.address || undefined,
    panelId: doc.panelId,
  }
  return item
}

const NSS_LINK_TEXT = /solicitud\s+de\s+asignaci[oó]n\s+o\s+localizaci[oó]n\s+de\s+nss/i

function isTrackingUrl(value: string) {
  try {
    const url = new URL(value)
    return url.protocol === 'https:' && url.hostname.endsWith('.sendgrid.net')
  } catch {
    return false
  }
}

function anchorText(inner: string) {
  return htmlToText(inner).replace(/\s+/g, ' ').trim()
}

/** IMSS links of the e-mail; the "Solicitud de Asignación o Localización de NSS" anchor goes first. */
function messageLinks(html: string): string[] {
  const named: string[] = []
  const others: string[] = []
  for (const match of html.matchAll(/<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
    const href = match[1].replace(/&amp;/gi, '&').trim()
    if (!isImssUrl(href) && !isTrackingUrl(href)) continue
    ;(NSS_LINK_TEXT.test(anchorText(match[2])) ? named : others).push(href)
  }
  return [...new Set([...named, ...others, ...extractImssLinks(html)])]
}

interface MessageOutcome {
  items: ReceiverItem[]
  /** The e-mail was read to the end; otherwise the next pass retries it. */
  done: boolean
}

/**
 * Every PDF attachment of one e-mail is saved through the SUBIR reading into DESCARGAR.
 * Without attachments, the exact link of the e-mail is handed to the user ("ABRIR ENLACE"):
 * the server never requests the IMSS site, so no 403/CAPTCHA/block is touched.
 * The documents IMSS sends afterwards arrive in a later e-mail, which the next pass reads.
 */
async function handleMessage(src: Source, token: string, html: string, hasAttachments: boolean): Promise<MessageOutcome> {
  const items: ReceiverItem[] = []
  if (hasAttachments) {
    // PDFs of the same CURP in one e-mail are joined here, in memory, before anything is saved:
    // the stored-file listing can lag right after a save, so it can't be relied on to find the first one.
    const groups = new Map<
      string,
      { origin: PdfOrigin; name: string | null; parts: Uint8Array[]; hashes: Set<string>; read: { curp: string | null; ready: boolean } }
    >()
    const attachments = (await listPdfAttachments(token, src.messageId)).filter((a) => a.size <= MAX_PDF_BYTES)
    // Download + read run in parallel; grouping below keeps the original attachment order.
    const fetched: ({ bytes: Uint8Array; read: { curp: string | null; ready: boolean } } | null)[] = new Array(attachments.length).fill(null)
    let cursor = 0
    await forEachLimited(attachments, ATTACHMENT_CONCURRENCY, async (attachment) => {
      const index = cursor++
      const bytes = await downloadAttachment(token, src.messageId, attachment.id)
      if (!looksLikePdf(bytes)) return
      fetched[index] = { bytes, read: await readPdf(bytes) }
    })
    attachments.forEach((attachment, index) => {
      const entry = fetched[index]
      if (!entry) return
      const { bytes, read } = entry
      // Same id formula as the IMSS trámite search, so a PDF already captured there is never duplicated.
      const origin = {
        key: `${src.account.id}:${src.messageId}:${attachment.id}`,
        address: src.account.address,
        subject: src.subject,
        receivedAt: src.receivedAt,
        taken: src.taken,
      }
      const hash = createHash('sha256').update(bytes).digest('hex')
      const group = groups.get(read.curp ?? origin.key)
      if (group) {
        if (!group.hashes.has(hash)) group.parts.push(bytes)
        group.hashes.add(hash)
        return
      }
      groups.set(read.curp ?? origin.key, { origin, name: attachment.name, parts: [bytes], hashes: new Set([hash]), read })
    })
    for (const group of groups.values()) {
      const merged = group.parts.length > 1
      const bytes = merged ? await mergeVerified(group.parts) : group.parts[0]
      // A single PDF was already read; a merged one is read again, as before.
      items.push(await receivePdf(group.origin, group.name, bytes, 'attachment', merged ? undefined : group.read))
    }
  }
  if (items.length) return { items, done: true }

  const link = messageLinks(html)[0]
  if (!link) return { items, done: true }
  return {
    items: [
      {
        id: shortHash(`mail:${src.account.id}:${src.messageId}`, 24),
        name: src.subject || 'Correo IMSS',
        receivedAt: src.receivedAt,
        status: 'abrir',
        link,
        account: src.account.address,
      },
    ],
    done: true,
  }
}

function freshState(now: number): ReceiverState {
  return { since: new Date(now - FIRST_LOOKBACK_MS).toISOString(), received: 0, processed: [], items: [] }
}

export async function readReceiver(): Promise<ReceiverState> {
  const state = (await getReceiverState()) ?? freshState(Date.now())
  // Cards saved before the sender/download fields existed get them from the stored document (read-only).
  if (state.items.some((i) => (i.status === 'listo' || i.status === 'sin_datos') && (!i.panelId || !i.account))) {
    const docs = new Map((await listDocuments()).map((d) => [d.id, d]))
    state.items = state.items.map((i) => {
      const doc = docs.get(i.id)
      return doc ? { ...i, account: i.account || doc.account || undefined, panelId: i.panelId || doc.panelId } : i
    })
  }
  // Saved globally so every user and device sees the link as attended from now on.
  if (attendByDelivery(state.items)) {
    const latest = await getReceiverState()
    if (latest) {
      const marks = new Map(state.items.filter((i) => i.attendedAt).map((i) => [i.id, i.attendedAt]))
      for (const item of latest.items) item.attendedAt ??= marks.get(item.id)
      await saveReceiverState(latest)
    }
  }
  return state
}

/** One pass over every linked Outlook account. Safe to repeat: messages and PDFs are keyed. */
export async function scanReceiver({ force = false }: { force?: boolean } = {}): Promise<ReceiverState> {
  const now = Date.now()
  const state = (await getReceiverState()) ?? freshState(now)
  const gap = force ? FORCED_CHECK_GAP_MS : MIN_CHECK_GAP_MS
  if (state.lastCheckAt && now - new Date(state.lastCheckAt).getTime() < gap) return state

  // Another pass (cron, RECEPTOR or DESCARGAR) is already reading the inboxes: its results show up in the next read.
  const lock = await acquireScanLock()
  if (!lock) return state
  try {
    return await runPass(now, state)
  } finally {
    await releaseScanLock(lock)
  }
}

async function runPass(now: number, state: ReceiverState): Promise<ReceiverState> {
  const accounts = (await listAccounts()).filter((a) => a.status === 'ok')
  state.note = accounts.length ? undefined : 'No hay cuentas Outlook vinculadas.'
  const processed = new Set(state.processed)
  // A fixed window instead of "since last check": e-mails left pending are retried, and the keyed set avoids repeats.
  const from = new Date(now - LOOKBACK_MS).toISOString()
  const taken = new Set(state.items.map((i) => i.name.toLowerCase()))
  let budget = MAX_MESSAGES_PER_PASS
  let pending = false
  const metrics: NonNullable<ReceiverState['metrics']> = {
    at: new Date(now).toISOString(),
    accounts: accounts.length,
    messages: 0,
    pdfs: 0,
    mailboxesMs: 0,
    totalMs: 0,
  }

  const checkAccount = async (account: (typeof accounts)[number]) => {
    const before = { usedAt: account.usedAt, lastError: account.lastError, lastCheckAt: account.lastCheckAt }
    try {
      const token = await accessTokenFor(account)
      const messages = (await listMessagesSince(token, from)).filter((m) => isImssAddress(m.from?.emailAddress?.address))
      if (messages.length && !account.usedAt) account.usedAt = new Date().toISOString()
      for (const message of messages.reverse()) {
        const key = `${PROCESSED_VERSION}:${account.id}:${message.id}`
        if (processed.has(key)) continue
        if (budget-- <= 0 || Date.now() - now > PASS_TIME_BUDGET_MS) {
          pending = true
          break
        }
        try {
          metrics.messages++
          const { items, done } = await handleMessage(
            {
              account,
              messageId: message.id,
              subject: message.subject ?? '',
              receivedAt: message.receivedDateTime,
              taken,
            },
            token,
            message.body?.content ?? '',
            Boolean(message.hasAttachments),
          )
          for (const item of items) {
            const existing = state.items.findIndex((i) => i.id === item.id)
            if (existing >= 0) {
              // An e-mail read by older rules ("enlace") is upgraded to its ABRIR ENLACE card; PDFs never repeat.
              if (item.status === 'abrir' && state.items[existing].status === 'enlace') state.items[existing] = item
              continue
            }
            state.items.unshift(item)
            if (item.status === 'listo' || item.status === 'sin_datos') {
              metrics.pdfs++
              const latency = Date.now() - new Date(item.receivedAt).getTime()
              if (Number.isFinite(latency)) metrics.maxMailToDownloadMs = Math.max(metrics.maxMailToDownloadMs ?? 0, latency)
            }
          }
          if (done) processed.add(key)
        } catch (error) {
          // Left unprocessed: the next pass retries this e-mail.
          console.error('[receiver] message failed', account.address, error)
        }
      }
      account.lastCheckAt = new Date().toISOString()
      account.lastError = undefined
      const lastSaved = before.lastCheckAt ? new Date(before.lastCheckAt).getTime() : NaN
      const changed = before.usedAt !== account.usedAt || before.lastError !== undefined
      if (changed || !(Date.now() - lastSaved < ACCOUNT_SAVE_GAP_MS)) await saveAccount(account)
    } catch (error) {
      const auth = error instanceof GraphAuthError
      console.error('[receiver] mailbox check failed', account.address, error)
      account.lastError = auth ? 'Vuelve a vincular esta cuenta.' : 'No se pudo revisar; se reintentará.'
      if (auth && /invalid_grant|interaction_required|token-unreadable/.test(error.message)) account.status = 'reconnect'
      await saveAccount(account).catch(() => {})
    }
  }
  // One account after another took over 2 min with 130+ accounts (504 at 60 s); a small fixed pool keeps it well under.
  await forEachLimited(accounts, ACCOUNT_CONCURRENCY, checkAccount)
  metrics.mailboxesMs = Date.now() - now
  metrics.pending = pending

  state.processed = [...processed].slice(-KEEP_PROCESSED)
  // PDFs/messages from an opened link may have been saved while this pass was reading the mailboxes.
  state.items = mergeItems(state.items, (await getReceiverState())?.items ?? [])
  const lastSweep = state.duplicatesCheckedAt ? new Date(state.duplicatesCheckedAt).getTime() : NaN
  if (metrics.pdfs > 0 || !(Date.now() - lastSweep < DUPLICATE_SWEEP_GAP_MS)) {
    await joinStoredDuplicates(state).catch((error) => console.error('[receiver] join duplicates failed', error))
    state.duplicatesCheckedAt = new Date().toISOString()
  }
  // With messages still pending, keep the window so the next pass picks them up.
  state.lastCheckAt = pending ? state.lastCheckAt : new Date().toISOString()
  clearHistoryIfDue(state)
  metrics.totalMs = Date.now() - now
  state.metrics = metrics
  await saveFinal(state)
  console.log('[receiver] pass', JSON.stringify(metrics))
  return state
}

/**
 * Receiver files of the same CURP already saved separately in DESCARGAR (e.g. "NSS_X.pdf" + "NSS_X_2.pdf")
 * are joined into ONE file: one CURP = one PDF and one card with a single download.
 * Skipped if any part can't be read, so nothing is deleted without its merged copy.
 */
async function joinStoredDuplicates(state: ReceiverState) {
  const groups = new Map<string, Awaited<ReturnType<typeof listDocuments>>>()
  for (const doc of await listDocuments()) {
    if (doc.watchId !== RECEIVER_ID || !doc.curp || !doc.panelId) continue
    // Same CURP from the same e-mail (account + receive time) = the same trámite.
    const key = `${doc.curp}|${doc.account}|${doc.receivedAt}`
    groups.set(key, [...(groups.get(key) ?? []), doc])
  }
  for (const docs of groups.values()) {
    if (docs.length < 2) continue
    const curp = docs[0].curp
    docs.sort((a, b) => a.receivedAt.localeCompare(b.receivedAt) || a.name.length - b.name.length)
    const parts: Uint8Array[] = []
    const hashes = new Set<string>()
    let complete = true
    for (const doc of docs) {
      const file = await openDocumentFile(doc.id)
      const bytes = file ? new Uint8Array(await new Response(file.stream).arrayBuffer()) : null
      if (!bytes || !looksLikePdf(bytes)) {
        complete = false
        break
      }
      const hash = createHash('sha256').update(bytes).digest('hex')
      if (!hashes.has(hash)) parts.push(bytes)
      hashes.add(hash)
    }
    if (!complete) continue

    const [keep, ...rest] = docs
    const merged = parts.length > 1 ? await mergeVerified(parts).catch(() => null) : parts[0]
    if (!merged) continue
    const { ready } = await readPdf(merged)
    await deleteUpload(keep.panelId!)
    await deleteDocument(keep.id)
    const saved = await saveDocument(
      {
        id: keep.id,
        name: keep.name,
        originalName: keep.originalName,
        curp,
        watchId: RECEIVER_ID,
        source: keep.source,
        account: keep.account,
        subject: keep.subject,
        receivedAt: keep.receivedAt,
        parts: [...new Set(docs.flatMap((d) => d.parts ?? [d.id]))],
      },
      merged,
    )
    // The extra files are removed only once the merged copy is confirmed saved.
    if (saved.contentHash !== createHash('sha256').update(merged).digest('hex')) continue
    for (const doc of rest) {
      await deleteUpload(doc.panelId!)
      await deleteDocument(doc.id)
    }

    const removed = new Set(rest.map((d) => d.id))
    state.deleted = [...new Set([...(state.deleted ?? []), ...removed])]
    state.items = state.items.filter((i) => !removed.has(i.id))
    const card = state.items.find((i) => i.id === keep.id)
    if (card) {
      card.name = saved.name
      card.panelId = saved.panelId
      card.status = ready ? 'listo' : 'sin_datos'
    }
  }
}

function mergeItems(mine: ReceiverItem[], latest: ReceiverItem[]): ReceiverItem[] {
  const byId = new Map(mine.map((i) => [i.id, i]))
  for (const item of latest) {
    const own = byId.get(item.id)
    if (!own) byId.set(item.id, item)
    else if (own.status === 'abrir' && (item.status === 'enlace' || item.status === 'mensaje' || item.status === 'accion'))
      byId.set(item.id, item)
    const kept = byId.get(item.id)
    const attendedAt = own?.attendedAt ?? item.attendedAt
    if (kept && attendedAt && !kept.attendedAt) byId.set(item.id, { ...kept, attendedAt })
  }
  return [...byId.values()].sort((a, b) => b.receivedAt.localeCompare(a.receivedAt))
}

const LINK_FAILURE =
  /\b(error|40[0-9]|50[0-9]|forbidden|not found|unavailable|timeout|tiempo de espera|no disponible|intente (m[aá]s tarde|nuevamente)|no se pudo|sin conexi[oó]n|captcha|verificaci[oó]n)\b/i

/**
 * A link e-mail whose account later delivered a PDF to DESCARGAR was entered successfully
 * (the IMSS only sends the documents after the link is used). Marks it once; never cleared.
 */
function attendByDelivery(items: ReceiverItem[]): boolean {
  let changed = false
  for (const card of items) {
    if (!card.link || card.attendedAt || !card.account) continue
    const delivered = items.find(
      (i) =>
        (i.status === 'listo' || i.status === 'sin_datos') &&
        i.account === card.account &&
        i.receivedAt >= card.receivedAt,
    )
    if (delivered) {
      card.attendedAt = delivered.receivedAt
      changed = true
    }
  }
  return changed
}

async function saveFinal(state: ReceiverState) {
  // A card deleted while this pass ran stays deleted: the list is shared and only ever grows.
  const latest = await getReceiverState()
  const deleted = new Set([...(state.deleted ?? []), ...(latest?.deleted ?? [])])
  state.deleted = [...deleted].slice(-KEEP_DELETED)
  attendByDelivery(state.items)
  state.items = state.items.filter((i) => !deleted.has(i.id)).slice(0, KEEP_ITEMS)
  // The counter only ever reflects PDFs that reached DESCARGAR, never e-mails still waiting on their link.
  state.received = state.items.filter((i) => i.status === 'listo' || i.status === 'sin_datos').length
  await saveReceiverState(state)
}

const KEEP_DELETED = 2000

/**
 * Every 2 h the receiver history is emptied by the same path as a manual delete: only the cards go.
 * The processed e-mail keys stay, so cleared e-mails are never read or downloaded again, and
 * Outlook accounts, Outlook mail and the PDFs in DESCARGAR are untouched.
 * Link e-mails still waiting to be attended are kept: they are trámites in progress, not history.
 */
function clearHistoryIfDue(state: ReceiverState) {
  const now = Date.now()
  const last = state.historyClearedAt ? new Date(state.historyClearedAt).getTime() : NaN
  if (!Number.isFinite(last)) {
    state.historyClearedAt = new Date(now).toISOString()
    return
  }
  if (now - last < HISTORY_CLEAR_MS) return
  const cleared = state.items.filter((i) => !(i.link && !i.attendedAt)).map((i) => i.id)
  state.deleted = [...new Set([...(state.deleted ?? []), ...cleared])]
  state.historyClearedAt = new Date(now).toISOString()
  console.log('[receiver] history cleared', cleared.length)
}

/** Removes receiver cards for every user. Never touches Outlook mail or the PDFs saved in DESCARGAR. */
export async function deleteReceiverItems(ids: string[]): Promise<ReceiverState> {
  const state = (await getReceiverState()) ?? freshState(Date.now())
  state.deleted = [...new Set([...(state.deleted ?? []), ...ids])]
  await saveFinal(state)
  return state
}

async function linkCard(cardId: string) {
  const state = await getReceiverState()
  const card = state?.items.find((i) => i.id === cardId && i.link)
  return state && card ? { state, card } : null
}

/**
 * The documents downloaded from the page of one IMSS e-mail link. They belong to the same trámite,
 * so they are joined into ONE PDF, read once with the SUBIR reading, and saved once in DESCARGAR.
 * Keyed by the trámite card: a trámite already received is never processed or saved again.
 */
export async function acceptLinkPdfs(cardId: string, files: { bytes: Uint8Array; name: string | null }[]) {
  const pdfs = files.filter((f) => looksLikePdf(f.bytes) && f.bytes.byteLength <= MAX_PDF_BYTES)
  if (!pdfs.length) return { error: 'not-pdf' as const }
  const found = await linkCard(cardId)
  if (!found) return { error: 'unknown-card' as const }
  const { state, card } = found
  const id = shortHash(`link:${cardId}`, 24)
  const existing = state.items.find((i) => i.id === id)
  if (card.status === 'enlace' && existing) return { item: existing }
  if (card.status === 'enlace' && state.deleted?.includes(id)) return { error: 'unknown-card' as const }

  // The same document fetched twice (link + download listener) is kept only once.
  const seen = new Set<string>()
  const unique = pdfs.filter((f) => {
    const hash = createHash('sha256').update(f.bytes).digest('hex')
    if (seen.has(hash)) return false
    seen.add(hash)
    return true
  })
  const bytes = unique.length > 1 ? await mergePdfs(unique.map((f) => f.bytes)) : unique[0].bytes
  const item = await receivePdf(
    {
      key: `link:${cardId}`,
      address: card.account ?? '',
      subject: card.name,
      receivedAt: card.receivedAt || new Date().toISOString(),
      taken: new Set(state.items.filter((i) => i.id !== id).map((i) => i.name.toLowerCase())),
    },
    unique[0].name,
    bytes,
    'link',
  )
  if (!state.items.some((i) => i.id === item.id)) state.items.unshift(item)
  card.status = 'enlace'
  card.message = undefined
  card.attendedAt ??= new Date().toISOString()
  await saveFinal(state)
  return { item }
}

/**
 * The opened page showed a message instead of documents → MENSAJE RECIBIDO card, not an error.
 * With `manual`, the page asked for a CAPTCHA/verification: the automatic flow stops and says so.
 */
export async function acceptLinkMessage(cardId: string, message: string, manual = false) {
  const found = await linkCard(cardId)
  if (!found) return { error: 'unknown-card' as const }
  const { state, card } = found
  // Documents already received from this link are never replaced by a later message.
  if (card.status !== 'enlace') {
    card.status = manual ? 'accion' : 'mensaje'
    card.message =
      message.replace(/\s+/g, ' ').trim().slice(0, 400) ||
      (manual ? 'El portal pide una verificación manual.' : 'La página no mostró documentos.')
  }
  // The portal answered with its own content (e.g. trámite bloqueado, acudir a subdelegación): the link was entered.
  // CAPTCHA/verification, empty pages and server/connection errors keep it pending.
  if (!manual && message.trim() && !LINK_FAILURE.test(message)) card.attendedAt ??= new Date().toISOString()
  await saveFinal(state)
  return { item: card }
}
