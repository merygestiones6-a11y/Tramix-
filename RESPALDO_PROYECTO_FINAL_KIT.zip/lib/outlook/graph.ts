import { GRAPH_SCOPES, microsoftConfig } from './config'
import { seal, unseal } from './crypto'
import { type StoredAccount, saveAccount } from './store'

const GRAPH = 'https://graph.microsoft.com/v1.0'
const TOKEN_LABEL = 'outlook-refresh'

export class GraphAuthError extends Error {}

function config() {
  const cfg = microsoftConfig()
  if (!cfg) throw new GraphAuthError('microsoft-not-configured')
  return cfg
}

interface TokenResponse {
  access_token: string
  refresh_token?: string
}

async function tokenRequest(params: Record<string, string>): Promise<TokenResponse> {
  const cfg = config()
  const res = await fetch(`https://login.microsoftonline.com/${cfg.tenant}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: cfg.clientId, client_secret: cfg.clientSecret, scope: GRAPH_SCOPES, ...params }),
    signal: AbortSignal.timeout(20_000),
  })
  const data = (await res.json().catch(() => ({}))) as Partial<TokenResponse> & {
    error?: string
    error_description?: string
  }
  if (!res.ok || !data.access_token) {
    console.error('[outlook] token request failed', res.status, data.error, data.error_description)
    throw new GraphAuthError(data.error ?? `token-${res.status}`)
  }
  return data as TokenResponse
}

export function authorizeUrl(params: { redirectUri: string; state: string; challenge: string }): string {
  const cfg = config()
  const url = new URL(`https://login.microsoftonline.com/${cfg.tenant}/oauth2/v2.0/authorize`)
  url.search = new URLSearchParams({
    client_id: cfg.clientId,
    response_type: 'code',
    redirect_uri: params.redirectUri,
    response_mode: 'query',
    scope: GRAPH_SCOPES,
    state: params.state,
    code_challenge: params.challenge,
    code_challenge_method: 'S256',
    prompt: 'select_account',
  }).toString()
  return url.toString()
}

export function exchangeCode(code: string, redirectUri: string, verifier: string) {
  return tokenRequest({ grant_type: 'authorization_code', code, redirect_uri: redirectUri, code_verifier: verifier })
}

export const sealRefreshToken = (token: string) => seal(token, TOKEN_LABEL, config().clientSecret)

/** Exchanges the stored refresh token and persists the rotated one Microsoft returns. */
export async function accessTokenFor(account: StoredAccount): Promise<string> {
  const refresh = unseal(account.refresh, TOKEN_LABEL, config().clientSecret)
  if (!refresh) throw new GraphAuthError('token-unreadable')
  const tokens = await tokenRequest({ grant_type: 'refresh_token', refresh_token: refresh })
  if (tokens.refresh_token && tokens.refresh_token !== refresh) {
    account.refresh = sealRefreshToken(tokens.refresh_token)
    account.updatedAt = new Date().toISOString()
    await saveAccount(account)
  }
  return tokens.access_token
}

async function graph<T>(token: string, path: string): Promise<T> {
  const res = await fetch(path.startsWith('https://') ? path : `${GRAPH}${path}`, {
    headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
    signal: AbortSignal.timeout(25_000),
  })
  if (res.status === 401) throw new GraphAuthError('graph-401')
  if (!res.ok) throw new Error(`graph-${res.status}`)
  return res.json() as Promise<T>
}

export interface GraphUser {
  id: string
  displayName?: string
  mail?: string | null
  userPrincipalName?: string
}

export const getMe = (token: string) => graph<GraphUser>(token, '/me?$select=id,displayName,mail,userPrincipalName')

export interface GraphMessage {
  id: string
  subject?: string
  receivedDateTime: string
  hasAttachments: boolean
  from?: { emailAddress?: { address?: string; name?: string } }
  toRecipients?: { emailAddress?: { address?: string } }[]
  body?: { contentType: string; content: string }
}

/** Every folder (Inbox, Junk, Clutter…) received since `sinceIso`, newest first. */
export async function listMessagesSince(token: string, sinceIso: string, maxPages = 4): Promise<GraphMessage[]> {
  const query = new URLSearchParams({
    $filter: `receivedDateTime ge ${sinceIso}`,
    $orderby: 'receivedDateTime desc',
    $top: '50',
    $select: 'id,subject,receivedDateTime,hasAttachments,from,toRecipients,body',
  })
  let next: string | undefined = `/me/messages?${query.toString()}`
  const messages: GraphMessage[] = []
  for (let page = 0; next && page < maxPages; page++) {
    const data: { value: GraphMessage[]; '@odata.nextLink'?: string } = await graph(token, next)
    messages.push(...data.value)
    next = data['@odata.nextLink']
  }
  return messages
}

export interface GraphAttachment {
  id: string
  name: string
  contentType?: string
  size: number
  isInline?: boolean
  '@odata.type'?: string
}

export async function listPdfAttachments(token: string, messageId: string): Promise<GraphAttachment[]> {
  const data = await graph<{ value: GraphAttachment[] }>(
    token,
    `/me/messages/${encodeURIComponent(messageId)}/attachments?$select=id,name,contentType,size,isInline`,
  )
  return data.value.filter(
    (a) =>
      a['@odata.type'] !== '#microsoft.graph.itemAttachment' &&
      a['@odata.type'] !== '#microsoft.graph.referenceAttachment' &&
      (/pdf/i.test(a.contentType ?? '') || /\.pdf$/i.test(a.name)),
  )
}

export async function downloadAttachment(token: string, messageId: string, attachmentId: string): Promise<Uint8Array> {
  const res = await fetch(
    `${GRAPH}/me/messages/${encodeURIComponent(messageId)}/attachments/${encodeURIComponent(attachmentId)}/$value`,
    { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(30_000) },
  )
  if (!res.ok) throw new Error(`attachment-${res.status}`)
  return new Uint8Array(await res.arrayBuffer())
}
