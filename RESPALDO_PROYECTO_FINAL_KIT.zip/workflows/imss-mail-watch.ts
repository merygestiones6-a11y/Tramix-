import { sleep } from 'workflow'

async function checkMailboxes(watchId: string, finalize: boolean) {
  'use step'
  const { checkWatch } = await import('@/lib/outlook/imss-mail')
  return checkWatch(watchId, { finalize })
}

/** Frequent checks right after submitting, then backing off: ~24 h in total. */
const SCHEDULE = ['30s', ...Array(14).fill('1m'), ...Array(20).fill('3m'), ...Array(136).fill('10m')] as const

/**
 * Durable poller for one submitted IMSS trámite. It keeps looking until a PDF for the
 * CURP is saved, so a first notice e-mail without the PDF does not end the search.
 */
export async function imssMailWatch(watchId: string) {
  'use workflow'
  for (const wait of SCHEDULE) {
    await sleep(wait)
    const result = await checkMailboxes(watchId, false)
    if (result.done) return result
  }
  return checkMailboxes(watchId, true)
}
