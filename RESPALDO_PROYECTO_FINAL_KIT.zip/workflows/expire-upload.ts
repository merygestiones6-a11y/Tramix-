import { sleep } from 'workflow'

async function removeUpload(id: string) {
  'use step'
  const { deleteUpload } = await import('@/lib/panel/store')
  const removed = await deleteUpload(id)
  return { id, removed }
}

/** One durable timer per upload: sleeps until that file's own expiry, then deletes it. */
export async function expireUpload(id: string, expiresAt: string) {
  'use workflow'
  await sleep(new Date(expiresAt))
  return removeUpload(id)
}
