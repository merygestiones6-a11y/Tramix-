;(() => {
  if (window.__tramixImssLoaded) return
  window.__tramixImssLoaded = true

  const api = globalThis.browser ?? globalThis.chrome
  const isTop = window === window.top
  const FIELD_TIMEOUT_MS = 120000

  const RX = {
    captcha:
      /captcha|codigo (de (la )?)?(imagen|seguridad|verificacion)|texto (de la )?imagen|caracteres|escrib[ae] el codigo|codigo que (se )?muestra/,
    curp: /\bcurp\b/,
    email: /correo|e-?mail|\bmail\b/,
    confirm: /confirm|repet|verific|vuelv|nuevamente|ratific|otra vez/,
    submit: /continuar|siguiente|aceptar|enviar|solicitar|buscar|consultar|validar/,
    notSubmit: /limpiar|cancelar|regresar|salir|borrar/,
    linkSent: /(le )?hemos enviado una liga|liga de confirmacion (a|en) su correo/,
  }

  const filledEls = new WeakSet()
  const filled = new Set()
  let job = null
  let fields = {}
  let captchaReady = false
  let submitted = false
  let ui = null

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
  const norm = (s) =>
    (s || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim()

  const report = (status, detail = {}) => api.runtime.sendMessage({ type: 'IMSS_STATUS', status, detail }).catch(() => {})

  function visible(el) {
    const r = el.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return false
    const st = getComputedStyle(el)
    return st.visibility !== 'hidden' && st.display !== 'none'
  }

  function ownDescription(el) {
    const parts = [
      el.id,
      el.name,
      el.placeholder,
      el.title,
      el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname'),
      el.getAttribute('ng-model'),
    ]
    if (el.labels) for (const label of el.labels) parts.push(label.textContent)
    const labelledBy = el.getAttribute('aria-labelledby')
    if (labelledBy) for (const id of labelledBy.split(/\s+/)) parts.push(document.getElementById(id)?.textContent)
    return norm(parts.filter(Boolean).join(' | '))
  }

  // Nearby text (table cell, wrapper, previous sibling) for portals that don't use <label for>.
  function contextText(el) {
    const parts = []
    let node = el.parentElement
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      if (node.querySelectorAll('input:not([type=hidden])').length > 1) break
      parts.push(node.textContent)
    }
    parts.push(el.previousElementSibling?.textContent, el.closest('td')?.previousElementSibling?.textContent)
    return norm(parts.filter(Boolean).join(' | ')).slice(0, 240)
  }

  function describe(el) {
    const own = ownDescription(el)
    if (RX.curp.test(own) || RX.email.test(own) || RX.captcha.test(own)) return own
    return `${own} | ${contextText(el)}`
  }

  function findFields() {
    const inputs = [
      ...document.querySelectorAll(
        'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button]):not([type=image]):not([type=file]):not([type=password])',
      ),
    ].filter((el) => !el.disabled && !el.readOnly && visible(el))

    const found = {}
    for (const el of inputs) {
      const d = describe(el)
      if (RX.captcha.test(d)) {
        found.captcha ??= el
      } else if (RX.curp.test(d)) {
        found.curp ??= el
      } else if (el.type === 'email' || RX.email.test(d)) {
        if (RX.confirm.test(d)) found.confirm ??= el
        else if (!found.email) found.email = el
        else found.confirm ??= el
      }
    }
    return found
  }

  const widgetCaptcha = () =>
    document.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, .h-captcha')

  function captchaSolved() {
    if (fields.captcha) return fields.captcha.value.trim().length >= 3
    const token = document.querySelector('textarea[name="g-recaptcha-response"], textarea[name="h-captcha-response"]')
    return Boolean(token && token.value.trim())
  }

  const hasCaptcha = () => Boolean(fields.captcha || widgetCaptcha())

  function setValue(el, value) {
    el.focus()
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value)
    el.dispatchEvent(new Event('input', { bubbles: true }))
    el.dispatchEvent(new Event('change', { bubbles: true }))
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }))
    el.blur()
  }

  function findSubmit() {
    const scope = (fields.email || fields.curp)?.form || document
    const buttons = [
      ...scope.querySelectorAll('button, input[type=submit], input[type=button], a.btn, a[role=button]'),
    ].filter((b) => visible(b) && !b.closest('#tramix-imss-assistant'))
    const label = (b) => norm(b.textContent || b.value)
    const usable = buttons.filter((b) => !RX.notSubmit.test(label(b)))
    return usable.find((b) => RX.submit.test(label(b))) || usable.find((b) => b.type === 'submit') || null
  }

  function markSubmitted() {
    if (submitted) return
    submitted = true
    report('submitted')
    render()
  }

  // The IMSS green notice "...le hemos enviado una liga de confirmación a su correo electrónico"
  // is what confirms the trámite was accepted.
  let linkSent = false
  function watchLinkSent() {
    if (!job || linkSent) return false
    if (!RX.linkSent.test(norm(document.body?.innerText || ''))) return false
    linkSent = true
    captchaReady = true
    markSubmitted()
    report('link_sent', {
      message: 'Para continuar con su trámite le hemos enviado una liga de confirmación a su correo electrónico.',
    })
    render()
    return true
  }

  function tryFill() {
    if (!job) return
    if (linkSent || watchLinkSent()) return
    fields = findFields()
    const changed = []
    const fill = (key, el, value) => {
      if (!el || filledEls.has(el)) return
      if (norm(el.value) !== norm(value)) setValue(el, value)
      filledEls.add(el)
      filled.add(key)
      changed.push(key)
    }
    fill('curp', fields.curp, job.curp)
    fill('email', fields.email, job.email)
    fill('confirm', fields.confirm, job.email)
    if (!changed.length) return

    report('filled', { fields: [...filled], hasCaptcha: hasCaptcha() })
    mountUi()
    render()
    const target = fields.captcha || widgetCaptcha()
    target?.scrollIntoView({ block: 'center', behavior: 'smooth' })
    if (fields.captcha) setTimeout(() => fields.captcha?.focus(), 300)
  }

  function watchCaptcha() {
    if (!filled.size || submitted) return
    const ready = captchaSolved()
    if (ready && !captchaReady) report('captcha_ready')
    if (ready !== captchaReady) {
      captchaReady = ready
      render()
    }
  }

  function mountUi() {
    if (ui) return
    const host = document.createElement('div')
    host.id = 'tramix-imss-assistant'
    host.style.cssText =
      'all:initial;position:fixed;left:0;right:0;bottom:0;z-index:2147483647;display:flex;justify-content:center;padding:12px;pointer-events:none;'
    const root = host.attachShadow({ mode: 'open' })
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; margin: 0; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
        .card { pointer-events: auto; width: 100%; max-width: 420px; display: flex; flex-direction: column; gap: 10px;
          padding: 14px; border-radius: 20px; background: rgba(15, 23, 42, 0.94); color: #f8fafc;
          box-shadow: 0 12px 40px rgba(2, 6, 23, 0.45); backdrop-filter: blur(12px); border: 1px solid rgba(148, 163, 184, 0.2); }
        .head { display: flex; align-items: center; gap: 8px; }
        .brand { font-size: 11px; font-weight: 800; letter-spacing: 0.12em; color: #60a5fa; }
        .title { flex: 1; font-size: 13px; font-weight: 600; }
        .x { all: unset; cursor: pointer; width: 28px; height: 28px; display: grid; place-items: center; border-radius: 8px; color: #94a3b8; font-size: 18px; }
        .x:hover { background: rgba(148, 163, 184, 0.15); }
        ul { list-style: none; padding: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        li { display: flex; align-items: center; gap: 8px; font-size: 12px; padding: 6px 8px; border-radius: 10px; background: rgba(148, 163, 184, 0.12); color: #cbd5e1; }
        li::before { content: ""; flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; border: 1.5px solid currentColor; }
        li.done { background: rgba(34, 197, 94, 0.16); color: #86efac; }
        li.done::before { width: 4px; height: 8px; margin: 0 2px 2px; border-radius: 0; border-width: 0 2px 2px 0; transform: rotate(45deg); }
        li.manual { background: rgba(250, 204, 21, 0.14); color: #fde68a; }
        .msg { font-size: 13px; line-height: 1.45; color: #e2e8f0; }
        .go { all: unset; cursor: pointer; text-align: center; height: 44px; line-height: 44px; border-radius: 12px;
          background: #2563eb; color: #fff; font-size: 14px; font-weight: 700; letter-spacing: 0.04em; }
        .go[disabled] { opacity: 0.45; cursor: not-allowed; }
        .go:not([disabled]):active { transform: scale(0.98); }
      </style>
      <div class="card" role="status" aria-live="polite">
        <div class="head">
          <span class="brand">TRAMIX</span>
          <span class="title">IMSS — NSS</span>
          <button class="x" type="button" aria-label="Ocultar asistente">×</button>
        </div>
        <ul>
          <li data-k="curp">CURP</li>
          <li data-k="email">Correo</li>
          <li data-k="confirm">Confirmación</li>
          <li data-k="captcha">CAPTCHA (manual)</li>
        </ul>
        <p class="msg"></p>
        <button class="go" type="button" disabled>CONTINUAR</button>
      </div>`
    root.querySelector('.x').addEventListener('click', () => host.remove())
    root.querySelector('.go').addEventListener('click', () => {
      const button = findSubmit()
      if (!button) {
        root.querySelector('.msg').textContent = 'Pulsa el botón del portal para continuar.'
        return
      }
      markSubmitted()
      button.click()
    })
    document.documentElement.appendChild(host)
    ui = root
  }

  function render() {
    if (!ui) return
    for (const li of ui.querySelectorAll('li')) {
      const key = li.dataset.k
      const done = key === 'captcha' ? captchaReady || !hasCaptcha() : filled.has(key)
      li.className = done ? 'done' : key === 'captcha' ? 'manual' : ''
    }
    const go = ui.querySelector('.go')
    const msg = ui.querySelector('.msg')
    if (submitted) {
      msg.textContent = 'Formulario enviado. Sigue las indicaciones del portal del IMSS.'
      go.disabled = true
    } else if (hasCaptcha() && !captchaReady) {
      msg.textContent = 'Datos colocados. Resuelve el CAPTCHA en la página y después pulsa CONTINUAR.'
      go.disabled = true
    } else {
      msg.textContent = hasCaptcha()
        ? 'CAPTCHA listo. Pulsa CONTINUAR para enviar el formulario.'
        : 'Datos colocados. Revisa y pulsa CONTINUAR.'
      go.disabled = false
    }
  }

  async function loadJob() {
    for (let i = 0; i < 6; i++) {
      const res = await api.runtime.sendMessage({ type: 'IMSS_GET_JOB' }).catch(() => null)
      if (res?.job) return res.job
      await sleep(700)
    }
    return null
  }

  async function init() {
    job = await loadJob()
    if (!job) return

    tryFill()
    let pending = null
    new MutationObserver(() => {
      clearTimeout(pending)
      pending = setTimeout(tryFill, 150)
    }).observe(document.documentElement, { childList: true, subtree: true })
    setInterval(watchCaptcha, 600)
    setInterval(watchLinkSent, 700)

    document.addEventListener(
      'click',
      (event) => {
        if (!filled.size || !captchaReady) return
        const button = findSubmit()
        if (button && event.composedPath().includes(button)) markSubmitted()
      },
      true,
    )

    if (isTop) {
      setTimeout(() => {
        if (!filled.size) report('fields_not_found')
      }, FIELD_TIMEOUT_MS)
    }
  }

  init()
})()
