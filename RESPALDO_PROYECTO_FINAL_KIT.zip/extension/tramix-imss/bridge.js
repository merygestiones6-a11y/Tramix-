;(() => {
  const api = globalThis.browser ?? globalThis.chrome
  const version = api.runtime.getManifest().version
  const reply = (msg) => window.postMessage({ source: 'tramix-ext', ...msg }, window.location.origin)

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return
    const data = event.data
    if (!data || data.source !== 'tramix-page') return

    if (data.type === 'PING') {
      reply({ type: 'PONG', version })
      return
    }

    if (data.type === 'IMSS_START') {
      const result = await api.runtime
        .sendMessage({ type: 'IMSS_START', requestId: data.requestId, curp: data.curp, email: data.email })
        .catch((error) => ({ ok: false, error: String(error) }))
      reply({ type: 'IMSS_STARTED', requestId: data.requestId, ok: Boolean(result?.ok), error: result?.error })
    }
  })

  api.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'IMSS_STATUS') reply(msg)
  })
})()
