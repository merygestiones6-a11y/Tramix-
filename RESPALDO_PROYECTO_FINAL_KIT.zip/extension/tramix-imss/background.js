const api = globalThis.browser ?? globalThis.chrome
const PORTAL_URL = 'https://serviciosdigitales.imss.gob.mx/gestionAsegurados-web-externo/asignacionNSS'
const JOB_TTL_MS = 30 * 60 * 1000
const CURP_RX = /^[A-Z0-9]{18}$/
const EMAIL_RX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
// Session storage keeps jobs in memory only (cleared when the browser closes) and survives service-worker restarts.
const store = api.storage.session ?? api.storage.local

async function readJobs() {
  const { jobs = {} } = await store.get('jobs')
  const now = Date.now()
  for (const id of Object.keys(jobs)) {
    if (now - jobs[id].createdAt > JOB_TTL_MS) delete jobs[id]
  }
  return jobs
}

const writeJobs = (jobs) => store.set({ jobs })

function notifySource(job, status, detail = {}) {
  return api.tabs
    .sendMessage(job.sourceTabId, { type: 'IMSS_STATUS', requestId: job.requestId, status, detail })
    .catch(() => {})
}

async function handle(msg, sender) {
  const tabId = sender.tab?.id
  if (tabId == null) return { ok: false, error: 'Sin pestaña' }

  if (msg.type === 'IMSS_START') {
    const curp = String(msg.curp ?? '').toUpperCase()
    const email = String(msg.email ?? '').toLowerCase()
    if (!CURP_RX.test(curp) || !EMAIL_RX.test(email)) return { ok: false, error: 'Datos inválidos' }
    const tab = await api.tabs.create({ url: PORTAL_URL, active: true })
    const jobs = await readJobs()
    jobs[tab.id] = {
      requestId: String(msg.requestId ?? ''),
      curp,
      email,
      sourceTabId: tabId,
      createdAt: Date.now(),
      anyFilled: false,
    }
    await writeJobs(jobs)
    return { ok: true }
  }

  if (msg.type === 'IMSS_GET_JOB') {
    const job = (await readJobs())[tabId]
    return { job: job ? { curp: job.curp, email: job.email } : null }
  }

  if (msg.type === 'IMSS_STATUS') {
    const jobs = await readJobs()
    const job = jobs[tabId]
    if (!job) return { ok: false }
    if (msg.status === 'filled') job.anyFilled = true
    if (msg.status === 'fields_not_found' && job.anyFilled) return { ok: true }
    await writeJobs(jobs)
    await notifySource(job, msg.status, msg.detail)
    if (msg.status === 'submitted' || msg.status === 'link_sent') {
      await api.tabs.update(job.sourceTabId, { active: true }).catch(() => {})
    }
    return { ok: true }
  }

  return { ok: false, error: 'Mensaje desconocido' }
}

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender).then(sendResponse, (error) => sendResponse({ ok: false, error: String(error) }))
  return true
})

api.tabs.onRemoved.addListener(async (tabId) => {
  const jobs = await readJobs()
  const job = jobs[tabId]
  if (!job) return
  delete jobs[tabId]
  await writeJobs(jobs)
  await notifySource(job, 'closed')
})
