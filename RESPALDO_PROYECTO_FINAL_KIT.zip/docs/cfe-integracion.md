# RECIBO DE LUZ — Punto de integración con una fuente CFE autorizada

Estado: **pendiente de definir la fuente autorizada**. No se agregan funciones nuevas hasta que exista.

## Flujo final

```
NÚMERO DE SERVICIO
  → FUENTE CFE AUTORIZADA          (lib/cfe/sources.ts  — único punto a implementar)
  → PDF
  → DETECTAR TITULAR + Nº SERVICIO (lib/cfe/holder.ts   — ya existe, mismo que la importación manual)
  → VALIDAR 11 DÍGITOS / COINCIDENCIA
  → RENOMBRAR  NOMBRE_DEL_TITULAR_NUMERO_DE_SERVICIO.pdf
  → GUARDAR    (Blob privado, deduplicado por SHA-256)
  → SOLICITUD = DESCARGADO
```

Todo lo que va después de "PDF" ya está construido en `lib/cfe/ingest.ts` (`ingestReceipt`), y la fuente automática lo reutiliza tal cual.

## Dónde se conecta (elegir UNA modalidad según lo que ofrezca CFE)

### A) Push: la fuente autorizada nos envía el PDF

- Endpoint existente: `POST /api/cfe/ingest` (`app/api/cfe/ingest/route.ts`).
- Autenticación: `Authorization: Bearer <CFE_INGEST_SECRET>`. Mientras la variable no exista, el endpoint responde `not-configured`.
- Cuerpo:
  - `application/pdf` en bruto, con encabezados opcionales `X-Service-Number` y `X-Request-Id`, **o**
  - `multipart/form-data` con `file`, y opcionalmente `serviceNumber` y `requestId`.
- Para activarlo solo hay que definir `CFE_INGEST_SECRET` en *Vars* y entregárselo a la fuente autorizada. No hace falta cambiar código.

### B) Pull: nosotros pedimos el PDF a la fuente autorizada

- Archivo: `lib/cfe/sources.ts`, arreglo `SOURCES` (está marcado con `PUNTO DE INTEGRACIÓN`).
- Se registra una entrada con `automatic: true` y `fetchReceipt(request)`, que devuelve `{ bytes, fileName? }` o `null` si el recibo todavía no está disponible.
- `pullReceipt` (`lib/cfe/pull.ts`) ya se encarga de llamarla para una solicitud `pendiente` y de pasar el resultado a `ingestReceipt`.
- Credenciales de la fuente: solo en variables de entorno del servidor, nunca en el cliente ni en el repositorio.

## Reglas de validación (ya implementadas, compartidas con la importación manual)

| Comprobación | Resultado si falla |
|---|---|
| Tamaño ≤ `MAX_RECEIPT_BYTES` | `too-large` |
| El archivo empieza por `%PDF` y se puede leer | `invalid-pdf` |
| El número de servicio declarado tiene 11 dígitos | `invalid-service` |
| Se detectan el titular y un número de servicio de 11 dígitos en el PDF | `needs-review` |
| El número del PDF coincide con el de la solicitud | `service-mismatch` |
| El mismo PDF (SHA-256) ya estaba guardado | se devuelve el existente (`duplicate: true`) |

Un rechazo **no se adivina ni se corrige solo**: la solicitud queda pendiente y se resuelve con la importación manual.

## Respaldo manual (sin cambios)

La sección "Importar recibo PDF" sigue igual: se detecta el titular y el número, se pueden corregir, se renombra y se guarda. Es el camino para cualquier rechazo de la fuente automática.

## Fuera de alcance (no se implementa)

- Servicios de Accessibility o control de otras aplicaciones (CFE Contigo incluida).
- Resolución o evasión de CAPTCHA.
- Inicio de sesión automatizado o scraping del portal de CFE.
- Cualquier método para evadir los controles de CFE.

## Qué se necesita para continuar

1. Que CFE (o un proveedor autorizado por CFE) confirme la fuente: API, webhook o entrega de archivos.
2. Saber si es **push** (A) o **pull** (B), y su método de autenticación.
3. Con eso, solo cambia `CFE_INGEST_SECRET` (A) o una entrada en `SOURCES` (B).

## Canal FileKit ↔ Dispositivo Android

Activación: definir `CFE_DEVICE_ENROLL_SECRET` (sin él, todas las rutas responden 503).

| Paso | Ruta | Auth |
|---|---|---|
| Registro (una vez) | `POST /api/cfe/device/register` `{ name }` → `{ deviceId, token }` | `Bearer <CFE_DEVICE_ENROLL_SECRET>` |
| CONECTADO | `POST /api/cfe/device/heartbeat` | `Bearer <token>` |
| Tomar solicitud | `POST /api/cfe/device/jobs/next` → `{ job }` o 204 | `Bearer <token>` |
| PROCESANDO / ERROR | `POST /api/cfe/device/jobs/:id/status` `{ state, message?, retryable? }` | `Bearer <token>` |
| Enviar PDF | `POST /api/cfe/device/jobs/:id/receipt` (cuerpo `application/pdf`) → COMPLETADO | `Bearer <token>` |
| Admin | `GET /api/cfe/devices`, `DELETE /api/cfe/devices/:id` (revocar) | sesión FileKit |

- Token: `deviceId.secreto`; solo se guarda el SHA-256 del secreto (`cfe/devices.json`, Blob privado). Revocable.
- Cola: una tarea por solicitud `pendiente`; arrendamiento de 5 min, renovado con CONECTADO/PROCESANDO.
- Reintentos: máx. 3 intentos, espera 30 s / 60 s; arrendamiento vencido vuelve a la cola. Cliente Android reintenta red/5xx con backoff.
- Duplicados: mismo PDF (SHA-256) nunca se guarda dos veces; reenviar tras COMPLETADO devuelve el recibo existente.
- El PDF pasa por `ingestReceipt` (mismo flujo que la fuente autorizada); si falla la validación queda en ERROR y se usa la importación manual.
- Cliente: `android/.../FileKitDeviceLink.kt`. Solo transporta el PDF; no controla otras apps.
