plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Optional default TRAMIX address (e.g. -PtramixUrl=https://tramix.example.com).
// When empty, the app receives it from the "ABRIR EN LA APP" link or asks for it once.
val tramixUrl = (project.findProperty("tramixUrl") as String?)?.trim().orEmpty()

android {
    namespace = "mx.tramix.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "mx.tramix.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "1.3.0"
        buildConfigField("String", "TRAMIX_URL", "\"$tramixUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sideloaded APK: signed with the local debug key so it installs without a store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.12.1")
}
