(function () {
  'use strict'
  var cfg = window.__tramixRun || {}
  var B = window.TramixOutlook
  if (!B || window.__tramixRunHref === location.href) return
  window.__tramixRunHref = location.href

  var host = location.hostname.toLowerCase()
  var isLogin = /(^|\.)(login\.live\.com|login\.microsoftonline\.com|login\.microsoft\.com|account\.live\.com|account\.microsoft\.com)$/.test(host)
  var isOutlook = /^outlook\.(live|office|office365)\.com$/.test(host)
  var isImss = host === 'imss.gob.mx' || /\.imss\.gob\.mx$/.test(host)
  var isRun = cfg.mode === 'run'

  function send(o) {
    try { B.report(JSON.stringify(o)) } catch (e) {}
  }
  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms) })
  }
  function waitFor(fn, ms) {
    var end = Date.now() + ms
    return new Promise(function (resolve) {
      ;(function tick() {
        var v = null
        try { v = fn() } catch (e) {}
        if (v) return resolve(v)
        if (Date.now() > end) return resolve(null)
        setTimeout(tick, 500)
      })()
    })
  }
  function visible(el) {
    var r = el.getBoundingClientRect()
    return r.width > 0 && r.height > 0
  }
  function text(el) {
    return ((el && (el.innerText || el.textContent || el.value || el.title || el.getAttribute('aria-label'))) || '')
      .replace(/\s+/g, ' ')
      .trim()
  }
  function all(sel, root) {
    return [].slice.call((root || document).querySelectorAll(sel))
  }
  function setValue(input, value) {
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(input, value)
    input.dispatchEvent(new Event('input', { bubbles: true }))
    input.dispatchEvent(new Event('change', { bubbles: true }))
  }
  function pressEnter(el) {
    ;['keydown', 'keypress', 'keyup'].forEach(function (type) {
      el.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }))
    })
  }
  function realUrl(href) {
    try {
      var u = new URL(href)
      if (/safelinks\.protection\.outlook\.com$/i.test(u.hostname)) return u.searchParams.get('url') || href
      return u.href
    } catch (e) {
      return null
    }
  }
  function imssUrl(href) {
    try {
      var u = new URL(href)
      return u.protocol === 'https:' && (u.hostname === 'imss.gob.mx' || /\.imss\.gob\.mx$/i.test(u.hostname))
    } catch (e) {
      return false
    }
  }

  // ---------- Microsoft sign-in pages ----------
  // TRAMIX already knows the address: fill it so the user only types the password.
  async function prefillEmail() {
    var email = String(cfg.email || '')
    if (!email) return
    var input = await waitFor(function () {
      return all('input[name="loginfmt"], input[type="email"], input[name="username"]').filter(visible)[0]
    }, 12000)
    if (!input || input.value.trim().toLowerCase() === email) return
    if (input.value.trim()) return
    input.focus()
    setValue(input, email)
    if (cfg.mode !== 'login') return
    await sleep(600)
    var next =
      document.querySelector('#idSIButton9, input[type="submit"][value*="Siguiente" i], input[type="submit"][value*="Next" i]') ||
      all('button[type="submit"], button').filter(function (b) { return visible(b) && /siguiente|next/i.test(text(b)) })[0]
    if (next) next.click()
  }

  if (isLogin) {
    var page = document.body ? text(document.body) : ''
    var verification =
      /verific|c[oó]digo|captcha|aprueba|approve|authenticator|seguridad de la cuenta|protect your account|prove/i.test(page) ||
      !!document.querySelector('input[name="otc"], iframe[src*="captcha" i], iframe[src*="arkose" i]')
    send({ type: 'signed_out', verification: verification })
    prefillEmail()
    return
  }

  // ---------- Outlook ----------
  function mailbox() {
    return document.querySelector(
      '#topSearchInput, input[aria-label*="Search" i], input[aria-label*="Buscar" i], [role="tree"], div[role="listbox"]',
    )
  }

  async function outlook() {
    var ready = await waitFor(mailbox, 30000)
    if (!ready) {
      if (/\/mail\//.test(location.pathname)) send({ type: 'error', message: 'Outlook no terminó de cargar', account: false })
      else send({ type: 'signed_out' })
      return
    }
    send({ type: 'signed_in' })
    if (!isRun || cfg.stage !== 'search') return
    await sleep(1500)
    await searchImss()
  }

  async function searchImss() {
    send({ type: 'step', step: 'search', message: 'Buscando el correo del IMSS' })
    var input = await waitFor(function () {
      return (
        document.querySelector('#topSearchInput') ||
        all('input[aria-label*="Search" i], input[aria-label*="Buscar" i], input[placeholder*="Buscar" i], input[placeholder*="Search" i]').filter(visible)[0]
      )
    }, 20000)
    if (!input) {
      send({ type: 'error', message: 'No encontré el buscador de Outlook', account: false })
      return
    }
    input.focus()
    input.click()
    await sleep(400)
    setValue(input, 'IMSS')
    await sleep(400)
    pressEnter(input)

    var curp = String(cfg.curp || '').toUpperCase()
    var round = Number(cfg.round || 0)
    var skip = Array.isArray(cfg.skip) ? cfg.skip : []
    var item = await waitFor(function () {
      var options = all('[role="option"], [role="listitem"]').filter(visible).filter(function (o) {
        return /imss/i.test(text(o))
      })
      if (!options.length) return null
      // After the first IMSS mail came without PDFs, prefer a mail we have not opened yet (the second one).
      var fresh = options.filter(function (o) { return skip.indexOf(mailId(o)) < 0 })
      var pool = fresh.length ? fresh : options
      return pool.filter(function (o) { return curp && text(o).toUpperCase().indexOf(curp) >= 0 })[0] || pool[0]
    }, 25000)
    if (!item) {
      send({ type: 'not_found' })
      return
    }

    var id = mailId(item)
    var isNew = skip.indexOf(id) < 0
    send({
      type: 'step',
      step: 'mail_found',
      message: round ? (isNew ? 'Segundo correo del IMSS encontrado' : 'Revisando de nuevo el hilo del IMSS') : 'Correo del IMSS encontrado',
    })
    item.click()
    var body = await waitFor(function () {
      var b = document.querySelector('[aria-label="Message body"], [aria-label="Cuerpo del mensaje"], div[role="document"]')
      return b && text(b).length > 20 ? b : null
    }, 25000)
    if (!body) {
      send({ type: 'error', message: 'No se pudo abrir el contenido del correo', account: false })
      return
    }
    send({ type: 'note', step: 'mail', message: (round ? 'Segundo correo abierto' : 'Correo abierto') + ' · esperando a que cargue todo el contenido' })
    await settle(body)
    expandThread()
    await sleep(2000)

    // Analyze the mail repeatedly until a PDF or the tramite link appears. Never decide "no link" on a half-loaded mail.
    var bodies = [body]
    var attachments = []
    var target = null
    var info = null
    var deadline = Date.now() + MAIL_ANALYZE_MS
    var pass = 0
    while (Date.now() < deadline) {
      pass++
      // The second IMSS mail may be threaded with the first: inspect every message in the reading pane, newest first.
      bodies = messageBodies()
      if (!bodies.length) bodies = [body]
      attachments = pdfAttachments(document.querySelector('[role="main"]') || body)
      if (attachments.length) break
      if (!cfg.linkOpened) {
        target = null
        info = null
        for (var b = 0; b < bodies.length && !target; b++) target = tramiteText(bodies[b])
        for (var k = 0; k < bodies.length && !(info && info.url); k++) info = tramiteLink(bodies[k])
        if (target || (info && info.url)) break
      }
      if (pass === 3) expandThread()
      send({ type: 'note', step: 'mail', message: 'Leyendo el correo del IMSS · buscando el enlace del trámite o el PDF (' + pass + ')' })
      await sleep(2500)
    }

    // Rule: PDF attachments win. The link is only used when the mail has no PDF attached.
    if (attachments.length) {
      send({ type: 'attachments', count: attachments.length })
      for (var i = 0; i < attachments.length; i++) {
        await downloadAttachment(attachments[i])
        await sleep(2500)
      }
      await sleep(15000)
      send({ type: 'check_docs' })
      return
    }

    // The first mail exists to open the portal: read the body, find the exact purple/blue underlined
    // text "Solicitud de Asignación o Localización de NSS" and tap it. Never build or guess a URL.
    if (!cfg.linkOpened) {
      if (target) {
        // Keep the real href as method 2 in case tapping does not open the portal.
        send({ type: 'note', step: 'link', message: 'Texto "Solicitud de Asignación o Localización de NSS" localizado · tocando el enlace' })
        await tap(target)
        // Native confirms the step only when an IMSS page really loads; it retries or uses method 2 otherwise.
        send({ type: 'link_clicked', id: id, url: (info && info.url) || '' })
        return
      }
      if (info && info.url) {
        // The visible text differs slightly, but the mail carries the real tramite link: open that exact href.
        send({ type: 'note', step: 'link', message: 'Enlace del trámite detectado en el correo · abriéndolo' })
        send({ type: 'link_clicked', id: id, url: info.url, open: true })
        return
      }
    }
    // Not a failure: the IMSS sends a second mail a minute or two later. Native waits and searches again.
    send({ type: 'mail_empty', id: id })
  }

  var MAIL_ANALYZE_MS = 30000

  /** Waits until the mail body stops changing (text, links, images loaded) so it is analyzed only when complete. */
  async function settle(body) {
    var last = ''
    var stable = 0
    var end = Date.now() + 20000
    while (Date.now() < end) {
      var main = document.querySelector('[role="main"]') || body
      var sig = text(main).length + ':' + main.querySelectorAll('a, img, [role="attachment"]').length
      stable = sig === last ? stable + 1 : 0
      last = sig
      if (stable >= 3) return
      await sleep(1000)
    }
  }

  /** The visible element whose own text is exactly the tramite link (smallest match, prefer real links). */
  function tramiteText(body) {
    var matches = all('a, [role="link"], span, font, u, b, strong, td, p, div', body).filter(function (el) {
      var t = text(el)
      return visible(el) && TRAMITE_EXACT.test(t) && t.length < 120
    })
    if (!matches.length) return null
    matches.sort(function (a, b) { return text(a).length - text(b).length })
    var smallest = matches.filter(function (el) { return !matches.some(function (o) { return o !== el && el.contains(o) }) })
    var el = smallest[0] || matches[0]
    return el.closest('a, [role="link"]') || el
  }

  /** Tap the element like a finger would: scroll it into view and fire pointer + mouse events at its center. */
  async function tap(el) {
    el.scrollIntoView({ block: 'center' })
    await sleep(800)
    var r = el.getBoundingClientRect()
    var opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 }
    try { el.dispatchEvent(new PointerEvent('pointerdown', opts)) } catch (e) {}
    el.dispatchEvent(new MouseEvent('mousedown', opts))
    try { el.dispatchEvent(new PointerEvent('pointerup', opts)) } catch (e) {}
    el.dispatchEvent(new MouseEvent('mouseup', opts))
    el.click()
  }

  /** Stable id for an Outlook message-list row. */
  function mailId(row) {
    var holder = row.matches('[data-convid]') ? row : row.querySelector('[data-convid], [data-itemid]')
    var id = (holder && (holder.getAttribute('data-convid') || holder.getAttribute('data-itemid'))) || row.id
    return id || text(row).replace(/\s+/g, ' ').slice(0, 120)
  }

  /** Expands collapsed messages of a conversation so the second IMSS mail is readable too. */
  function expandThread() {
    all('[aria-expanded="false"]', document.querySelector('[role="main"]') || document)
      .filter(visible)
      .filter(function (el) { return /imss/i.test(text(el)) && text(el).length < 400 })
      .slice(0, 4)
      .forEach(function (el) { el.click() })
  }

  function messageBodies() {
    return all('[aria-label="Message body"], [aria-label="Cuerpo del mensaje"], div[role="document"]')
      .filter(function (b) { return visible(b) && text(b).length > 20 })
      .reverse()
  }

  function fileName(label) {
    var m = label.match(/[^\\/:*?"<>|\s][^\\/:*?"<>|]*?\.pdf\b/i)
    return m ? m[0].trim().toLowerCase() : ''
  }

  /** One element per distinct PDF attachment card (outside the message body). */
  function pdfAttachments(body) {
    var reading = body.closest('[role="main"]') || document
    var byName = {}
    var list = []
    all('[role="attachment"], [role="option"], [role="listitem"], [aria-label], [title]', reading).forEach(function (el) {
      if (!visible(el) || body.contains(el)) return
      var label = text(el) + ' ' + (el.getAttribute('title') || '')
      var name = fileName(label)
      if (!name) return
      var current = byName[name]
      // Prefer the card that holds the action buttons.
      if (!current || (!current.querySelector('button') && el.querySelector('button')) || (current.contains(el) && el.querySelector('button'))) {
        if (current) list.splice(list.indexOf(current), 1, el)
        else list.push(el)
        byName[name] = el
      }
    })
    return list.slice(0, 10)
  }

  async function downloadAttachment(card) {
    var buttons = all('button, [role="button"], a[href]', card)
    var direct = buttons.filter(function (b) { return /descargar|download/i.test(text(b) + ' ' + (b.getAttribute('title') || '')) })[0]
    if (direct) {
      direct.click()
      return true
    }
    var more = buttons.filter(function (b) { return /m[aá]s opciones|more options|more actions|acciones|options/i.test(text(b) + ' ' + (b.getAttribute('title') || '')) })[0]
    if (!more) {
      card.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true }))
    } else {
      more.click()
    }
    var item = await waitFor(function () {
      return all('[role="menuitem"], [role="menuitemradio"], button').filter(function (m) {
        return visible(m) && /^\s*(descargar|download)\b/i.test(text(m))
      })[0]
    }, 5000)
    if (item) {
      item.click()
      return true
    }
    document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
    return false
  }

  var TRAMITE = /solicitud\s+de\s+asignaci[oó]n\s+o\s+localizaci[oó]n(\s+de\s+nss)?/i
  var TRAMITE_EXACT = /^\W*solicitud\s+de\s+asignaci[oó]n\s+o\s+localizaci[oó]n\s+de\s+nss\W*$/i

  /** The purple "Solicitud de Asignación o Localización de NSS" text is a link even if it looks like plain text. */
  function tramiteLink(body) {
    var named = all('a, [role="link"], [data-href], [onclick], span, font, b, strong', body).filter(function (el) {
      return TRAMITE.test(text(el)) && text(el).length < 160
    })
    for (var i = 0; i < named.length; i++) {
      var anchor = named[i].closest('a') || named[i].querySelector('a')
      var href = anchor && (anchor.getAttribute('originalsrc') || anchor.getAttribute('data-auth-href') || anchor.href)
      href = href || named[i].getAttribute('data-href')
      var url = href && realUrl(href)
      if (url && /^https:/i.test(url)) return { url: url, named: true }
    }
    var links = all('a[href]', body).map(function (a) { return realUrl(a.getAttribute('originalsrc') || a.href) }).filter(imssUrl)
    var inText = (text(body).match(/https:\/\/[^\s"'<>]+/g) || []).map(realUrl).filter(imssUrl)
    links = links.concat(inText)
    if (links.length) return { url: links[0], named: false }
    var clickable = named.filter(function (el) { return el.closest('a, [role="link"], [onclick], [data-href]') })[0]
    return clickable ? { el: clickable.closest('a, [role="link"], [onclick], [data-href]') } : null
  }

  // ---------- IMSS portal ----------
  /** Waits until the page stops changing (no spinner, text length stable for ~3 s). */
  async function settle(maxMs) {
    var end = Date.now() + (maxMs || 20000)
    var last = -1
    var stable = 0
    while (Date.now() < end) {
      var n = (document.body && document.body.innerText.length) || 0
      stable = n === last ? stable + 1 : 0
      last = n
      var busy = all('.ui-blockui, .blockUI, .blockOverlay, [aria-busy="true"], .loading, .spinner, .ui-dialog-loading').some(visible)
      if (stable >= 3 && !busy) return true
      await sleep(1000)
    }
    return false
  }

  /** The page really loaded: document complete and some content visible. */
  function waitLoaded(ms) {
    return waitFor(function () {
      return document.readyState === 'complete' && document.body && text(document.body).length > 60
    }, ms)
  }

  function captcha() {
    return document.querySelector(
      'img[src*="aptcha" i], img[id*="aptcha" i], input[name*="aptcha" i], input[id*="aptcha" i], .g-recaptcha, iframe[src*="recaptcha"], iframe[src*="hcaptcha"]',
    )
  }
  function blocker() {
    if (captcha()) return 'El IMSS pide un CAPTCHA o verificación. Pulsa INTERVENIR para resolverlo.'
    var page = (document.title + ' ' + ((document.body && document.body.innerText) || '').slice(0, 1500))
    if (/(error|http|estado|status)\s*:?\s*50[03]\b|^\s*50[03]\b|internal server error|error interno del servidor|service unavailable/im.test(page))
      return 'El portal del IMSS respondió con un error (500). Pulsa INTERVENIR para continuar desde esta pantalla.'
    if (/verifica que no eres un robot|soy humano|verificaci[oó]n de seguridad/i.test(page))
      return 'El IMSS pide una verificación. Pulsa INTERVENIR para resolverla.'
    return null
  }
  function rank(label) {
    if (/descargar|constancia|pdf/i.test(label)) return 3
    if (/generar|obtener|consultar/i.test(label)) return 2
    if (/continuar|aceptar|confirmar|siguiente/i.test(label)) return 1
    return 0
  }
  function toDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader()
      r.onload = function () { resolve(r.result) }
      r.onerror = reject
      r.readAsDataURL(blob)
    })
  }
  async function submitForPdf(el) {
    var form = el.form || el.closest('form')
    if (!form || !form.action || !imssUrl(form.action)) return false
    var data = new FormData(form)
    if (el.name) data.append(el.name, el.value || el.name)
    else if (el.id) data.append(el.id, el.id)
    try {
      var res = await fetch(form.action, {
        method: (form.method || 'post').toUpperCase(),
        body: new URLSearchParams(data),
        credentials: 'include',
      })
      var type = res.headers.get('content-type') || ''
      if (!/pdf|octet-stream/i.test(type)) return false
      var blob = await res.blob()
      var disposition = res.headers.get('content-disposition') || ''
      var match = disposition.match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i)
      var name = match ? decodeURIComponent(match[1]) : 'documento-imss.pdf'
      B.saveDataUrl(name, 'application/pdf', await toDataUrl(blob))
      return true
    } catch (e) {
      return false
    }
  }

  function label(el) {
    return [text(el), el.getAttribute('title'), el.getAttribute('alt'), el.getAttribute('aria-label'), typeof el.className === 'string' ? el.className : '']
      .join(' ')
  }

  var NOT_DOWNLOAD = /sobre|envelope|correo|mail|enviar|send|imprim|print/i
  var IS_DOWNLOAD = /descarg|download|arrow-?down|arrowthick-1-s|arrowthickstop-1-s|arrowstop-1-s|fa-arrow-down|glyphicon-download|file-pdf|fa-file-pdf/i

  /** Only the down-arrow download icons in "Documentos" (never the envelope or print icons). */
  function downloadControls() {
    var found = []
    all('a, button, input[type="button"], input[type="image"], input[type="submit"], [role="button"], img, i, span').forEach(function (el) {
      if (!visible(el)) return
      var target = el.closest('a, button, [role="button"], input') || el
      var l = label(el) + ' ' + label(target) + ' ' + (el.getAttribute('src') || '')
      var isPdfLink = target.tagName === 'A' && /\.pdf(\?|#|$)/i.test(target.href || '')
      if (!isPdfLink && !IS_DOWNLOAD.test(l)) return
      if (NOT_DOWNLOAD.test(l)) return
      if (/^\s*documentos?\s*$/i.test(text(el))) return
      if (found.some(function (f) { return f === target || f.contains(target) || target.contains(f) })) return
      found.push(target)
    })
    return found.slice(0, 6)
  }

  /** "Número de Seguridad Social" and "Tarjeta de Número de Seguridad Social" rows. */
  function namedDocumentCount() {
    var page = (document.body && document.body.innerText) || ''
    var n = 0
    if (/tarjeta\s+de\s+n[uú]mero\s+de\s+seguridad\s+social/i.test(page)) n++
    if (/(^|\n|\s)n[uú]mero\s+de\s+seguridad\s+social/i.test(page.replace(/tarjeta\s+de\s+n[uú]mero\s+de\s+seguridad\s+social/gi, ''))) n++
    return n
  }

  /** Clicks a visible control whose text matches, once per page session. */
  async function clickOnce(key, pattern, message) {
    if (sessionStorage.getItem(key)) return false
    var el = all('a, button, input[type="button"], input[type="submit"], [role="tab"], [role="menuitem"], [role="button"], li, span, label, div')
      .filter(visible)
      .filter(function (e) {
        var t = text(e) || e.value || ''
        return t.length < 60 && pattern.test(t)
      })
      .sort(function (a, b) { return text(a).length - text(b).length })[0]
    if (!el) return false
    sessionStorage.setItem(key, '1')
    send({ type: 'step', step: 'portal', message: message })
    ;(el.closest('a, button, input, [role="tab"], [role="menuitem"], [role="button"]') || el).click()
    await sleep(2500)
    await settle(30000)
    return true
  }

  /** Paso 2 → Finalizar trámite → Documentos. */
  async function openDocumentsSection() {
    var moved = false
    if (await clickOnce('tramix-paso2', /^\s*paso\s*2\b/i, 'Portal del IMSS · Paso 2')) moved = true
    if (await clickOnce('tramix-finalizar', /^\s*finalizar\s+tr[aá]mite\s*$/i, 'Portal del IMSS · Finalizar trámite')) moved = true
    if (await clickOnce('tramix-docs-tab', /^\s*documentos\s*$/i, 'Portal del IMSS · entrando a "Documentos"')) moved = true
    return moved
  }

  async function downloadDocuments() {
    var controls = downloadControls()
    if (!controls.length) return false
    send({ type: 'documents', count: Math.max(controls.length, namedDocumentCount()) })
    for (var i = 0; i < controls.length; i++) {
      var el = controls[i]
      if (el.tagName === 'A' && /\.pdf(\?|#|$)/i.test(el.href || '')) send({ type: 'pdf_url', url: el.href })
      else if (!(await submitForPdf(el))) el.click()
      await sleep(3000)
      await settle(20000)
    }
    await sleep(12000)
    send({ type: 'check_docs' })
    return true
  }

  async function portal(attempt) {
    if (!isRun || cfg.stage === 'manual') return
    if (!attempt) {
      send({ type: 'note', step: 'portal', message: 'Esperando a que el portal del IMSS cargue por completo' })
      // Slow page: never cancel. Native waits and reloads, then offers INTERVENIR.
      if (!(await waitLoaded(60000))) {
        send({ type: 'slow_page', step: 'portal' })
        return
      }
      await settle(25000)
    }
    var block = blocker()
    if (block) {
      send({ type: 'manual', reason: block })
      return
    }
    // Only now, with the page loaded and readable, the portal step is confirmed.
    send({ type: 'step', step: attempt ? 'navigate' : 'portal', message: attempt ? 'Navegando el portal del IMSS' : 'Portal del IMSS cargado' })
    // Preferred path: Paso 2 → Finalizar trámite → Documentos → each down-arrow icon.
    var openedDocs = await openDocumentsSection()
    block = blocker()
    if (block) {
      send({ type: 'manual', reason: block })
      return
    }
    if (window.__tramixRunHref !== location.href && !openedDocs) return
    if (await downloadDocuments()) return
    if (openedDocs) {
      await sleep(3000)
      if (await downloadDocuments()) return
    }
    var pdfLink = all('a[href]').filter(function (a) { return /\.pdf(\?|#|$)/i.test(a.href) })[0]
    if (pdfLink) {
      send({ type: 'pdf_url', url: pdfLink.href })
      return
    }
    var embed = document.querySelector('embed[type="application/pdf"], object[type="application/pdf"], iframe[src*=".pdf"]')
    if (embed && (embed.src || embed.data)) {
      send({ type: 'pdf_url', url: embed.src || embed.data })
      return
    }

    var key = 'tramix-clicked'
    var done = []
    try { done = JSON.parse(sessionStorage.getItem(key) || '[]') } catch (e) {}
    var candidates = all('a, button, input[type="button"], input[type="submit"]')
      .filter(visible)
      .map(function (el) { return { el: el, label: text(el).slice(0, 80) } })
      .filter(function (c) { return c.label && rank(c.label) > 0 && done.indexOf(c.label) < 0 && !NOT_DOWNLOAD.test(label(c.el)) })
      .sort(function (a, b) { return rank(b.label) - rank(a.label) })
    var next = candidates[0]
    if (!next || done.length >= 8) {
      var err = document.querySelector('.ui-messages-error, .alert-danger, .error, [role="alert"]')
      send({
        type: 'manual',
        reason: err && text(err)
          ? 'El IMSS respondió: ' + text(err).slice(0, 140) + '. Pulsa INTERVENIR.'
          : 'No encontré cómo obtener el PDF. Pulsa INTERVENIR para continuar en el portal.',
      })
      return
    }
    done.push(next.label)
    sessionStorage.setItem(key, JSON.stringify(done))
    send({ type: 'step', step: 'navigate', message: 'Portal IMSS: ' + next.label })
    if (rank(next.label) === 3 && (await submitForPdf(next.el))) return
    next.el.click()
    // JSF/AJAX steps update the page without navigating; look again.
    await sleep(2500)
    await settle(30000)
    if (window.__tramixRunHref === location.href) portal((attempt || 0) + 1)
  }

  if (isOutlook) outlook()
  else if (isImss) portal(0)
  else if (/microsoft\.com$|live\.com$/.test(host)) send({ type: 'signed_out' })
})()
