// Injected by the TRAMIX Android app into the official IMSS portal.
// Fills CURP, correo and confirmación only. The CAPTCHA is never read, solved or bypassed:
// the user types it, and CONTINUAR stays disabled until they do.
;(() => {
  if (window.__tramixImssLoaded) return
  window.__tramixImssLoaded = true

  const B = window.TramixImss
  if (!B) return
  const FIELD_TIMEOUT_MS = 120000
  const SUBMIT_FLAG = 'tramixImssSubmitted'

  const RX = {
    captcha:
      /captcha|codigo (de (la )?)?(imagen|seguridad|verificacion)|texto (de la )?imagen|caracteres|escrib[ae] el codigo|codigo que (se )?muestra/,
    curp: /\bcurp\b/,
    email: /correo|e-?mail|\bmail\b/,
    confirm: /confirm|repet|verific|vuelv|nuevamente|ratific|otra vez/,
    submit: /continuar|siguiente|aceptar|enviar|solicitar|buscar|consultar|validar/,
    notSubmit: /limpiar|cancelar|regresar|salir|borrar/,
    document: /descarg|imprim|\bpdf\b|constancia|comprobante|formato|obtener/,
    linkSent: /(le )?hemos enviado una liga|liga de confirmacion (a|en) su correo/,
  }

  const filledEls = new WeakSet()
  const filled = new Set()
  let job = null
  let fields = {}
  let captchaReady = false
  let submitted = false
  let ui = null

  const norm = (s) =>
    (s || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim()

  const report = (status, detail) => {
    try {
      B.report(status, JSON.stringify(detail || {}))
    } catch {}
  }

  // The portal may render the form inside same-origin frames.
  function docs() {
    const out = [document]
    for (let i = 0; i < out.length; i++) {
      for (const frame of out[i].querySelectorAll('iframe, frame')) {
        try {
          if (frame.contentDocument) out.push(frame.contentDocument)
        } catch {}
      }
    }
    return out
  }

  function visible(el) {
    const r = el.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return false
    const st = el.ownerDocument.defaultView.getComputedStyle(el)
    return st.visibility !== 'hidden' && st.display !== 'none'
  }

  function ownDescription(el) {
    const doc = el.ownerDocument
    const parts = [
      el.id,
      el.name,
      el.placeholder,
      el.title,
      el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname'),
      el.getAttribute('ng-model'),
    ]
    if (el.labels) for (const label of el.labels) parts.push(label.textContent)
    const labelledBy = el.getAttribute('aria-labelledby')
    if (labelledBy) for (const id of labelledBy.split(/\s+/)) parts.push(doc.getElementById(id)?.textContent)
    return norm(parts.filter(Boolean).join(' | '))
  }

  function contextText(el) {
    const parts = []
    let node = el.parentElement
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      if (node.querySelectorAll('input:not([type=hidden])').length > 1) break
      parts.push(node.textContent)
    }
    parts.push(el.previousElementSibling?.textContent, el.closest('td')?.previousElementSibling?.textContent)
    return norm(parts.filter(Boolean).join(' | ')).slice(0, 240)
  }

  function describe(el) {
    const own = ownDescription(el)
    if (RX.curp.test(own) || RX.email.test(own) || RX.captcha.test(own)) return own
    return `${own} | ${contextText(el)}`
  }

  function findFields() {
    const found = {}
    for (const doc of docs()) {
      const inputs = [
        ...doc.querySelectorAll(
          'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button]):not([type=image]):not([type=file]):not([type=password])',
        ),
      ].filter((el) => !el.disabled && !el.readOnly && visible(el))
      for (const el of inputs) {
        const d = describe(el)
        if (RX.captcha.test(d)) {
          found.captcha ??= el
        } else if (RX.curp.test(d)) {
          found.curp ??= el
        } else if (el.type === 'email' || RX.email.test(d)) {
          if (RX.confirm.test(d)) found.confirm ??= el
          else if (!found.email) found.email = el
          else found.confirm ??= el
        }
      }
    }
    return found
  }

  const widgetCaptcha = () => {
    for (const doc of docs()) {
      const el = doc.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, .h-captcha')
      if (el) return el
    }
    return null
  }

  function captchaSolved() {
    if (fields.captcha) return fields.captcha.value.trim().length >= 3
    for (const doc of docs()) {
      const token = doc.querySelector('textarea[name="g-recaptcha-response"], textarea[name="h-captcha-response"]')
      if (token && token.value.trim()) return true
    }
    return false
  }

  const hasCaptcha = () => Boolean(fields.captcha || widgetCaptcha())

  function setValue(el, value) {
    const win = el.ownerDocument.defaultView
    el.focus()
    const proto = el instanceof win.HTMLTextAreaElement ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value)
    el.dispatchEvent(new win.Event('input', { bubbles: true }))
    el.dispatchEvent(new win.Event('change', { bubbles: true }))
    el.dispatchEvent(new win.KeyboardEvent('keyup', { bubbles: true }))
    el.blur()
  }

  const label = (b) => norm(b.textContent || b.value)

  function findSubmit() {
    const anchor = fields.email || fields.curp
    const scope = anchor?.form || anchor?.ownerDocument || document
    const buttons = [
      ...scope.querySelectorAll('button, input[type=submit], input[type=button], a.btn, a[role=button]'),
    ].filter((b) => visible(b) && !b.closest('#tramix-imss-assistant'))
    const usable = buttons.filter((b) => !RX.notSubmit.test(label(b)))
    return usable.find((b) => RX.submit.test(label(b))) || usable.find((b) => b.type === 'submit') || null
  }

  function markSubmitted() {
    if (submitted) return
    submitted = true
    try {
      sessionStorage.setItem(SUBMIT_FLAG, '1')
    } catch {}
    report('submitted')
    render()
  }

  // The IMSS answers an accepted form with a green notice: "...le hemos enviado una liga de
  // confirmación a su correo electrónico." That text, not the click, is what marks the trámite as sent.
  let linkSent = false
  function linkSentText() {
    for (const doc of docs()) {
      if (RX.linkSent.test(norm(doc.body?.innerText || ''))) return true
    }
    return false
  }

  function watchLinkSent() {
    if (!job || linkSent) return false
    if (!linkSentText()) return false
    linkSent = true
    captchaReady = true
    markSubmitted()
    report('link_sent', { message: 'Para continuar con su trámite le hemos enviado una liga de confirmación a su correo electrónico.' })
    render()
    return true
  }

  function tryFill() {
    if (!job) return
    if (linkSent || watchLinkSent()) return
    fields = findFields()
    const changed = []
    const fill = (key, el, value) => {
      if (!el || filledEls.has(el)) return
      if (norm(el.value) !== norm(value)) setValue(el, value)
      filledEls.add(el)
      filled.add(key)
      changed.push(key)
    }
    fill('curp', fields.curp, job.curp)
    fill('email', fields.email, job.email)
    fill('confirm', fields.confirm, job.email)
    if (!changed.length) return

    // Form shown again after a submit means the IMSS rejected it (often a wrong CAPTCHA).
    let retry = false
    try {
      retry = sessionStorage.getItem(SUBMIT_FLAG) === '1'
      sessionStorage.removeItem(SUBMIT_FLAG)
    } catch {}
    submitted = false
    captchaReady = false
    report('filled', { fields: [...filled], hasCaptcha: hasCaptcha(), retry })
    mountUi()
    render()
    const target = fields.captcha || widgetCaptcha()
    target?.scrollIntoView({ block: 'center', behavior: 'smooth' })
    if (fields.captcha) setTimeout(() => fields.captcha?.focus(), 300)
  }

  function watchCaptcha() {
    if (!filled.size || submitted) return
    const ready = captchaSolved()
    if (ready && !captchaReady) report('captcha_ready')
    if (ready !== captchaReady) {
      captchaReady = ready
      render()
    }
  }

  function mountUi() {
    if (ui) return
    const host = document.createElement('div')
    host.id = 'tramix-imss-assistant'
    host.style.cssText =
      'all:initial;position:fixed;left:0;right:0;bottom:0;z-index:2147483647;display:flex;justify-content:center;padding:10px;pointer-events:none;'
    const root = host.attachShadow({ mode: 'open' })
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; margin: 0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
        .card { pointer-events: auto; width: 100%; max-width: 440px; display: flex; flex-direction: column; gap: 10px;
          padding: 14px; border-radius: 20px; background: rgba(15, 23, 42, 0.95); color: #f8fafc;
          box-shadow: 0 12px 40px rgba(2, 6, 23, 0.45); border: 1px solid rgba(148, 163, 184, 0.2); }
        .card.min ul, .card.min .msg { display: none; }
        .head { display: flex; align-items: center; gap: 8px; }
        .brand { font-size: 11px; font-weight: 800; letter-spacing: 0.12em; color: #60a5fa; }
        .title { flex: 1; font-size: 13px; font-weight: 600; }
        .x { all: unset; cursor: pointer; min-width: 44px; height: 32px; display: grid; place-items: center; border-radius: 8px; color: #94a3b8; font-size: 12px; font-weight: 700; }
        ul { list-style: none; padding: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        li { display: flex; align-items: center; gap: 8px; font-size: 12px; padding: 7px 8px; border-radius: 10px; background: rgba(148, 163, 184, 0.12); color: #cbd5e1; }
        li::before { content: ""; flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; border: 1.5px solid currentColor; }
        li.done { background: rgba(34, 197, 94, 0.16); color: #86efac; }
        li.done::before { width: 4px; height: 8px; margin: 0 2px 2px; border-radius: 0; border-width: 0 2px 2px 0; transform: rotate(45deg); }
        li.manual { background: rgba(250, 204, 21, 0.14); color: #fde68a; }
        .msg { font-size: 13px; line-height: 1.45; color: #e2e8f0; }
        .go { all: unset; cursor: pointer; text-align: center; height: 48px; line-height: 48px; border-radius: 12px;
          background: #2563eb; color: #fff; font-size: 15px; font-weight: 700; letter-spacing: 0.04em; }
        .go[disabled] { opacity: 0.45; cursor: not-allowed; }
        .go:not([disabled]):active { transform: scale(0.98); }
      </style>
      <div class="card" role="status" aria-live="polite">
        <div class="head">
          <span class="brand">TRAMIX</span>
          <span class="title">IMSS — NSS</span>
          <button class="x" type="button" aria-label="Minimizar asistente">MENOS</button>
        </div>
        <ul>
          <li data-k="curp">CURP</li>
          <li data-k="email">Correo</li>
          <li data-k="confirm">Confirmación</li>
          <li data-k="captcha">CAPTCHA (manual)</li>
        </ul>
        <p class="msg"></p>
        <button class="go" type="button" disabled>CONTINUAR</button>
      </div>`
    const card = root.querySelector('.card')
    const toggle = root.querySelector('.x')
    toggle.addEventListener('click', () => {
      card.classList.toggle('min')
      toggle.textContent = card.classList.contains('min') ? 'MÁS' : 'MENOS'
    })
    root.querySelector('.go').addEventListener('click', () => {
      const button = findSubmit()
      if (!button) {
        root.querySelector('.msg').textContent = 'Pulsa el botón del portal para continuar.'
        return
      }
      markSubmitted()
      button.click()
    })
    document.documentElement.appendChild(host)
    ui = root
  }

  function render() {
    if (!ui) return
    for (const li of ui.querySelectorAll('li')) {
      const key = li.dataset.k
      const done = key === 'captcha' ? captchaReady || !hasCaptcha() : filled.has(key)
      li.className = done ? 'done' : key === 'captcha' ? 'manual' : ''
    }
    const go = ui.querySelector('.go')
    const msg = ui.querySelector('.msg')
    if (submitted) {
      msg.textContent = 'Formulario enviado. Regresando a TRAMIX; el documento se descargará automáticamente.'
      go.disabled = true
    } else if (hasCaptcha() && !captchaReady) {
      msg.textContent = 'Datos colocados. Escribe el CAPTCHA en la página y después pulsa CONTINUAR.'
      go.disabled = true
    } else {
      msg.textContent = hasCaptcha()
        ? 'CAPTCHA listo. Pulsa CONTINUAR para enviar el formulario.'
        : 'Datos colocados. Revisa y pulsa CONTINUAR.'
      go.disabled = false
    }
  }

  function filenameFrom(disposition, fallback) {
    const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(disposition || '')
    if (!m) return fallback
    try {
      return decodeURIComponent(m[1])
    } catch {
      return m[1]
    }
  }

  function sendBlob(blob, name) {
    const reader = new FileReader()
    reader.onload = () => B.saveDataUrl(name, blob.type || '', reader.result)
    reader.onerror = () => B.downloadFailed('No se pudo leer el documento')
    reader.readAsDataURL(blob)
  }

  // JSF "Descargar/Imprimir" buttons POST the form and answer with a PDF, which a WebView
  // can't hand to its download listener. Replay that POST with the session cookies and keep the file.
  const bypass = new WeakSet()
  function interceptDocumentButton(event) {
    const btn = event.target instanceof Element && event.target.closest('button, input[type=submit], input[type=image]')
    if (!btn || bypass.has(btn) || btn.closest('#tramix-imss-assistant')) return
    const form = btn.form
    if (!form || (btn.type && btn.type !== 'submit' && btn.type !== 'image')) return
    if (!RX.document.test(label(btn) || norm(btn.title) || norm(btn.alt))) return
    if (fields.curp && form.contains(fields.curp)) return

    event.preventDefault()
    event.stopImmediatePropagation()
    const data = new FormData(form)
    if (btn.name) data.append(btn.name, btn.value || '')
    const multipart = (form.enctype || '').includes('multipart')
    const method = (form.method || 'post').toUpperCase()
    const action = form.action || location.href
    const request =
      method === 'GET'
        ? fetch(`${action.split('?')[0]}?${new URLSearchParams(data)}`, { credentials: 'include' })
        : fetch(action, { method, credentials: 'include', body: multipart ? data : new URLSearchParams(data) })

    request
      .then((res) => {
        const type = (res.headers.get('content-type') || '').toLowerCase()
        const disposition = res.headers.get('content-disposition') || ''
        if (type.includes('pdf') || type.includes('octet-stream') || /attachment/i.test(disposition)) {
          return res.blob().then((blob) => sendBlob(blob, filenameFrom(disposition, 'constancia-nss.pdf')))
        }
        bypass.add(btn)
        btn.click()
      })
      .catch(() => {
        bypass.add(btn)
        btn.click()
      })
  }

  // After the IMSS accepts the form, TRAMIX is back in front; this keeps working in the
  // background: it relays the portal's answer and requests the generated document once.
  const AUTO_DOC_WINDOW_MS = 180000
  const MAX_DOC_ATTEMPTS = 4
  const DOC_CONTAINER = /pdf|reporte|constancia|documento|formato|comprobante/i
  const tried = new WeakSet()
  let docAttempts = 0
  let lastMessage = ''

  function afterSubmit() {
    if (submitted) return true
    try {
      return sessionStorage.getItem(SUBMIT_FLAG) === '1' && !filled.size
    } catch {
      return false
    }
  }

  function imssMessage() {
    const selector =
      '[role=alert], .ui-messages, .ui-message, .ui-growl-message, .alert, .mensaje, .mensajes, .error, .exito'
    for (const doc of docs()) {
      for (const el of doc.querySelectorAll(selector)) {
        if (el.closest('#tramix-imss-assistant') || !visible(el)) continue
        const text = (el.textContent || '').replace(/\s+/g, ' ').trim()
        if (text.length > 3) return text.slice(0, 280)
      }
    }
    return ''
  }

  function fetchDocument(url, fallbackName) {
    return fetch(url, { credentials: 'include' })
      .then((res) => {
        const type = (res.headers.get('content-type') || '').toLowerCase()
        const disposition = res.headers.get('content-disposition') || ''
        const isFile = type.includes('pdf') || type.includes('octet-stream') || /attachment/i.test(disposition)
        if (!res.ok || !isFile) return false
        return res.blob().then((blob) => {
          sendBlob(blob, filenameFrom(disposition, fallbackName))
          return true
        })
      })
      .catch(() => false)
  }

  function inCurpForm(el) {
    const form = el.closest('form')
    return Boolean(form && fields.curp && form.contains(fields.curp))
  }

  function autoDocument() {
    if (!afterSubmit() || docAttempts >= MAX_DOC_ATTEMPTS) return
    const message = imssMessage()
    if (message && message !== lastMessage) {
      lastMessage = message
      report('imss_response', { message })
    }
    for (const doc of docs()) {
      for (const el of doc.querySelectorAll('iframe[src], embed[src], object[data]')) {
        const src = el.getAttribute('src') || el.getAttribute('data') || ''
        if (tried.has(el) || !DOC_CONTAINER.test(`${src} ${el.getAttribute('type') || ''}`)) continue
        tried.add(el)
        docAttempts++
        report('document_requested')
        fetchDocument(new URL(src, doc.baseURI).href, 'constancia-nss.pdf')
        return
      }
      const target = [
        ...doc.querySelectorAll('a[href], button, input[type=submit], input[type=button], input[type=image]'),
      ].find(
        (el) =>
          visible(el) &&
          !tried.has(el) &&
          !el.closest('#tramix-imss-assistant') &&
          !inCurpForm(el) &&
          RX.document.test(`${label(el)} ${norm(el.title)} ${norm(el.alt)} ${norm(el.getAttribute('href'))}`),
      )
      if (!target) continue
      tried.add(target)
      docAttempts++
      report('document_requested')
      const href = target.tagName === 'A' ? target.href : ''
      if (/^https:/i.test(href)) fetchDocument(href, 'constancia-nss.pdf').then((ok) => ok || target.click())
      else target.click()
      return
    }
  }

  function loadJob() {
    try {
      const raw = B.getJob()
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  }

  function init() {
    job = loadJob()
    if (!job) return

    tryFill()
    let pending = null
    const observe = (doc) =>
      new MutationObserver(() => {
        clearTimeout(pending)
        pending = setTimeout(tryFill, 150)
      }).observe(doc.documentElement, { childList: true, subtree: true })
    observe(document)
    setInterval(watchCaptcha, 600)
    setInterval(tryFill, 1500)
    setInterval(watchLinkSent, 700)

    document.addEventListener('click', interceptDocumentButton, true)
    document.addEventListener(
      'click',
      (event) => {
        if (!filled.size || !captchaReady) return
        const button = findSubmit()
        if (button && event.composedPath().includes(button)) markSubmitted()
      },
      true,
    )

    let alreadySubmitted = false
    try {
      alreadySubmitted = sessionStorage.getItem(SUBMIT_FLAG) === '1'
    } catch {}
    setTimeout(() => {
      if (!filled.size && !alreadySubmitted) report('fields_not_found')
    }, FIELD_TIMEOUT_MS)

    const docLoop = setInterval(autoDocument, 2000)
    setTimeout(() => clearInterval(docLoop), AUTO_DOC_WINDOW_MS)
  }

  init()
})()
