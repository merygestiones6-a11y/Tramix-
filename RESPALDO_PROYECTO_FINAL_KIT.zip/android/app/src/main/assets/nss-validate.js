// Injected by the TRAMIX Android app ("NO DERECHO IMSS") into the official IMSS portal.
// It types CURP and correos, copies the portal's own CAPTCHA image so the user can read it
// inside TRAMIX, and types exactly what the user wrote. The CAPTCHA is never read or solved here.
// Later official steps (domicilio, etc.) are shown to the user inside TRAMIX to complete by hand.
;(() => {
  if (window.__tramixNssLoaded) return
  window.__tramixNssLoaded = true

  const B = window.TramixNss
  if (!B) return
  const FLOW_KEY = 'tramixNoDerechoFlow'
  const FIELD_TIMEOUT_MS = 45000
  const RESULT_TIMEOUT_MS = 60000

  const RX = {
    captcha:
      /captcha|codigo (de (la )?)?(imagen|seguridad|verificacion)|texto (de la )?imagen|caracteres|escrib[ae] el codigo|codigo que (se )?muestra/,
    curp: /\bcurp\b/,
    nss: /\bnss\b|seguridad social/,
    vigenciaSent: /(constancia|vigencia|informacion|documento|solicitud)[^.]{0,120}(enviad|envio|remiti)[^.]{0,60}correo/,
    email: /correo|e-?mail|\bmail\b/,
    confirm: /confirm|repet|verific|vuelv|nuevamente|ratific|otra vez/,
    submit: /continuar|siguiente|aceptar|enviar|solicitar|buscar|consultar|validar/,
    notSubmit: /limpiar|cancelar|regresar|salir|borrar/,
    refresh: /actualiz|recarg|otra imagen|otro codigo|nueva imagen|cambiar (imagen|codigo)|refresh|reload/,
    document: /descarg|imprim|\bpdf\b|constancia|comprobante/,
    linkSent: /(le )?hemos enviado una liga|liga de confirmacion (a|en) su correo/,
    notFound: /no (se )?(encontr|localiz|exist)|no cuenta con (un )?(nss|numero)|sin (registro|nss)|no se tiene registro|no esta registrad/,
    wrongCaptcha: /captcha|codigo (de (la )?)?(imagen|seguridad|verificacion)|caracteres de la imagen|codigo incorrecto/,
    incomplete: /no has llenado|no ha llenado|llena(do)? todos los campos|campos? (son )?(obligatori|requerid)|campo requerido|es obligatorio/,
  }

  let job = null
  let fields = {}
  let lastCaptchaKey = ''
  let lastStepKey = ''
  let finished = false
  let pdfReported = false

  const isVigencia = () => job?.service === 'vigencia' || /\/vigencia\b/i.test(location.pathname)
  const isConstancia = () => job?.service === 'constancia'

  const norm = (s) =>
    (s || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim()

  const report = (status, detail) => {
    try {
      B.report(status, JSON.stringify(detail || {}))
    } catch {}
  }

  // Flow state survives the portal's own page navigations (JSF posts, redirects).
  function flow() {
    try {
      return JSON.parse(sessionStorage.getItem(FLOW_KEY) || 'null')
    } catch {
      return null
    }
  }
  function setFlow(next) {
    try {
      if (next) sessionStorage.setItem(FLOW_KEY, JSON.stringify(next))
      else sessionStorage.removeItem(FLOW_KEY)
    } catch {}
  }

  function docs() {
    const out = [document]
    for (let i = 0; i < out.length; i++) {
      for (const frame of out[i].querySelectorAll('iframe, frame')) {
        try {
          if (frame.contentDocument) out.push(frame.contentDocument)
        } catch {}
      }
    }
    return out
  }

  function visible(el) {
    const r = el.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return false
    const st = el.ownerDocument.defaultView.getComputedStyle(el)
    return st.visibility !== 'hidden' && st.display !== 'none'
  }

  function ownDescription(el) {
    const doc = el.ownerDocument
    const parts = [el.id, el.name, el.placeholder, el.title, el.getAttribute('aria-label'), el.getAttribute('formcontrolname')]
    if (el.labels) for (const l of el.labels) parts.push(l.textContent)
    const labelledBy = el.getAttribute('aria-labelledby')
    if (labelledBy) for (const id of labelledBy.split(/\s+/)) parts.push(doc.getElementById(id)?.textContent)
    return norm(parts.filter(Boolean).join(' | '))
  }

  function contextText(el) {
    const parts = []
    let node = el.parentElement
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      if (node.querySelectorAll('input:not([type=hidden])').length > 1) break
      parts.push(node.textContent)
    }
    parts.push(el.previousElementSibling?.textContent, el.closest('td')?.previousElementSibling?.textContent)
    return norm(parts.filter(Boolean).join(' | ')).slice(0, 240)
  }

  function describe(el) {
    const own = ownDescription(el)
    if (RX.curp.test(own) || RX.email.test(own) || RX.captcha.test(own)) return own
    return `${own} | ${contextText(el)}`
  }

  const TEXT_INPUTS =
    'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button]):not([type=image]):not([type=file]):not([type=password])'

  function findFields() {
    const found = {}
    const unmatched = []
    for (const doc of docs()) {
      const inputs = [...doc.querySelectorAll(TEXT_INPUTS)].filter((el) => !el.disabled && !el.readOnly && visible(el))
      for (const el of inputs) {
        const d = describe(el)
        const own = ownDescription(el)
        if (isVigencia() && !found.nss && (RX.nss.test(own) || (!own && RX.nss.test(d))) && !RX.curp.test(own) && !RX.captcha.test(own)) found.nss = el
        else if (RX.captcha.test(d)) found.captcha ??= el
        else if (RX.curp.test(d)) found.curp ??= el
        else if (el.type === 'email' || RX.email.test(d)) {
          if (RX.confirm.test(d)) found.confirm ??= el
          else if (!found.email) found.email = el
          else found.confirm ??= el
        } else unmatched.push(el)
      }
    }
    // Vigencia's correo / confirmar correo boxes can lack labels the regexes recognise:
    // the remaining visible text boxes of the same form are those two fields, in order.
    if (isVigencia()) {
      const form = (found.captcha || found.curp || found.nss)?.form
      for (const el of unmatched) {
        if (form && el.form !== form) continue
        if (!found.email) found.email = el
        else if (!found.confirm) found.confirm = el
      }
    }
    return found
  }

  function widgetCaptcha() {
    for (const doc of docs()) {
      const el = doc.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, .h-captcha')
      if (el) return el
    }
    return null
  }

  // The WebView sits behind the TRAMIX page, so el.focus()/blur() never take effect and the
  // portal's validators (which listen to focus, key and blur events) would still see the
  // fields as empty. Every event is dispatched explicitly, character by character.
  function typeInto(el, value) {
    const win = el.ownerDocument.defaultView
    const setter = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value').set
    const fire = (type, Ctor = win.Event, init = {}) => el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, ...init }))
    try {
      el.focus({ preventScroll: true })
    } catch {}
    fire('focus', win.FocusEvent, { bubbles: false })
    fire('focusin', win.FocusEvent)
    setter.call(el, '')
    fire('input')
    let current = ''
    for (const ch of String(value)) {
      const code = ch.charCodeAt(0)
      const keyInit = { key: ch, char: ch, keyCode: code, which: code, charCode: code }
      fire('keydown', win.KeyboardEvent, keyInit)
      fire('keypress', win.KeyboardEvent, keyInit)
      current += ch
      setter.call(el, current)
      fire('input', win.InputEvent, { data: ch, inputType: 'insertText' })
      fire('keyup', win.KeyboardEvent, keyInit)
    }
    if (el.value !== value) setter.call(el, value)
    fire('change')
    fire('blur', win.FocusEvent, { bubbles: false })
    fire('focusout', win.FocusEvent)
    const $ = win.jQuery
    if ($) {
      try {
        $(el).trigger('change').trigger('blur')
      } catch {}
    }
    try {
      el.blur()
    } catch {}
    return norm(el.value) === norm(value)
  }

  const label = (b) => norm(b.textContent || b.value || b.title || b.alt || '')

  function fieldLabel(el) {
    const own = el.labels?.[0]?.textContent || el.getAttribute('aria-label') || el.placeholder || el.title || el.name || el.id
    return (own || contextText(el)).replace(/\s+/g, ' ').replace(/[*:]/g, '').trim().slice(0, 60)
  }

  // Visible required controls that the portal would still consider empty.
  function missingFields(scope) {
    const out = []
    const roots = scope ? [scope] : docs()
    for (const root of roots) {
      for (const el of root.querySelectorAll('input, select, textarea')) {
        if (el.type === 'hidden' || el.disabled || !visible(el)) continue
        const required =
          el.required || el.getAttribute('aria-required') === 'true' || /required|obligatori|ui-state-error|is-invalid|ng-invalid/i.test(el.className)
        if (!required) continue
        const empty = el.type === 'checkbox' || el.type === 'radio' ? !root.querySelector(`[name="${CSS.escape(el.name)}"]:checked`) : !el.value.trim()
        if (empty) out.push(fieldLabel(el))
      }
    }
    return [...new Set(out)].filter(Boolean).slice(0, 8)
  }

  function findSubmit() {
    const anchor = fields.captcha || fields.email || fields.curp
    const scope = anchor?.form || anchor?.ownerDocument || document
    const buttons = [...scope.querySelectorAll('button, input[type=submit], input[type=button], a.btn, a[role=button]')].filter(visible)
    const usable = buttons.filter((b) => !RX.notSubmit.test(label(b)) && !RX.refresh.test(label(b)))
    return usable.find((b) => RX.submit.test(label(b))) || usable.find((b) => b.type === 'submit') || null
  }

  // The CAPTCHA picture sits next to its input; logos and banners are skipped.
  function captchaImage() {
    const input = fields.captcha
    const isCandidate = (el) => visible(el) && !/logo|escudo|gob\.mx\/.*(header|footer)|banner/i.test(el.src || '')
    const named = (el) => /captcha|kaptcha|jcaptcha|imagen|codigo|code|seguridad/i.test(`${el.src || ''} ${el.id || ''} ${el.alt || ''} ${el.className || ''}`)
    if (input) {
      let node = input.parentElement
      for (let i = 0; node && i < 6; i++, node = node.parentElement) {
        const imgs = [...node.querySelectorAll('img, canvas')].filter(isCandidate)
        const pick = imgs.find(named) || imgs.find((el) => el.getBoundingClientRect().width >= 60)
        if (pick) return pick
      }
    }
    for (const doc of docs()) {
      const el = [...doc.querySelectorAll('img, canvas')].find((e) => isCandidate(e) && named(e) && /captcha/i.test(`${e.src || ''} ${e.id || ''}`))
      if (el) return el
    }
    return null
  }

  function snapshot(el) {
    try {
      if (el.tagName === 'CANVAS') return el.toDataURL('image/png')
      if (!el.complete || !el.naturalWidth) return null
      const canvas = document.createElement('canvas')
      canvas.width = el.naturalWidth
      canvas.height = el.naturalHeight
      canvas.getContext('2d').drawImage(el, 0, 0)
      return canvas.toDataURL('image/png')
    } catch {
      return 'tainted'
    }
  }

  function visibleMessages() {
    const selector =
      '[role=alert], .ui-messages, .ui-message, .ui-growl-message, .alert, .mensaje, .mensajes, .error, .exito, .msg, .modal.show .modal-body, .ui-dialog-content'
    const out = []
    for (const doc of docs()) {
      for (const el of doc.querySelectorAll(selector)) {
        if (!visible(el)) continue
        const text = (el.textContent || '').replace(/\s+/g, ' ').trim()
        if (text.length > 3) out.push(text.slice(0, 400))
      }
    }
    return out
  }

  function imssMessage() {
    return visibleMessages()[0] || ''
  }

  // CONSTANCIA keeps static notices (requisitos: "CURP y correo válido") always on screen. Only a message
  // that was not visible when CONTINUAR was pressed is the portal's answer to this request.
  function freshMessage(state) {
    const seen = new Set(state?.baseline || [])
    return visibleMessages().find((t) => !seen.has(t)) || ''
  }
  const responseMessage = (state) => (isConstancia() ? freshMessage(state || flow()) : imssMessage())

  const pageText = () => docs().map((d) => d.body?.innerText || '').join('\n')

  function fillEmails() {
    if (!job?.email) return
    for (const key of ['email', 'confirm']) {
      const el = fields[key]
      if (el && norm(el.value) !== norm(job.email)) typeInto(el, job.email)
    }
  }

  function publishCaptcha(force) {
    if (finished || flow()?.mode === 'steps') return
    fields = findFields()
    if (!fields.curp && !fields.email && !fields.captcha) return
    if (!flow()) fillEmails()
    if (!fields.captcha) {
      if (widgetCaptcha() && (force || lastCaptchaKey !== 'widget')) {
        lastCaptchaKey = 'widget'
        report('captcha_widget', { message: 'El portal pide resolver su verificación directamente.' })
      }
      return
    }
    const img = captchaImage()
    if (!img) return
    const key = `${img.currentSrc || img.src || 'canvas'}|${img.naturalWidth || img.width}`
    if (!force && key === lastCaptchaKey) return
    const image = snapshot(img)
    if (!image) return
    lastCaptchaKey = key
    if (image === 'tainted') {
      report('captcha_widget', { message: 'El portal no permite copiar su CAPTCHA; resuélvelo en la vista del portal.' })
      return
    }
    const prev = flow()
    setFlow(null)
    if (isConstancia()) {
      // Rejected only when the portal itself shows a new CAPTCHA message; otherwise it is a plain new code.
      const answer = prev ? freshMessage(prev) : ''
      const rejected = Boolean(answer) && RX.wrongCaptcha.test(norm(answer))
      if (prev && answer && !rejected) {
        // The portal answered this request with its own error (e.g. CURP no válida): end it with that reason.
        diag('response_error', { stage: 'response' })
        return report('result', { kind: 'error', stage: 'response', message: answer })
      }
      if (rejected) diag('captcha_rejected')
      report('captcha', { image, retry: rejected, resubmit: Boolean(prev) && !rejected, message: rejected ? answer : '', fields: Object.keys(fields) })
      return
    }
    const retry = Boolean(prev)
    const message = retry ? imssMessage() : ''
    report('captcha', { image, retry, message, fields: Object.keys(fields) })
  }

  const digits = (s) => (s || '').replace(/\D/g, '')

  function parseResult(text) {
    const flat = text.replace(/\s+/g, ' ')
    const nssMatch = /(?:\bnss\b|n[uú]mero de seguridad social)[^0-9]{0,60}((?:\d[\s-]?){11})/i.exec(flat)
    const nss = nssMatch ? digits(nssMatch[1]).slice(0, 11) : ''
    const nameMatch =
      /nombre(?: completo)?(?: del asegurado)?\s*:?\s*([A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ.' ]{4,90}?)(?=\s+(?:curp|nss|n[uú]mero|fecha|correo|sexo|domicilio|$))/i.exec(flat)
    const curpMatch = /\b([A-Z][AEIOUX][A-Z]{2}\d{6}[HMX][A-Z]{5}[A-Z0-9]\d)\b/.exec(flat.toUpperCase())
    return {
      nss: nss.length === 11 ? nss : '',
      name: nameMatch ? nameMatch[1].trim().toUpperCase() : '',
      curp: curpMatch ? curpMatch[1] : job?.curp || '',
    }
  }

  function documentSource() {
    for (const doc of docs()) {
      for (const el of doc.querySelectorAll('iframe[src], embed[src], object[data]')) {
        const src = el.getAttribute('src') || el.getAttribute('data') || ''
        if (/pdf|reporte|constancia|documento/i.test(src)) return { kind: 'embed', url: new URL(src, doc.baseURI).href }
      }
      const target = [...doc.querySelectorAll('a[href], button, input[type=submit], input[type=button]')].find(
        (el) => visible(el) && RX.document.test(`${label(el)} ${norm(el.getAttribute('href'))}`) && !RX.notSubmit.test(label(el)),
      )
      if (target) return { kind: 'control', el: target }
    }
    return null
  }

  function sendBlob(blob, name) {
    const reader = new FileReader()
    reader.onload = () => B.saveDataUrl(name, blob.type || 'application/pdf', reader.result)
    reader.onerror = () => B.downloadFailed('No se pudo leer el documento')
    reader.readAsDataURL(blob)
  }

  function download() {
    const src = documentSource()
    if (!src) return B.downloadFailed('El portal del IMSS todavía no muestra el PDF.')
    if (src.kind === 'control') return src.el.click()
    fetch(src.url, { credentials: 'include' })
      .then((res) => (res.ok ? res.blob() : Promise.reject(new Error(`HTTP ${res.status}`))))
      .then((blob) =>
        sendBlob(blob, job?.service === 'constancia' ? `${job?.curp || 'IMSS'}.pdf` : `${isVigencia() ? 'VIGENCIA' : 'NO_DERECHO'}_${job?.curp || 'IMSS'}.pdf`),
      )
      .catch((e) => B.downloadFailed(`No se pudo descargar el PDF: ${e.message}`))
  }

  function finish(detail) {
    if (finished) return
    finished = true
    setFlow(null)
    const hasPdf = Boolean(documentSource())
    report('result', { ...detail, hasPdf })
    if (hasPdf) {
      pdfReported = true
      setTimeout(download, 800)
    }
  }

  // A later official form (domicilio, datos complementarios…) that the user completes in the portal.
  function currentStepKey() {
    const inputs = docs().flatMap((d) => [...d.querySelectorAll('input, select, textarea')]).filter((el) => el.type !== 'hidden' && !el.disabled && visible(el))
    if (inputs.length === 0) return ''
    return `${location.pathname}|${inputs.map((el) => el.name || el.id).join(',')}`
  }

  function showStep(reason, missing) {
    const key = currentStepKey()
    if (!key || key === lastStepKey) return
    lastStepKey = key
    setFlow({ ...(flow() || {}), mode: 'steps', at: Date.now() })
    report('step', { reason, missing, message: responseMessage() })
  }

  function checkResult() {
    const state = flow()
    if (finished || !state) return
    // Applies on every page shape (form, result page without inputs…): a request never stays PROCESANDO.
    if (isConstancia() && state.mode === 'submitted' && Date.now() - (state.at || 0) > RESULT_TIMEOUT_MS) {
      return failConstancia('response', 'El portal del IMSS no respondió a la solicitud a tiempo.')
    }
    const text = pageText()
    const message = responseMessage(state)
    const n = norm(text)
    const nm = norm(message)

    const parsed = parseResult(text)
    // Vigencia echoes the NSS the user typed, so an NSS on the page does not mean the request was sent.
    if (parsed.nss && !isVigencia() && !isConstancia()) return finish({ kind: 'found', ...parsed, message })
    if (RX.linkSent.test(n) || (isVigencia() && RX.vigenciaSent.test(n))) {
      return finish({
        kind: 'link_sent',
        curp: job?.curp || '',
        email: job?.email || '',
        message: message || 'Para continuar con su trámite le hemos enviado una liga de confirmación a su correo electrónico.',
      })
    }
    if (message && RX.notFound.test(nm)) return finish({ kind: 'not_found', curp: job?.curp || '', message })

    const stillOnCaptchaForm = Boolean(findFields().captcha)
    if (isConstancia()) {
      // The generated constancia (embedded PDF, or a download control once the form is gone) is downloaded right away.
      const src = documentSource()
      if (src && (src.kind === 'embed' || !stillOnCaptchaForm)) return finish({ kind: 'document', curp: job?.curp || '', message })
    }
    if (stillOnCaptchaForm && state.mode !== 'steps') {
      if (message && RX.incomplete.test(nm)) return showStep('incomplete', missingFields())
      if (message && RX.wrongCaptcha.test(nm)) {
        publishCaptcha(true)
        return
      }
    }

    if (!pdfReported && documentSource()) {
      pdfReported = true
      report('pdf_available', { curp: parsed.curp, name: parsed.name })
    }

    if (!stillOnCaptchaForm || state.mode === 'steps') {
      if (state.mode !== 'steps' && Date.now() - (state.at || 0) > (isConstancia() ? 5000 : 1500)) showStep('next', missingFields())
      return
    }
    if (message && Date.now() - (state.at || 0) > 2500) return finish({ kind: 'error', curp: job?.curp || '', message })
    if (Date.now() - (state.at || 0) > RESULT_TIMEOUT_MS) {
      finish({ kind: 'error', curp: job?.curp || '', message: 'El IMSS no respondió a la consulta. Intenta de nuevo.' })
    }
  }

  function submit(curp, email, captcha, nss) {
    if (!job) return
    job.curp = curp
    job.email = email
    if (nss) {
      job.nss = nss
      job.service = 'vigencia'
    }
    finished = false
    lastStepKey = ''
    fields = findFields()
    if (!fields.captcha) return report('result', { kind: 'error', curp, message: 'El formulario del IMSS ya no está disponible. Pide otro código.' })
    const base = isConstancia() ? { baseline: visibleMessages() } : {}

    const typed = { curp: fields.curp ? typeInto(fields.curp, curp) : true }
    for (const key of ['email', 'confirm']) typed[key] = fields[key] ? typeInto(fields[key], email) : true
    // Vigencia always asks for the correo: never click CONTINUAR without the assigned account typed in.
    if (isVigencia() && !fields.email) typed.email = false
    if (isVigencia()) typed.nss = fields.nss && job.nss ? typeInto(fields.nss, job.nss) : false
    typed.captcha = typeInto(fields.captcha, captcha)

    const scope = fields.captcha.form || null
    const missing = missingFields(scope)
    const notTyped = Object.entries(typed)
      .filter(([, ok]) => !ok)
      .map(([k]) => ({ curp: 'CURP', nss: 'NSS', email: 'Correo', confirm: 'Confirmar correo', captcha: 'CAPTCHA' })[k])
    if (notTyped.length || missing.length) {
      setFlow({ mode: 'steps', at: Date.now(), ...base })
      lastStepKey = currentStepKey()
      return report('step', { reason: 'incomplete', missing: [...notTyped, ...missing] })
    }

    const button = findSubmit()
    if (!button) {
      setFlow({ mode: 'steps', at: Date.now(), ...base })
      lastStepKey = currentStepKey()
      return report('step', { reason: 'no_button', missing: [] })
    }
    setFlow({ mode: 'submitted', at: Date.now(), ...base })
    report('submitting')
    if (isConstancia() && fields.captcha.form) return void setTimeout(() => postConstancia(fields.captcha.form), 200)
    setTimeout(() => button.click(), 200)
  }

  // ---- CONSTANCIA IMSS ------------------------------------------------------------------------------
  // The portal's own continuar.js does: GET obtenerNonce → add hidden "nonce" → POST the form to
  // testimoniumObtinere. Sending exactly those requests here (with the CAPTCHA the user typed) lets the app
  // read the real answer: the PDF bytes, or the portal's HTML page with its message. Nothing is bypassed.
  // Diagnostics carry only the stage, HTTP status, content type, sizes and timings — never CURP or correo.
  const diag = (stage, info) => report('diag', { stage, ...(info || {}) })
  const STAGE = { nonce: 'la autorización del envío', submit: 'el envío de la solicitud', response: 'la respuesta del portal', download: 'la descarga del PDF' }

  function failConstancia(stage, message) {
    if (finished) return
    finished = true
    setFlow(null)
    diag('failed', { at: stage })
    report('result', { kind: 'error', stage, message })
  }

  async function timedFetch(url, init, ms) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), ms)
    try {
      return await fetch(url, { ...init, credentials: 'same-origin', signal: ctrl.signal })
    } finally {
      clearTimeout(timer)
    }
  }

  async function postConstancia(form) {
    const started = Date.now()
    let stage = 'nonce'
    try {
      diag('nonce_request')
      const nonceRes = await timedFetch(new URL('obtenerNonce', location.href).href, { method: 'GET' }, 30000)
      diag('nonce_response', { http: nonceRes.status, ms: Date.now() - started })
      if (!nonceRes.ok) return failConstancia(stage, `El portal del IMSS no autorizó el envío (HTTP ${nonceRes.status}). Intenta de nuevo.`)
      const nonce = (await nonceRes.json().catch(() => null))?.nonce
      if (!nonce) return failConstancia(stage, 'El portal del IMSS no entregó la clave de envío. Intenta de nuevo.')

      stage = 'submit'
      const body = new URLSearchParams()
      for (const [k, v] of new FormData(form)) if (typeof v === 'string') body.append(k, v)
      body.set('nonce', nonce)
      diag('submit_request', { fields: [...new Set(body.keys())].length })
      const res = await timedFetch(
        new URL('testimoniumObtinere', location.href).href,
        { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } },
        60000,
      )
      const type = (res.headers.get('content-type') || '').toLowerCase()
      const buf = await res.arrayBuffer()
      const head = new Uint8Array(buf, 0, Math.min(5, buf.byteLength))
      const isPdf = String.fromCharCode(...head) === '%PDF-'
      diag('submit_response', { http: res.status, type: type.split(';')[0], bytes: buf.byteLength, pdf: isPdf, ms: Date.now() - started })

      if (isPdf) {
        // The constancia of this request: saved by the app as CURP.pdf after it validates the bytes again.
        stage = 'download'
        finished = true
        pdfReported = true
        setFlow(null)
        report('pdf_available', {})
        return sendBlob(new Blob([buf], { type: 'application/pdf' }), `${job?.curp || 'IMSS'}.pdf`)
      }
      if (/pdf|octet-stream/.test(type)) return failConstancia('download', 'El portal envió un archivo, pero no es un PDF válido.')
      if (!res.ok) return failConstancia(stage, `El portal del IMSS respondió con error HTTP ${res.status}.`)

      // An HTML answer (message, CAPTCHA incorrecto, liga enviada…) is shown exactly as the portal sent it,
      // and the normal result checks read it.
      stage = 'response'
      const charset = /charset=([\w-]+)/.exec(type)?.[1] || 'utf-8'
      let html
      try {
        html = new TextDecoder(charset).decode(buf)
      } catch {
        html = new TextDecoder('utf-8').decode(buf)
      }
      if (!html.trim()) return failConstancia(stage, 'El portal del IMSS respondió vacío. Intenta de nuevo.')
      if (res.url && res.url !== location.href) {
        try {
          history.replaceState(null, '', res.url)
        } catch {}
      }
      lastCaptchaKey = ''
      setFlow({ ...(flow() || {}), mode: 'submitted', at: Date.now() })
      document.open()
      document.write(html)
      document.close()
      watchDocuments()
      diag('response_rendered')
    } catch (e) {
      const timeout = e?.name === 'AbortError'
      failConstancia(stage, timeout ? `Tiempo de espera agotado durante ${STAGE[stage]}.` : `Falló ${STAGE[stage]}: ${e?.message || 'error de red'}.`)
    }
  }

  function refresh() {
    fields = findFields()
    const img = captchaImage()
    const scope = img?.parentElement?.parentElement || document
    const control = [...scope.querySelectorAll('a, button, img, input[type=image], span[onclick]')].find(
      (el) => el !== img && visible(el) && RX.refresh.test(norm(`${el.title || ''} ${el.alt || ''} ${el.textContent || ''} ${el.id || ''} ${el.className || ''}`)),
    )
    lastCaptchaKey = ''
    setFlow(null)
    if (control) {
      control.click()
      setTimeout(() => publishCaptcha(true), 900)
    } else {
      location.reload()
    }
  }

  // The user finished a step by hand in the portal: keep watching for the result.
  function resume() {
    const state = flow()
    if (state) setFlow({ ...state, mode: 'submitted', at: Date.now() })
    lastStepKey = currentStepKey()
  }

  window.__tramixNss = { submit, refresh, download, resume }

  // RECEPTOR DE DOCUMENTOS: the exact e-mail link was opened here. Only read what the page shows and
  // download its documents; a CAPTCHA, verification or block is left to the user, never bypassed.
  const RECEIVER_KEY = 'tramixReceiver'
  const RECEIVER_WAIT_MS = 90000
  const NOT_DOWNLOAD = /sobre|envelope|correo|mail|enviar|send|imprim|print/
  const IS_DOWNLOAD = /descarg|download|arrow-?down|arrowthick-1-s|arrowthickstop-1-s|arrowstop-1-s|fa-arrow-down|glyphicon-download|file-pdf|fa-file-pdf/
  const BLOCKED = /captcha|recaptcha|verifica que no eres|no soy un robot|acceso denegado|forbidden|\b403\b/

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
  /** Resolves as soon as `ready()` is true, or after `maxMs` at most (the old fixed wait). */
  async function waitFor(ready, maxMs, stepMs = 150) {
    const end = Date.now() + maxMs
    for (;;) {
      try {
        if (ready()) return true
      } catch {}
      if (Date.now() >= end) return false
      await sleep(stepMs)
    }
  }
  const resourceCount = () => {
    try {
      return performance.getEntriesByType('resource').length
    } catch {
      return 0
    }
  }
  const textOf = (el) => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim()
  const tagOf = (el) =>
    norm([textOf(el), el.getAttribute('title'), el.getAttribute('alt'), el.getAttribute('aria-label'), typeof el.className === 'string' ? el.className : '', el.getAttribute('src')].join(' '))

  function receiverState() {
    let s = null
    try {
      s = JSON.parse(sessionStorage.getItem(RECEIVER_KEY) || 'null')
    } catch {}
    if (!s || s.jobId !== job.id) s = { jobId: job.id, startedAt: Date.now(), clicked: [], downloaded: [], done: false }
    return s
  }
  const saveReceiver = (s) => sessionStorage.setItem(RECEIVER_KEY, JSON.stringify(s))

  function receiverPageText() {
    return docs().map((d) => textOf(d.body || d.documentElement || {})).join(' ').trim()
  }

  /** Down-arrow download icons only (never the envelope or print icons). */
  function receiverControls() {
    const found = []
    for (const doc of docs()) {
      for (const el of doc.querySelectorAll('a, button, input[type="button"], input[type="image"], input[type="submit"], [role="button"], img, i, span')) {
        if (!visible(el)) continue
        const target = el.closest('a, button, [role="button"], input') || el
        const tag = `${tagOf(el)} ${tagOf(target)}`
        const pdfHref = target.tagName === 'A' && /\.pdf(\?|#|$)/i.test(target.href || '')
        if (!pdfHref && !IS_DOWNLOAD.test(tag)) continue
        if (NOT_DOWNLOAD.test(tag) || /^\s*documentos?\s*$/i.test(textOf(el))) continue
        if (found.some((f) => f === target || f.contains(target) || target.contains(f))) continue
        found.push(target)
      }
    }
    return found.slice(0, 6)
  }

  /** Paso 2 → Finalizar trámite → Documentos, each clicked once. */
  function enterDocuments(s) {
    const steps = [
      ['paso2', /^\s*paso\s*2\b/i],
      ['finalizar', /^\s*finalizar\s+tr[aá]mite\s*$/i],
      ['documentos', /^\s*documentos\s*$/i],
    ]
    for (const [key, pattern] of steps) {
      if (s.clicked.includes(key)) continue
      const el = docs()
        .flatMap((d) => [...d.querySelectorAll('a, button, input[type="button"], input[type="submit"], [role="tab"], [role="button"], li, span, label')])
        .filter((e) => visible(e) && textOf(e).length < 60 && pattern.test(textOf(e) || e.value || ''))
        .sort((a, b) => textOf(a).length - textOf(b).length)[0]
      if (!el) continue
      s.clicked.push(key)
      saveReceiver(s)
      ;(el.closest('a, button, input, [role="tab"], [role="button"]') || el).click()
      return true
    }
    return false
  }

  async function fetchPdf(url, name) {
    try {
      const res = await fetch(url, { credentials: 'include' })
      if (!res.ok) return false
      const blob = await res.blob()
      if (!/pdf|octet-stream/i.test(blob.type || res.headers.get('content-type') || '')) return false
      sendBlob(blob, name)
      return true
    } catch {
      return false
    }
  }

  /** The message the page shows instead of documents (blocked trámite, acudir a subdelegación…). */
  function pageMessage() {
    for (const doc of docs()) {
      const box = [...doc.querySelectorAll('.ui-messages-error, .ui-messages-info, .ui-messages-warn, .alert, .mensaje, .error, [role="alert"], h1, h2, h3')]
        .filter(visible)
        .map(textOf)
        .filter((t) => t.length > 12)
      if (box.length) return box.slice(0, 3).join(' · ')
    }
    return receiverPageText().slice(0, 400) || document.title || 'La página no mostró documentos.'
  }

  async function receiver() {
    const s = receiverState()
    saveReceiver(s)
    if (s.done) return
    // Wait until the page has fully loaded before reading it.
    await waitFor(() => document.readyState === 'complete', 60000, 200)
    // Continue as soon as the page shows something to act on (documents, a step, a block or text).
    const blocked = () => BLOCKED.test(norm(receiverPageText())) || widgetCaptcha()
    await waitFor(() => receiverControls().length > 0 || blocked() || receiverPageText().length > 40, 2500)
    let warned = false
    while (Date.now() - s.startedAt < RECEIVER_WAIT_MS || s.downloaded.length) {
      // CAPTCHA, verification or block: never solved here. The user completes it on screen, then this continues.
      if (blocked()) {
        if (!warned) report('manual', { message: 'INTERVENCIÓN MANUAL REQUERIDA: completa la verificación en la página; el receptor continúa después.' })
        warned = true
        s.startedAt = Date.now()
        saveReceiver(s)
        await waitFor(() => !blocked(), 3000, 300)
        continue
      }
      if (warned) {
        warned = false
        report('resumed', {})
      }
      const controls = receiverControls()
      const pending = controls.filter((_, i) => !s.downloaded.includes(i))
      if (controls.length && !pending.length) break
      if (pending.length) {
        report('documents', { count: controls.length })
        for (let i = 0; i < controls.length; i++) {
          if (s.downloaded.includes(i)) continue
          const el = controls[i]
          s.downloaded.push(i)
          saveReceiver(s)
          const name = `documento-imss-${i + 1}.pdf`
          if (el.tagName === 'A' && el.href && !el.href.startsWith('javascript:') && (await fetchPdf(el.href, name))) continue
          // The WebView download listener saves what the portal returns. Wait until the portal
          // answers the click (or the previous fixed 3.5 s) before the next document, never both at once.
          const before = resourceCount()
          el.click()
          if (await waitFor(() => resourceCount() > before, 3500)) await sleep(300)
        }
        break
      }
      const beforeText = receiverPageText()
      if (enterDocuments(s)) {
        // Next step as soon as the section has actually changed and finished loading.
        await waitFor(() => document.readyState === 'complete' && receiverPageText() !== beforeText, 3500)
        await sleep(250)
        continue
      }
      await sleep(400)
    }
    s.done = true
    saveReceiver(s)
    if (!s.downloaded.length) report('page_message', { message: pageMessage() })
  }

  // document.open() clears listeners, so this runs again after an HTML answer is rendered.
  function watchDocuments() {
    for (const doc of docs()) {
      doc.addEventListener('load', (e) => e.target?.tagName === 'IMG' && setTimeout(() => publishCaptcha(false), 100), true)
      doc.addEventListener('click', (e) => {
        if (flow()?.mode === 'steps' && e.target?.closest?.('button, input[type=submit], input[type=button], a')) setTimeout(resume, 300)
      }, true)
    }
  }

  function init() {
    try {
      job = JSON.parse(B.getJob() || 'null')
    } catch {
      job = null
    }
    if (!job) return
    if (job.mode === 'receiver') return void receiver()
    // An emailed confirmation link opened inside TRAMIX continues the same trámite.
    if (job.continuing && !flow()) setFlow({ mode: 'submitted', at: Date.now() })
    publishCaptcha(false)
    setInterval(() => publishCaptcha(false), 1200)
    setInterval(checkResult, 700)
    watchDocuments()
    setTimeout(() => {
      if (!lastCaptchaKey && !finished && !flow()) {
        const text = (document.body?.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 300)
        report('fields_not_found', { message: text || document.title || 'El portal no mostró el formulario.' })
      }
    }, FIELD_TIMEOUT_MS)
  }

  init()
})()
