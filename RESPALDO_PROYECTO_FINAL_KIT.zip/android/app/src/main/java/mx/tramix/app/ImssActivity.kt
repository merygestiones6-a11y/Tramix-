package mx.tramix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.concurrent.Executors

/**
 * Hosts the official IMSS portal in a WebView. An injected script fills CURP, correo
 * and confirmación; the CAPTCHA is left for the user. Downloads are captured and handed
 * back to TRAMIX. Nothing here reads or answers the CAPTCHA.
 */
class ImssActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var store: DocumentStore
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val portalScript by lazy { assets.open("imss-android.js").bufferedReader().use { it.readText() } }

    @Volatile private var currentHost: String? = null
    private var submitted = false
    private var documentSaved = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val job = ImssSession.job
        if (job == null) {
            finish()
            return
        }
        ImssSession.portal = WeakReference(this)
        store = DocumentStore(this)
        buildLayout()

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.addJavascriptInterface(PortalBridge(), "TramixImss")
        web.webViewClient = PortalClient()
        web.webChromeClient = PortalChrome()
        web.setDownloadListener { url, userAgent, disposition, mime, _ -> onDownload(url, userAgent, disposition, mime) }

        setStatus("Cargando el portal oficial del IMSS…")
        web.loadUrl(PORTAL_URL)
    }

    private fun buildLayout() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val primary = getColor(R.color.tramix_primary)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(getColor(R.color.tramix_background))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(14), dp(6))
        }
        val back = TextView(this).apply {
            text = "‹  TRAMIX"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(primary)
            setPadding(dp(10), dp(10), dp(14), dp(10))
            contentDescription = "Volver a TRAMIX"
            isClickable = true
            setOnClickListener { goToTramix() }
        }
        val title = TextView(this).apply {
            text = "IMSS — NSS · portal oficial"
            textSize = 13f
            setTextColor(getColor(R.color.tramix_muted))
            gravity = Gravity.END
        }
        bar.addView(back)
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(getColor(R.color.tramix_foreground))
            setBackgroundColor(Color.argb(24, Color.red(primary), Color.green(primary), Color.blue(primary)))
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(primary)
        }
        web = WebView(this)

        root.addView(bar)
        root.addView(status)
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun setStatus(text: String) {
        status.text = text
    }

    /** The portal WebView stays alive behind TRAMIX so the IMSS session can still deliver the document. */
    private fun goToTramix() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private fun bringPortalToFront() {
        startActivity(Intent(this, ImssActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    private fun isImssHost(host: String?) = host != null && (host == "imss.gob.mx" || host.endsWith(".imss.gob.mx"))

    /** reCAPTCHA and gob.mx assets must load in-frame; everything else opens outside. */
    private fun isAllowedNavigation(uri: Uri): Boolean {
        val host = uri.host ?: return false
        if (uri.scheme != "https") return false
        return isImssHost(host) || host == "gob.mx" || host.endsWith(".gob.mx")
    }

    private fun openExternally(uri: Uri) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else goToTramix()
    }

    override fun onDestroy() {
        if (ImssSession.portal?.get() === this) ImssSession.portal = null
        if (::web.isInitialized) {
            if (!submitted && !documentSaved) ImssSession.push("closed")
            web.destroy()
        }
        io.shutdown()
        super.onDestroy()
    }

    private fun onDownload(url: String, userAgent: String?, disposition: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, disposition, mime)
        ImssSession.push("download_started", JSONObject().put("name", name))
        setStatus("Descargando documento…")
        when {
            url.startsWith("blob:") -> web.evaluateJavascript(Downloader.blobScript("TramixImss", url, name), null)
            url.startsWith("data:") -> io.execute {
                runCatching { Downloader.decodeDataUrl(url) }
                    .onSuccess { handlePayload(it, name) }
                    .onFailure { failDownload(it.message) }
            }
            url.startsWith("https://") -> {
                val referer = web.url
                io.execute {
                    runCatching { Downloader.fetch(url, userAgent, referer) }
                        .onSuccess { handlePayload(it, URLUtil.guessFileName(url, it.disposition ?: disposition, it.mime)) }
                        .onFailure { failDownload(it.message) }
                }
            }
            else -> failDownload("Tipo de descarga no compatible")
        }
    }

    private fun handlePayload(payload: Payload, suggestedName: String) {
        val bytes = payload.bytes
        if (bytes.isEmpty()) return failDownload("El archivo llegó vacío")
        val isPdf = Downloader.isPdf(bytes)
        if (!isPdf && Downloader.looksLikeHtml(bytes)) {
            return failDownload("El portal devolvió una página en lugar del documento")
        }
        val mime = if (isPdf) "application/pdf" else payload.mime.ifBlank { "application/octet-stream" }
        val meta = runCatching { store.save(suggestedName, mime, bytes, "imss") }.getOrElse {
            return failDownload("No se pudo guardar: ${it.message}")
        }
        documentSaved = true
        ImssSession.push("document", meta)
        main.post {
            setStatus("Documento guardado. Abriendo en TRAMIX…")
            val savedTo = meta.optString("savedTo").takeIf { it.isNotBlank() && it != "null" }
            Toast.makeText(this, savedTo?.let { "Guardado en $it" } ?: "Documento guardado", Toast.LENGTH_LONG).show()
            main.postDelayed({ if (!isDestroyed) goToTramix() }, 900)
        }
    }

    private fun failDownload(reason: String?) {
        val message = reason ?: "Error desconocido"
        ImssSession.push("download_failed", JSONObject().put("reason", message))
        main.post { setStatus("No se pudo descargar: $message") }
    }

    private fun statusText(status: String): String? = when (status) {
        "filled" -> "CURP y correos colocados. Escribe el CAPTCHA en la página."
        "captcha_ready" -> "CAPTCHA escrito. Pulsa CONTINUAR en el asistente."
        "submitted" -> "Formulario enviado. Regresando a TRAMIX…"
        "link_sent" -> "Trámite enviado. Regresando a TRAMIX…"
        "document_requested" -> "Solicitando el documento al IMSS…"
        "fields_not_found" -> "No se encontró el formulario. Navega a la sección de Asignación de NSS."
        else -> null
    }

    private inner class PortalBridge {
        private val allowedStatuses = setOf(
            "filled", "captcha_ready", "submitted", "fields_not_found", "imss_response", "document_requested",
            "link_sent",
        )

        private fun allowed() = isImssHost(currentHost)

        @JavascriptInterface
        fun getJob(): String = if (allowed()) ImssSession.job?.toJson()?.toString().orEmpty() else ""

        @JavascriptInterface
        fun report(status: String, detail: String) {
            if (!allowed() || status !in allowedStatuses) return
            val json = runCatching { JSONObject(detail) }.getOrElse { JSONObject() }
            if (status == "imss_response") {
                json.put("message", json.optString("message").take(280))
            }
            if (status == "submitted" && !submitted) {
                submitted = true
                main.postDelayed({ if (!isDestroyed && submitted && !documentSaved) goToTramix() }, RETURN_DELAY_MS)
            }
            if (status == "link_sent") {
                submitted = true
                json.put("message", json.optString("message").take(280))
                main.post { if (!isDestroyed) goToTramix() }
            }
            if (status == "filled") {
                // The form showing up again after a submit means the IMSS rejected it (usually the CAPTCHA).
                val rejected = submitted || json.optBoolean("retry")
                submitted = false
                if (rejected) main.post { if (!isDestroyed) bringPortalToFront() }
            }
            ImssSession.push(status, json)
            statusText(status)?.let { text -> main.post { setStatus(text) } }
        }

        @JavascriptInterface
        fun saveDataUrl(name: String, mime: String, dataUrl: String) {
            if (!allowed()) return
            io.execute {
                runCatching { Downloader.decodeDataUrl(dataUrl) }
                    .onSuccess { handlePayload(Payload(it.bytes, mime.ifBlank { it.mime }, null), name) }
                    .onFailure { failDownload(it.message) }
            }
        }

        @JavascriptInterface
        fun downloadFailed(reason: String) {
            if (allowed()) failDownload(reason)
        }
    }

    private inner class PortalClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (!request.isForMainFrame) return false
            if (isAllowedNavigation(request.url)) return false
            openExternally(request.url)
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            currentHost = url?.let { Uri.parse(it).host }
            progress.visibility = View.VISIBLE
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            currentHost = url?.let { Uri.parse(it).host }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            currentHost = url?.let { Uri.parse(it).host }
            progress.visibility = View.GONE
            if (isImssHost(currentHost)) {
                view.evaluateJavascript(portalScript, null)
                if (status.text.startsWith("Cargando")) setStatus("Colocando CURP y correo…")
            }
        }
    }

    private inner class PortalChrome : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.progress = newProgress
        }

        /** Popups (e.g. "Imprimir constancia" in a new window) load in the same WebView. */
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            val popup = WebView(this@ImssActivity)
            popup.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                    route(request.url)
                    return true
                }

                override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                    url?.let { route(Uri.parse(it)) }
                }

                private fun route(uri: Uri) {
                    popup.stopLoading()
                    if (isAllowedNavigation(uri)) web.loadUrl(uri.toString()) else openExternally(uri)
                    main.post { popup.destroy() }
                }
            }
            popup.setDownloadListener { url, userAgent, disposition, mime, _ -> onDownload(url, userAgent, disposition, mime) }
            (resultMsg.obj as WebView.WebViewTransport).webView = popup
            resultMsg.sendToTarget()
            return true
        }
    }

    companion object {
        private const val RETURN_DELAY_MS = 1200L
        const val PORTAL_URL = "https://serviciosdigitales.imss.gob.mx/gestionAsegurados-web-externo/asignacionNSS"
    }
}
