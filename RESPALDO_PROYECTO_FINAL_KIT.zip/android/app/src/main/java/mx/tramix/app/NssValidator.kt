package mx.tramix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.Executors

/**
 * "NO DERECHO IMSS": the official IMSS portal runs in a WebView kept behind the TRAMIX page.
 * Later official steps (domicilio, etc.) bring that WebView to the front inside TRAMIX.
 * The injected script fills CURP and correos and relays the portal's own CAPTCHA image so the
 * user can read and type it inside TRAMIX. The CAPTCHA is never read or answered by the app.
 * If the portal uses a widget CAPTCHA, the portal view is brought to the front instead.
 */
class NssValidator(
    private val activity: Activity,
    private val store: DocumentStore,
    private val container: FrameLayout,
) {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val script by lazy { activity.assets.open("nss-validate.js").bufferedReader().use { it.readText() } }
    private val events = mutableListOf<JSONObject>()

    private var overlay: LinearLayout? = null
    private var web: WebView? = null
    @Volatile private var job: JSONObject? = null
    @Volatile private var currentHost: String? = null
    var portalVisible = false
        private set

    fun start(email: String): Boolean = begin(email, "nss", ImssActivity.PORTAL_URL)

    /** VIGENCIA DE DERECHOS: same WebView, script, events and downloads; only the official page changes. */
    fun startVigencia(email: String): Boolean = begin(email, "vigencia", VIGENCIA_URL)

    /** CONSTANCIA IMSS: same WebView and script on the official "solicitudConstancia" page. */
    fun startConstancia(email: String): Boolean = begin(email, "constancia", CONSTANCIA_URL)

    private fun begin(email: String, service: String, url: String): Boolean {
        val e = email.trim().lowercase()
        if (e.length > 254 || !EMAIL.matches(e)) return false
        val next = JSONObject().put("id", UUID.randomUUID().toString()).put("email", e).put("service", service)
        synchronized(events) { events.clear() }
        job = next
        main.post { load(url) }
        return true
    }

    fun submitVigencia(nss: String, curp: String, email: String, captcha: String): Boolean {
        val n = nss.filter { it.isDigit() }
        val c = curp.trim().uppercase()
        val e = email.trim().lowercase()
        val code = captcha.trim()
        if (n.length != 11 || !CURP.matches(c) || !EMAIL.matches(e) || code.isEmpty() || code.length > 32) return false
        val current = job ?: return false
        // The Vigencia page may have been opened through nssOpenLink (job created as "nss").
        current.put("service", "vigencia")
        current.put("curp", c).put("email", e).put("nss", n)
        val args = JSONArray().put(c).put(e).put(code).put(n).toString()
        main.post { web?.evaluateJavascript("window.__tramixNss && window.__tramixNss.submit.apply(null, $args)", null) }
        return true
    }

    fun submit(curp: String, email: String, captcha: String): Boolean {
        val c = curp.trim().uppercase()
        val e = email.trim().lowercase()
        val code = captcha.trim()
        if (!CURP.matches(c) || !EMAIL.matches(e) || code.isEmpty() || code.length > 32) return false
        job?.put("curp", c)?.put("email", e)?.put("submittedAt", System.currentTimeMillis()) ?: return false
        val args = JSONArray().put(c).put(e).put(code).toString()
        main.post { web?.evaluateJavascript("window.__tramixNss && window.__tramixNss.submit.apply(null, $args)", null) }
        return true
    }

    fun refresh(): Boolean {
        if (job == null) return false
        main.post { web?.evaluateJavascript("window.__tramixNss ? window.__tramixNss.refresh() : location.reload()", null) }
        return true
    }

    fun download(): Boolean {
        if (job == null) return false
        main.post { web?.evaluateJavascript("window.__tramixNss && window.__tramixNss.download()", null) }
        return true
    }

    /** Opens the confirmation link the IMSS emailed, in the same WebView and session (cookies kept). */
    fun openLink(url: String): Boolean {
        val uri = runCatching { Uri.parse(url.trim()) }.getOrNull() ?: return false
        if (uri.scheme != "https" || !isImssHost(uri.host)) return false
        val current = job ?: return false
        current.put("continuing", true)
        main.post {
            if (web == null) load(uri.toString()) else web?.loadUrl(uri.toString())
            setPortalVisible(true)
        }
        return true
    }

    /**
     * RECEPTOR DE DOCUMENTOS: opens exactly the link of an IMSS e-mail in this WebView (visible to the user).
     * The page script only reads what the portal shows and downloads its documents; it never solves CAPTCHA.
     */
    fun receive(url: String): Boolean {
        val uri = runCatching { Uri.parse(url.trim()) }.getOrNull() ?: return false
        if (uri.scheme != "https") return false
        job = JSONObject().put("id", UUID.randomUUID().toString()).put("email", "").put("mode", "receiver")
        synchronized(events) { events.clear() }
        // Loaded in the background; shown only when the page needs the user (status "manual").
        main.post {
            load(uri.toString())
            setPortalVisible(false)
        }
        return true
    }

    fun showPortal(show: Boolean) = main.post { setPortalVisible(show) }

    fun cancel() = main.post {
        job = null
        setPortalVisible(false)
        destroyWeb()
    }

    fun drain(): String = synchronized(events) {
        val out = JSONArray(events)
        events.clear()
        out.toString()
    }

    fun destroy() {
        destroyWeb()
        io.shutdown()
    }

    private fun push(status: String, detail: JSONObject = JSONObject()) {
        val id = job?.optString("id") ?: return
        synchronized(events) {
            if (events.size > 50) events.removeAt(0)
            events.add(JSONObject().put("jobId", id).put("status", status).put("detail", detail))
        }
    }

    private fun destroyWeb() {
        web?.destroy()
        web = null
        overlay?.let { container.removeView(it) }
        overlay = null
        currentHost = null
    }

    private fun setPortalVisible(show: Boolean) {
        portalVisible = show && overlay != null
        overlay?.translationZ = if (portalVisible) 20f * activity.resources.displayMetrics.density else 0f
        if (portalVisible) overlay?.bringToFront() else overlay?.let { container.removeView(it); container.addView(it, 0) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun load(url: String = ImssActivity.PORTAL_URL) {
        destroyWeb()
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val view = WebView(activity)
        web = view

        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(14), dp(6))
        }
        bar.addView(TextView(activity).apply {
            text = "‹  NO DERECHO IMSS"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(activity.getColor(R.color.tramix_primary))
            setPadding(dp(10), dp(10), dp(14), dp(10))
            contentDescription = "Volver a No derecho IMSS"
            isClickable = true
            setOnClickListener { setPortalVisible(false) }
        })
        bar.addView(TextView(activity).apply {
            text = "Portal oficial del IMSS"
            textSize = 13f
            setTextColor(activity.getColor(R.color.tramix_muted))
            gravity = Gravity.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(activity.getColor(R.color.tramix_background))
            addView(bar)
            addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        overlay = panel
        // Behind the TRAMIX page but laid out at full size, so the portal renders normally.
        container.addView(panel, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        view.addJavascriptInterface(PortalBridge(), "TramixNss")
        view.webViewClient = PortalClient()
        view.setDownloadListener { url, userAgent, disposition, mime, _ -> onDownload(view, url, userAgent, disposition, mime) }
        push("loading")
        view.loadUrl(url)
    }

    private fun isImssHost(host: String?) = host != null && (host == "imss.gob.mx" || host.endsWith(".imss.gob.mx"))

    private fun isAllowed(uri: Uri): Boolean {
        val host = uri.host ?: return false
        return uri.scheme == "https" && (isImssHost(host) || host == "gob.mx" || host.endsWith(".gob.mx"))
    }

    private fun onDownload(view: WebView, url: String, userAgent: String?, disposition: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, disposition, mime)
        when {
            url.startsWith("blob:") -> view.evaluateJavascript(Downloader.blobScript("TramixNss", url, name), null)
            url.startsWith("data:") -> io.execute {
                runCatching { Downloader.decodeDataUrl(url) }
                    .onSuccess { savePayload(it, name) }
                    .onFailure { failDownload(it.message) }
            }
            url.startsWith("https://") -> {
                val referer = view.url
                io.execute {
                    runCatching { Downloader.fetch(url, userAgent, referer) }
                        .onSuccess { savePayload(it, URLUtil.guessFileName(url, it.disposition ?: disposition, it.mime)) }
                        .onFailure { failDownload(it.message) }
                }
            }
        }
    }

    private fun savePayload(payload: Payload, name: String) {
        val bytes = payload.bytes
        if (bytes.isEmpty()) return failDownload("El archivo llegó vacío")
        if (!Downloader.isPdf(bytes)) return failDownload("El portal no devolvió un PDF")
        val current = job
        var finalName = name
        if (current?.optString("service") == "constancia") {
            // Only a PDF produced after this request's CONTINUAR belongs to it; it is named exactly CURP.pdf.
            val curp = current.optString("curp")
            val stamp = current.optLong("submittedAt")
            if (curp.isEmpty() || stamp == 0L) return failDownload("Se ignoró un PDF que no corresponde a esta solicitud")
            // One file per request: a second download of the same constancia is not saved again.
            if (current.optLong("deliveredAt") == stamp) return
            current.put("deliveredAt", stamp)
            finalName = "$curp.pdf"
        }
        runCatching { store.save(finalName, "application/pdf", bytes, "nss") }
            .onSuccess { push("document", it) }
            .onFailure {
                current?.remove("deliveredAt")
                failDownload("No se pudo guardar: ${it.message}")
            }
    }

    private fun failDownload(reason: String?) = push("download_failed", JSONObject().put("reason", reason ?: "Error desconocido"))

    private inner class PortalBridge {
        private val allowedStatuses =
            setOf("captcha", "captcha_widget", "submitting", "result", "fields_not_found", "step", "pdf_available", "documents", "page_message", "manual", "resumed", "diag")

        private fun allowed() = isImssHost(currentHost)

        @JavascriptInterface
        fun getJob(): String = if (allowed()) job?.toString().orEmpty() else ""

        @JavascriptInterface
        fun report(status: String, detail: String) {
            if (!allowed() || status !in allowedStatuses) return
            val json = runCatching { JSONObject(detail) }.getOrElse { JSONObject() }
            if (json.optString("image").length > MAX_IMAGE_CHARS) json.remove("image")
            json.optString("message").takeIf { it.isNotEmpty() }?.let { json.put("message", it.take(400)) }
            if (status == "captcha_widget" || status == "step" || status == "manual") main.post { setPortalVisible(true) }
            if (status == "result" || status == "captcha") main.post { setPortalVisible(false) }
            push(status, json)
        }

        @JavascriptInterface
        fun saveDataUrl(name: String, mime: String, dataUrl: String) {
            if (!allowed()) return
            io.execute {
                runCatching { Downloader.decodeDataUrl(dataUrl) }
                    .onSuccess { savePayload(Payload(it.bytes, mime.ifBlank { it.mime }, null), name) }
                    .onFailure { failDownload(it.message) }
            }
        }

        @JavascriptInterface
        fun downloadFailed(reason: String) {
            if (allowed()) failDownload(reason)
        }
    }

    private inner class PortalClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            request.isForMainFrame && !isAllowed(request.url)

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            currentHost = url?.let { Uri.parse(it).host }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            currentHost = url?.let { Uri.parse(it).host }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            currentHost = url?.let { Uri.parse(it).host }
            CookieManager.getInstance().flush()
            if (isImssHost(currentHost)) view.evaluateJavascript(script, null)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            push("load_error", JSONObject().put("reason", "No se pudo abrir el portal del IMSS: ${error.description}"))
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
            if (!request.isForMainFrame || response.statusCode < 500) return
            push("load_error", JSONObject().put("reason", "El portal del IMSS respondió con error ${response.statusCode}."))
        }
    }

    companion object {
        private val CURP = Regex("^[A-Z][AEIOUX][A-Z]{2}\\d{6}[HMX][A-Z]{5}[A-Z0-9]\\d$")
        private val EMAIL = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
        private const val MAX_IMAGE_CHARS = 400_000
        const val CONSTANCIA_URL = "https://digital.imss.gob.mx/derechohabiencia/tramite/solicitudConstancia"
        const val VIGENCIA_URL = "https://serviciosdigitales.imss.gob.mx/gestionAsegurados-web-externo/vigencia"
    }
}
