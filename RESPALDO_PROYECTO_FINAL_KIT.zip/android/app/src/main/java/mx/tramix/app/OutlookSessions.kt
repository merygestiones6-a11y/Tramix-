package mx.tramix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.URLUtil
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.Executors

/**
 * One isolated WebView profile per Outlook account (own cookies, localStorage, IndexedDB and cache).
 * Passwords are never seen by TRAMIX: the user signs in on Microsoft's own page and only the
 * profile's session cookies persist. Runs drive Outlook → IMSS mail → link/attachment → IMSS portal → PDF.
 */
class OutlookSessions(
    private val activity: Activity,
    private val store: DocumentStore,
    private val frame: FrameLayout,
) {
    private val prefs = activity.getSharedPreferences("tramix_outlook", Activity.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val script by lazy { activity.assets.open("outlook-run.js").bufferedReader().use { it.readText() } }
    private val sessions = HashMap<String, Session>()
    private var overlay: LinearLayout? = null
    private var overlaySession: Session? = null

    val supported: Boolean
        get() = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)

    val overlayVisible: Boolean
        get() = overlay != null

    private inner class Session(val email: String, val mode: String, val view: WebView, val cookies: CookieManager) {
        var runId: String? = null
        @Volatile var host: String? = null
        var stage = "search"
        var notFound = 0
        var mailRound = 0
        val skipMail = mutableListOf<String>()
        var portalOpened = false
        /** True only once an imss.gob.mx page really finished loading after the link was used. */
        var linkConfirmed = false
        var linkAttempts = 0
        var linkUrl: String? = null
        var linkMailId: String? = null
        var linkWatch: Runnable? = null
        var slowReloads = 0
        var finishPending: Runnable? = null
        var resumeStage: String? = null
        /** Opened by REINTENTAR: if this account has no IMSS mail, move on to the next linked account. */
        var chain = false
    }

    private val sweeper = object : Runnable {
        override fun run() {
            sweep()
            main.postDelayed(this, 30_000)
        }
    }

    init {
        recoverInterrupted()
        main.postDelayed(sweeper, 5_000)
    }

    private fun now() = System.currentTimeMillis()

    // ---------- accounts ----------

    @Synchronized
    private fun readAccounts(): JSONObject = runCatching { JSONObject(prefs.getString(KEY_ACCOUNTS, "{}")!!) }.getOrDefault(JSONObject())

    @Synchronized
    private fun setAccount(email: String, status: String, message: String) {
        val all = readAccounts()
        all.put(email, JSONObject().put("status", status).put("message", message).put("updatedAt", System.currentTimeMillis()))
        prefs.edit().putString(KEY_ACCOUNTS, all.toString()).apply()
    }

    private fun account(email: String): JSONObject? = readAccounts().optJSONObject(email)

    fun accounts(): String {
        val all = readAccounts()
        val list = JSONArray()
        all.keys().forEach { email -> list.put(JSONObject(all.getJSONObject(email).toString()).put("email", email)) }
        return list.toString()
    }

    fun add(email: String): Boolean {
        val clean = normalize(email) ?: return false
        if (!supported) return false
        if (account(clean) == null) setAccount(clean, LOGIN_REQUIRED, "Inicia sesión en Outlook")
        return login(clean)
    }

    fun login(email: String): Boolean {
        val clean = normalize(email) ?: return false
        if (!supported || account(clean) == null) return false
        if (account(clean)?.optString("status") == IN_USE) return false
        setAccount(clean, LOGIN_REQUIRED, "Esperando inicio de sesión en Microsoft")
        main.post {
            val session = open(clean, MODE_LOGIN)
            showOverlay(session, "Inicia sesión con $clean")
            session.view.loadUrl("https://outlook.live.com/owa/?nlp=1&login_hint=" + Uri.encode(clean))
        }
        return true
    }

    fun test(email: String): Boolean {
        val clean = normalize(email) ?: return false
        val current = account(clean) ?: return false
        if (!supported || current.optString("status") == IN_USE) return false
        setAccount(clean, current.optString("status"), "Probando sesión…")
        main.post {
            val session = open(clean, MODE_TEST)
            session.view.loadUrl(MAILBOX)
            main.postDelayed({
                if (sessions[clean] === session && session.mode == MODE_TEST) {
                    setAccount(clean, ERROR, "Outlook no respondió al probar la sesión")
                    close(clean)
                }
            }, 60_000)
        }
        return true
    }

    fun remove(email: String): Boolean {
        val clean = normalize(email) ?: return false
        synchronized(this) {
            val all = readAccounts()
            all.remove(clean)
            prefs.edit().putString(KEY_ACCOUNTS, all.toString()).apply()
        }
        updateRuns { run ->
            if (run.optString("email") == clean && run.optString("status") in ACTIVE) {
                run.put("status", "error").put("message", "La cuenta se eliminó")
            }
        }
        main.post {
            close(clean)
            if (!supported) return@post
            val name = profileName(clean)
            runCatching {
                ProfileStore.getInstance().getProfile(name)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.webStorage.deleteAllData()
                }
            }
            main.postDelayed({ runCatching { ProfileStore.getInstance().deleteProfile(name) } }, 800)
        }
        return true
    }

    // ---------- runs ----------

    @Synchronized
    private fun readRuns(): JSONArray = runCatching { JSONArray(prefs.getString(KEY_RUNS, "[]")!!) }.getOrDefault(JSONArray())

    @Synchronized
    private fun updateRuns(change: (JSONObject) -> Unit) {
        val runs = readRuns()
        for (i in 0 until runs.length()) change(runs.getJSONObject(i))
        prefs.edit().putString(KEY_RUNS, runs.toString()).apply()
    }

    @Synchronized
    private fun updateRun(id: String, change: (JSONObject) -> Unit) = updateRuns { if (it.optString("id") == id) change(it) }

    @Synchronized
    private fun findRun(id: String): JSONObject? {
        val runs = readRuns()
        for (i in 0 until runs.length()) if (runs.getJSONObject(i).optString("id") == id) return runs.getJSONObject(i)
        return null
    }

    fun runs(): String = readRuns().toString()

    @Synchronized
    private fun writeRuns(keep: (JSONObject) -> Boolean): Int {
        val runs = readRuns()
        val next = JSONArray()
        var removed = 0
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (keep(r)) next.put(r) else removed++
        }
        prefs.edit().putString(KEY_RUNS, next.toString()).apply()
        return removed
    }

    /** Deletes one TRAMIX record from the trash. Never touches Outlook mail. */
    fun deleteRun(id: String): Boolean = writeRuns { !(it.optString("id") == id && it.optBoolean("trashed")) } > 0

    /** Empties the trash. Never touches Outlook mail. */
    fun emptyTrash(): Int = writeRuns { !it.optBoolean("trashed") }

    private fun markReached(run: JSONObject, step: String) {
        val reached = run.optJSONArray("reached") ?: JSONArray().also { run.put("reached", it) }
        for (i in 0 until reached.length()) if (reached.optString(i) == step) return
        reached.put(step)
    }

    private fun reachedStep(run: JSONObject, step: String): Boolean {
        val reached = run.optJSONArray("reached") ?: return false
        return (0 until reached.length()).any { reached.optString(it) == step }
    }

    private fun hold(run: JSONObject) {
        run.put("holdUntil", now() + HOLD_MS).put("updatedAt", now())
    }

    private fun hasActiveRun(email: String): Boolean {
        val runs = readRuns()
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (r.optString("email") == email && r.optString("status") in ACTIVE) return true
        }
        return false
    }

    /** After the 10-minute intervention window, runs move to the trash and their session is closed. */
    private fun sweep() {
        val time = now()
        val expired = ArrayList<JSONObject>()
        updateRuns { r ->
            if (r.optBoolean("trashed") || r.optString("status") in ACTIVE) return@updateRuns
            val until = r.optLong("holdUntil", 0).takeIf { it > 0 } ?: (r.optLong("updatedAt") + HOLD_MS)
            if (until <= time) {
                r.put("trashed", true).put("trashedAt", time)
                expired.add(JSONObject(r.toString()))
            }
        }
        expired.forEach { r ->
            val email = r.optString("email")
            val session = sessions[email]
            if (session != null && session.runId == r.optString("id") && overlaySession !== session) close(email)
            if (account(email)?.optString("status") == IN_USE && !hasActiveRun(email)) {
                if (r.optBoolean("accountError")) setAccount(email, ERROR, r.optString("message").take(160))
                else setAccount(email, AVAILABLE, "Liberada")
            }
        }
    }

    /** Returns the run id, or an error code: no-account | login-required | busy | unsupported | invalid. */
    @Synchronized
    fun run(email: String, curp: String): String {
        val clean = normalize(email) ?: return "!invalid"
        val upperCurp = curp.trim().uppercase()
        if (!CURP.matches(upperCurp)) return "!invalid"
        if (!supported) return "!unsupported"
        val runs = readRuns()
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (r.optString("email") == clean && r.optString("curp") == upperCurp && r.optString("status") in ACTIVE) return r.optString("id")
        }
        val acct = account(clean) ?: return "!no-account"
        when (acct.optString("status")) {
            LOGIN_REQUIRED -> return "!login-required"
            IN_USE -> return "!busy"
        }
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val run = JSONObject()
            .put("id", id).put("email", clean).put("curp", upperCurp)
            .put("status", "running").put("step", "assigned").put("message", "Cuenta asignada")
            .put("docs", JSONArray()).put("startedAt", now).put("updatedAt", now)
        val next = JSONArray().put(run)
        for (i in 0 until minOf(runs.length(), 49)) next.put(runs.get(i))
        prefs.edit().putString(KEY_RUNS, next.toString()).apply()
        setAccount(clean, IN_USE, "Trámite $upperCurp")
        main.post {
            val session = open(clean, MODE_RUN)
            session.runId = id
            step(session, "outlook", "Abriendo Outlook")
            session.view.loadUrl(MAILBOX)
        }
        main.postDelayed({
            val current = findRun(id)
            if (current != null && current.optString("status") in setOf("running", "manual")) {
                fail(id, "Se agotó el tiempo (35 min) sin obtener el PDF", accountError = false)
            }
        }, RUN_TIMEOUT_MS)
        return id
    }

    /** Opens the run's real session (same profile and cookies). Reopens the profile if the view was closed. */
    fun intervene(runId: String): Boolean {
        val run = findRun(runId) ?: return false
        if (run.optBoolean("trashed")) return false
        val open = run.optString("status") in ACTIVE || run.optLong("holdUntil", 0) > now()
        if (!open || !supported) return false
        val email = run.optString("email")
        main.post {
            var session = sessions[email]?.takeIf { it.runId == runId }
            if (session == null) {
                val other = sessions[email]
                val otherActive = other?.runId?.let { findRun(it)?.optString("status") }?.let { it in ACTIVE } == true
                if (otherActive) {
                    toast("La cuenta $email está atendiendo otro trámite")
                    return@post
                }
                session = open(email, MODE_RUN).also {
                    it.runId = runId
                    it.stage = "manual"
                    it.portalOpened = true
                }
                session.view.loadUrl(run.optString("lastUrl").takeIf { it.startsWith("https://") } ?: MAILBOX)
            }
            showOverlay(session, "Intervención manual · $email")
        }
        return true
    }

    fun cancel(runId: String): Boolean {
        val run = findRun(runId) ?: return false
        if (run.optString("status") !in ACTIVE) return false
        updateRun(runId) {
            it.put("status", "cancelled").put("message", "Cancelado")
            hold(it)
        }
        release(run.optString("email"), AVAILABLE, "Liberada")
        return true
    }

    private fun allUploaded(run: JSONObject): Boolean {
        val docs = run.optJSONArray("docs") ?: return false
        return docs.length() > 0 && (0 until docs.length()).all { docs.getJSONObject(it).optBoolean("uploaded") }
    }

    private fun markDone(run: JSONObject) {
        val count = run.optJSONArray("docs")?.length() ?: 0
        run.put("status", "done").put("step", "descargar").put("message", "COMPLETADO · $count PDF en DESCARGAR")
        markReached(run, "pdf")
        markReached(run, "descargar")
        hold(run)
    }

    /** Called by the web once a PDF from this run is stored in DESCARGAR. */
    fun uploaded(runId: String, docId: String): Boolean {
        var finished = false
        var email = ""
        updateRun(runId) { run ->
            val docs = run.optJSONArray("docs") ?: JSONArray()
            for (i in 0 until docs.length()) {
                val d = docs.getJSONObject(i)
                if (d.optString("id") == docId) d.put("uploaded", true)
            }
            run.put("updatedAt", now())
            if (allUploaded(run) && run.optString("status") == "uploading") {
                markDone(run)
                finished = true
                email = run.optString("email")
            }
        }
        // The session stays open for the 10-minute intervention window; the account is free for new runs.
        if (finished && account(email) != null) setAccount(email, AVAILABLE, "Liberada")
        return true
    }

    /** A run is complete only once every detected document is saved. */
    private fun evaluate(session: Session) {
        val runId = session.runId ?: return
        var complete = false
        var finished = false
        updateRun(runId) {
            if (it.optString("status") !in ACTIVE) return@updateRun
            val got = it.optJSONArray("docs")?.length() ?: 0
            val expected = maxOf(it.optInt("expected", 1), 1)
            if (got >= expected) {
                complete = true
                markReached(it, "pdf")
                if (allUploaded(it)) {
                    markDone(it)
                    finished = true
                } else {
                    it.put("status", "uploading").put("step", "pdf").put("message", "$got PDF descargados · enviando a DESCARGAR").put("updatedAt", now())
                }
            } else {
                it.put("status", "manual").put("updatedAt", now()).put(
                    "message",
                    if (got == 0) "No se pudo descargar ningún documento · REQUIERE INTERVENCIÓN"
                    else "Se obtuvieron $got de $expected documentos · REQUIERE INTERVENCIÓN",
                )
            }
        }
        if (finished && account(session.email) != null) setAccount(session.email, AVAILABLE, "Liberada")
        if (complete) {
            if (overlaySession === session) hideOverlay()
            session.view.stopLoading()
        }
    }

    private fun scheduleEvaluate(session: Session, delayMs: Long) {
        main.post {
            session.finishPending?.let { main.removeCallbacks(it) }
            val task = Runnable { if (sessions[session.email] === session) evaluate(session) }
            session.finishPending = task
            main.postDelayed(task, delayMs)
        }
    }

    private fun release(email: String, status: String, message: String) {
        if (account(email) != null) setAccount(email, status, message)
        main.post { close(email) }
    }

    private fun step(session: Session, step: String, message: String) {
        val id = session.runId ?: return
        updateRun(id) {
            if (it.optString("status") in ACTIVE) {
                it.put("step", step).put("message", message).put("updatedAt", now())
                markReached(it, step)
                if (it.optString("status") == "manual") it.put("status", "running")
            }
        }
    }

    /** Updates the visible message without marking the step as reached (the action is still in progress). */
    private fun note(session: Session, step: String, message: String) {
        val id = session.runId ?: return
        updateRun(id) {
            if (it.optString("status") in ACTIVE) it.put("step", step).put("message", message).put("updatedAt", now())
        }
    }

    /** "Revisar ahora": runs the real flow again from where the run is (portal page or mailbox). */
    fun retry(runId: String): Boolean {
        val run = findRun(runId) ?: return false
        if (run.optBoolean("trashed") || run.optString("status") !in ACTIVE || !supported) return false
        val email = run.optString("email")
        updateRun(runId) { if (it.optString("status") == "manual") it.put("status", "running") }
        main.post {
            val existing = sessions[email]?.takeIf { it.runId == runId }
            if (existing != null && overlaySession === existing) return@post // the user is intervening
            if (existing == null) {
                val session = open(email, MODE_RUN).also { it.runId = runId }
                note(session, "search", "Revisar ahora · reabriendo Outlook")
                session.view.loadUrl(MAILBOX)
                return@post
            }
            existing.slowReloads = 0
            if (existing.host?.let { isImss(it) } == true) {
                existing.stage = "portal"
                note(existing, "portal", "Revisar ahora · recargando el portal del IMSS")
                existing.view.reload()
            } else {
                existing.stage = "search"
                note(existing, "search", "Revisar ahora · abriendo el correo del IMSS")
                existing.view.loadUrl(MAILBOX)
            }
        }
        return true
    }

    /**
     * REINTENTAR: keeps the run (CURP, docs, progress) and continues searching the IMSS mail/PDF in the next
     * linked Outlook account that has not been checked yet. Never resubmits the IMSS form.
     */
    fun retryNext(runId: String): Boolean {
        val run = findRun(runId) ?: return false
        if (run.optBoolean("trashed") || run.optString("status") == "done" || !supported) return false
        main.post {
            val email = run.optString("email")
            val existing = sessions[email]?.takeIf { it.runId == runId }
            if (existing != null && overlaySession === existing) return@post // the user is intervening
            // Current account not fully reviewed yet: continue there from the saved state (portal or pending mail).
            val reviewed = existing == null || existing.mailRound > MAX_MAIL_ROUNDS || existing.notFound >= MAX_SEARCHES
            if (!reviewed) {
                updateRun(runId) { it.put("status", "running").remove("accountError").put("updatedAt", now()) }
                existing!!.slowReloads = 0
                if (existing.portalOpened && existing.host?.let { isImss(it) } == true) {
                    existing.stage = "portal"
                    note(existing, "portal", "Reintentar · continuando en el portal del IMSS")
                    existing.view.reload()
                } else {
                    existing.stage = "search"
                    note(existing, "search", "Reintentar · volviendo a leer el correo del IMSS pendiente")
                    existing.view.loadUrl(MAILBOX)
                }
                return@post
            }
            advanceAccount(runId)
        }
        return true
    }

    private fun advanceAccount(runId: String) {
        val run = findRun(runId) ?: return
        val current = run.optString("email")
        val tried = LinkedHashSet<String>()
        run.optJSONArray("tried")?.let { arr -> for (i in 0 until arr.length()) tried.add(arr.optString(i)) }
        tried.add(current)
        val all = readAccounts()
        val next = all.keys().asSequence().firstOrNull { email ->
            email !in tried && all.optJSONObject(email)?.optString("status") == AVAILABLE && !hasActiveRun(email)
        }
        if (next == null) {
            updateRun(runId) {
                it.put("tried", JSONArray(tried.toList()))
                if (it.optString("status") in ACTIVE) it.put("status", "manual")
                it.put("message", "No quedan más cuentas Outlook disponibles por revisar (${tried.size} revisadas) · Pulsa INTERVENIR").put("updatedAt", now())
            }
            sessions[current]?.takeIf { it.runId == runId }?.chain = false
            return
        }
        // Free the previous account; the run keeps its state and continues in the next one.
        sessions[current]?.takeIf { it.runId == runId }?.let { close(current) }
        if (account(current)?.optString("status") == IN_USE) setAccount(current, AVAILABLE, "Liberada")
        updateRun(runId) {
            it.put("email", next).put("tried", JSONArray(tried.toList())).remove("holdUntil")
            it.put("status", "running").put("step", "search").remove("accountError")
            it.put("message", "Reintentar · buscando el correo del IMSS en $next (cuenta ${tried.size + 1})").put("updatedAt", now())
        }
        setAccount(next, IN_USE, "Trámite ${run.optString("curp")}")
        val session = open(next, MODE_RUN).also {
            it.runId = runId
            it.chain = true
            it.stage = "search"
        }
        session.view.loadUrl(MAILBOX)
    }

    /** After a tap, the IMSS portal must really load. Otherwise: tap again, then method 2 (open the href), then INTERVENIR. */
    private fun watchLink(session: Session) {
        session.linkWatch?.let { main.removeCallbacks(it) }
        val task = Runnable {
            if (sessions[session.email] !== session || session.linkConfirmed || session.stage == "manual") return@Runnable
            val runId = session.runId ?: return@Runnable
            if (findRun(runId)?.optString("status") !in ACTIVE) return@Runnable
            session.linkAttempts++
            val url = session.linkUrl
            when {
                session.linkAttempts < MAX_LINK_TAPS -> {
                    session.portalOpened = false
                    session.stage = "search"
                    session.linkMailId?.let { session.skipMail.remove(it) }
                    note(session, "link", "El portal del IMSS no abrió todavía · vuelvo a tocar el enlace (${session.linkAttempts + 1}/$MAX_LINK_TAPS)")
                    session.view.loadUrl(MAILBOX)
                }
                session.linkAttempts == MAX_LINK_TAPS && url != null -> {
                    session.portalOpened = true
                    session.stage = "portal"
                    note(session, "link", "Método 2 · abriendo directamente la dirección del enlace")
                    session.view.loadUrl(url)
                    watchLink(session)
                }
                else -> manual(session, "No se pudo abrir el enlace del trámite tras varios intentos · Pulsa INTERVENIR y tócalo.")
            }
        }
        session.linkWatch = task
        main.postDelayed(task, LINK_CONFIRM_MS)
    }

    /** Injects the page script into the current page (also used to continue after INTERVENIR). */
    private fun inject(session: Session, rerun: Boolean) {
        val runId = session.runId
        val config = JSONObject()
            .put("mode", session.mode)
            .put("stage", session.stage)
            .put("email", session.email)
            .put("curp", runId?.let { findRun(it)?.optString("curp") } ?: "")
            .put("round", session.mailRound)
            .put("skip", JSONArray(session.skipMail))
            .put("linkOpened", session.portalOpened)
        val reset = if (rerun) "window.__tramixRunHref=null;\n" else ""
        session.view.evaluateJavascript("${reset}window.__tramixRun=$config;\n$script", null)
    }

    private fun manual(session: Session, message: String) {
        val id = session.runId ?: return
        updateRun(id) {
            if (it.optString("status") in ACTIVE) it.put("status", "manual").put("message", message).put("updatedAt", System.currentTimeMillis())
        }
    }

    private fun fail(runId: String, message: String, accountError: Boolean) {
        val run = findRun(runId) ?: return
        if (run.optString("status") !in ACTIVE) return
        updateRun(runId) {
            it.put("status", "error").put("message", "$message · REQUIERE INTERVENCIÓN").put("accountError", accountError)
            hold(it)
        }
        // Keep the session and the account reserved for the 10-minute intervention window.
        val email = run.optString("email")
        if (account(email) != null) setAccount(email, IN_USE, "Retenida 10 min para intervención")
    }

    private fun recoverInterrupted() {
        updateRuns { run ->
            if (run.optString("status") in setOf("running", "manual", "uploading") && !allUploaded(run)) {
                run.put("status", "error").put("message", "La app se cerró durante el trámite · REQUIERE INTERVENCIÓN")
                hold(run)
            }
        }
        val all = readAccounts()
        all.keys().forEach { email ->
            if (all.getJSONObject(email).optString("status") == IN_USE) setAccount(email, AVAILABLE, "Liberada al reiniciar la app")
        }
    }

    // ---------- WebView per profile ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun open(email: String, mode: String): Session {
        close(email)
        val name = profileName(email)
        val profiles = ProfileStore.getInstance()
        val profile = profiles.getOrCreateProfile(name)
        val view = WebView(activity)
        WebViewCompat.setProfile(view, name)
        val session = Session(email, mode, view, profile.cookieManager)
        sessions[email] = session

        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            // Outlook opens mail links in a new tab: we capture it and switch this session to it.
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = DESKTOP_UA
        }
        session.cookies.setAcceptCookie(true)
        session.cookies.setAcceptThirdPartyCookies(view, true)
        view.addJavascriptInterface(PageBridge(session), "TramixOutlook")
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean =
                request.url.scheme != "https"

            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                session.host = url?.let { Uri.parse(it).host?.lowercase() }
            }

            override fun onPageFinished(v: WebView, url: String?) {
                val host = url?.let { Uri.parse(it).host?.lowercase() }
                session.host = host
                val runId = session.runId
                if (runId != null && url != null && url.startsWith("https://") && host != null && (isOutlook(host) || isImss(host))) {
                    updateRun(runId) { it.put("lastUrl", url.take(2_000)) }
                }
                // The link counts as opened only when an IMSS page actually finished loading in this session.
                if (runId != null && session.mode == MODE_RUN && host != null && isImss(host) && !session.linkConfirmed) {
                    session.linkConfirmed = true
                    session.portalOpened = true
                    if (session.stage != "manual") session.stage = "portal"
                    session.linkWatch?.let { main.removeCallbacks(it) }
                    updateRun(runId) {
                        if (it.optString("status") in ACTIVE) {
                            it.put("path", "link").put("step", "link").put("message", "Enlace abierto · esperando a que el portal del IMSS cargue por completo").put("updatedAt", now())
                            markReached(it, "link")
                        }
                    }
                }
                inject(session, rerun = false)
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (session.mode != MODE_RUN) return false
                val popup = WebView(v.context)
                popup.webViewClient = object : WebViewClient() {
                    private var taken = false
                    private fun take(url: String?): Boolean {
                        if (taken || url == null || !url.startsWith("https://")) return true
                        taken = true
                        main.post {
                            if (sessions[session.email] === session) {
                                note(session, "link", "Se abrió una pestaña nueva · cambiando a ella y esperando el portal del IMSS")
                                session.view.loadUrl(url)
                            }
                            popup.stopLoading()
                            popup.destroy()
                        }
                        return true
                    }
                    override fun shouldOverrideUrlLoading(w: WebView, request: WebResourceRequest): Boolean = take(request.url.toString())
                    override fun onPageStarted(w: WebView, url: String?, favicon: Bitmap?) { take(url) }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
        view.setDownloadListener { url, userAgent, disposition, mime, _ ->
            val fileName = URLUtil.guessFileName(url, disposition, mime)
            when {
                url.startsWith("blob:") -> view.evaluateJavascript(Downloader.blobScript("TramixOutlook", url, fileName), null)
                url.startsWith("data:") -> io.execute {
                    runCatching { Downloader.decodeDataUrl(url) }.onSuccess { savePdf(session, it.bytes, fileName) }
                }
                url.startsWith("https://") -> fetchPdf(session, url, userAgent, view.url, disposition, mime)
            }
        }
        frame.addView(view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return session
    }

    private fun close(email: String) {
        val session = sessions.remove(email) ?: return
        if (overlaySession === session) hideOverlay()
        session.finishPending?.let { main.removeCallbacks(it) }
        session.cookies.flush()
        (session.view.parent as? ViewGroup)?.removeView(session.view)
        session.view.stopLoading()
        session.view.destroy()
    }

    fun destroy() {
        main.removeCallbacks(sweeper)
        sessions.keys.toList().forEach { close(it) }
        io.shutdown()
    }

    private fun fetchPdf(session: Session, url: String, userAgent: String?, referer: String?, disposition: String?, mime: String?) {
        if (session.runId == null) return
        note(session, "pdf", "Descargando PDF · esperando a que termine")
        io.execute {
            runCatching { Downloader.fetch(url, userAgent ?: DESKTOP_UA, referer, session.cookies) }
                .onSuccess { savePdf(session, it.bytes, URLUtil.guessFileName(url, it.disposition ?: disposition, it.mime.ifBlank { mime })) }
                .onFailure { manual(session, "No se pudo descargar el PDF (${it.message}). Pulsa INTERVENIR.") }
        }
    }

    private fun savePdf(session: Session, bytes: ByteArray, name: String) {
        val runId = session.runId ?: return
        if (!Downloader.isPdf(bytes)) {
            manual(session, "El archivo descargado no es un PDF. Pulsa INTERVENIR para continuar.")
            return
        }
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val existing = findRun(runId) ?: return
        if (existing.optBoolean("trashed")) return
        val known = existing.optJSONArray("docs") ?: JSONArray()
        if ((0 until known.length()).any { known.getJSONObject(it).optString("hash") == hash }) {
            scheduleEvaluate(session, SETTLE_MS)
            return
        }
        val meta = runCatching { store.save(name, "application/pdf", bytes, "outlook") }.getOrNull()
        if (meta == null) {
            manual(session, "No se pudo guardar el PDF en el teléfono · REQUIERE INTERVENCIÓN")
            return
        }
        updateRun(runId) { run ->
            // A PDF obtained during the intervention window reopens the run.
            if (run.optString("status") !in ACTIVE) {
                run.put("status", "manual").remove("holdUntil")
            }
            val docs = run.optJSONArray("docs") ?: JSONArray().also { run.put("docs", it) }
            docs.put(JSONObject().put("id", meta.getString("id")).put("name", meta.getString("name")).put("hash", hash).put("uploaded", false))
            val expected = maxOf(run.optInt("expected", 1), 1)
            run.put("step", "pdf").put("message", "PDF descargado (${docs.length()}/$expected): ${meta.getString("name")}").put("updatedAt", now())
        }
        if (account(session.email)?.optString("status") != IN_USE) setAccount(session.email, IN_USE, "Trámite en curso")
        // Several documents may arrive back to back; evaluate once they have settled.
        scheduleEvaluate(session, SETTLE_MS)
    }

    private fun handle(session: Session, raw: String) {
        val msg = runCatching { JSONObject(raw) }.getOrNull() ?: return
        val runId = session.runId
        when (msg.optString("type")) {
            "signed_in" -> when (session.mode) {
                MODE_LOGIN, MODE_TEST -> {
                    setAccount(session.email, AVAILABLE, "Sesión activa")
                    if (session.mode == MODE_LOGIN) toast("Sesión de ${session.email} guardada")
                    close(session.email)
                }
                MODE_RUN -> {
                    setAccount(session.email, IN_USE, "Trámite en curso")
                    if (overlaySession === session && session.stage == "search") hideOverlay()
                    step(session, "outlook", "Outlook abierto")
                }
            }
            "signed_out" -> when (session.mode) {
                MODE_TEST -> {
                    setAccount(session.email, LOGIN_REQUIRED, "La sesión expiró: vuelve a iniciar sesión")
                    close(session.email)
                }
                MODE_RUN -> {
                    setAccount(session.email, LOGIN_REQUIRED, "Microsoft pidió iniciar sesión o verificación")
                    manual(
                        session,
                        if (msg.optBoolean("verification")) "Microsoft pide verificación (MFA/CAPTCHA). Pulsa INTERVENIR."
                        else "Microsoft pide iniciar sesión. Pulsa INTERVENIR.",
                    )
                }
            }
            "step" -> step(session, msg.optString("step", "search"), msg.optString("message").take(160))
            "note" -> note(session, msg.optString("step", "search"), msg.optString("message").take(160))
            "slow_page" -> if (runId != null) {
                // The page is slow: wait and reload instead of cancelling.
                if (session.slowReloads >= MAX_SLOW_RELOADS) {
                    manual(session, "La página del IMSS no termina de cargar · Pulsa INTERVENIR para continuar")
                    return
                }
                session.slowReloads++
                note(session, msg.optString("step", "portal"), "La página tarda en cargar · espero y reintento (${session.slowReloads}/$MAX_SLOW_RELOADS)")
                main.postDelayed({ if (sessions[session.email] === session && session.stage != "manual") session.view.reload() }, 10_000)
            }
            "not_found" -> {
                if (runId == null) return
                if (session.chain) {
                    note(session, "search", "No hay correo del IMSS en ${session.email} · pasando a la siguiente cuenta")
                    advanceAccount(runId)
                    return
                }
                session.notFound++
                if (session.notFound >= MAX_SEARCHES) {
                    fail(runId, "El correo del IMSS no llegó a ${session.email} en 30 minutos", accountError = false)
                    return
                }
                step(session, "search", "Aún no llega el correo del IMSS · reviso de nuevo en 1 min (${session.notFound}/$MAX_SEARCHES)")
                main.postDelayed({ if (sessions[session.email] === session && session.stage == "search") session.view.loadUrl(MAILBOX) }, 60_000)
            }
            "mail_empty" -> if (runId != null) {
                // The first IMSS mail often has neither PDFs nor the link: wait for the second one. Never fail here.
                msg.optString("id").take(200).takeIf { it.isNotBlank() && it !in session.skipMail }?.let { session.skipMail.add(it) }
                session.mailRound++
                setAccount(session.email, IN_USE, "Esperando el segundo correo del IMSS")
                if (session.mailRound > MAX_MAIL_ROUNDS) {
                    // This account's IMSS mails are exhausted: continue in the next linked account (manual only if none left).
                    note(session, "search", "Sin enlace ni PDF en ${session.email} · pasando a la siguiente cuenta Outlook")
                    advanceAccount(runId)
                    return
                }
                val label = if (session.mailRound == 1) "El primer correo del IMSS no trae PDF" else "Aún no llega el segundo correo del IMSS"
                step(session, "search", "$label · espero ${SECOND_MAIL_WAIT_MS / 1000} s y reviso el segundo correo (${session.mailRound}/$MAX_MAIL_ROUNDS)")
                session.stage = "search"
                main.postDelayed({
                    if (sessions[session.email] === session && session.stage == "search" && findRun(runId)?.optString("status")?.let { it in ACTIVE } == true) {
                        step(session, "search", "Revisando el segundo correo del IMSS")
                        session.view.loadUrl(MAILBOX)
                    }
                }, SECOND_MAIL_WAIT_MS)
            }
            "attachments" -> if (runId != null) {
                val count = msg.optInt("count").coerceIn(1, 10)
                updateRun(runId) {
                    it.put("path", "attachments").put("expected", count)
                    markReached(it, "attachments")
                }
                session.stage = "attachments"
                step(session, "attachments", "$count documento(s) adjunto(s) detectado(s) · descargando del correo")
            }
            "documents" -> if (runId != null) {
                val count = msg.optInt("count").coerceIn(1, 10)
                updateRun(runId) {
                    it.put("path", "link").put("expected", maxOf(count, it.optInt("expected", 1)))
                    markReached(it, "documents")
                }
                step(session, "documents", "$count documento(s) detectado(s) en el portal · descargando")
            }
            "check_docs" -> if (runId != null) scheduleEvaluate(session, SETTLE_MS)
            "link" -> {
                val url = msg.optString("url")
                val host = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull()
                if (runId == null || !url.startsWith("https://") || host == null) return
                // The named "Solicitud de Asignación o Localización de NSS" link may go through a redirector.
                if (!isImss(host) && !msg.optBoolean("named")) return
                if (session.portalOpened) return
                session.portalOpened = true
                session.stage = "portal"
                session.linkUrl = url
                updateRun(runId) { it.put("path", "link") }
                note(session, "link", "Enlace localizado en el correo · abriéndolo")
                main.postDelayed({
                    if (sessions[session.email] === session) {
                        note(session, "link", "Abriendo el enlace · esperando a que cargue el portal del IMSS")
                        session.view.loadUrl(url)
                        watchLink(session)
                    }
                }, 4_000)
            }
            "link_clicked" -> if (runId != null && !session.portalOpened) {
                // First mail did its job (opening the portal). Never a failure: the PDFs may come in a second mail.
                session.portalOpened = true
                session.stage = "portal"
                val mailId = msg.optString("id").take(200).takeIf { it.isNotBlank() }
                session.linkMailId = mailId
                mailId?.takeIf { it !in session.skipMail }?.let { session.skipMail.add(it) }
                msg.optString("url").takeIf { it.startsWith("https://") }?.let { session.linkUrl = it }
                updateRun(runId) { it.put("path", "link") }
                // Not marked as reached yet: only a real IMSS page load (onPageFinished) confirms the link was opened.
                if (msg.optBoolean("open") && session.linkUrl != null) {
                    // The mail's own href (never a guessed URL): open it and let the page load completely.
                    note(session, "link", "Abriendo el enlace del correo · esperando a que cargue el portal del IMSS")
                    val target = session.linkUrl!!
                    main.postDelayed({ if (sessions[session.email] === session && session.stage == "portal") session.view.loadUrl(target) }, 3_000)
                } else {
                    note(session, "link", "Enlace \"Solicitud de Asignación o Localización de NSS\" tocado · esperando a que abra el portal del IMSS")
                }
                watchLink(session)
                main.postDelayed({
                    val run = findRun(runId)
                    if (sessions[session.email] !== session || run == null || run.optString("status") !in ACTIVE) return@postDelayed
                    if (!session.linkConfirmed) return@postDelayed // the link watch handles retries / method 2
                    if (session.stage != "portal") return@postDelayed // intervención en curso o ya descargando
                    if (reachedStep(run, "documents")) return@postDelayed // still downloading in the portal
                    if (allUploaded(run)) return@postDelayed
                    if ((run.optJSONArray("docs")?.length() ?: 0) >= maxOf(run.optInt("expected", 2), 2)) return@postDelayed
                    session.mailRound++
                    session.stage = "search"
                    step(session, "search", "Revisando el nuevo correo del IMSS con los PDF")
                    session.view.loadUrl(MAILBOX)
                }, PORTAL_THEN_MAIL_MS)
            }
            "pdf_url" -> {
                val url = msg.optString("url")
                if (url.startsWith("https://")) main.post { fetchPdf(session, url, DESKTOP_UA, session.view.url, null, "application/pdf") }
            }
            "manual" -> manual(session, msg.optString("reason").take(200).ifBlank { "Se necesita tu intervención. Pulsa INTERVENIR." })
            "error" -> if (runId != null) {
                val text = msg.optString("message").take(200).ifBlank { "Error en el trámite" }
                if (msg.optBoolean("account")) fail(runId, text, accountError = true) else manual(session, "$text. Pulsa INTERVENIR para continuar.")
            } else if (session.mode == MODE_TEST) {
                setAccount(session.email, ERROR, msg.optString("message").take(160))
                close(session.email)
            }
        }
    }

    private inner class PageBridge(private val session: Session) {
        private fun trusted(): Boolean {
            val host = session.host ?: return false
            return isOutlook(host) || isImss(host) || isMicrosoftLogin(host)
        }

        @JavascriptInterface
        fun report(json: String) {
            if (trusted() && json.length < 4_000) main.post { if (sessions[session.email] === session) handle(session, json) }
        }

        @JavascriptInterface
        fun saveDataUrl(name: String, mime: String, dataUrl: String) {
            if (!trusted()) return
            io.execute { runCatching { Downloader.decodeDataUrl(dataUrl) }.onSuccess { savePdf(session, it.bytes, name) } }
        }

        @JavascriptInterface
        fun downloadFailed(reason: String) {
            if (trusted()) main.post { manual(session, "La descarga falló. Pulsa INTERVENIR.") }
        }
    }

    // ---------- manual intervention overlay ----------

    private fun showOverlay(session: Session, title: String) {
        hideOverlay()
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(activity.getColor(R.color.tramix_background))
            isClickable = true
        }
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        val label = TextView(activity).apply {
            text = title
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(activity.getColor(R.color.tramix_foreground))
            maxLines = 2
        }
        val back = Button(activity).apply {
            text = "VOLVER A TRAMIX"
            setOnClickListener { hideOverlay() }
        }
        bar.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(back)
        (session.view.parent as? ViewGroup)?.removeView(session.view)
        container.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(session.view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frame.addView(container, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = container
        overlaySession = session
        // Automation pauses while the user is in control; downloads are still captured.
        if (session.mode == MODE_RUN && session.stage != "manual") {
            session.resumeStage = session.stage
            session.stage = "manual"
        }
    }

    fun hideOverlay() {
        val container = overlay ?: return
        val session = overlaySession
        overlay = null
        overlaySession = null
        frame.removeView(container)
        if (session != null && sessions[session.email] === session) {
            container.removeView(session.view)
            frame.addView(session.view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            session.resumeStage?.let { session.stage = it }
            session.resumeStage = null
            if (session.mode == MODE_LOGIN) close(session.email)
            if (session.mode == MODE_RUN && session.runId != null) {
                scheduleEvaluateIfDocs(session)
                // Continue automatically from the same screen the user left (e.g. after solving a CAPTCHA).
                val runId = session.runId!!
                if (session.stage != "manual" && findRun(runId)?.optString("status") in ACTIVE) {
                    updateRun(runId) { if (it.optString("status") == "manual") it.put("status", "running").put("message", "Continuando desde la misma pantalla").put("updatedAt", now()) }
                    session.slowReloads = 0
                    main.postDelayed({ if (sessions[session.email] === session && overlaySession !== session) inject(session, rerun = true) }, 1_500)
                }
            }
        }
    }

    private fun scheduleEvaluateIfDocs(session: Session) {
        val run = findRun(session.runId ?: return) ?: return
        if (run.optString("status") in ACTIVE && (run.optJSONArray("docs")?.length() ?: 0) > 0) scheduleEvaluate(session, 1_000)
    }

    private fun toast(text: String) = main.post { Toast.makeText(activity, text, Toast.LENGTH_LONG).show() }

    companion object {
        private const val KEY_ACCOUNTS = "accounts"
        private const val KEY_RUNS = "runs"
        private const val MODE_LOGIN = "login"
        private const val MODE_TEST = "test"
        private const val MODE_RUN = "run"
        const val AVAILABLE = "available"
        const val IN_USE = "in_use"
        const val ERROR = "error"
        const val LOGIN_REQUIRED = "login_required"
        private const val MAX_SEARCHES = 30
        private const val SECOND_MAIL_WAIT_MS = 90_000L
        private const val PORTAL_THEN_MAIL_MS = 120_000L
        private const val MAX_MAIL_ROUNDS = 6
        private const val RUN_TIMEOUT_MS = 35L * 60 * 1000
        private const val HOLD_MS = 10L * 60 * 1000
        private const val SETTLE_MS = 10_000L
        private const val LINK_CONFIRM_MS = 45_000L
        private const val MAX_LINK_TAPS = 2
        private const val MAX_SLOW_RELOADS = 2
        private const val MAILBOX = "https://outlook.live.com/mail/0/"
        private val ACTIVE = setOf("running", "manual", "uploading")
        private val EMAIL = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
        private val CURP = Regex("^[A-Z][AEIOUX][A-Z]{2}\\d{6}[HM][A-Z]{5}[A-Z0-9]\\d$")
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        fun normalize(email: String): String? = email.trim().lowercase().takeIf { EMAIL.matches(it) && it.length <= 254 }

        private fun profileName(email: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(email.toByteArray())
            return "outlook_" + digest.take(12).joinToString("") { "%02x".format(it) }
        }

        private fun isOutlook(host: String) = host in setOf("outlook.live.com", "outlook.office.com", "outlook.office365.com")
        private fun isImss(host: String) = host == "imss.gob.mx" || host.endsWith(".imss.gob.mx")
        private fun isMicrosoftLogin(host: String) = listOf(
            "login.live.com", "login.microsoftonline.com", "login.microsoft.com", "account.live.com", "account.microsoft.com",
        ).any { host == it || host.endsWith(".$it") }
    }
}
