package mx.tramix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** Loads the deployed TRAMIX web app and exposes the TramixAndroid bridge to it. */
class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var store: DocumentStore
    private var web: WebView? = null
    private var nss: NssValidator? = null
    private var outlook: OutlookSessions? = null
    private var origin: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    @Volatile private var currentOrigin: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("tramix", MODE_PRIVATE)
        store = DocumentStore(this)
        val path = handleLink(intent)
        origin = prefs.getString(KEY_ORIGIN, null) ?: normalizeOrigin(BuildConfig.TRAMIX_URL)
        if (origin == null) showSetup() else showWeb(path)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        val path = handleLink(intent) ?: return
        val stored = prefs.getString(KEY_ORIGIN, null) ?: return
        if (web == null || stored != origin) {
            origin = stored
            showWeb(path)
        } else {
            web?.loadUrl(stored + path)
        }
    }

    override fun onResume() {
        super.onResume()
        web?.evaluateJavascript("window.dispatchEvent(new Event('tramix-android'))", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        outlook?.takeIf { it.overlayVisible }?.let { it.hideOverlay(); return }
        nss?.takeIf { it.portalVisible }?.let { it.showPortal(false); return }
        val view = web
        if (view != null && view.canGoBack()) view.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onDestroy() {
        outlook?.destroy()
        nss?.destroy()
        web?.destroy()
        io.shutdown()
        super.onDestroy()
    }

    /** tramix://open?url=https://…&curp=…&email=… — sent by the TRAMIX page opened in Chrome. */
    private fun handleLink(intent: Intent?): String? {
        val data = intent?.data ?: return null
        if (data.scheme != "tramix" || data.host != "open") return null
        normalizeOrigin(data.getQueryParameter("url"))?.let { prefs.edit().putString(KEY_ORIGIN, it).apply() }
        when (data.getQueryParameter("path")) {
            "/no-derecho-imss", "/validar-nss" -> return "/no-derecho-imss"
        }
        val curp = data.getQueryParameter("curp")
        val email = data.getQueryParameter("email")
        if (curp != null && email != null) ImssSession.pendingFromLink = ImssSession.createJob(curp, email)
        return "/imss-nss"
    }

    private fun normalizeOrigin(raw: String?): String? {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return null
        val uri = Uri.parse(if (text.contains("://")) text else "https://$text")
        val host = uri.host ?: return null
        if (uri.scheme != "https" || host.isBlank()) return null
        return "https://$host" + if (uri.port > 0) ":${uri.port}" else ""
    }

    private fun isMicrosoftSignIn(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return MICROSOFT_SIGN_IN_DOMAINS.any { h == it || h.endsWith(".$it") }
    }

    private val MICROSOFT_SIGN_IN_DOMAINS = listOf(
        "login.microsoftonline.com",
        "login.microsoft.com",
        "login.live.com",
        "account.live.com",
        "account.microsoft.com",
        "logincdn.msauth.net",
        "msauth.net",
        "msftauth.net",
        "aadcdn.msftauth.net",
    )

    private fun originOf(url: String?): String? = url?.let { normalizeOrigin(it.takeIf { u -> u.startsWith("https://") }) }

    private fun showSetup() {
        outlook?.destroy()
        outlook = null
        nss?.destroy()
        nss = null
        web?.destroy()
        web = null
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(getColor(R.color.tramix_background))
        }
        val title = TextView(this).apply {
            text = "TRAMIX"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(getColor(R.color.tramix_foreground))
        }
        val body = TextView(this).apply {
            text = "Abre TRAMIX en Chrome y pulsa «ABRIR EN LA APP», o escribe aquí la dirección de tu TRAMIX."
            textSize = 15f
            setLineSpacing(0f, 1.3f)
            setTextColor(getColor(R.color.tramix_muted))
            setPadding(0, dp(8), 0, dp(20))
        }
        val input = EditText(this).apply {
            hint = "https://tu-tramix.vercel.app"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            isSingleLine = true
        }
        val button = Button(this).apply {
            text = "ABRIR TRAMIX"
            setOnClickListener {
                val value = normalizeOrigin(input.text.toString())
                if (value == null) {
                    input.error = "Escribe una dirección https válida"
                } else {
                    prefs.edit().putString(KEY_ORIGIN, value).apply()
                    origin = value
                    showWeb(null)
                }
            }
        }
        input.setOnEditorActionListener { _, _, _ -> button.performClick(); true }
        column.addView(title)
        column.addView(body)
        column.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })
        setContentView(column)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showWeb(path: String?) {
        val base = origin ?: return showSetup()
        outlook?.destroy()
        outlook = null
        nss?.destroy()
        nss = null
        web?.destroy()
        val view = WebView(this)
        web = view
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        view.addJavascriptInterface(AppBridge(), "TramixAndroid")
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val url = request.url
                if (originOf(url.toString()) == base) return false
                // Microsoft sign-in posts forms between its own hosts; replaying them as a GET in an
                // external browser fails with AADSTS900561 and loses the TRAMIX state cookie.
                if (url.scheme == "https" && isMicrosoftSignIn(url.host)) return false
                if (url.scheme == "tramix") {
                    onNewIntent(Intent(Intent.ACTION_VIEW, url))
                    return true
                }
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, url)) }
                return true
            }

            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                currentOrigin = originOf(url)
            }

            override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
                currentOrigin = originOf(url)
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams,
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val chooser = params.createIntent().apply {
                    if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(chooser, REQUEST_FILES)
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        view.setDownloadListener { url, userAgent, disposition, mime, _ ->
            val name = URLUtil.guessFileName(url, disposition, mime)
            when {
                url.startsWith("blob:") -> view.evaluateJavascript(Downloader.blobScript("TramixAndroid", url, name), null)
                url.startsWith("data:") -> saveFileKitDownload(name, null, url)
                url.startsWith("https://") -> {
                    // WebView methods throw "A WebView method was called on thread…" off the main thread.
                    val referer = view.url
                    io.execute {
                        runCatching { Downloader.fetch(url, userAgent, referer) }
                            .onSuccess { saveFileKitPayload(it, URLUtil.guessFileName(url, it.disposition ?: disposition, it.mime)) }
                            .onFailure { toast("No se pudo descargar: ${it.message}") }
                    }
                }
            }
        }

        val frame = FrameLayout(this).apply {
            fitsSystemWindows = true
            setBackgroundColor(getColor(R.color.tramix_background))
            addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        setContentView(frame)
        nss = NssValidator(this, store, frame)
        outlook = OutlookSessions(this, store, frame)
        currentOrigin = base
        view.loadUrl(base + (path ?: "/"))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_FILES) return
        val uris: Array<Uri>? = when {
            resultCode != RESULT_OK -> null
            data?.clipData != null -> data.clipData!!.let { clip: ClipData -> Array(clip.itemCount) { clip.getItemAt(it).uri } }
            data?.data != null -> arrayOf(data.data!!)
            else -> null
        }
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    private fun saveFileKitDownload(name: String, mime: String?, dataUrl: String) {
        io.execute {
            runCatching { Downloader.decodeDataUrl(dataUrl) }
                .onSuccess { saveFileKitPayload(Payload(it.bytes, mime?.ifBlank { null } ?: it.mime, null), name) }
                .onFailure { toast("No se pudo guardar: ${it.message}") }
        }
    }

    private fun saveFileKitPayload(payload: Payload, name: String) {
        val mime = if (Downloader.isPdf(payload.bytes)) "application/pdf" else payload.mime.ifBlank { "application/octet-stream" }
        runCatching { store.save(name, mime, payload.bytes, "filekit") }
            .onSuccess { meta ->
                val savedTo = meta.optString("savedTo").takeIf { it.isNotBlank() && it != "null" }
                toast(savedTo?.let { "Guardado en $it" } ?: "Archivo guardado")
            }
            .onFailure { toast("No se pudo guardar: ${it.message}") }
    }

    private fun toast(text: String) = main.post { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }

    private fun openDocument(id: String, share: Boolean): Boolean {
        val meta = store.meta(id) ?: return false
        val uri = store.uri(id) ?: return false
        val mime = meta.optString("mime", "application/pdf")
        val intent = if (share) {
            Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
        } else {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
        }.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return runCatching {
            startActivity(Intent.createChooser(intent, if (share) "Compartir documento" else "Abrir con"))
            true
        }.getOrDefault(false)
    }

    /** Opens a PDF from DESCARGAR in the phone's PDF viewer (WebView cannot render PDFs itself). */
    private fun previewPdf(name: String, base64: String): Boolean {
        val bytes = runCatching { Base64.decode(base64, Base64.DEFAULT) }.getOrNull() ?: return false
        if (bytes.size > Downloader.MAX_BYTES || !Downloader.isPdf(bytes)) return false
        val dir = java.io.File(cacheDir, "previews").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val file = java.io.File(dir, DocumentStore.sanitize(name, "application/pdf"))
        file.writeBytes(bytes)
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", file)
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return runCatching {
            main.post { startActivity(Intent.createChooser(intent, "Vista previa")) }
            true
        }.getOrDefault(false)
    }

    private inner class AppBridge {
        private fun allowed() = currentOrigin != null && currentOrigin == origin

        @JavascriptInterface
        fun version(): String = if (allowed()) BuildConfig.VERSION_NAME else ""

        @JavascriptInterface
        fun startImss(curp: String, email: String): Boolean {
            if (!allowed()) return false
            val job = ImssSession.createJob(curp, email) ?: return false
            ImssSession.job = job
            ImssSession.clear()
            main.post {
                ImssSession.portalActivity()?.finish()
                startActivity(Intent(this@MainActivity, ImssActivity::class.java))
            }
            return true
        }

        @JavascriptInterface
        fun resumeImss(): Boolean {
            if (!allowed() || ImssSession.portalActivity() == null) return false
            main.post {
                startActivity(Intent(this@MainActivity, ImssActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            }
            return true
        }

        @JavascriptInterface
        fun takePendingJob(): String {
            if (!allowed()) return ""
            val job = ImssSession.pendingFromLink ?: return ""
            ImssSession.pendingFromLink = null
            return job.toJson().toString()
        }

        @JavascriptInterface
        fun takeEvents(): String = if (allowed()) ImssSession.drain().toString() else "[]"

        @JavascriptInterface
        fun listDocuments(): String = if (allowed()) store.list("imss").toString() else "[]"

        @JavascriptInterface
        fun readDocument(id: String): String {
            if (!allowed()) return ""
            val file = store.file(id) ?: return ""
            if (file.length() > Downloader.MAX_BYTES) return ""
            return Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        }

        @JavascriptInterface
        fun openDocument(id: String): Boolean = allowed() && openDocument(id, share = false)

        @JavascriptInterface
        fun shareDocument(id: String): Boolean = allowed() && openDocument(id, share = true)

        @JavascriptInterface
        fun saveDataUrl(name: String, mime: String, dataUrl: String) {
            if (allowed()) saveFileKitDownload(name, mime, dataUrl)
        }

        @JavascriptInterface
        fun downloadFailed(reason: String) {
            if (allowed()) toast("No se pudo descargar: $reason")
        }

        @JavascriptInterface
        fun nssStart(email: String): Boolean = allowed() && nss?.start(email) == true

        @JavascriptInterface
        fun nssSubmit(curp: String, email: String, captcha: String): Boolean =
            allowed() && nss?.submit(curp, email, captcha) == true

        @JavascriptInterface
        fun constanciaStart(email: String): Boolean = allowed() && nss?.startConstancia(email) == true

        @JavascriptInterface
        fun vigenciaStart(email: String): Boolean = allowed() && nss?.startVigencia(email) == true

        @JavascriptInterface
        fun vigenciaSubmit(nssNumber: String, curp: String, email: String, captcha: String): Boolean =
            allowed() && nss?.submitVigencia(nssNumber, curp, email, captcha) == true

        @JavascriptInterface
        fun nssRefresh(): Boolean = allowed() && nss?.refresh() == true

        @JavascriptInterface
        fun nssDownload(): Boolean = allowed() && nss?.download() == true

        @JavascriptInterface
        fun nssOpenLink(url: String): Boolean = allowed() && nss?.openLink(url) == true

        @JavascriptInterface
        fun nssReceive(url: String): Boolean = allowed() && nss?.receive(url) == true

        @JavascriptInterface
        fun nssShowPortal(show: Boolean) {
            if (allowed()) nss?.showPortal(show)
        }

        @JavascriptInterface
        fun nssCancel() {
            if (allowed()) nss?.cancel()
        }

        @JavascriptInterface
        fun nssTakeEvents(): String = if (allowed()) nss?.drain() ?: "[]" else "[]"

        @JavascriptInterface
        fun previewDocument(name: String, base64: String): Boolean = allowed() && previewPdf(name, base64)

        @JavascriptInterface
        fun outlookSupported(): Boolean = allowed() && outlook?.supported == true

        @JavascriptInterface
        fun outlookAccounts(): String = if (allowed()) outlook?.accounts() ?: "[]" else "[]"

        @JavascriptInterface
        fun outlookAdd(email: String): Boolean = allowed() && outlook?.add(email) == true

        @JavascriptInterface
        fun outlookLogin(email: String): Boolean = allowed() && outlook?.login(email) == true

        @JavascriptInterface
        fun outlookTest(email: String): Boolean = allowed() && outlook?.test(email) == true

        @JavascriptInterface
        fun outlookRemove(email: String): Boolean = allowed() && outlook?.remove(email) == true

        @JavascriptInterface
        fun outlookRun(email: String, curp: String): String = if (allowed()) outlook?.run(email, curp) ?: "!unsupported" else ""

        @JavascriptInterface
        fun outlookRuns(): String = if (allowed()) outlook?.runs() ?: "[]" else "[]"

        @JavascriptInterface
        fun outlookIntervene(runId: String): Boolean = allowed() && outlook?.intervene(runId) == true

        @JavascriptInterface
        fun outlookCancel(runId: String): Boolean = allowed() && outlook?.cancel(runId) == true

        @JavascriptInterface
        fun outlookUploaded(runId: String, docId: String): Boolean = allowed() && outlook?.uploaded(runId, docId) == true

        @JavascriptInterface
        fun outlookDeleteRun(runId: String): Boolean = allowed() && outlook?.deleteRun(runId) == true

        @JavascriptInterface
        fun outlookRetry(runId: String): Boolean = allowed() && outlook?.retry(runId) == true

        @JavascriptInterface
        fun outlookRetryNext(runId: String): Boolean = allowed() && outlook?.retryNext(runId) == true

        @JavascriptInterface
        fun outlookEmptyTrash(): Int = if (allowed()) outlook?.emptyTrash() ?: 0 else 0
    }

    companion object {
        private const val KEY_ORIGIN = "origin"
        private const val REQUEST_FILES = 41
    }
}
