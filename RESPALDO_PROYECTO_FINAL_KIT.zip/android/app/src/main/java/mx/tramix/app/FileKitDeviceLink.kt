package mx.tramix.app

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * FileKit ↔ Android channel for CFE requests.
 * Blocking calls: run them off the main thread.
 *
 * Flow:
 *   register(enrollSecret, name)  once, stores the device token
 *   nextJob()                     leases a request (11-digit service number) or returns null
 *   report(job, "PROCESANDO")     while working
 *   uploadPdf(job, bytes)         FileKit runs the CFE flow and marks it COMPLETADO / DESCARGADO
 *   report(job, "ERROR", msg)     if the device could not get the PDF
 *
 * The PDF itself must come from an authorized source; this class only transports it.
 */
class FileKitDeviceLink(context: Context, private val baseUrl: String) {

    data class Job(val id: String, val requestId: String, val serviceNumber: String, val state: String)

    data class UploadResult(
        val ok: Boolean,
        val state: String,
        val fileName: String?,
        val duplicate: Boolean,
        val error: String?,
    )

    class LinkException(val status: Int, val code: String) : IOException("FileKit $status $code")

    private val prefs = context.applicationContext.getSharedPreferences("filekit_device", Context.MODE_PRIVATE)

    val isRegistered: Boolean get() = token() != null

    private fun token(): String? = prefs.getString(KEY_TOKEN, null)

    fun register(enrollSecret: String, name: String) {
        val body = JSONObject().put("name", name).toString().toByteArray()
        val json = call("POST", "/api/cfe/device/register", enrollSecret, "application/json", body)
            ?: throw LinkException(500, "empty-response")
        prefs.edit().putString(KEY_TOKEN, json.getString("token")).apply()
    }

    fun forget() = prefs.edit().remove(KEY_TOKEN).apply()

    /** Reports CONECTADO. */
    fun heartbeat() {
        call("POST", "/api/cfe/device/heartbeat", requireToken())
    }

    fun nextJob(): Job? {
        val json = call("POST", "/api/cfe/device/jobs/next", requireToken()) ?: return null
        return parseJob(json.getJSONObject("job"))
    }

    /** state: CONECTADO, PROCESANDO or ERROR. COMPLETADO is set by FileKit after the upload. */
    fun report(job: Job, state: String, message: String? = null, retryable: Boolean = true): Job {
        val body = JSONObject().put("state", state).put("retryable", retryable)
        if (message != null) body.put("message", message.take(300))
        val json = call(
            "POST", "/api/cfe/device/jobs/${job.id}/status", requireToken(),
            "application/json", body.toString().toByteArray(),
        ) ?: throw LinkException(500, "empty-response")
        return parseJob(json.getJSONObject("job"))
    }

    /** Safe to repeat: FileKit returns the stored receipt instead of saving a second copy. */
    fun uploadPdf(job: Job, pdf: ByteArray): UploadResult {
        return try {
            val json = call(
                "POST", "/api/cfe/device/jobs/${job.id}/receipt", requireToken(), "application/pdf", pdf,
            ) ?: throw LinkException(500, "empty-response")
            UploadResult(
                ok = true,
                state = json.getJSONObject("job").getString("state"),
                fileName = json.optJSONObject("receipt")?.optString("fileName"),
                duplicate = json.optBoolean("duplicate"),
                error = null,
            )
        } catch (e: LinkException) {
            if (e.status != 422) throw e
            UploadResult(false, "ERROR", null, false, e.code)
        }
    }

    private fun requireToken() = token() ?: throw LinkException(401, "not-registered")

    private fun parseJob(o: JSONObject) = Job(
        id = o.getString("id"),
        requestId = o.getString("requestId"),
        serviceNumber = o.getString("serviceNumber"),
        state = o.getString("state"),
    )

    /** Retries network failures and 5xx with backoff; 4xx are returned to the caller. */
    private fun call(
        method: String,
        path: String,
        bearer: String,
        contentType: String? = null,
        body: ByteArray? = null,
    ): JSONObject? {
        var delayMs = 2_000L
        var last: IOException? = null
        repeat(MAX_TRIES) { attempt ->
            try {
                return once(method, path, bearer, contentType, body)
            } catch (e: LinkException) {
                if (e.status < 500) throw e
                last = e
            } catch (e: IOException) {
                last = e
            }
            if (attempt < MAX_TRIES - 1) {
                Thread.sleep(delayMs)
                delayMs *= 2
            }
        }
        throw last ?: IOException("FileKit unreachable")
    }

    private fun once(method: String, path: String, bearer: String, contentType: String?, body: ByteArray?): JSONObject? {
        val url = URL(baseUrl.trimEnd('/') + path)
        require(url.protocol == "https" || url.host == "10.0.2.2" || url.host == "localhost") { "FileKit must use HTTPS" }
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("Authorization", "Bearer $bearer")
            conn.setRequestProperty("Accept", "application/json")
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", contentType ?: "application/octet-stream")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val status = conn.responseCode
            if (status == 204) return null
            val text = (if (status >= 400) conn.errorStream else conn.inputStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = if (text.isNotBlank()) runCatching { JSONObject(text) }.getOrNull() else null
            if (status >= 400) throw LinkException(status, json?.optString("error")?.ifBlank { null } ?: "http-$status")
            return json
        } finally {
            conn.disconnect()
        }
    }

    private companion object {
        const val KEY_TOKEN = "device_token"
        const val MAX_TRIES = 4
    }
}
