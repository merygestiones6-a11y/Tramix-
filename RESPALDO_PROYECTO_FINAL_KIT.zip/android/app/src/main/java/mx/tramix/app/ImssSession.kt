package mx.tramix.app

import android.app.Activity
import org.json.JSONArray
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.UUID

data class ImssJob(val id: String, val curp: String, val email: String) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("curp", curp).put("email", email)
}

/** Shared state between the TRAMIX WebView and the IMSS portal WebView (same process). */
object ImssSession {
    private val CURP = Regex("^[A-Z0-9]{18}$")
    private val EMAIL = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$")

    @Volatile var job: ImssJob? = null
    @Volatile var pendingFromLink: ImssJob? = null
    @Volatile var portal: WeakReference<Activity>? = null

    private val events = mutableListOf<JSONObject>()

    fun createJob(curp: String, email: String): ImssJob? {
        val c = curp.trim().uppercase()
        val e = email.trim().lowercase()
        if (!CURP.matches(c) || e.length > 254 || !EMAIL.matches(e)) return null
        return ImssJob(UUID.randomUUID().toString(), c, e)
    }

    @Synchronized
    fun push(status: String, detail: JSONObject = JSONObject()) {
        val id = job?.id ?: return
        events.add(JSONObject().put("jobId", id).put("status", status).put("detail", detail))
    }

    @Synchronized
    fun drain(): JSONArray {
        val out = JSONArray(events.toList())
        events.clear()
        return out
    }

    @Synchronized
    fun clear() = events.clear()

    fun portalActivity(): Activity? = portal?.get()?.takeUnless { it.isFinishing || it.isDestroyed }
}
