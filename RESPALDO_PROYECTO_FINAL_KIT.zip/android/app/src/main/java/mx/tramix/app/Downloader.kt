package mx.tramix.app

import android.util.Base64
import android.webkit.CookieManager
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

class Payload(val bytes: ByteArray, val mime: String, val disposition: String?)

object Downloader {
    const val MAX_BYTES = 25 * 1024 * 1024

    /** Re-requests a WebView download with the portal session cookies so the user isn't asked to log in again. */
    fun fetch(
        url: String,
        userAgent: String?,
        referer: String?,
        cookies: CookieManager = CookieManager.getInstance(),
    ): Payload {
        var current = URL(url)
        var redirects = 0
        while (true) {
            if (current.protocol != "https") throw IOException("Solo se permiten descargas HTTPS")
            val connection = current.openConnection() as HttpURLConnection
            try {
                connection.instanceFollowRedirects = false
                connection.connectTimeout = 20_000
                connection.readTimeout = 60_000
                cookies.getCookie(current.toString())?.let { connection.setRequestProperty("Cookie", it) }
                userAgent?.let { connection.setRequestProperty("User-Agent", it) }
                referer?.let { connection.setRequestProperty("Referer", it) }

                val code = connection.responseCode
                connection.headerFields["Set-Cookie"]?.forEach { cookies.setCookie(current.toString(), it) }
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location") ?: throw IOException("Redirección sin destino")
                    if (++redirects > 5) throw IOException("Demasiadas redirecciones")
                    current = URL(current, location)
                    continue
                }
                if (code !in 200..299) throw IOException("El portal respondió HTTP $code")

                val out = ByteArrayOutputStream()
                connection.inputStream.use { input ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        if (out.size() + read > MAX_BYTES) throw IOException("Archivo demasiado grande")
                        out.write(buffer, 0, read)
                    }
                }
                val mime = connection.contentType?.substringBefore(';')?.trim().orEmpty()
                return Payload(out.toByteArray(), mime, connection.getHeaderField("Content-Disposition"))
            } finally {
                connection.disconnect()
            }
        }
    }

    fun decodeDataUrl(dataUrl: String): Payload {
        val comma = dataUrl.indexOf(',')
        if (!dataUrl.startsWith("data:") || comma < 0) throw IOException("Datos inválidos")
        val header = dataUrl.substring(5, comma)
        val body = dataUrl.substring(comma + 1)
        val bytes = if (header.contains(";base64")) {
            Base64.decode(body, Base64.DEFAULT)
        } else {
            URLDecoder.decode(body, "UTF-8").toByteArray()
        }
        if (bytes.size > MAX_BYTES) throw IOException("Archivo demasiado grande")
        return Payload(bytes, header.substringBefore(';'), null)
    }

    /** Blob URLs only exist inside the page, so the page itself reads them and hands back a data URL. */
    fun blobScript(bridge: String, url: String, name: String): String = """
        (function (u, n) {
          fetch(u).then(function (r) { return r.blob(); }).then(function (b) {
            return new Promise(function (ok, ko) {
              var f = new FileReader();
              f.onload = function () { ok([f.result, b.type]); };
              f.onerror = ko;
              f.readAsDataURL(b);
            });
          }).then(function (x) { $bridge.saveDataUrl(n, x[1] || '', x[0]); })
            .catch(function (e) { $bridge.downloadFailed(String(e)); });
        })(${JSONObject.quote(url)}, ${JSONObject.quote(name)});
    """.trimIndent()

    fun isPdf(bytes: ByteArray): Boolean =
        bytes.size > 4 && bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() &&
            bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte()

    fun looksLikeHtml(bytes: ByteArray): Boolean {
        val head = String(bytes, 0, minOf(bytes.size, 512), Charsets.ISO_8859_1).trimStart().lowercase()
        return head.startsWith("<!doctype html") || head.startsWith("<html") || head.startsWith("<?xml")
    }
}
