package mx.tramix.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Documents live in app-private storage (shown inside TRAMIX) and a copy goes to
 * Descargas/TRAMIX. On Android 10+ MediaStore needs no permission; on 7–9 the copy
 * goes to the app's own external folder, which also needs no permission.
 */
class DocumentStore(private val context: Context) {
    private val root = File(context.filesDir, "documents").apply { mkdirs() }

    fun save(
        name: String,
        mime: String,
        bytes: ByteArray,
        source: String,
        copyToDownloads: Boolean = true,
        extra: Map<String, Any> = emptyMap(),
    ): JSONObject {
        val id = UUID.randomUUID().toString()
        val fileName = sanitize(name, mime)
        val dir = File(root, id).apply { mkdirs() }
        File(dir, fileName).writeBytes(bytes)
        val meta = JSONObject()
            .put("id", id)
            .put("name", fileName)
            .put("mime", mime)
            .put("size", bytes.size)
            .put("source", source)
            .put("createdAt", System.currentTimeMillis())
            .put("savedTo", (if (copyToDownloads) copyToDownloads(fileName, mime, bytes) else null) ?: JSONObject.NULL)
        extra.forEach { (key, value) -> meta.put(key, value) }
        File(dir, META).writeText(meta.toString())
        return meta
    }

    /** Gives a pending document its final name and only then copies it to Descargas/TRAMIX. */
    fun finalize(id: String, newName: String): JSONObject? {
        val meta = meta(id) ?: return null
        val dir = File(root, id)
        val current = File(dir, meta.getString("name"))
        if (!current.isFile) return null
        val mime = meta.optString("mime", "application/pdf")
        val fileName = sanitize(newName, mime)
        val target = File(dir, fileName)
        if (target != current && !current.renameTo(target)) return null
        meta.put("name", fileName).put("pending", false)
        if (meta.isNull("savedTo")) meta.put("savedTo", copyToDownloads(fileName, mime, target.readBytes()) ?: JSONObject.NULL)
        File(dir, META).writeText(meta.toString())
        return meta
    }

    fun mark(id: String, key: String, value: Boolean): Boolean {
        val meta = meta(id) ?: return false
        meta.put(key, value)
        File(File(root, id), META).writeText(meta.toString())
        return true
    }

    fun delete(id: String): Boolean {
        if (meta(id) == null) return false
        return File(root, id).deleteRecursively()
    }

    fun list(source: String): JSONArray {
        val items = root.listFiles().orEmpty().mapNotNull { dir ->
            runCatching { JSONObject(File(dir, META).readText()) }.getOrNull()
        }.filter { it.optString("source") == source }.sortedByDescending { it.optLong("createdAt") }
        return JSONArray(items)
    }

    fun meta(id: String): JSONObject? {
        if (!ID.matches(id)) return null
        return runCatching { JSONObject(File(File(root, id), META).readText()) }.getOrNull()
    }

    fun file(id: String): File? {
        val meta = meta(id) ?: return null
        return File(File(root, id), meta.getString("name")).takeIf { it.isFile }
    }

    fun uri(id: String): Uri? = file(id)?.let { FileProvider.getUriForFile(context, "${context.packageName}.files", it) }

    private fun copyToDownloads(name: String, mime: String, bytes: ByteArray): String? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/TRAMIX")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@runCatching null
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Descargas/TRAMIX/$name"
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return@runCatching null
            File(dir, name).writeBytes(bytes)
            "Android/data/${context.packageName}/files/Download/$name"
        }
    }.getOrNull()

    companion object {
        private const val META = "meta.json"
        private val ID = Regex("^[0-9a-f-]{36}$")

        fun sanitize(name: String, mime: String): String {
            var clean = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.')
            if (clean.isBlank() || clean.startsWith("downloadfile")) clean = "documento-imss"
            if (mime == "application/pdf" && !clean.lowercase().endsWith(".pdf")) {
                clean = clean.substringBeforeLast(".bin") + ".pdf"
            }
            return clean.take(120)
        }
    }
}
