'use client'

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { AlertTriangle, ExternalLink, Loader2, MailCheck, RefreshCw, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { TRAMIX_APK_URL } from '@/lib/imss-android'
import { completeAccount, releaseAccount, reserveAccount } from '@/lib/outlook/linked-reservation'
import type { PoolReservation } from '@/lib/outlook-pool/types'
import {
  CURP_PATTERN,
  DEFAULT_NSS_EMAIL,
  nssCancel,
  nssRefresh,
  nssShowPortal,
  nssStart,
  nssSubmit,
  nssSupport,
  nssTakeEvents,
  NSS_PATTERN,
  vigenciaStart,
  vigenciaSubmit,
  vigenciaSupport,
  type NssResult,
} from '@/lib/validar-nss'

type Phase = 'loading' | 'captcha' | 'widget' | 'submitting' | 'step' | 'sent' | 'rejected' | 'blocked'

const VIGENCIA_WAIT_MS = 25_000
const VIGENCIA_RETRY_DELAY_MS = 2_500
const VIGENCIA_MAX_ATTEMPTS = 3

const noop = () => () => {}
const useSupport = (vigencia: boolean) =>
  useSyncExternalStore(noop, vigencia ? vigenciaSupport : nssSupport, () => 'none' as const)

const fieldClass =
  'h-12 w-full rounded-xl border border-input bg-card px-4 text-base text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30 disabled:opacity-60'

/** The IMSS accepted the form with this email: it now belongs to that trámite. */
const isConfirmationLink = (text: string) =>
  /liga de confirmaci[oó]n/i.test(text.normalize('NFC'))
/** Portal wording that means the request did not go through, even if the page looked like a result. */
const PORTAL_FAILURE =
  /mantenimiento|intento(s)? previo|previamente|ya (se )?(ha|había|existe|cuenta)|no es posible|no (se )?pud|no fue posible|int[eé]nte(lo)? m[aá]s tarde|rechaz|error|inv[aá]lid|bloque/i
const isAccepted = (r: NssResult) => {
  const message = (r.message || '').normalize('NFC')
  if (isConfirmationLink(message)) return true
  return (r.kind === 'link_sent' || r.kind === 'found') && !PORTAL_FAILURE.test(message)
}

export function EnviarImss({ service = 'nss' }: { service?: 'nss' | 'vigencia' }) {
  const vigencia = service === 'vigencia'
  const support = useSupport(vigencia)
  const [curp, setCurp] = useState('')
  const [nss, setNss] = useState('')
  const [captcha, setCaptcha] = useState('')
  const [image, setImage] = useState<string | null>(null)
  const [phase, setPhase] = useState<Phase>('loading')
  const [notice, setNotice] = useState('')
  const [sentCurp, setSentCurp] = useState('')
  const [reserving, setReserving] = useState(false)
  const reservationRef = useRef<{ curp: string; r: PoolReservation; done: boolean } | null>(null)
  const startedRef = useRef(false)

  const releaseOpen = useCallback(() => {
    const held = reservationRef.current
    reservationRef.current = null
    if (held && !held.done) void releaseAccount(held.r)
  }, [])

  const attemptsRef = useRef(0)
  const submittedRef = useRef(false)
  const watchdogRef = useRef<number | null>(null)
  const clearWatchdog = () => {
    if (watchdogRef.current !== null) window.clearTimeout(watchdogRef.current)
    watchdogRef.current = null
  }

  const openPortal = useCallback(() => {
    // The portal is loaded with a neutral address; the reserved email replaces it when the form is sent.
    if (!vigencia) return nssStart(DEFAULT_NSS_EMAIL)
    clearWatchdog()
    const opened = vigenciaStart(DEFAULT_NSS_EMAIL)
    // The Vigencia page can be slow: if no CAPTCHA appears in time, reopen it before showing an error.
    watchdogRef.current = window.setTimeout(() => retryVigenciaRef.current('El portal de Vigencia no terminó de cargar.'), VIGENCIA_WAIT_MS)
    return opened
  }, [vigencia])

  const retryVigenciaRef = useRef<(reason: string) => void>(() => {})
  retryVigenciaRef.current = (reason: string) => {
    clearWatchdog()
    if (attemptsRef.current >= VIGENCIA_MAX_ATTEMPTS) {
      nssShowPortal(false)
      releaseOpen()
      setPhase('blocked')
      setNotice(reason)
      return
    }
    attemptsRef.current += 1
    setPhase('loading')
    window.setTimeout(() => {
      if (!openPortal()) retryVigenciaRef.current('La app no pudo abrir el portal del IMSS.')
    }, VIGENCIA_RETRY_DELAY_MS)
  }

  const start = useCallback(() => {
    setImage(null)
    setCaptcha('')
    setNotice('')
    setSentCurp('')
    setPhase('loading')
    attemptsRef.current = 0
    submittedRef.current = false
    if (!openPortal()) {
      if (vigencia) return retryVigenciaRef.current('La app no pudo abrir el portal del IMSS.')
      setPhase('blocked')
      setNotice('La app no pudo abrir el portal del IMSS.')
    }
  }, [vigencia, openPortal])

  useEffect(() => clearWatchdog, [])

  const again = () => {
    reservationRef.current = null
    setCurp('')
    setNss('')
    start()
  }

  useEffect(() => {
    if (support !== 'ready' || startedRef.current) return
    startedRef.current = true
    start()
    return () => {
      releaseOpen()
      nssCancel()
    }
  }, [support, start, releaseOpen])

  useEffect(() => {
    if (support !== 'ready') return
    const id = window.setInterval(() => {
      for (const event of nssTakeEvents()) {
        switch (event.status) {
          case 'loading':
            setPhase((p) => (p === 'sent' ? p : 'loading'))
            break
          case 'captcha': {
            if (vigencia) clearWatchdog()
            if (event.detail.image) setImage(event.detail.image)
            setCaptcha('')
            setPhase((p) => (p === 'sent' ? p : 'captcha'))
            // Before the first submit, Vigencia's CAPTCHA is the initial one, not a rejection.
            const rejected = event.detail.retry && (!vigencia || submittedRef.current)
            setNotice(rejected ? event.detail.message || 'El IMSS rechazó el CAPTCHA. Escribe el nuevo código.' : '')
            break
          }
          case 'captcha_widget':
            setPhase('widget')
            setNotice(event.detail.message || 'Resuelve la verificación en el portal.')
            break
          case 'submitting':
            setPhase('submitting')
            break
          case 'step':
            setPhase('step')
            setNotice(event.detail.message || 'El IMSS pide un paso adicional. Complétalo en el portal oficial.')
            break
          case 'result': {
            const result = event.detail
            nssShowPortal(false)
            const held = reservationRef.current
            if (isAccepted(result)) {
              if (held && !held.done) {
                held.done = true
                void completeAccount(held.r)
              }
              setSentCurp(result.curp || held?.curp || '')
              setPhase('sent')
            } else {
              releaseOpen()
              setNotice(result.message || 'El IMSS no aceptó la solicitud.')
              setPhase('rejected')
            }
            break
          }
          case 'fields_not_found':
          case 'load_error':
            if (vigencia && !submittedRef.current) {
              retryVigenciaRef.current(event.detail.reason || event.detail.message || 'El portal del IMSS no respondió.')
              break
            }
            nssShowPortal(false)
            releaseOpen()
            setPhase('blocked')
            setNotice(event.detail.reason || event.detail.message || 'El portal del IMSS no respondió.')
            break
        }
      }
    }, 600)
    return () => window.clearInterval(id)
  }, [support, releaseOpen, vigencia])

  const curpOk = CURP_PATTERN.test(curp)
  const nssOk = !vigencia || NSS_PATTERN.test(nss)
  const canSubmit = support === 'ready' && phase === 'captcha' && curpOk && nssOk && captcha.trim().length >= 3 && !reserving

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    setNotice('')

    let held = reservationRef.current
    if (held && held.curp !== curp) {
      releaseOpen()
      held = null
    }
    if (!held) {
      setReserving(true)
      const r = await reserveAccount(curp)
      setReserving(false)
      if (r === 'none') return setNotice('No hay correos disponibles. Agrega más en LECTURA DE CORREOS IMSS.')
      if (r === 'locked') return setNotice('Acceso bloqueado. Vuelve a entrar a IMSS DIRECT.')
      if (r === 'error') return setNotice('No se pudo asignar un correo. Intenta de nuevo.')
      held = { curp, r, done: false }
      reservationRef.current = held
    }

    const sent = vigencia
      ? vigenciaSubmit(nss, curp, held.r.email, captcha.trim())
      : nssSubmit(curp, held.r.email, captcha.trim())
    if (sent) {
      submittedRef.current = true
      setPhase('submitting')
    } else {
      releaseOpen()
      setNotice('No se pudo enviar al portal. Pide otro código.')
    }
  }

  if (phase === 'sent') {
    return (
      <section aria-live="polite" className="glass flex flex-col gap-4 rounded-3xl border border-border p-5 sm:p-6">
        <div role="status" className="flex flex-col gap-1 rounded-2xl border border-success/40 bg-success/10 px-4 py-3">
          <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wide text-success">
            <span className="size-3 shrink-0 rounded-full bg-success" aria-hidden="true" />
            TRÁMITE ENVIADO CORRECTAMENTE
          </h2>
          <p className="flex items-center gap-2 pl-5 text-xs font-semibold tracking-wide text-success">
            <MailCheck className="size-4" aria-hidden="true" />
            ESPERANDO DOCUMENTOS EN EL RECEPTOR
          </p>
        </div>
        {sentCurp ? (
          <div className="flex flex-col gap-0.5 rounded-xl border border-border bg-card px-4 py-3">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground">CURP</span>
            <span className="font-mono text-base tracking-wider text-foreground">{sentCurp}</span>
          </div>
        ) : null}
        {vigencia && nss ? (
          <div className="flex flex-col gap-0.5 rounded-xl border border-border bg-card px-4 py-3">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground">NSS</span>
            <span className="font-mono text-base tracking-wider text-foreground">{nss}</span>
          </div>
        ) : null}
        <Button type="button" size="lg" className="h-12 rounded-xl font-semibold tracking-wide" onClick={again}>
          NUEVO TRÁMITE
        </Button>
      </section>
    )
  }

  return (
    <form onSubmit={submit} className="glass flex flex-col gap-5 rounded-3xl border border-border p-5 sm:p-6" noValidate>
      <div className="flex flex-col gap-2">
        <label htmlFor="enviar-curp" className="text-xs font-semibold tracking-wide text-muted-foreground">
          CURP
        </label>
        <input
          id="enviar-curp"
          value={curp}
          onChange={(e) => setCurp(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 18))}
          className={cn(fieldClass, 'font-mono tracking-wider uppercase')}
          placeholder="ABCD000000HDFXXX00"
          autoCapitalize="characters"
          autoComplete="off"
          spellCheck={false}
          aria-invalid={Boolean(curp) && !curpOk}
          disabled={phase === 'submitting'}
        />
        {curp && !curpOk ? <p className="text-sm text-destructive">Revisa la CURP: deben ser 18 caracteres válidos.</p> : null}
      </div>

      {vigencia ? (
        <div className="flex flex-col gap-2">
          <label htmlFor="vigencia-nss" className="text-xs font-semibold tracking-wide text-muted-foreground">
            NSS
          </label>
          <input
            id="vigencia-nss"
            value={nss}
            onChange={(e) => setNss(e.target.value.replace(/\D/g, '').slice(0, 11))}
            className={cn(fieldClass, 'font-mono tracking-wider')}
            placeholder="00000000000"
            inputMode="numeric"
            autoComplete="off"
            spellCheck={false}
            aria-invalid={Boolean(nss) && !nssOk}
            disabled={phase === 'submitting'}
          />
          {nss && !nssOk ? <p className="text-sm text-destructive">Revisa el NSS: deben ser 11 dígitos.</p> : null}
        </div>
      ) : null}

      {support !== 'ready' ? (
        <OpenInApp outdated={support === 'outdated'} />
      ) : (
        <div className="flex flex-col gap-3 rounded-2xl border border-border bg-muted/50 p-4">
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground">CAPTCHA</span>
            {phase === 'captcha' || phase === 'loading' ? (
              <button
                type="button"
                onClick={() => {
                  setPhase('loading')
                  setImage(null)
                  if (!nssRefresh()) start()
                }}
                disabled={phase === 'loading'}
                className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-sm font-medium text-primary transition-colors hover:bg-accent disabled:opacity-50"
              >
                <RefreshCw className={cn('size-4', phase === 'loading' && 'animate-spin')} aria-hidden="true" />
                Otro código
              </button>
            ) : null}
          </div>

          <div className="flex min-h-20 items-center justify-center rounded-xl border border-border bg-card p-2" aria-live="polite">
            {phase === 'loading' ? (
              <span className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                Abriendo el portal del IMSS…
              </span>
            ) : phase === 'widget' || phase === 'step' ? (
              <div className="flex flex-col items-center gap-3 py-2 text-center">
                <p className="text-sm leading-relaxed text-muted-foreground">{notice}</p>
                <Button type="button" variant="outline" onClick={() => nssShowPortal(true)}>
                  <ExternalLink className="size-4" aria-hidden="true" />
                  Continuar en el portal
                </Button>
              </div>
            ) : phase === 'blocked' || phase === 'rejected' ? (
              <div role="alert" className="flex flex-col items-center gap-2 py-2 text-center">
                <p className="flex items-center gap-2 text-sm font-semibold tracking-wide text-destructive">
                  <AlertTriangle className="size-4 shrink-0" aria-hidden="true" />
                  REQUIERE INTERVENCIÓN EN EL SISTEMA
                </p>
                {notice ? <p className="text-xs leading-relaxed text-destructive/80">{notice}</p> : null}
                <Button type="button" variant="outline" className="mt-1" onClick={start}>
                  <RefreshCw className="size-4" aria-hidden="true" />
                  Reintentar
                </Button>
              </div>
            ) : image ? (
              // eslint-disable-next-line @next/next/no-img-element -- live data URL copied from the IMSS portal
              <img src={image} alt="Código CAPTCHA del portal del IMSS" className="h-auto max-h-28 w-auto max-w-full [image-rendering:pixelated]" />
            ) : (
              <span className="text-sm text-muted-foreground">Esperando el código…</span>
            )}
          </div>

          <label htmlFor="enviar-captcha" className="sr-only">
            Escribe el código CAPTCHA
          </label>
          <input
            id="enviar-captcha"
            value={captcha}
            onChange={(e) => setCaptcha(e.target.value.replace(/\s/g, '').slice(0, 32))}
            className={cn(fieldClass, 'text-center font-mono text-lg tracking-[0.3em]')}
            placeholder="Escribe el código"
            autoComplete="off"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            disabled={phase !== 'captcha'}
          />
        </div>
      )}

      {phase === 'captcha' && notice ? (
        <p
          role="alert"
          className={cn('flex items-start gap-2 text-sm leading-relaxed', isConfirmationLink(notice) ? 'text-success' : 'text-destructive')}
        >
          {isConfirmationLink(notice) ? (
            <MailCheck className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          ) : (
            <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          )}
          {notice}
        </p>
      ) : null}

      <Button type="submit" size="lg" className="h-13 rounded-xl text-base font-semibold tracking-wide" disabled={!canSubmit}>
        {phase === 'submitting' || reserving ? (
          <>
            <Loader2 className="size-5 animate-spin" aria-hidden="true" />
            ENVIANDO…
          </>
        ) : (
          'CONTINUAR'
        )}
      </Button>
    </form>
  )
}

function OpenInApp({ outdated }: { outdated: boolean }) {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-muted/50 p-4">
      <p className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground">
        <Smartphone className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
        El CAPTCHA del IMSS solo se muestra dentro de la app IMSS DIRECT para Android.
      </p>
      <a
        href={TRAMIX_APK_URL}
        download="IMSS-DIRECT.apk"
        className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold text-foreground transition-colors hover:bg-accent"
      >
        {outdated ? 'ACTUALIZAR APP' : 'DESCARGAR APP'}
      </a>
    </div>
  )
}
