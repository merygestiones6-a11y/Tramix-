'use client'

import {
  AlertTriangle,
  Check,
  CircleCheck,
  ClipboardCopy,
  Clock,
  Download,
  ExternalLink,
  Loader2,
  Mail,
  Play,
  Plug,
  Plus,
  RefreshCw,
  RotateCcw,
  Send,
  ShieldCheck,
  Smartphone,
} from 'lucide-react'
import Link from 'next/link'
import { useEffect, useMemo, useRef, useState } from 'react'
import { copyText } from '@/lib/clipboard'
import { cleanCurpInput, validateCurp } from '@/lib/curp-validator'
import { IMSS_NSS_PORTAL_URL } from '@/lib/imss'
import { type ReserveResult, completeAccount, releaseAccount, reserveAccount } from '@/lib/outlook-pool/reservation'
import type { PoolReservation } from '@/lib/outlook-pool/types'
import { IMSS_EXTENSION_ZIP, detectExtension, onImssStatus, startImssAutomation } from '@/lib/imss-bridge'
import {
  type AndroidImssEvent,
  type ImssDocument,
  TRAMIX_APK_URL,
  androidAppVersion,
  buildAppIntentUrl,
  isAndroidBrowser,
  listAndroidDocuments,
  readAndroidDocument,
  resumeAndroidImss,
  startAndroidImss,
  takeAndroidEvents,
  takePendingAndroidJob,
} from '@/lib/imss-android'
import { ImssDocumentCard } from '@/components/imss/imss-document'
import { ImssMailWatch } from '@/components/imss/imss-mail-watch'
import { cn } from '@/lib/utils'

type CopyKey = 'curp' | 'email'
type Mode = 'idle' | 'starting' | 'automating' | 'manual'
type ExtensionState = 'checking' | 'missing' | { version: string }
type Platform = { app: string | null; android: boolean }

interface Progress {
  fields: Set<string>
  hasCaptcha: boolean
  captchaReady: boolean
  submitted: boolean
  retry: boolean
  downloading: boolean
  documentId: string | null
  downloadError: string | null
  imssMessage: string | null
  documentRequested: boolean
  linkSent: boolean
  error: 'fields_not_found' | 'closed' | 'start_failed' | null
}

type CloudState = 'idle' | 'saving' | 'saved' | 'failed'

const initialProgress = (): Progress => ({
  fields: new Set(),
  hasCaptcha: true,
  captchaReady: false,
  submitted: false,
  retry: false,
  downloading: false,
  documentId: null,
  downloadError: null,
  imssMessage: null,
  documentRequested: false,
  linkSent: false,
  error: null,
})

function applyStatus(prev: Progress, status: string, detail: AndroidImssEvent['detail'] | undefined): Progress {
  const next = { ...prev, fields: new Set(prev.fields) }
  if (status === 'filled') {
    for (const field of detail?.fields ?? []) next.fields.add(field)
    next.hasCaptcha = detail?.hasCaptcha ?? prev.hasCaptcha
    next.retry = Boolean(detail?.retry)
    if (detail?.retry) {
      next.captchaReady = false
      next.submitted = false
      next.imssMessage = null
      next.documentRequested = false
    }
    next.error = null
  } else if (status === 'imss_response' && detail?.message) {
    next.imssMessage = detail.message
  } else if (status === 'document_requested') {
    next.documentRequested = true
  } else if (status === 'captcha_ready') {
    next.captchaReady = true
  } else if (status === 'submitted') {
    next.captchaReady = true
    next.submitted = true
    next.retry = false
  } else if (status === 'link_sent') {
    next.captchaReady = true
    next.submitted = true
    next.linkSent = true
    next.retry = false
    next.error = null
    if (detail?.message) next.imssMessage = detail.message
  } else if (status === 'fields_not_found') {
    next.error = 'fields_not_found'
  } else if (status === 'closed' && !prev.submitted && !prev.documentId) {
    next.error = 'closed'
  } else if (status === 'download_started') {
    next.downloading = true
    next.downloadError = null
  } else if (status === 'download_failed') {
    next.downloading = false
    next.downloadError = detail?.reason ?? 'Error desconocido'
  } else if (status === 'document' && detail?.id) {
    next.downloading = false
    next.downloadError = null
    next.documentId = detail.id
    next.submitted = true
    next.error = null
  }
  return next
}

export function ImssNss() {
  const [curp, setCurp] = useState('')
  const [email, setEmail] = useState('')
  const [mode, setMode] = useState<Mode>('idle')
  const [extension, setExtension] = useState<ExtensionState>('checking')
  const [requestId, setRequestId] = useState<string | null>(null)
  const [progress, setProgress] = useState<Progress>(initialProgress)
  const [copied, setCopied] = useState<CopyKey | null>(null)
  const [platform, setPlatform] = useState<Platform>({ app: null, android: false })
  const [documents, setDocuments] = useState<ImssDocument[]>([])
  const [poolError, setPoolError] = useState<Exclude<ReserveResult, PoolReservation> | null>(null)
  const [manualDone, setManualDone] = useState(false)
  const [watchId, setWatchId] = useState<string | null>(null)
  const [cloud, setCloud] = useState<CloudState>('idle')
  const [savedName, setSavedName] = useState<string | null>(null)
  const uploadedRef = useRef<Set<string>>(new Set())
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const reservationRef = useRef<PoolReservation | null>(null)
  const committedRef = useRef(false)
  const inApp = platform.app !== null

  useEffect(() => {
    let active = true
    const app = androidAppVersion()
    setPlatform({ app, android: isAndroidBrowser() })
    if (app) {
      setDocuments(listAndroidDocuments())
      const pending = takePendingAndroidJob()
      if (pending) setCurp(cleanCurpInput(pending.curp))
    } else {
      detectExtension().then((version) => {
        if (active) setExtension(version ? { version } : 'missing')
      })
    }
    return () => {
      active = false
      if (timer.current) clearTimeout(timer.current)
    }
  }, [])

  useEffect(() => {
    if (!requestId || inApp) return
    return onImssStatus(requestId, ({ status, detail }) => setProgress((prev) => applyStatus(prev, status, detail)))
  }, [requestId, inApp])

  // The app queues portal events while its WebView is in the background; drain them here.
  useEffect(() => {
    if (!inApp || mode !== 'automating') return
    const drain = () => {
      const events = takeAndroidEvents()
      if (!events.length) return
      setProgress((prev) => events.reduce((acc, e) => applyStatus(acc, e.status, e.detail), prev))
      if (events.some((e) => e.status === 'document')) setDocuments(listAndroidDocuments())
    }
    drain()
    const interval = setInterval(drain, 700)
    window.addEventListener('tramix-android', drain)
    return () => {
      clearInterval(interval)
      window.removeEventListener('tramix-android', drain)
    }
  }, [inApp, mode])

  // Account lifecycle: reserved on INICIAR, consumed once the IMSS accepts the form, returned if it never gets there.
  useEffect(() => {
    if (mode === 'automating' && progress.submitted) commitReservation()
  }, [mode, progress.submitted])

  useEffect(() => {
    if (mode === 'automating' && progress.error === 'closed' && !progress.submitted) dropReservation()
  }, [mode, progress.error, progress.submitted])

  useEffect(() => {
    const onLeave = () => dropReservation()
    window.addEventListener('pagehide', onLeave)
    return () => {
      window.removeEventListener('pagehide', onLeave)
      dropReservation()
    }
  }, [])

  function commitReservation() {
    const current = reservationRef.current
    if (!current || committedRef.current) return
    committedRef.current = true
    void completeAccount(current)
  }

  function dropReservation() {
    const current = reservationRef.current
    reservationRef.current = null
    if (current && !committedRef.current) void releaseAccount(current)
  }

  const curpResult = useMemo(() => (curp.length > 0 ? validateCurp(curp) : null), [curp])
  const curpValid = curpResult?.valid === true
  const ready = curpValid && mode !== 'starting'
  const latestDocument = progress.documentId ? documents.find((d) => d.id === progress.documentId) : undefined
  const pastDocuments = documents.filter((d) => d.id !== latestDocument?.id)

  // The app captured the PDF from the portal: publish it to the panel's Descargas for the whole team.
  useEffect(() => {
    if (!inApp || !watchId || !latestDocument || uploadedRef.current.has(latestDocument.id)) return
    const bytes = readAndroidDocument(latestDocument.id)
    if (!bytes) {
      setCloud('failed')
      return
    }
    uploadedRef.current.add(latestDocument.id)
    setCloud('saving')
    fetch(`/api/imss-mail/watch/${watchId}/document`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/pdf', 'x-file-name': encodeURIComponent(latestDocument.name) },
      body: new Blob([bytes as BlobPart], { type: 'application/pdf' }),
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error(String(res.status)))))
      .then((data: { name: string }) => {
        setSavedName(data.name)
        setCloud('saved')
      })
      .catch(() => {
        uploadedRef.current.delete(latestDocument.id)
        setCloud('failed')
      })
  }, [inApp, watchId, latestDocument])

  const onMailFound = (found: { id: string; name: string }[]) => {
    if (!found.length) return
    setSavedName((prev) => prev ?? found[found.length - 1].name)
    setCloud('saved')
  }

  const flash = (key: CopyKey) => {
    setCopied(key)
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setCopied(null), 2000)
  }

  const copy = async (key: CopyKey) => {
    if (await copyText(key === 'curp' ? curp : email)) flash(key)
  }

  const startManual = () => {
    window.open(IMSS_NSS_PORTAL_URL, '_blank', 'noopener,noreferrer')
    setMode('manual')
    void copy('curp')
  }

  const assignAccount = async (): Promise<string | null> => {
    const held = reservationRef.current
    if (held && !committedRef.current) return held.email
    dropReservation()
    const result = await reserveAccount(curp)
    if (typeof result === 'string') {
      setPoolError(result)
      return null
    }
    reservationRef.current = result
    committedRef.current = false
    setEmail(result.email)
    return result.email
  }

  const handleStart = async () => {
    if (!ready) return
    setPoolError(null)
    setManualDone(false)
    setProgress(initialProgress())
    setWatchId(null)
    setCloud('idle')
    setSavedName(null)
    setMode('starting')
    const email = await assignAccount()
    if (!email) {
      setMode('idle')
      return
    }
    if (inApp) {
      if (startAndroidImss(curp, email)) {
        setRequestId('android')
        setMode('automating')
      } else {
        setProgress({ ...initialProgress(), error: 'start_failed' })
        setMode('manual')
      }
      return
    }
    const version = await detectExtension()
    setExtension(version ? { version } : 'missing')
    if (!version) {
      startManual()
      return
    }
    const result = await startImssAutomation(curp, email)
    if (!result?.ok) {
      setProgress({ ...initialProgress(), error: 'start_failed' })
      setMode('manual')
      return
    }
    setRequestId(result.requestId)
    setMode('automating')
  }

  const recheck = async () => {
    setExtension('checking')
    const version = await detectExtension()
    setExtension(version ? { version } : 'missing')
  }

  const reset = () => {
    dropReservation()
    setCurp('')
    setEmail('')
    setMode('idle')
    setRequestId(null)
    setProgress(initialProgress())
    setCopied(null)
    setPoolError(null)
    setWatchId(null)
    setCloud('idle')
    setSavedName(null)
  }

  const editing = () => {
    setPoolError(null)
    if (mode !== 'idle') {
      dropReservation()
      setEmail('')
      setMode('idle')
      setRequestId(null)
    }
  }

  const confirmManualSubmit = () => {
    commitReservation()
    setManualDone(true)
  }

  return (
    <div className="flex flex-col gap-4">
      <form
        onSubmit={(event) => {
          event.preventDefault()
          void handleStart()
        }}
        className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5"
      >
        <div className="flex flex-col gap-2">
          <label htmlFor="imss-curp" className="text-sm font-semibold">
            CURP
          </label>
          <input
            id="imss-curp"
            value={curp}
            onChange={(e) => {
              setCurp(cleanCurpInput(e.target.value))
              editing()
            }}
            placeholder="18 caracteres"
            autoComplete="off"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            maxLength={40}
            aria-invalid={curpResult ? !curpValid : undefined}
            aria-describedby="imss-curp-hint"
            className="field-input font-mono tracking-wider uppercase"
          />
          <p
            id="imss-curp-hint"
            className={cn(
              'text-xs leading-relaxed',
              curpValid ? 'text-success' : curpResult ? 'text-destructive' : 'text-muted-foreground',
            )}
          >
            {curpValid
              ? 'CURP válida'
              : curpResult && !curpResult.valid
                ? curpResult.reasons[0]
                : `${curp.length}/18 caracteres`}
          </p>
        </div>

        <p className="flex items-start gap-2 rounded-2xl bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
          <Mail className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
          {email ? (
            <span>
              Cuenta asignada: <span className="font-semibold break-all text-foreground">{email}</span>
            </span>
          ) : (
            'Al pulsar INICIAR se asigna una cuenta disponible de Cuentas Outlook al correo y su confirmación.'
          )}
        </p>

        {poolError ? (
          <div role="alert" className="flex flex-col gap-2">
            <Notice
              text={
                poolError === 'none'
                  ? 'NO HAY CUENTAS DISPONIBLES. AGREGUE UNA CUENTA PARA CONTINUAR.'
                  : poolError === 'locked'
                    ? 'Ingresa la clave del panel en Cuentas Outlook para asignar una cuenta.'
                    : 'No se pudo asignar una cuenta. Intenta de nuevo.'
              }
            />
            {poolError !== 'error' ? (
              <Link
                href="/cuentas-outlook"
                className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent"
              >
                <Plus className="size-4" aria-hidden="true" />
                {poolError === 'none' ? 'AGREGAR CUENTA' : 'ABRIR CUENTAS OUTLOOK'}
              </Link>
            ) : null}
          </div>
        ) : null}

        <button
          type="submit"
          disabled={!ready}
          className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold tracking-wide text-primary-foreground transition-all hover:bg-primary/90 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50"
        >
          {mode === 'starting' ? (
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          ) : (
            <Play className="size-4" aria-hidden="true" />
          )}
          INICIAR
        </button>

        {inApp ? (
          <p className="flex items-center justify-center gap-2 text-xs font-medium text-success">
            <Smartphone className="size-3.5" aria-hidden="true" />
            App IMSS DIRECT Android · v{platform.app} · llenado automático
          </p>
        ) : platform.android && extension === 'missing' ? (
          <p className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
            <Smartphone className="size-3.5" aria-hidden="true" />
            En Android usa la app IMSS DIRECT para el llenado automático.
          </p>
        ) : (
          <ExtensionBadge state={extension} onRecheck={recheck} />
        )}
      </form>

      {platform.android && !inApp && mode === 'idle' ? (
        <AndroidAppCard curp={curpValid ? curp : ''} email="" />
      ) : null}

      <div aria-live="polite" className="flex flex-col gap-4">
        {mode === 'automating' ? (
          <AutomationStatus
            progress={progress}
            native={inApp}
            cloud={cloud}
            savedName={savedName}
            curp={curp}
            email={email}
            copied={copied}
            onCopy={copy}
            onReset={reset}
          />
        ) : null}

        {mode === 'automating' && latestDocument ? <ImssDocumentCard document={latestDocument} highlight /> : null}

        {mode === 'automating' && progress.submitted ? (
          <ImssMailWatch curp={curp} email={email} onWatch={setWatchId} onFound={onMailFound} />
        ) : null}

        {mode === 'manual' ? (
          <>
            {platform.android && !inApp ? (
              <AndroidAppCard curp={curp} email={email} />
            ) : extension === 'missing' ? (
              <InstallCard onRecheck={recheck} />
            ) : null}
            {progress.error === 'start_failed' ? (
              <Notice
                text={
                  inApp
                    ? 'La app no pudo abrir el portal. Continúa con los pasos manuales.'
                    : 'La extensión no pudo abrir el portal. Continúa con los pasos manuales.'
                }
              />
            ) : null}
            <ManualSteps curp={curp} email={email} copied={copied} onCopy={copy} onReset={reset} />
            {manualDone ? (
              <ImssMailWatch curp={curp} email={email} />
            ) : (
              <button
                type="button"
                onClick={confirmManualSubmit}
                className="inline-flex h-12 w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                <Send className="size-4" aria-hidden="true" />
                YA ENVIÉ EL TRÁMITE
              </button>
            )}
          </>
        ) : null}

        {mode === 'idle' || mode === 'starting' ? (
          <p className="flex items-start gap-2 px-1 text-xs leading-relaxed text-muted-foreground">
            <ShieldCheck className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            La CURP se valida en tu dispositivo. El CAPTCHA del IMSS siempre lo resuelves tú.
          </p>
        ) : null}
      </div>

      {inApp && pastDocuments.length > 0 ? (
        <section aria-labelledby="imss-docs-heading" className="flex flex-col gap-3">
          <h2 id="imss-docs-heading" className="px-1 text-sm font-semibold text-muted-foreground">
            DOCUMENTOS GUARDADOS
          </h2>
          {pastDocuments.map((doc) => (
            <ImssDocumentCard key={doc.id} document={doc} />
          ))}
        </section>
      ) : null}
    </div>
  )
}

function AndroidAppCard({ curp, email }: { curp: string; email: string }) {
  const [href, setHref] = useState(TRAMIX_APK_URL)
  useEffect(() => setHref(buildAppIntentUrl(curp, email)), [curp, email])

  return (
    <section aria-labelledby="imss-android-heading" className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
      <h2 id="imss-android-heading" className="flex items-center gap-2 text-base font-semibold">
        <Smartphone className="size-5 text-primary" aria-hidden="true" />
        Llenado automático en Android
      </h2>
      <p className="text-sm leading-relaxed text-muted-foreground">
        Chrome para Android no permite que una página llene otra. La app IMSS DIRECT abre el portal oficial del IMSS dentro
        de IMSS DIRECT, coloca CURP y correos, te deja el CAPTCHA y guarda el documento.
      </p>
      <details className="rounded-2xl border border-border bg-muted p-3 text-sm">
        <summary className="cursor-pointer font-semibold">Cómo instalarla</summary>
        <ol className="mt-2 flex list-decimal flex-col gap-1 pl-5 leading-relaxed text-muted-foreground">
          <li>Pulsa DESCARGAR APP y abre el archivo descargado.</li>
          <li>Si Android lo pide, permite instalar apps de Chrome.</li>
          <li>Vuelve aquí y pulsa ABRIR EN LA APP.</li>
        </ol>
      </details>
      <div className="flex flex-col gap-2">
        <a
          href={href}
          className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Smartphone className="size-4" aria-hidden="true" />
          ABRIR EN LA APP
        </a>
        <a
          href={TRAMIX_APK_URL}
          download="IMSS-DIRECT.apk"
          className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent"
        >
          <Download className="size-4" aria-hidden="true" />
          DESCARGAR APP
        </a>
      </div>
    </section>
  )
}

function ExtensionBadge({ state, onRecheck }: { state: ExtensionState; onRecheck: () => void }) {
  if (state === 'checking') {
    return (
      <p className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
        <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
        Buscando extensión IMSS DIRECT…
      </p>
    )
  }
  if (state === 'missing') {
    return (
      <p className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
        <Plug className="size-3.5" aria-hidden="true" />
        Extensión no detectada: modo manual.
        <a href={IMSS_EXTENSION_ZIP} download className="font-semibold text-primary underline-offset-2 hover:underline">
          Instalar
        </a>
        <button type="button" onClick={onRecheck} className="font-semibold text-primary underline-offset-2 hover:underline">
          Reintentar
        </button>
      </p>
    )
  }
  return (
    <p className="flex items-center justify-center gap-2 text-xs font-medium text-success">
      <Plug className="size-3.5" aria-hidden="true" />
      Extensión conectada · v{state.version} · llenado automático
    </p>
  )
}

interface Step {
  label: string
  note: string
  done: boolean
  manual?: boolean
  waiting?: boolean
}

function postSubmitSteps(progress: Progress, cloud: CloudState, savedName: string | null, native: boolean): Step[] {
  const { documentId, downloading, documentRequested, imssMessage, linkSent } = progress
  const responded = Boolean(documentId) || downloading || documentRequested || cloud === 'saved'
  const waitingLabel = linkSent ? 'ESPERANDO LIGA DE CONFIRMACIÓN' : 'ESPERANDO RESPUESTA DEL IMSS...'
  const waitingNote = linkSent
    ? 'Revisando el correo asignado para abrir la liga'
    : 'El portal sigue trabajando en segundo plano'
  const documentNote = documentId
    ? cloud === 'saved'
      ? savedName ?? 'Guardado en Descargas'
      : cloud === 'saving'
        ? 'Subiendo a Descargas…'
        : cloud === 'failed'
          ? 'Guardado en el teléfono; no se pudo subir a Descargas'
          : 'Guardado en el teléfono'
    : cloud === 'saved'
      ? savedName ?? 'Recibido por correo y guardado en Descargas'
      : downloading
        ? 'Descargando…'
        : native
          ? 'Se descargará automáticamente'
          : 'Se buscará en los correos vinculados'
  return [
    { label: 'CAPTCHA COMPLETADO', note: 'Resuelto por ti en el portal', done: true },
    { label: 'CONTINUAR FORMULARIO', note: 'Completado', done: true },
    {
      label: linkSent ? 'TRÁMITE ENVIADO' : 'FORMULARIO ENVIADO',
      note: linkSent ? 'El IMSS envió la liga de confirmación al correo' : 'Aceptado por el portal del IMSS',
      done: true,
    },
    {
      label: responded ? 'RESPUESTA DEL IMSS RECIBIDA' : waitingLabel,
      note: responded ? 'El IMSS generó el documento' : linkSent ? waitingNote : imssMessage ?? waitingNote,
      done: responded,
    },
    {
      label: cloud === 'saved' || documentId ? 'DOCUMENTO DESCARGADO' : 'DOCUMENTO PENDIENTE',
      note: documentNote,
      done: cloud === 'saved' || (Boolean(documentId) && cloud !== 'saving'),
      waiting: !documentId && cloud !== 'saved',
    },
  ]
}

function AutomationStatus({
  progress,
  native,
  cloud,
  savedName,
  curp,
  email,
  copied,
  onCopy,
  onReset,
}: {
  progress: Progress
  native: boolean
  cloud: CloudState
  savedName: string | null
  curp: string
  email: string
  copied: CopyKey | null
  onCopy: (key: CopyKey) => void
  onReset: () => void
}) {
  const { fields, hasCaptcha, captchaReady, submitted, error, retry, documentId, downloadError } = progress
  const emailDone = fields.has('email')
  const finished = cloud === 'saved' || (Boolean(documentId) && cloud !== 'saving')
  const preSubmitSteps: Step[] = [
    {
      label: native ? 'Portal oficial abierto en IMSS DIRECT' : 'Portal oficial abierto',
      note: 'serviciosdigitales.imss.gob.mx',
      done: true,
    },
    { label: 'CURP colocada', note: 'Llenado automático', done: fields.has('curp') },
    {
      label: 'Correo y confirmación colocados',
      note: emailDone && !fields.has('confirm') ? 'Confirmación pendiente en el portal' : 'Mismo correo en ambos campos',
      done: emailDone && fields.has('confirm'),
    },
    {
      label: 'CAPTCHA',
      note: retry
        ? 'El IMSS rechazó el envío: vuelve a escribirlo'
        : hasCaptcha
          ? 'Manual: resuélvelo tú en el portal'
          : 'No se detectó CAPTCHA',
      done: captchaReady || (!hasCaptcha && emailDone),
      manual: true,
    },
    { label: 'Continuar formulario', note: 'Pulsa CONTINUAR en el asistente del portal', done: submitted },
  ]
  const steps = submitted ? postSubmitSteps(progress, cloud, savedName, native) : preSubmitSteps
  const current = steps.findIndex((s) => !s.done)

  return (
    <section aria-labelledby="imss-auto-heading" className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
      <h2
        id="imss-auto-heading"
        className={cn('flex items-center gap-2 text-base font-semibold', finished ? 'text-success' : 'text-foreground')}
      >
        {finished ? (
          <CircleCheck className="size-5" aria-hidden="true" />
        ) : (
          <Loader2 className="size-5 animate-spin text-primary" aria-hidden="true" />
        )}
        {finished ? 'PROCESO COMPLETADO' : 'AUTOMATIZACIÓN EN CURSO'}
      </h2>

      <ol className="flex flex-col gap-2">
        {steps.map((step, i) => {
          const active = i === current && !error
          return (
            <li
              key={step.label}
              className={cn(
                'flex items-center gap-3 rounded-2xl border p-3',
                step.done
                  ? 'border-success/30 bg-success/10'
                  : active
                    ? 'border-primary/40 bg-primary/5'
                    : 'border-border bg-muted',
              )}
            >
              <span
                className={cn(
                  'flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold',
                  step.done ? 'bg-success text-success-foreground' : 'bg-card text-muted-foreground',
                )}
              >
                {step.done ? (
                  <Check className="size-3.5" aria-hidden="true" />
                ) : step.waiting && !active ? (
                  <Clock className="size-3.5" aria-hidden="true" />
                ) : active ? (
                  <Loader2 className="size-3.5 animate-spin text-primary" aria-hidden="true" />
                ) : (
                  i + 1
                )}
              </span>
              <div className="flex min-w-0 flex-col">
                <span className="text-sm font-semibold">{step.label}</span>
                <span className="truncate text-xs text-muted-foreground">{step.note}</span>
              </div>
              <span className="sr-only">{step.done ? 'Completado' : active ? 'En curso' : 'Pendiente'}</span>
            </li>
          )
        })}
      </ol>

      {error ? (
        <div className="flex flex-col gap-2">
          <Notice
            text={
              error === 'closed'
                ? native
                  ? 'Se cerró el portal antes de terminar. Pulsa INICIAR para volver a abrirlo.'
                  : 'Se cerró la pestaña del portal antes de terminar.'
                : 'No se encontraron los campos en el portal. Si apareció una verificación del IMSS, complétala; si no, usa copiar y pegar.'
            }
          />
          <CopyButton label="CURP" value={curp} mono active={copied === 'curp'} onCopy={() => onCopy('curp')} />
          <CopyButton label="CORREO" value={email} active={copied === 'email'} onCopy={() => onCopy('email')} />
        </div>
      ) : null}

      {downloadError ? <Notice text={`No se pudo descargar el documento: ${downloadError}`} /> : null}

      <div className="flex flex-col gap-2">
        {native && !submitted && !documentId && error !== 'closed' ? (
          <button
            type="button"
            onClick={() => resumeAndroidImss()}
            className="inline-flex h-12 w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            <ExternalLink className="size-4" aria-hidden="true" />
            VOLVER AL PORTAL
          </button>
        ) : null}
        <button
          type="button"
          onClick={onReset}
          className="inline-flex h-11 w-full shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent"
        >
          <RotateCcw className="size-4" aria-hidden="true" />
          NUEVO
        </button>
      </div>
    </section>
  )
}

function InstallCard({ onRecheck }: { onRecheck: () => void }) {
  return (
    <section aria-labelledby="imss-install-heading" className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
      <h2 id="imss-install-heading" className="flex items-center gap-2 text-base font-semibold">
        <Plug className="size-5 text-primary" aria-hidden="true" />
        Activa el llenado automático
      </h2>
      <p className="text-sm leading-relaxed text-muted-foreground">
        El portal del IMSS bloquea navegadores de servidor, así que el llenado ocurre en tu propio navegador con la
        extensión IMSS DIRECT. Funciona en Chrome, Edge, Brave y Firefox.
      </p>
      <details className="rounded-2xl border border-border bg-muted p-3 text-sm">
        <summary className="cursor-pointer font-semibold">Cómo instalarla</summary>
        <ol className="mt-2 flex list-decimal flex-col gap-1 pl-5 leading-relaxed text-muted-foreground">
          <li>Descarga y descomprime el archivo.</li>
          <li>
            Abre <span className="font-mono text-foreground">chrome://extensions</span> y activa el modo desarrollador.
          </li>
          <li>Pulsa “Cargar descomprimida” y elige la carpeta.</li>
          <li>Vuelve aquí y pulsa REINTENTAR.</li>
        </ol>
      </details>
      <div className="flex flex-col gap-2 sm:flex-row">
        <a
          href={IMSS_EXTENSION_ZIP}
          download
          className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 sm:flex-1"
        >
          <Download className="size-4" aria-hidden="true" />
          DESCARGAR EXTENSIÓN
        </a>
        <button
          type="button"
          onClick={onRecheck}
          className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent sm:flex-1"
        >
          <RefreshCw className="size-4" aria-hidden="true" />
          REINTENTAR
        </button>
      </div>
    </section>
  )
}

function ManualSteps({
  curp,
  email,
  copied,
  onCopy,
  onReset,
}: {
  curp: string
  email: string
  copied: CopyKey | null
  onCopy: (key: CopyKey) => void
  onReset: () => void
}) {
  return (
    <section aria-labelledby="imss-steps-heading" className="glass flex flex-col gap-4 rounded-3xl border-success/30 p-4 sm:p-5">
      <h2 id="imss-steps-heading" className="flex items-center gap-2 text-base font-semibold text-success">
        <CircleCheck className="size-5" aria-hidden="true" />
        PORTAL IMSS ABIERTO
      </h2>
      <ol className="flex flex-col gap-3">
        <Step n={1} title="Pega la CURP" note="Ya está copiada.">
          <CopyButton label="CURP" value={curp} mono active={copied === 'curp'} onCopy={() => onCopy('curp')} />
        </Step>
        <Step n={2} title="Pega el correo en ambos campos" note="Correo y confirmación llevan el mismo valor.">
          <CopyButton label="CORREO" value={email} active={copied === 'email'} onCopy={() => onCopy('email')} />
        </Step>
        <Step n={3} title="Resuelve el CAPTCHA" note="Hazlo tú directamente en el portal del IMSS." />
      </ol>
      <div className="flex flex-col gap-2 sm:flex-row">
        <a
          href={IMSS_NSS_PORTAL_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent sm:flex-1"
        >
          <ExternalLink className="size-4" aria-hidden="true" />
          ABRIR PORTAL
        </a>
        <button
          type="button"
          onClick={onReset}
          className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent sm:flex-1"
        >
          <RotateCcw className="size-4" aria-hidden="true" />
          NUEVO
        </button>
      </div>
    </section>
  )
}

function Notice({ text }: { text: string }) {
  return (
    <p className="flex items-start gap-2 rounded-2xl border border-destructive/30 bg-destructive/10 p-3 text-xs leading-relaxed text-destructive">
      <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
      {text}
    </p>
  )
}

function Step({ n, title, note, children }: { n: number; title: string; note: string; children?: React.ReactNode }) {
  return (
    <li className="flex flex-col gap-2.5 rounded-2xl border border-border bg-muted p-3.5">
      <div className="flex items-start gap-3">
        <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
          {n}
        </span>
        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-semibold">{title}</span>
          <span className="text-xs leading-relaxed text-muted-foreground">{note}</span>
        </div>
      </div>
      {children}
    </li>
  )
}

function CopyButton({
  label,
  value,
  mono,
  active,
  onCopy,
}: {
  label: string
  value: string
  mono?: boolean
  active: boolean
  onCopy: () => void
}) {
  return (
    <button
      type="button"
      onClick={onCopy}
      aria-label={`Copiar ${label}`}
      className={cn(
        'flex h-11 w-full items-center justify-between gap-3 rounded-xl border px-3.5 text-left transition-colors',
        active ? 'border-success/40 bg-success/10' : 'border-border bg-card hover:bg-accent',
      )}
    >
      <span className={cn('truncate text-sm font-medium', mono && 'font-mono tracking-wider')}>{value}</span>
      <span
        className={cn(
          'inline-flex shrink-0 items-center gap-1.5 text-xs font-semibold',
          active ? 'text-success' : 'text-primary',
        )}
      >
        {active ? (
          <Check className="size-4 animate-pop" aria-hidden="true" />
        ) : (
          <ClipboardCopy className="size-4" aria-hidden="true" />
        )}
        {active ? 'COPIADO' : 'COPIAR'}
      </span>
    </button>
  )
}
