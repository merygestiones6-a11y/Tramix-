'use client'

import { CircleCheck, FileText, Loader2, Mail, MailQuestion, RefreshCw } from 'lucide-react'
import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { WatchSteps } from '@/components/imss/watch-steps'
import { AppRunCard } from '@/components/outlook-pool/app-runs'
import { outlookApp, useOutlookApp } from '@/lib/outlook-app'
import { STAGE_TEXT, type WatchProgress } from '@/lib/outlook/progress-types'
import { usePoll } from '@/lib/outlook/use-poll'
import { cn } from '@/lib/utils'

type WatchStatus = Omit<WatchProgress, 'accountErrors'> & {
  id: string
  status: 'waiting' | 'found' | 'expired' | 'cancelled'
  checks: number
  lastCheckAt: string | null
  accountErrors: number
}

const fetcher = async (url: string): Promise<WatchStatus> => {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) throw new Error(`status-${res.status}`)
  return res.json()
}

const FINAL_STAGES = new Set(['completed', 'expired', 'cancelled'])

/** In the Android app: opens the Outlook session for this email and follows the trámite on the phone. */
function PhoneRun({ curp, email }: { curp: string; email: string }) {
  const app = useOutlookApp()
  const [runId, setRunId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const started = useRef(false)

  useEffect(() => {
    if (!app.ready || !app.inApp || !app.supported || started.current) return
    started.current = true
    const id = outlookApp.run(email, curp)
    if (id.startsWith('!')) {
      setError(
        id === '!in_use'
          ? 'Esa cuenta Outlook ya está en uso en otro trámite.'
          : id === '!login_required'
            ? 'Inicia sesión en esa cuenta desde CUENTAS OUTLOOK y vuelve a intentarlo.'
            : 'No se pudo abrir la sesión de Outlook en el teléfono.',
      )
    } else setRunId(id)
  }, [app.ready, app.inApp, app.supported, curp, email])

  if (error) {
    return (
      <p role="alert" className="glass rounded-2xl p-4 text-sm leading-relaxed text-destructive">
        {error}
      </p>
    )
  }
  const run = runId ? app.runs.find((r) => r.id === runId) : undefined
  if (!run) return null
  const active = run.status === 'running' || run.status === 'manual'
  return (
    <div className="flex flex-col gap-2">
      <ul className="flex flex-col" aria-label="Trámite en el teléfono">
        <AppRunCard run={run} />
      </ul>
      {active && (
        <button
          type="button"
          onClick={() => {
            if (!outlookApp.retry(run.id)) setError('No se pudo reintentar el trámite en el teléfono.')
          }}
          className="inline-flex items-center justify-center gap-2 self-start rounded-full border border-border px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          <RefreshCw className="size-4" aria-hidden="true" />
          Revisar ahora en el teléfono
        </button>
      )}
    </div>
  )
}

/** Shown once the IMSS form is sent: registers the trámite and follows it until the PDF is in DESCARGAR. */
export function ImssMailWatch(props: {
  curp: string
  email: string
  onWatch?: (id: string) => void
  onFound?: (documents: { id: string; name: string }[]) => void
}) {
  return (
    <>
      <PhoneRun curp={props.curp} email={props.email} />
      <ServerWatch {...props} />
    </>
  )
}

function ServerWatch({
  curp,
  email,
  onWatch,
  onFound,
}: {
  curp: string
  email: string
  onWatch?: (id: string) => void
  onFound?: (documents: { id: string; name: string }[]) => void
}) {
  const [watchId, setWatchId] = useState<string | null>(null)
  const [failed, setFailed] = useState(false)
  const [checking, setChecking] = useState(false)
  const registered = useRef(false)

  useEffect(() => {
    if (registered.current) return
    registered.current = true
    fetch('/api/imss-mail/watch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ curp, email }),
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(res.status)))
      .then((data: { id: string }) => {
        setWatchId(data.id)
        onWatch?.(data.id)
      })
      .catch(() => setFailed(true))
  }, [curp, email, onWatch])

  const { data, mutate } = usePoll(watchId ? `/api/imss-mail/watch/${watchId}` : null, fetcher, {
    refreshInterval: (latest) => (latest && FINAL_STAGES.has(latest.stage) ? 0 : 10_000),
  })

  const docsKey = data?.documents.map((d) => d.panelId).join(',') ?? ''
  useEffect(() => {
    if (docsKey && data) onFound?.(data.documents.map((d) => ({ id: d.panelId, name: d.name })))
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fire once per new set of documents in DESCARGAR
  }, [docsKey])

  async function checkNow() {
    if (!watchId) return
    setChecking(true)
    await fetch(`/api/imss-mail/watch/${watchId}/check`, { method: 'POST' }).catch(() => null)
    await mutate()
    setChecking(false)
  }

  const stage = data?.stage
  const done = stage === 'completed' || stage === 'collecting'
  const stalled = failed || stage === 'expired' || stage === 'cancelled' || stage === 'no_accounts'
  const working = !!data && !FINAL_STAGES.has(data.stage) && stage !== 'no_accounts'
  const text = stage ? STAGE_TEXT[stage] : null
  const title = failed ? 'NO SE PUDO INICIAR LA BÚSQUEDA' : (text?.title ?? 'REGISTRANDO TRÁMITE')
  let note = failed ? 'Revisa tu conexión y vuelve a intentarlo.' : (text?.note ?? 'Registrando el trámite…')
  if (stage === 'searching' && data) {
    note = `Revisando ${data.accounts} ${data.accounts === 1 ? 'cuenta' : 'cuentas'} Outlook vinculadas.`
  }

  return (
    <section aria-labelledby="imss-mail-watch-heading" className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
      <h2
        id="imss-mail-watch-heading"
        className={cn('flex items-center gap-2 text-base font-semibold', done ? 'text-success' : 'text-foreground')}
      >
        {done ? (
          <CircleCheck className="size-5" aria-hidden="true" />
        ) : stalled ? (
          <MailQuestion className="size-5 text-muted-foreground" aria-hidden="true" />
        ) : (
          <Mail className="size-5 text-primary" aria-hidden="true" />
        )}
        {title}
      </h2>
      <p className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground" aria-live="polite">
        {working ? <Loader2 className="mt-0.5 size-4 shrink-0 animate-spin text-primary" aria-hidden="true" /> : null}
        {note}
      </p>

      {data ? <WatchSteps steps={data.steps} /> : null}

      {data && data.accountErrors > 0 ? (
        <p className="text-xs leading-relaxed text-destructive">
          {data.accountErrors === 1 ? 'Una cuenta Outlook necesita' : `${data.accountErrors} cuentas Outlook necesitan`}{' '}
          volver a vincularse en CUENTAS OUTLOOK.
        </p>
      ) : null}

      {data?.documents.length ? (
        <ul className="flex flex-col gap-2">
          {data.documents.map((doc) => (
            <li key={doc.panelId} className="flex items-center gap-2 rounded-2xl border border-success/30 bg-success/10 p-3">
              <FileText className="size-4 shrink-0 text-success" aria-hidden="true" />
              <span className="truncate text-sm font-semibold">{doc.name}</span>
            </li>
          ))}
        </ul>
      ) : null}

      <div className="flex flex-col gap-2 sm:flex-row">
        {working ? (
          <button
            type="button"
            onClick={checkNow}
            disabled={checking}
            className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 text-sm font-semibold transition-colors hover:bg-accent disabled:opacity-50 sm:flex-1"
          >
            <RefreshCw className={cn('size-4', checking && 'animate-spin')} aria-hidden="true" />
            REVISAR AHORA
          </button>
        ) : null}
        {stage === 'no_accounts' ? (
          <Link
            href="/cuentas-outlook"
            className="inline-flex h-11 shrink-0 items-center justify-center rounded-xl border border-border bg-card px-4 text-sm font-semibold transition-colors hover:bg-accent sm:flex-1"
          >
            VINCULAR OUTLOOK
          </Link>
        ) : null}
        <Link
          href={stalled ? '/' : '/panel'}
          className={cn(
            'inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-colors sm:flex-1',
            done ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'border border-border bg-card hover:bg-accent',
          )}
        >
          {done ? 'VER EN DESCARGAR' : stalled ? 'IR A SUBIR' : 'ABRIR DESCARGAR'}
        </Link>
      </div>
    </section>
  )
}
