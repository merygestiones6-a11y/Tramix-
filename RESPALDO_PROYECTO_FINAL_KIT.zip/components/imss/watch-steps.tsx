import { CircleCheck, CircleDashed, CircleMinus, CircleX, Loader2 } from 'lucide-react'
import { STEP_LABELS, type StepState, type WatchProgress } from '@/lib/outlook/progress-types'
import { cn } from '@/lib/utils'

const STATE_LABEL: Record<StepState, string> = {
  pending: 'pendiente',
  active: 'en curso',
  done: 'listo',
  failed: 'falló',
  skipped: 'no necesario',
}

function StepIcon({ state }: { state: StepState }) {
  const cls = 'size-4 shrink-0'
  if (state === 'done') return <CircleCheck className={cn(cls, 'text-success')} aria-hidden="true" />
  if (state === 'active') return <Loader2 className={cn(cls, 'animate-spin text-primary')} aria-hidden="true" />
  if (state === 'failed') return <CircleX className={cn(cls, 'text-destructive')} aria-hidden="true" />
  if (state === 'skipped') return <CircleMinus className={cn(cls, 'text-muted-foreground')} aria-hidden="true" />
  return <CircleDashed className={cn(cls, 'text-muted-foreground/60')} aria-hidden="true" />
}

/** Real per-step status of the Outlook → IMSS → DESCARGAR chain. */
export function WatchSteps({ steps }: { steps: WatchProgress['steps'] }) {
  return (
    <ol className="flex flex-col gap-1.5">
      {STEP_LABELS.map(([key, label]) => {
        const state = steps[key]
        return (
          <li key={key} className="flex items-center gap-2 text-sm">
            <StepIcon state={state} />
            <span className={cn(state === 'pending' || state === 'skipped' ? 'text-muted-foreground' : 'text-foreground')}>
              {label}
            </span>
            <span className="sr-only">: {STATE_LABEL[state]}</span>
          </li>
        )
      })}
    </ol>
  )
}
