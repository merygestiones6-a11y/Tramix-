'use client'

import { ExternalLink, FileText, Loader2, Share2 } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import {
  type ImssDocument,
  formatBytes,
  openAndroidDocument,
  readAndroidDocument,
  shareAndroidDocument,
} from '@/lib/imss-android'
import { openPdfDocument } from '@/lib/pdf/pdfjs'

const MAX_PAGES = 4

/** Renders the PDF saved by the Android app with pdf.js (Android WebView has no built-in PDF viewer). */
function PdfPages({ id }: { id: string }) {
  const container = useRef<HTMLDivElement>(null)
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [pages, setPages] = useState(0)

  useEffect(() => {
    let cancelled = false
    let close: (() => unknown) | null = null
    const host = container.current
    setState('loading')

    ;(async () => {
      const bytes = readAndroidDocument(id)
      if (!bytes || !host) throw new Error('missing')
      const opened = await openPdfDocument(bytes)
      close = opened.close
      const { doc } = opened
      if (cancelled) return
      setPages(doc.numPages)
      host.replaceChildren()
      const width = host.clientWidth || 360
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      for (let n = 1; n <= Math.min(doc.numPages, MAX_PAGES); n++) {
        const page = await doc.getPage(n)
        if (cancelled) return
        const base = page.getViewport({ scale: 1 })
        const viewport = page.getViewport({ scale: (width / base.width) * ratio })
        const canvas = document.createElement('canvas')
        canvas.width = viewport.width
        canvas.height = viewport.height
        canvas.className = 'w-full rounded-xl border border-border bg-card'
        canvas.setAttribute('aria-label', `Página ${n}`)
        host.appendChild(canvas)
        await page.render({ canvas, viewport }).promise
      }
      if (!cancelled) setState('ready')
    })().catch(() => {
      if (!cancelled) setState('error')
    })

    return () => {
      cancelled = true
      void close?.()
    }
  }, [id])

  return (
    <div className="flex flex-col gap-2">
      {state === 'loading' ? (
        <p className="flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground">
          <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          Cargando vista previa…
        </p>
      ) : null}
      {state === 'error' ? (
        <p className="py-4 text-center text-xs text-muted-foreground">
          No se pudo mostrar la vista previa. Usa ABRIR para verlo.
        </p>
      ) : null}
      <div ref={container} className="flex flex-col gap-2" />
      {state === 'ready' && pages > MAX_PAGES ? (
        <p className="text-center text-xs text-muted-foreground">
          {`Mostrando ${MAX_PAGES} de ${pages} páginas.`}
        </p>
      ) : null}
    </div>
  )
}

export function ImssDocumentCard({ document, highlight }: { document: ImssDocument; highlight?: boolean }) {
  const isPdf = document.mime === 'application/pdf'
  const date = new Date(document.createdAt).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' })

  return (
    <article
      className={`glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5 ${highlight ? 'border-success/40' : ''}`}
      aria-label={document.name}
    >
      <div className="flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <FileText className="size-5" aria-hidden="true" />
        </span>
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className="truncate text-sm font-semibold">{document.name}</span>
          <span className="text-xs text-muted-foreground">
            {formatBytes(document.size)} · {date}
          </span>
          {document.savedTo ? (
            <span className="truncate text-xs text-success">{`Guardado en ${document.savedTo}`}</span>
          ) : null}
        </div>
      </div>

      {isPdf && highlight ? <PdfPages id={document.id} /> : null}

      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => openAndroidDocument(document.id)}
          className="inline-flex h-11 flex-1 shrink-0 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <ExternalLink className="size-4" aria-hidden="true" />
          ABRIR
        </button>
        <button
          type="button"
          onClick={() => shareAndroidDocument(document.id)}
          className="inline-flex h-11 flex-1 shrink-0 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold transition-colors hover:bg-accent"
        >
          <Share2 className="size-4" aria-hidden="true" />
          COMPARTIR
        </button>
      </div>
    </article>
  )
}
