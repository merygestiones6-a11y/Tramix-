'use client'

import { useRef, useState, type FormEvent } from 'react'
import { Check, Copy, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const CURP_REGEX = /^[A-Z]{4}\d{6}[HMX][A-Z]{5}[A-Z\d]\d$/

type State =
  | { kind: 'idle' }
  | { kind: 'loading' }
  | { kind: 'success'; nss: string }
  | { kind: 'not_found'; message: string }
  | { kind: 'error'; message: string }

export type NssLookupProps = {
  /** Ruta del backend que consulta Datos Non Stop. */
  endpoint?: string
  /** Se ejecuta cuando se obtiene un NSS válido. */
  onResult?: (result: { curp: string; nss: string }) => void
  className?: string
}

export function NssLookup({ endpoint = '/api/nss', onResult, className }: NssLookupProps) {
  const [curp, setCurp] = useState('')
  const [state, setState] = useState<State>({ kind: 'idle' })
  const [copied, setCopied] = useState(false)
  const inFlight = useRef(false)
  const lastQueried = useRef<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const isValid = CURP_REGEX.test(curp)
  const isLoading = state.kind === 'loading'
  const showFormatError = curp.length === 18 && !isValid

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    // Avoid duplicate requests: one at a time, and never re-query a CURP whose result is on screen.
    if (!isValid || inFlight.current) return
    if (lastQueried.current === curp && state.kind !== 'idle' && state.kind !== 'error') return

    inFlight.current = true
    lastQueried.current = curp
    setState({ kind: 'loading' })
    setCopied(false)

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ curp }),
      })
      const data = (await response.json().catch(() => ({}))) as {
        nss?: string
        error?: string
        code?: string
      }

      if (response.ok && data.nss && /^\d{11}$/.test(data.nss)) {
        setState({ kind: 'success', nss: data.nss })
        onResult?.({ curp, nss: data.nss })
      } else if (data.code === 'not_found') {
        setState({ kind: 'not_found', message: data.error ?? 'No hay un NSS asociado a esta CURP.' })
      } else {
        setState({ kind: 'error', message: data.error ?? 'Ocurrió un error. Intenta de nuevo.' })
      }
    } catch {
      setState({ kind: 'error', message: 'Sin conexión. Revisa tu red e intenta de nuevo.' })
    } finally {
      inFlight.current = false
    }
  }

  async function handleCopy(nss: string) {
    try {
      await navigator.clipboard.writeText(nss)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  function handleReset() {
    setCurp('')
    setState({ kind: 'idle' })
    setCopied(false)
    lastQueried.current = null
    inputRef.current?.focus()
  }

  return (
    <div className={cn('flex flex-col gap-5', className)}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3" noValidate>
        <div className="flex items-baseline justify-between">
          <label htmlFor="curp" className="text-sm font-medium text-foreground">
            CURP
          </label>
          <span className="font-mono text-xs text-muted-foreground tabular-nums" aria-hidden="true">
            {curp.length}/18
          </span>
        </div>
        <input
          ref={inputRef}
          id="curp"
          name="curp"
          type="text"
          inputMode="text"
          autoComplete="off"
          autoCapitalize="characters"
          autoFocus
          spellCheck={false}
          maxLength={18}
          placeholder="Ingresa 18 caracteres"
          value={curp}
          onChange={(e) => {
            setCurp(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 18))
            if (!isLoading && state.kind !== 'idle') setState({ kind: 'idle' })
          }}
          aria-describedby="curp-hint"
          aria-invalid={showFormatError}
          className="h-12 w-full rounded-lg border border-input bg-background px-4 font-mono text-base tracking-widest text-foreground uppercase outline-none transition-colors placeholder:font-sans placeholder:tracking-normal placeholder:normal-case placeholder:text-muted-foreground focus-visible:border-primary focus-visible:bg-card focus-visible:ring-3 focus-visible:ring-primary/15 aria-invalid:border-destructive"
        />
        <p
          id="curp-hint"
          className={cn('min-h-4 text-xs', showFormatError ? 'text-destructive' : 'text-muted-foreground')}
        >
          {showFormatError ? 'El formato de la CURP no es válido.' : 'Se convierte a mayúsculas automáticamente.'}
        </p>
        <Button type="submit" size="lg" disabled={!isValid || isLoading} className="h-12 text-base">
          {isLoading ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Consultando…
            </>
          ) : (
            'Consultar NSS'
          )}
        </Button>
      </form>

      <div aria-live="polite">
        {state.kind === 'success' && (
          <div className="flex flex-col gap-4 border-t border-border pt-5">
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-muted-foreground">Número de Seguro Social</span>
              <output className="font-mono text-4xl font-semibold tracking-wider text-primary tabular-nums">
                {state.nss}
              </output>
            </div>
            <div className="flex gap-2">
              <Button type="button" size="lg" className="h-11 flex-1" onClick={() => handleCopy(state.nss)}>
                {copied ? <Check aria-hidden="true" /> : <Copy aria-hidden="true" />}
                {copied ? 'Copiado' : 'Copiar NSS'}
              </Button>
              <Button type="button" variant="outline" size="lg" className="h-11" onClick={handleReset}>
                Nueva consulta
              </Button>
            </div>
          </div>
        )}

        {state.kind === 'not_found' && (
          <div className="flex flex-col gap-1 rounded-lg bg-muted px-4 py-3 text-sm">
            <p className="font-medium text-foreground">NSS no encontrado</p>
            <p className="leading-relaxed text-muted-foreground">{state.message}</p>
          </div>
        )}

        {state.kind === 'error' && (
          <p role="alert" className="rounded-lg bg-destructive/5 px-4 py-3 text-sm leading-relaxed text-destructive">
            {state.message}
          </p>
        )}
      </div>
    </div>
  )
}
