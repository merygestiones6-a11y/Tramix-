'use client'

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { AlertTriangle, CheckCircle2, Download, ExternalLink, Loader2, RefreshCw, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { isValidEmail } from '@/lib/imss'
import { readAndroidDocument, TRAMIX_APK_URL } from '@/lib/imss-android'
import { downloadPdf } from '@/lib/download'
import { accessFetch } from '@/lib/outlook/client'
import { CURP_PATTERN, DEFAULT_NSS_EMAIL, nssCancel, nssRefresh, nssShowPortal, nssSubmit, nssTakeEvents } from '@/lib/validar-nss'
import { CONSTANCIA_EMAIL_KEY, CONSTANCIA_TIMEOUT_MS, constanciaStart, constanciaSupport, isValidPdf } from '@/lib/constancia'

type Phase = 'loading' | 'captcha' | 'widget' | 'submitting' | 'step' | 'blocked'
type Status = 'PROCESANDO' | 'COMPLETADO' | 'ERROR'

interface Request {
  key: string
  curp: string
  status: Status
  note: string
  submittedAt: number
  waitingUser: boolean
  bytes?: Uint8Array
}

const noop = () => () => {}
const useSupport = () => useSyncExternalStore(noop, constanciaSupport, () => 'none' as const)

const fieldClass =
  'h-12 w-full rounded-xl border border-input bg-card px-4 text-base text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30 disabled:opacity-60'

function savedEmail() {
  try {
    return window.localStorage.getItem(CONSTANCIA_EMAIL_KEY) || DEFAULT_NSS_EMAIL
  } catch {
    return DEFAULT_NSS_EMAIL
  }
}

const redact = (text: string) => text.replace(/[^\s@<>()"']+@[^\s@<>()"']+\.[a-z]{2,}/gi, 'el correo configurado')

export function ConstanciaImss() {
  const support = useSupport()
  const [curp, setCurp] = useState('')
  const [captcha, setCaptcha] = useState('')
  const [image, setImage] = useState<string | null>(null)
  const [phase, setPhase] = useState<Phase>('loading')
  const [requests, setRequests] = useState<Request[]>([])
  const [alert, setAlert] = useState<{ tone: 'error' | 'success'; text: string } | null>(null)
  const activeRef = useRef<string | null>(null)
  const jobRef = useRef<string | null>(null)
  const emailRef = useRef(DEFAULT_NSS_EMAIL)

  useEffect(() => {
    emailRef.current = savedEmail()
  }, [])

  const update = useCallback((key: string, patch: Partial<Request>) => {
    setRequests((list) => list.map((r) => (r.key === key ? { ...r, ...patch } : r)))
  }, [])

  const openPortal = useCallback(() => {
    jobRef.current = null
    setImage(null)
    setCaptcha('')
    setPhase('loading')
    if (!constanciaStart(emailRef.current.trim() || DEFAULT_NSS_EMAIL)) setPhase('blocked')
  }, [])

  const fail = useCallback(
    (raw: string) => {
      const reason = redact(raw)
      const key = activeRef.current
      setAlert({ tone: 'error', text: reason })
      if (!key) return
      activeRef.current = null
      update(key, { status: 'ERROR', note: reason, waitingUser: false })
      nssShowPortal(false)
      openPortal()
    },
    [update, openPortal],
  )

  const fileName = (c: string) => `${c}.pdf`

  const complete = useCallback(
    (documentId: string, createdAt: number) => {
      const key = activeRef.current
      if (!key) return
      const req = requestsRef.current.find((r) => r.key === key)
      if (!req) return
      // A document saved before this request's CONTINUAR is never this request's result.
      if (createdAt && createdAt < req.submittedAt - 1000) return
      const bytes = readAndroidDocument(documentId)
      if (!bytes || !isValidPdf(bytes)) return fail(`El archivo recibido para ${req.curp} no es un PDF válido.`)
      activeRef.current = null
      update(key, { status: 'COMPLETADO', note: fileName(req.curp), bytes, waitingUser: false })
      setAlert({ tone: 'success', text: `Constancia de ${req.curp} descargada como ${fileName(req.curp)}.` })
      nssShowPortal(false)
      accessFetch('/api/validar-nss/document', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/pdf',
          'x-curp': encodeURIComponent(req.curp),
          'x-email': encodeURIComponent(emailRef.current),
          'x-file-name': encodeURIComponent(fileName(req.curp)),
        },
        body: bytes,
      }).catch(() => {})
      openPortal()
    },
    [fail, update, openPortal],
  )

  const requestsRef = useRef(requests)
  requestsRef.current = requests
  const lastStageRef = useRef('')

  useEffect(() => {
    if (support !== 'ready') return
    openPortal()
    return () => nssCancel()
  }, [support, openPortal])

  useEffect(() => {
    if (support !== 'ready') return
    const id = window.setInterval(() => {
      for (const event of nssTakeEvents()) {
        if (!jobRef.current) jobRef.current = event.jobId
        if (event.jobId !== jobRef.current) continue
        const active = activeRef.current
        switch (event.status) {
          case 'loading':
            if (!active) setPhase('loading')
            break
          case 'captcha':
            if (event.detail.image) setImage(event.detail.image)
            setCaptcha('')
            setPhase('captcha')
            if (active && event.detail.retry) {
              // Only reported when the portal itself showed a CAPTCHA error after CONTINUAR.
              const text = `El IMSS rechazó el CAPTCHA: ${redact(event.detail.message || 'código incorrecto')}. Escribe el nuevo código para continuar esta solicitud.`
              update(active, { status: 'PROCESANDO', note: text, waitingUser: true })
              setAlert({ tone: 'error', text })
            } else if (active && event.detail.resubmit) {
              update(active, {
                status: 'PROCESANDO',
                note: 'El portal mostró un nuevo CAPTCHA sin confirmar el envío. Escribe el nuevo código para continuar esta solicitud.',
                waitingUser: true,
              })
            }
            break
          case 'captcha_widget':
            setPhase('widget')
            break
          case 'submitting':
            setPhase('submitting')
            if (active) update(active, { note: 'Enviando la solicitud al portal del IMSS…', waitingUser: false })
            break
          case 'step':
            setPhase('step')
            if (active) {
              const missing: string[] = Array.isArray(event.detail.missing) ? event.detail.missing.filter(Boolean) : []
              const note = event.detail.message
                ? redact(event.detail.message)
                : missing.length
                  ? `El portal no aceptó estos campos: ${missing.join(', ')}. Complétalos en la vista del portal.`
                  : 'El portal pide un paso adicional. Complétalo en la vista del portal.'
              update(active, { note, waitingUser: true })
              setAlert({ tone: 'error', text: note })
            }
            break
          case 'pdf_available':
            if (active) update(active, { note: 'El portal generó la constancia. Descargando PDF…', waitingUser: false })
            break
          case 'result': {
            const d = event.detail
            if (!active) break
            if (d.kind === 'error' || d.kind === 'not_found') fail(d.message || 'El IMSS no generó la constancia.')
            else if (d.kind === 'link_sent')
              update(active, {
                note: 'El IMSS envió una liga de confirmación al correo configurado. La constancia se descargará al abrirla.',
                waitingUser: true,
              })
            else if (d.hasPdf) update(active, { note: 'El portal generó la constancia. Descargando PDF…', waitingUser: false })
            else fail('El portal terminó la solicitud sin generar la constancia en PDF.')
            break
          }
          case 'fields_not_found':
          case 'load_error': {
            const reason =
              event.status === 'fields_not_found'
                ? 'El portal del IMSS no mostró el formulario a tiempo. Pulsa recargar para intentarlo de nuevo.'
                : redact(event.detail.reason || event.detail.message || 'El portal del IMSS no respondió.')
            if (active) fail(reason)
            else {
              setPhase('blocked')
              setAlert({ tone: 'error', text: reason })
            }
            break
          }
          case 'download_failed':
            if (active) fail(`Descarga fallida: ${event.detail.reason || 'no se pudo descargar el PDF'}.`)
            break
          case 'document':
            complete(event.detail.id, event.detail.createdAt)
            break
          case 'diag': {
            // Stage, HTTP status, content type, sizes and timings only — no CURP or correo.
            const { stage, ...info } = event.detail
            lastStageRef.current = String(stage || '')
            console.info('[constancia]', stage, info)
            if (active && stage === 'submit_request') update(active, { note: 'Solicitud enviada; esperando la respuesta del IMSS…' })
            break
          }
        }
      }

      const active = activeRef.current
      const req = active ? requestsRef.current.find((r) => r.key === active) : null
      if (req && !req.waitingUser && Date.now() - req.submittedAt > CONSTANCIA_TIMEOUT_MS) {
        fail(`Tiempo de espera agotado: el portal no entregó el PDF de ${req.curp} (última etapa: ${lastStageRef.current || 'sin respuesta'}).`)
      }
    }, 600)
    return () => window.clearInterval(id)
  }, [support, update, fail, complete])

  const curpOk = CURP_PATTERN.test(curp)
  const busy = activeRef.current !== null
  const canSubmit = support === 'ready' && phase === 'captcha' && curpOk && captcha.trim().length >= 3

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    const trimmed = emailRef.current.trim().toLowerCase()
    if (!isValidEmail(trimmed)) {
      setAlert({ tone: 'error', text: 'El correo configurado internamente no es válido. Revisa la configuración del módulo.' })
      return
    }
    const retrying = activeRef.current
    const key = retrying ?? `${curp}-${Date.now()}`
    if (!nssSubmit(curp, trimmed, captcha.trim())) {
      setAlert({ tone: 'error', text: 'La app no pudo llenar el formulario del IMSS. Pide otro código.' })
      return
    }
    setAlert(null)
    setPhase('submitting')
    if (retrying) update(key, { submittedAt: Date.now(), waitingUser: false, note: 'Enviando la solicitud al portal del IMSS…' })
    else {
      activeRef.current = key
      setRequests((list) => [
        { key, curp, status: 'PROCESANDO', note: 'Enviando la solicitud al portal del IMSS…', submittedAt: Date.now(), waitingUser: false },
        ...list,
      ])
    }
  }

  if (support !== 'ready') {
    return (
      <section className="glass flex flex-col gap-4 rounded-3xl p-5">
        <div className="flex items-start gap-3">
          <Smartphone className="mt-0.5 size-5 shrink-0 text-imss" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            El llenado automático y la descarga del PDF se ejecutan dentro de la app IMSS DIRECT para Android, que abre el portal oficial
            del IMSS. Abre este módulo desde la app.
          </p>
        </div>
        <a
          href={TRAMIX_APK_URL}
          className="inline-flex h-11 items-center justify-center rounded-xl bg-imss text-sm font-medium text-imss-foreground transition-colors hover:bg-imss/90"
        >
          Descargar app Android
        </a>
      </section>
    )
  }

  return (
    <div className="flex flex-col gap-5">
      {alert && (
        <div
          role="alert"
          className={cn(
            'flex items-start gap-3 rounded-2xl border p-4 text-sm leading-relaxed',
            alert.tone === 'error' ? 'border-destructive/30 bg-destructive/10 text-destructive' : 'border-success/30 bg-success/10 text-success',
          )}
        >
          {alert.tone === 'error' ? (
            <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          )}
          <p className="flex-1 font-medium text-pretty">{alert.text}</p>
          <button type="button" onClick={() => setAlert(null)} className="text-xs font-semibold underline-offset-2 hover:underline">
            Cerrar
          </button>
        </div>
      )}

      <form onSubmit={submit} className="glass flex flex-col gap-4 rounded-3xl p-5">
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold tracking-wide text-muted-foreground">CURP</span>
          <input
            value={curp}
            onChange={(e) => setCurp(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 18))}
            placeholder="18 caracteres"
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            disabled={busy}
            className={cn(fieldClass, 'font-mono tracking-wider uppercase')}
            aria-invalid={curp.length === 18 && !curpOk}
          />
        </label>

        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold tracking-wide text-muted-foreground">CAPTCHA</span>
          <div className="flex items-center gap-3">
            <div className="flex h-16 flex-1 items-center justify-center overflow-hidden rounded-xl border border-input bg-card">
              {phase === 'captcha' && image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={image} alt="CAPTCHA del portal del IMSS" className="h-full w-auto object-contain" />
              ) : phase === 'blocked' ? (
                <span className="px-3 text-center text-xs text-destructive">No se pudo abrir el portal</span>
              ) : phase === 'widget' || phase === 'step' ? (
                <span className="px-3 text-center text-xs text-muted-foreground">Continúa en la vista del portal</span>
              ) : (
                <Loader2 className="size-5 animate-spin text-muted-foreground" aria-label="Cargando portal del IMSS" />
              )}
            </div>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="size-12 shrink-0 rounded-xl"
              onClick={() => (phase === 'blocked' ? openPortal() : nssRefresh())}
              aria-label="Pedir otro CAPTCHA"
            >
              <RefreshCw className="size-4" aria-hidden="true" />
            </Button>
          </div>
          <input
            value={captcha}
            onChange={(e) => setCaptcha(e.target.value.slice(0, 32))}
            placeholder="Escribe el código de la imagen"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            disabled={phase !== 'captcha'}
            className={fieldClass}
          />
        </div>

        {(phase === 'widget' || phase === 'step') && (
          <Button type="button" variant="outline" className="h-11 rounded-xl" onClick={() => nssShowPortal(true)}>
            <ExternalLink className="size-4" aria-hidden="true" />
            Ver portal del IMSS
          </Button>
        )}

        <Button type="submit" disabled={!canSubmit} className="h-12 rounded-xl bg-imss text-base font-semibold text-imss-foreground hover:bg-imss/90">
          {phase === 'submitting' ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
          CONTINUAR
        </Button>
      </form>

      {requests.length > 0 && (
        <section aria-label="Solicitudes" className="flex flex-col gap-2">
          <h2 className="text-xs font-semibold tracking-wide text-muted-foreground">SOLICITUDES</h2>
          <ul className="flex flex-col gap-2">
            {requests.map((r) => (
              <li key={r.key} className="glass flex items-center gap-3 rounded-2xl p-4">
                <div className="flex min-w-0 flex-1 flex-col gap-1">
                  <span className="truncate font-mono text-sm font-semibold tracking-wider">{r.curp}</span>
                  <span className="text-xs leading-relaxed text-pretty text-muted-foreground">{r.note}</span>
                </div>
                {r.status === 'COMPLETADO' && r.bytes ? (
                  <Button
                    type="button"
                    size="sm"
                    className="h-9 rounded-lg bg-imss text-imss-foreground hover:bg-imss/90"
                    onClick={() => downloadPdf(r.bytes!, fileName(r.curp))}
                  >
                    <Download className="size-4" aria-hidden="true" />
                    DESCARGAR
                  </Button>
                ) : null}
                <span
                  className={cn(
                    'inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide',
                    r.status === 'PROCESANDO' && 'bg-imss-soft text-imss-soft-foreground',
                    r.status === 'COMPLETADO' && 'bg-success/15 text-success',
                    r.status === 'ERROR' && 'bg-destructive/10 text-destructive',
                  )}
                >
                  {r.status === 'PROCESANDO' && <Loader2 className="size-3 animate-spin" aria-hidden="true" />}
                  {r.status}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
