'use client'

import { useState } from 'react'
import { ChevronDown, Plus, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { orderedAccounts } from '@/lib/cfe/assign'
import { cfeCall, errorMessage } from '@/lib/cfe/client'
import { SERVICES_PER_ACCOUNT, type CfeAccount } from '@/lib/cfe/types'
import { cn } from '@/lib/utils'
import { ErrorText, ICON_BUTTON, INPUT, Section } from './section'

export function CfeAccounts({ accounts, activeId, onChange }: { accounts: CfeAccount[]; activeId: string | null; onChange: () => void }) {
  const [adding, setAdding] = useState(accounts.length === 0)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function add(event: React.FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setError(null)
    try {
      await cfeCall('/api/cfe/accounts', { method: 'POST', body: JSON.stringify({ email, password }) })
      setEmail('')
      setPassword('')
      setAdding(false)
      onChange()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const total = accounts.reduce((sum, a) => sum + a.services.length, 0)

  return (
    <Section
      id="cfe-accounts"
      title="Cuentas CFE"
      aside={
        <span className="text-xs text-muted-foreground">
          {total}/{accounts.length * SERVICES_PER_ACCOUNT} servicios
        </span>
      }
    >
      {accounts.length > 0 ? (
        <ul className="flex flex-col gap-2">
          {orderedAccounts(accounts).map((account) => (
            <AccountRow key={account.id} account={account} active={account.id === activeId} onChange={onChange} />
          ))}
        </ul>
      ) : null}

      {adding ? (
        <form onSubmit={add} className="flex flex-col gap-3 rounded-xl border border-border bg-card p-3">
          <label className="flex flex-col gap-1.5 text-sm font-medium">
            Correo
            <input type="email" autoComplete="off" required value={email} onChange={(e) => setEmail(e.target.value)} className={INPUT} />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium">
            Contraseña
            <input
              type="password"
              autoComplete="new-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={INPUT}
            />
          </label>
          <p className="text-xs leading-relaxed text-muted-foreground">La contraseña se guarda cifrada y nunca se muestra.</p>
          <ErrorText message={error} />
          <div className="flex gap-2">
            <Button type="submit" className="h-10 flex-1 rounded-xl" disabled={busy}>
              {busy ? 'Guardando…' : 'Guardar cuenta'}
            </Button>
            {accounts.length > 0 ? (
              <Button type="button" variant="outline" className="h-10 rounded-xl" onClick={() => setAdding(false)}>
                Cancelar
              </Button>
            ) : null}
          </div>
        </form>
      ) : (
        <Button type="button" variant="outline" className="h-10 rounded-xl" onClick={() => setAdding(true)}>
          <Plus className="size-4" aria-hidden="true" />
          Agregar cuenta
        </Button>
      )}
    </Section>
  )
}

function AccountRow({ account, active, onChange }: { account: CfeAccount; active: boolean; onChange: () => void }) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const count = account.services.length
  const full = count >= SERVICES_PER_ACCOUNT

  async function run(init: RequestInit, confirmText?: string) {
    if (confirmText && !window.confirm(confirmText)) return
    setBusy(true)
    setError(null)
    try {
      await cfeCall(`/api/cfe/accounts/${account.id}`, init)
      onChange()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <li className={cn('flex flex-col gap-2 rounded-xl border bg-card p-3', active ? 'border-primary/50' : 'border-border')}>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className="flex min-w-0 flex-1 items-center gap-2 text-left"
        >
          <ChevronDown className={cn('size-4 shrink-0 text-muted-foreground transition-transform', open && 'rotate-180')} aria-hidden="true" />
          <span className="flex min-w-0 flex-col">
            <span className="truncate text-sm font-medium">{account.email}</span>
            <span className="text-xs text-muted-foreground">{active ? 'Activa' : full ? 'Completa' : 'Disponible'}</span>
          </span>
        </button>
        <span
          className={cn(
            'rounded-full px-2.5 py-1 font-mono text-xs font-semibold tabular-nums',
            full ? 'bg-muted text-muted-foreground' : 'bg-accent text-accent-foreground',
          )}
          aria-label={`${count} de ${SERVICES_PER_ACCOUNT} servicios`}
        >
          {count}/{SERVICES_PER_ACCOUNT}
        </span>
        <button
          type="button"
          className={ICON_BUTTON}
          disabled={busy}
          aria-label={`Eliminar ${account.email}`}
          onClick={() => run({ method: 'DELETE' }, `¿Eliminar la cuenta ${account.email}?`)}
        >
          <Trash2 className="size-4" aria-hidden="true" />
        </button>
      </div>

      <div className="h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden="true">
        <div className="h-full rounded-full bg-primary transition-[width]" style={{ width: `${(count / SERVICES_PER_ACCOUNT) * 100}%` }} />
      </div>

      {open ? (
        <div className="flex flex-col gap-2 pt-1">
          {count === 0 ? (
            <p className="text-xs text-muted-foreground">Sin números de servicio.</p>
          ) : (
            <ul className="flex flex-wrap gap-1.5">
              {account.services.map((service) => (
                <li key={service} className="inline-flex items-center gap-1 rounded-lg bg-muted py-1 pr-1 pl-2 font-mono text-xs">
                  {service}
                  <button
                    type="button"
                    disabled={busy}
                    aria-label={`Quitar ${service}`}
                    className="rounded p-0.5 text-muted-foreground hover:text-foreground"
                    onClick={() =>
                      run({ method: 'PATCH', body: JSON.stringify({ action: 'remove-service', serviceNumber: service }) }, `¿Quitar ${service}?`)
                    }
                  >
                    <X className="size-3.5" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          )}
          {!active && !full ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="w-fit rounded-lg"
              disabled={busy}
              onClick={() => run({ method: 'PATCH', body: JSON.stringify({ action: 'activate' }) })}
            >
              Usar esta cuenta
            </Button>
          ) : null}
        </div>
      ) : null}
      <ErrorText message={error} />
    </li>
  )
}
