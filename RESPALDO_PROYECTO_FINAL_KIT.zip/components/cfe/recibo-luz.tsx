'use client'

import useSWR from 'swr'
import { accessJson } from '@/lib/outlook/client'
import { errorMessage, STATE_KEY } from '@/lib/cfe/client'
import type { CfeState } from '@/lib/cfe/types'
import { CfeAccounts } from './cfe-accounts'
import { ServiceRequestForm } from './service-request-form'
import { RequestHistory } from './request-history'
import { ReceiptImport } from './receipt-import'
import { ReceiptList } from './receipt-list'

export function ReciboLuz() {
  const { data, error, isLoading, mutate } = useSWR<CfeState>(STATE_KEY, accessJson, { revalidateOnFocus: true })
  const refresh = () => mutate()

  if (isLoading && !data) {
    return <p className="glass rounded-2xl p-5 text-sm text-muted-foreground">Cargando…</p>
  }
  if (error && !data) {
    return (
      <p role="alert" className="rounded-2xl border border-destructive/30 bg-destructive/10 p-5 text-sm text-destructive">
        {errorMessage(error)}
      </p>
    )
  }

  const state = data ?? { accounts: [], requests: [], receipts: [], activeAccountId: null }
  const active = state.accounts.find((a) => a.id === state.activeAccountId) ?? null

  return (
    <div className="flex flex-col gap-5">
      <ServiceRequestForm active={active} hasAccounts={state.accounts.length > 0} onDone={refresh} />
      <CfeAccounts accounts={state.accounts} activeId={state.activeAccountId} onChange={refresh} />
      <ReceiptImport requests={state.requests} onSaved={refresh} />
      <ReceiptList receipts={state.receipts} onChange={refresh} />
      <RequestHistory requests={state.requests} receipts={state.receipts} onChange={refresh} />
    </div>
  )
}
