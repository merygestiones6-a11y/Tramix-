'use client'

import { useState } from 'react'
import { Download, FileText, Trash2 } from 'lucide-react'
import { downloadPdf } from '@/lib/download'
import { accessFetch } from '@/lib/outlook/client'
import { cfeCall, errorMessage, formatDate } from '@/lib/cfe/client'
import type { CfeReceipt } from '@/lib/cfe/types'
import { ErrorText, ICON_BUTTON, Section } from './section'

export function ReceiptList({ receipts, onChange }: { receipts: CfeReceipt[]; onChange: () => void }) {
  const [busyId, setBusyId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function download(receipt: CfeReceipt) {
    setBusyId(receipt.id)
    setError(null)
    try {
      const res = await accessFetch(`/api/cfe/receipts/${receipt.id}`)
      if (!res.ok) throw new Error('not-found')
      downloadPdf(await res.blob(), receipt.fileName)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  async function remove(receipt: CfeReceipt) {
    if (!window.confirm(`¿Eliminar ${receipt.fileName}?`)) return
    setBusyId(receipt.id)
    setError(null)
    try {
      await cfeCall(`/api/cfe/receipts/${receipt.id}`, { method: 'DELETE' })
      onChange()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  return (
    <Section id="cfe-receipts" title="Recibos descargados" aside={<span className="text-xs text-muted-foreground">{receipts.length}</span>}>
      {receipts.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aún no hay recibos guardados.</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {receipts.map((receipt) => (
            <li key={receipt.id} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3">
              <FileText className="size-5 shrink-0 text-primary" aria-hidden="true" />
              <div className="flex min-w-0 flex-1 flex-col">
                <span className="truncate text-sm font-medium">{receipt.holder ?? 'SIN TITULAR'}</span>
                <span className="truncate font-mono text-xs text-muted-foreground">
                  {receipt.serviceNumber ?? 'sin servicio'} · {formatDate(receipt.createdAt)}
                </span>
              </div>
              <button
                type="button"
                className={ICON_BUTTON}
                disabled={busyId === receipt.id}
                aria-label={`Descargar ${receipt.fileName}`}
                onClick={() => download(receipt)}
              >
                <Download className="size-4" aria-hidden="true" />
              </button>
              <button
                type="button"
                className={ICON_BUTTON}
                disabled={busyId === receipt.id}
                aria-label={`Eliminar ${receipt.fileName}`}
                onClick={() => remove(receipt)}
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <ErrorText message={error} />
    </Section>
  )
}
