'use client'

import { useState } from 'react'
import { X } from 'lucide-react'
import { cfeCall, errorMessage, formatDate } from '@/lib/cfe/client'
import type { CfeReceipt, CfeRequest } from '@/lib/cfe/types'
import { cn } from '@/lib/utils'
import { ErrorText, ICON_BUTTON, Section } from './section'

export function RequestHistory({
  requests,
  receipts,
  onChange,
}: {
  requests: CfeRequest[]
  receipts: CfeReceipt[]
  onChange: () => void
}) {
  const [error, setError] = useState<string | null>(null)
  const holderOf = (id: string | null) => receipts.find((r) => r.id === id)?.holder

  async function remove(request: CfeRequest) {
    if (!window.confirm(`¿Quitar la solicitud ${request.serviceNumber} del historial?`)) return
    setError(null)
    try {
      await cfeCall(`/api/cfe/requests/${request.id}`, { method: 'DELETE' })
      onChange()
    } catch (err) {
      setError(errorMessage(err))
    }
  }

  return (
    <Section id="cfe-history" title="Historial de solicitudes" aside={<span className="text-xs text-muted-foreground">{requests.length}</span>}>
      {requests.length === 0 ? (
        <p className="text-sm text-muted-foreground">Sin solicitudes.</p>
      ) : (
        <ul className="flex flex-col divide-y divide-border">
          {requests.map((request) => (
            <li key={request.id} className="flex items-center gap-3 py-2.5">
              <div className="flex min-w-0 flex-1 flex-col">
                <span className="font-mono text-sm tracking-wide">{request.serviceNumber}</span>
                <span className="truncate text-xs text-muted-foreground">
                  {holderOf(request.receiptId) ?? request.accountEmail} · {formatDate(request.createdAt)}
                </span>
              </div>
              <span
                className={cn(
                  'rounded-full px-2.5 py-1 text-xs font-medium',
                  request.status === 'descargado' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground',
                )}
              >
                {request.status === 'descargado' ? 'Descargado' : 'Pendiente'}
              </span>
              <button type="button" className={ICON_BUTTON} aria-label={`Quitar ${request.serviceNumber}`} onClick={() => remove(request)}>
                <X className="size-4" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <ErrorText message={error} />
    </Section>
  )
}
