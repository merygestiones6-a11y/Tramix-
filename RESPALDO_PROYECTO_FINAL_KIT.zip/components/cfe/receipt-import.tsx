'use client'

import { useRef, useState } from 'react'
import { FileUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cfeCall, errorMessage } from '@/lib/cfe/client'
import { detectCfeHolder, detectServiceNumber, receiptFileName } from '@/lib/cfe/holder'
import { CFE_ERRORS, MAX_RECEIPT_BYTES, type CfeRequest } from '@/lib/cfe/types'
import { ErrorText, INPUT, Section } from './section'

interface Draft {
  file: File
  holder: string
  serviceNumber: string
}

export function ReceiptImport({ requests, onSaved }: { requests: CfeRequest[]; onSaved: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [draft, setDraft] = useState<Draft | null>(null)
  const [reading, setReading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const pending = requests.filter((r) => r.status === 'pendiente')

  async function pick(file: File | undefined) {
    if (!file) return
    setError(null)
    setDraft(null)
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) return setError(CFE_ERRORS['invalid-pdf'])
    if (file.size > MAX_RECEIPT_BYTES) return setError(CFE_ERRORS['too-large'])
    setReading(true)
    try {
      const { extractPdfText } = await import('@/lib/pdf/extract-text')
      const { pages } = await extractPdfText(new Uint8Array(await file.arrayBuffer()))
      const detected = detectServiceNumber(pages)
      const service = detected ?? (pending.length === 1 ? pending[0].serviceNumber : '')
      setDraft({ file, holder: detectCfeHolder(pages) ?? '', serviceNumber: service })
    } catch {
      setError(CFE_ERRORS['invalid-pdf'])
    } finally {
      setReading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  async function save() {
    if (!draft || saving) return
    setSaving(true)
    setError(null)
    try {
      const form = new FormData()
      form.set('file', draft.file)
      form.set('holder', draft.holder)
      form.set('serviceNumber', draft.serviceNumber)
      await cfeCall('/api/cfe/receipts', { method: 'POST', body: form })
      setDraft(null)
      onSaved()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  const serviceValid = draft ? draft.serviceNumber === '' || draft.serviceNumber.length === 11 : true

  return (
    <Section id="cfe-import" title="Importar recibo PDF">
      <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} tabIndex={-1} />
      {!draft ? (
        <Button type="button" variant="outline" className="h-11 rounded-xl" disabled={reading} onClick={() => inputRef.current?.click()}>
          <FileUp className="size-4" aria-hidden="true" />
          {reading ? 'Leyendo PDF…' : 'Seleccionar PDF'}
        </Button>
      ) : (
        <div className="flex flex-col gap-3">
          <p className="truncate text-xs text-muted-foreground">{draft.file.name}</p>
          <label className="flex flex-col gap-1.5 text-sm font-medium">
            Titular
            <input
              value={draft.holder}
              placeholder="No detectado — escríbelo"
              onChange={(e) => setDraft({ ...draft, holder: e.target.value.toUpperCase() })}
              className={INPUT}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium">
            Número de servicio
            <input
              inputMode="numeric"
              list="cfe-pending-services"
              value={draft.serviceNumber}
              placeholder="Opcional · 11 dígitos"
              onChange={(e) => setDraft({ ...draft, serviceNumber: e.target.value.replace(/\D/g, '').slice(0, 11) })}
              className={`${INPUT} font-mono tracking-wider`}
            />
            <datalist id="cfe-pending-services">
              {pending.map((r) => (
                <option key={r.id} value={r.serviceNumber} />
              ))}
            </datalist>
          </label>
          <p className="rounded-lg bg-muted px-3 py-2 font-mono text-xs break-all">
            {receiptFileName(draft.holder || null, draft.serviceNumber.length === 11 ? draft.serviceNumber : null)}
          </p>
          <div className="flex gap-2">
            <Button type="button" className="h-10 flex-1 rounded-xl" disabled={saving || !serviceValid} onClick={save}>
              {saving ? 'Guardando…' : 'Guardar recibo'}
            </Button>
            <Button type="button" variant="outline" className="h-10 rounded-xl" onClick={() => setDraft(null)}>
              Cancelar
            </Button>
          </div>
        </div>
      )}
      <ErrorText message={error ?? (serviceValid ? null : CFE_ERRORS['invalid-service'])} />
    </Section>
  )
}
