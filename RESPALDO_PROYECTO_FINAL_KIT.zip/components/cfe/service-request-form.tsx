'use client'

import { useState } from 'react'
import { Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cfeCall, errorMessage } from '@/lib/cfe/client'
import { SERVICES_PER_ACCOUNT, type CfeAccount, type CfeRequest } from '@/lib/cfe/types'
import { ErrorText, INPUT, Section } from './section'

export function ServiceRequestForm({
  active,
  hasAccounts,
  onDone,
}: {
  active: CfeAccount | null
  hasAccounts: boolean
  onDone: () => void
}) {
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const valid = value.length === 11

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (!valid || busy) return
    setBusy(true)
    setError(null)
    setNotice(null)
    try {
      const { request } = await cfeCall<{ request: CfeRequest }>('/api/cfe/requests', {
        method: 'POST',
        body: JSON.stringify({ serviceNumber: value }),
      })
      setNotice(`Solicitud registrada en ${request.accountEmail}.`)
      setValue('')
      onDone()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Section
      id="cfe-request"
      title="Nueva solicitud"
      aside={
        active ? (
          <span className="truncate rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
            {active.email} · {active.services.length}/{SERVICES_PER_ACCOUNT}
          </span>
        ) : null
      }
    >
      <form onSubmit={submit} className="flex flex-col gap-3">
        <label htmlFor="cfe-service" className="text-sm font-medium">
          Número de servicio
        </label>
        <div className="flex gap-2">
          <input
            id="cfe-service"
            inputMode="numeric"
            autoComplete="off"
            maxLength={11}
            placeholder="11 dígitos"
            value={value}
            onChange={(e) => setValue(e.target.value.replace(/\D/g, '').slice(0, 11))}
            className={`${INPUT} font-mono tracking-wider`}
            aria-describedby="cfe-service-hint"
            disabled={!hasAccounts}
          />
          <Button type="submit" className="h-11 rounded-xl px-4" disabled={!valid || busy || !hasAccounts}>
            <Zap className="size-4" aria-hidden="true" />
            {busy ? 'Guardando…' : 'Registrar'}
          </Button>
        </div>
        <p id="cfe-service-hint" className="text-xs leading-relaxed text-muted-foreground">
          {hasAccounts
            ? `${value.length}/11 · Se asigna a la cuenta activa; al llegar a ${SERVICES_PER_ACCOUNT} pasa a la siguiente.`
            : 'Agrega primero una cuenta CFE.'}
        </p>
        <ErrorText message={error} />
        {notice ? (
          <p role="status" className="text-sm text-primary">
            {notice}
          </p>
        ) : null}
      </form>
    </Section>
  )
}
