'use client'

import { Check, CircleCheck, CircleX, ClipboardCopy, Eraser } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { copyText } from '@/lib/clipboard'
import { cleanCurpInput, formatCurpDetails, validateCurp } from '@/lib/curp-validator'
import { cn } from '@/lib/utils'

export function CurpValidator() {
  const [value, setValue] = useState('')
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'failed'>('idle')
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current)
    },
    [],
  )

  const result = useMemo(() => (value.length > 0 ? validateCurp(value) : null), [value])

  const handleChange = (next: string) => {
    setValue(cleanCurpInput(next))
    setCopyState('idle')
  }

  const handleCopy = async () => {
    if (!result?.valid) return
    const ok = await copyText(formatCurpDetails(result.details))
    setCopyState(ok ? 'copied' : 'failed')
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setCopyState('idle'), 2500)
  }

  return (
    <div className="flex flex-col gap-4">
      <section className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
        <label htmlFor="curp-input" className="text-sm font-semibold">
          CURP
        </label>
        <div className="relative">
          <input
            id="curp-input"
            value={value}
            onChange={(e) => handleChange(e.target.value)}
            placeholder="Pega aquí la CURP"
            autoComplete="off"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            inputMode="text"
            maxLength={40}
            aria-describedby="curp-counter"
            className="field-input pr-12 font-mono tracking-wider uppercase"
          />
          {value ? (
            <button
              type="button"
              onClick={() => handleChange('')}
              className="absolute top-1/2 right-2 inline-flex size-9 -translate-y-1/2 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              aria-label="Borrar CURP"
            >
              <Eraser className="size-4" aria-hidden="true" />
            </button>
          ) : null}
        </div>
        <p id="curp-counter" className="text-xs text-muted-foreground">
          {value.length}/18 caracteres · Se valida en tu dispositivo, sin consultas externas.
        </p>
      </section>

      <div aria-live="polite">
        {result?.valid ? (
          <section
            aria-labelledby="curp-result-heading"
            className="glass flex flex-col gap-4 rounded-3xl border-success/30 p-4 sm:p-5"
          >
            <h2 id="curp-result-heading" className="flex items-center gap-2 text-base font-semibold text-success">
              <CircleCheck className="size-5" aria-hidden="true" />
              CURP VÁLIDA
            </h2>
            <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Detail label="CURP" value={result.details.curp} mono />
              <Detail label="Fecha de nacimiento" value={result.details.birthDate} />
              <Detail label="Sexo" value={result.details.sex} />
              <Detail label="Entidad federativa" value={result.details.state} />
            </dl>
            <button
              type="button"
              onClick={handleCopy}
              className={cn(
                'inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-semibold tracking-wide transition-all active:scale-[0.98]',
                copyState === 'copied'
                  ? 'bg-success text-success-foreground'
                  : 'bg-primary text-primary-foreground hover:bg-primary/90',
              )}
            >
              {copyState === 'copied' ? (
                <>
                  <Check className="size-4 animate-pop" aria-hidden="true" />
                  DATOS COPIADOS
                </>
              ) : (
                <>
                  <ClipboardCopy className="size-4" aria-hidden="true" />
                  COPIAR DATOS
                </>
              )}
            </button>
            {copyState === 'failed' ? (
              <p className="text-xs text-warning">No se pudo copiar automáticamente. Mantén presionado el texto para copiarlo.</p>
            ) : null}
          </section>
        ) : result ? (
          <section
            aria-labelledby="curp-result-heading"
            className="glass flex flex-col gap-3 rounded-3xl border-destructive/30 p-4 sm:p-5"
          >
            <h2 id="curp-result-heading" className="flex items-center gap-2 text-base font-semibold text-destructive">
              <CircleX className="size-5" aria-hidden="true" />
              CURP NO VÁLIDA
            </h2>
            <ul className="flex flex-col gap-1.5 text-sm leading-relaxed text-muted-foreground">
              {result.reasons.map((reason) => (
                <li key={reason} className="flex gap-2">
                  <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-destructive/70" />
                  {reason}
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </div>
    </div>
  )
}

function Detail({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex flex-col gap-1 rounded-2xl border border-border bg-muted p-3.5">
      <dt className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{label}</dt>
      <dd className={cn('text-base font-semibold break-all text-foreground', mono && 'font-mono tracking-wider')}>
        {value}
      </dd>
    </div>
  )
}
