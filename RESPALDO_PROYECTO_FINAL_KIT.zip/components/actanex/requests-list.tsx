'use client'

import { useState } from 'react'
import useSWR from 'swr'
import { Download, RefreshCw } from 'lucide-react'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { Solicitud } from '@/lib/actanex/goat'
import { downloadPdf } from '@/lib/download'

function tieneGuardadoNativo() {
  const bridge = (window as unknown as { TramixAndroid?: { saveDataUrl?: unknown } }).TramixAndroid
  return Boolean(bridge && typeof bridge.saveDataUrl === 'function')
}

const fetcher = async (url: string) => {
  const res = await fetch(url, { cache: 'no-store' })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error ?? 'Error al cargar')
  return data.registros as Solicitud[]
}

type Filtro = 'nuevas' | 'pendientes' | 'todas'

const esNueva = (r: Solicitud) => Boolean(r.RutaEncriptada) && r.Descargado !== 'Si'
const esPendiente = (r: Solicitud) => !r.RutaEncriptada && r.status === 'Pendiente'

function formatoFecha(r: Solicitud) {
  if (!r.fecha) return '—'
  const [y, m, d] = r.fecha.slice(0, 10).split('-')
  return `${d}/${m}/${y.slice(2)} ${r.hora?.slice(0, 5) ?? ''}`
}

// GOAT stores the request date and time in Mexico City time (UTC-6).
function horaSolicitud(r: Solicitud): number | null {
  if (!r.fecha || !r.hora) return null
  const t = Date.parse(`${r.fecha.slice(0, 10)}T${r.hora.slice(0, 8)}-06:00`)
  return Number.isNaN(t) ? null : t
}

function duracion(ms: number) {
  const s = Math.max(0, Math.round(ms / 1000))
  if (s < 60) return `${s} s`
  const min = Math.round(s / 60)
  if (min < 60) return `${min} min`
  const h = Math.floor(min / 60)
  if (h < 24) return min % 60 ? `${h} h ${min % 60} min` : `${h} h`
  return `${Math.floor(h / 24)} d ${h % 24} h`
}

function textoRecepcion(r: Solicitud): string | null {
  if (!r.RutaEncriptada || !r.recibido) return null
  const recibido = Date.parse(r.recibido)
  const solicitado = horaSolicitud(r)
  if (Number.isNaN(recibido) || solicitado === null) return null
  const hora = new Date(recibido).toLocaleTimeString('es-MX', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'America/Mexico_City',
  })
  return `Recibido en ${duracion(recibido - solicitado)} · ${hora}`
}

export function RequestsList() {
  const { data, error, isLoading, isValidating, mutate } = useSWR('/api/actanex/solicitudes', fetcher, {
    refreshInterval: 10000,
  })
  const [filtro, setFiltro] = useState<Filtro>('todas')

  const registros = [...(data ?? [])].sort((a, b) => {
    const fa = `${a.fecha?.slice(0, 10) ?? ''} ${a.hora ?? ''}`
    const fb = `${b.fecha?.slice(0, 10) ?? ''} ${b.hora ?? ''}`
    if (fa !== fb) return fb.localeCompare(fa)
    return Number(b.id) - Number(a.id)
  })
  const [retenidos, setRetenidos] = useState<Set<number>>(() => new Set())
  const nuevas = registros.filter((r) => esNueva(r) || (retenidos.has(r.id) && Boolean(r.RutaEncriptada)))
  const pendientes = registros.filter((r) => esPendiente(r) || (retenidos.has(r.id) && !r.RutaEncriptada))
  const visibles = filtro === 'nuevas' ? nuevas : filtro === 'pendientes' ? pendientes : registros

  const alDescargar = (id: number) => {
    setRetenidos((prev) => new Set(prev).add(id))
    setTimeout(() => mutate(), 2500)
  }

  const cambiarFiltro = (f: Filtro) => {
    setRetenidos(new Set())
    setFiltro(f)
  }

  const tabs: { id: Filtro; label: string; count: number }[] = [
    { id: 'todas', label: 'Todas', count: registros.length },
    { id: 'pendientes', label: 'En proceso', count: pendientes.length },
    { id: 'nuevas', label: 'Por descargar', count: nuevas.length },
  ]

  return (
    <section
      aria-labelledby="lista"
      className="flex min-w-0 flex-col gap-4 rounded-2xl border bg-card p-5 shadow-lg shadow-primary/5"
    >
      <div className="flex items-center justify-between gap-2">
        <h2 id="lista" className="flex items-center gap-2 text-base font-semibold text-primary">
          <span className="h-4 w-1 rounded-full bg-accent" aria-hidden="true" />
          Mis solicitudes
        </h2>
        <button
          type="button"
          onClick={() => mutate()}
          className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
          aria-label="Actualizar"
        >
          <RefreshCw className={cn('size-4', isValidating && 'animate-spin')} aria-hidden="true" />
        </button>
      </div>

      <div role="tablist" className="flex gap-1 rounded-xl bg-muted p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            type="button"
            aria-selected={filtro === t.id}
            onClick={() => cambiarFiltro(t.id)}
            className={cn(
              'flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg px-2 text-xs font-semibold transition-all',
              filtro === t.id
                ? 'bg-card text-primary shadow-sm'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {t.label}
            <span
              className={cn(
                'rounded-full px-1.5 py-0.5 text-[11px] tabular-nums',
                filtro === t.id ? 'bg-primary text-primary-foreground' : 'bg-card',
              )}
            >
              {t.count}
            </span>
          </button>
        ))}
      </div>

      {error && (
        <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error.message}
        </p>
      )}

      {isLoading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Cargando…</p>
      ) : visibles.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Sin registros</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {visibles.map((r) => (
            <li
              key={r.id}
              className="flex items-center justify-between gap-3 rounded-xl border bg-background px-3 py-3 transition-colors hover:border-primary/30"
            >
              <div className="flex min-w-0 flex-col gap-0.5">
                <span className="truncate text-sm font-medium tracking-wide">{r.curp ?? r.cadena ?? '—'}</span>
                {r.CurpOpcional && <span className="truncate text-xs tracking-wide text-muted-foreground">{r.CurpOpcional}</span>}
                <span className="flex flex-wrap items-center gap-x-2 text-xs text-muted-foreground">
                  <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[11px] font-semibold text-primary">{r.tipo}</span>
                  <span>{formatoFecha(r)}</span>
                  {Boolean(r.folio) && <span>Folio</span>}
                </span>
                {textoRecepcion(r) && (
                  <span className="text-[11px] text-muted-foreground">{textoRecepcion(r)}</span>
                )}
              </div>
              <Estado r={r} onDescarga={() => alDescargar(r.id)} />
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

const CURP_RE = /[A-Z]{4}\d{6}[HMX][A-Z]{5}[A-Z0-9]\d/

function curpDeSolicitud(r: Solicitud): string | null {
  for (const valor of [r.curp, r.cadena, r.CurpOpcional]) {
    const encontrada = String(valor ?? '').toUpperCase().match(CURP_RE)?.[0]
    if (encontrada) return encontrada
  }
  return null
}

// The TRAMIX Android app names blob: downloads after the URL's UUID, so there the PDF goes to its native saver.
function guardarEnDispositivo(blob: Blob, nombre: string) {
  if (tieneGuardadoNativo()) {
    downloadPdf(blob, nombre)
    return
  }
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = nombre
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 60000)
}

function BotonDescarga({ r, onDescarga }: { r: Solicitud; onDescarga: () => void }) {
  const [estado, setEstado] = useState<'idle' | 'cargando' | 'error'>('idle')
  const descargado = r.Descargado === 'Si'

  const descargar = async () => {
    setEstado('cargando')
    try {
      const res = await fetch(`/api/actanex/descargar/${r.RutaEncriptada}?id=${r.id}`, { cache: 'no-store' })
      if (!res.ok) throw new Error()
      const blob = await res.blob()
      if (blob.size === 0) throw new Error()
      const curp = curpDeSolicitud(r)
      const nombre = curp
        ? `${curp}.pdf`
        : r.cadena
          ? `${String(r.cadena).trim()}.pdf`
          : (res.headers.get('content-disposition')?.match(/filename="?([^";]+)"?/)?.[1] ?? `${r.id}.pdf`)
      guardarEnDispositivo(blob, nombre)
      setEstado('idle')
      onDescarga()
    } catch {
      setEstado('error')
    }
  }

  return (
    <button
      type="button"
      onClick={descargar}
      disabled={estado === 'cargando'}
      className={cn(
        buttonVariants({ variant: descargado || estado === 'error' ? 'outline' : 'default', size: 'sm' }),
        'h-9 shrink-0 gap-1.5 rounded-full px-4',
        estado === 'error' && 'border-destructive text-destructive',
      )}
    >
      <Download className="size-3.5" aria-hidden="true" />
      {estado === 'cargando' ? 'Descargando…' : estado === 'error' ? 'Reintentar' : descargado ? 'Otra vez' : 'PDF'}
    </button>
  )
}

function Estado({ r, onDescarga }: { r: Solicitud; onDescarga: () => void }) {
  if (r.RutaEncriptada) return <BotonDescarga r={r} onDescarga={onDescarga} />

  const pendiente = r.status === 'Pendiente'
  return (
    <span
      className={cn(
        'shrink-0 rounded-full px-2.5 py-1 text-xs font-medium',
        pendiente ? 'border border-accent text-accent' : 'bg-secondary text-muted-foreground',
      )}
    >
      {r.status}
    </span>
  )
}
