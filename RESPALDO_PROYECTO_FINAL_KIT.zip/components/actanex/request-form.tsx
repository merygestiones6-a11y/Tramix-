'use client'

import { useMemo, useState } from 'react'
import { mutate } from 'swr'
import { Check, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { parsearLineas, TIPOS, usaSegundaCurp } from '@/lib/actanex/curp'
import { cn } from '@/lib/utils'

export function RequestForm() {
  const [tipo, setTipo] = useState<string>('NACIMIENTO')
  const [folio, setFolio] = useState(false)
  const [texto, setTexto] = useState('')
  const [confirmando, setConfirmando] = useState(false)
  const [enviando, setEnviando] = useState(false)
  const [mensaje, setMensaje] = useState<{ tipo: 'ok' | 'error'; texto: string } | null>(null)

  const lineas = useMemo(() => parsearLineas(texto, tipo), [texto, tipo])
  const validas = lineas.filter((l) => !l.error)

  async function enviar() {
    setEnviando(true)
    setMensaje(null)
    try {
      const res = await fetch('/api/actanex/solicitudes', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          tipo,
          folio,
          items: validas.map(({ curp, CurpOpcional, cadena }) => ({ curp, CurpOpcional, cadena })),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? 'No se pudo enviar')
      setMensaje({ tipo: 'ok', texto: `${data.enviadas} solicitud(es) enviadas.` })
      setTexto('')
      mutate('/api/actanex/solicitudes')
    } catch (e) {
      setMensaje({ tipo: 'error', texto: e instanceof Error ? e.message : 'No se pudo enviar' })
    } finally {
      setEnviando(false)
      setConfirmando(false)
    }
  }

  return (
    <section
      aria-labelledby="nueva"
      className="flex flex-col gap-4 self-start rounded-2xl border bg-card p-5 shadow-lg shadow-primary/5"
    >
      <h2 id="nueva" className="flex items-center gap-2 text-base font-semibold text-primary">
        <span className="h-4 w-1 rounded-full bg-accent" aria-hidden="true" />
        Nueva solicitud
      </h2>

      <fieldset className="flex flex-col gap-2">
        <legend className="mb-2 text-sm font-medium">Tipo de acta</legend>
        <div className="grid grid-cols-2 gap-2">
          {TIPOS.map((t) => (
            <label
              key={t}
              className={cn(
                'flex h-11 cursor-pointer items-center justify-center rounded-xl border px-2 text-xs font-semibold tracking-wide transition-all',
                tipo === t
                  ? 'border-primary bg-primary text-primary-foreground shadow-md shadow-primary/20'
                  : 'bg-background hover:border-primary/50 hover:text-primary',
              )}
            >
              <input
                type="radio"
                name="tipo"
                value={t}
                checked={tipo === t}
                onChange={() => {
                  setTipo(t)
                  setConfirmando(false)
                }}
                className="sr-only"
              />
              {t}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="flex h-11 cursor-pointer items-center justify-between gap-3 rounded-xl border bg-background px-3">
        <span className="text-sm font-medium">Con folio</span>
        <input
          type="checkbox"
          checked={folio}
          onChange={(e) => setFolio(e.target.checked)}
          className="size-5 accent-primary"
        />
      </label>

      <div className="flex flex-col gap-2">
        <label htmlFor="lote" className="text-sm font-medium">
          CURPs o cadenas
        </label>
        <textarea
          id="lote"
          value={texto}
          onChange={(e) => {
            setTexto(e.target.value)
            setConfirmando(false)
          }}
          rows={7}
          spellCheck={false}
          placeholder={
            usaSegundaCurp(tipo)
              ? 'CURP1, CURP2 (esposo/a opcional)\nGAMA850101HDFRRL09, LOPB860202MDFPRR03'
              : 'Una por renglón\nGAMA850101HDFRRL09'
          }
          className="resize-y rounded-xl border border-input bg-background p-3 text-sm uppercase leading-relaxed tracking-wide outline-none placeholder:normal-case focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-ring/40"
        />
      </div>

      {lineas.length > 0 && (
        <ul className="flex max-h-56 flex-col gap-1 overflow-y-auto rounded-xl border bg-background p-2" aria-label="Vista previa">
          {lineas.map((l, i) => (
            <li key={i} className="flex items-center justify-between gap-2 px-1 py-1 text-xs">
              <span className="flex min-w-0 flex-col tracking-wide">
                <span className="truncate">{l.curp ?? l.cadena}</span>
                {l.CurpOpcional && <span className="truncate text-muted-foreground">{l.CurpOpcional}</span>}
              </span>
              {l.error ? (
                <span className="flex shrink-0 items-center gap-1 text-destructive">
                  <X className="size-3.5" aria-hidden="true" />
                  {l.error}
                </span>
              ) : (
                <span className="flex shrink-0 items-center gap-1 text-muted-foreground">
                  <Check className="size-3.5" aria-hidden="true" />
                  {l.curp ? 'CURP' : 'Cadena'}
                </span>
              )}
            </li>
          ))}
        </ul>
      )}

      {mensaje && (
        <p
          role="status"
          className={cn(
            'rounded-md px-3 py-2 text-sm',
            mensaje.tipo === 'ok' ? 'bg-secondary text-secondary-foreground' : 'bg-destructive/10 text-destructive',
          )}
        >
          {mensaje.texto}
        </p>
      )}

      {confirmando ? (
        <div className="flex flex-col gap-3 rounded-xl border border-accent/40 bg-secondary p-3">
          <p className="text-sm leading-relaxed">
            <strong>{validas.length}</strong> × <strong>{tipo}</strong>
            {folio ? ' con folio' : ''}
          </p>
          <div className="flex gap-2">
            <Button onClick={enviar} disabled={enviando} className="h-10 flex-1">
              {enviando ? 'Enviando…' : 'Confirmar'}
            </Button>
            <Button variant="outline" onClick={() => setConfirmando(false)} disabled={enviando} className="h-10">
              Cancelar
            </Button>
          </div>
        </div>
      ) : (
        <Button onClick={() => setConfirmando(true)} disabled={validas.length === 0} size="lg" className="h-12 rounded-xl text-sm shadow-md shadow-primary/20">
          {validas.length === 0 ? 'Enviar' : `Enviar (${validas.length})`}
        </Button>
      )}
    </section>
  )
}
