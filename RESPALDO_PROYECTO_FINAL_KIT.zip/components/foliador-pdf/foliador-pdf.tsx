'use client'

import { useRef, useState } from 'react'
import { CheckCircle2, Download, FileText, Loader2, Stamp, Trash2, Upload, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { saveFoliado } from '@/lib/foliador-download'
import { FoliadorError, findFolioInText, generateFolio, stampFolio } from '@/lib/foliador'
import { isCurpFormatValid } from '@/lib/extract'
import { pickPrimaryCurp } from '@/lib/extract/universal'
import { itemsToLines, type TextItemLike } from '@/lib/pdf/extract-text'
import { openPdfDocument } from '@/lib/pdf/pdfjs'

type Status = 'identificando' | 'pendiente' | 'procesando' | 'listo' | 'yaFoliado' | 'error'

type Item = {
  id: string
  file: File
  name: string
  status: Status
  /** CURP read from the document itself; null when it could not be identified. */
  curp?: string | null
  /** True once the user typed a name, so it is used instead of the CURP. */
  nameEdited?: boolean
  folio?: string
  message?: string
  output?: Uint8Array
}

const CURP_NOT_FOUND = 'No se pudo identificar la CURP del documento. Escribe el nombre del archivo para continuar.'

function withPdfExtension(name: string, fallback: string): string {
  const clean = name.replace(/[\\/:*?"<>|]/g, '').trim() || fallback
  return /\.pdf$/i.test(clean) ? clean : `${clean}.pdf`
}

async function documentCurp(file: File): Promise<string | null> {
  const { doc, close } = await openPdfDocument(new Uint8Array(await file.arrayBuffer()))
  try {
    const texts: string[] = []
    for (let n = 1; n <= doc.numPages; n++) {
      const content = await (await doc.getPage(n)).getTextContent()
      texts.push(itemsToLines(content.items.filter((it): it is TextItemLike & typeof it => 'str' in it) as TextItemLike[]))
    }
    const curp = pickPrimaryCurp(texts, null)
    return curp && isCurpFormatValid(curp) ? curp : null
  } finally {
    close()
  }
}

async function existingFolio(bytes: Uint8Array): Promise<string | null> {
  try {
    const { doc, close } = await openPdfDocument(bytes)
    try {
      const page = await doc.getPage(1)
      const content = await page.getTextContent()
      const text = content.items.map((it) => ('str' in it ? it.str : '')).join(' ')
      return findFolioInText(text)
    } finally {
      close()
    }
  } catch {
    return null
  }
}

export function FoliadorPdf() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [items, setItems] = useState<Item[]>([])
  const [running, setRunning] = useState(false)

  const update = (id: string, patch: Partial<Item>) =>
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)))

  function addFiles(list: FileList | null) {
    if (!list) return
    const pdfs = [...list].filter((f) => f.type === 'application/pdf' || /\.pdf$/i.test(f.name))
    const added = pdfs.map((file) => ({ id: crypto.randomUUID(), file, name: file.name, status: 'identificando' as const }))
    setItems((prev) => [...prev, ...added])
    for (const item of added) {
      documentCurp(item.file)
        .then((curp) =>
          setItems((prev) =>
            prev.map((it) => {
              if (it.id !== item.id) return it
              if (curp) return { ...it, curp, status: 'pendiente', name: it.nameEdited ? it.name : `${curp}.pdf` }
              return { ...it, curp: null, status: 'pendiente', message: CURP_NOT_FOUND }
            }),
          ),
        )
        .catch(() =>
          update(item.id, { curp: null, status: 'error', message: 'No se pudo leer el PDF. El original no se modificó.' }),
        )
    }
  }

  async function processAll() {
    setRunning(true)
    const taken = new Set(items.map((it) => it.folio).filter((f): f is string => Boolean(f)))
    for (const item of items) {
      if (item.status !== 'pendiente' && item.status !== 'error') continue
      if (!item.curp && !item.nameEdited) {
        update(item.id, { status: 'error', message: CURP_NOT_FOUND })
        continue
      }
      update(item.id, { status: 'procesando', message: undefined })
      try {
        const bytes = new Uint8Array(await item.file.arrayBuffer())
        const found = await existingFolio(bytes)
        if (found) {
          taken.add(found)
          update(item.id, { status: 'yaFoliado', folio: found, message: 'Este PDF ya tiene folio; no se modificó.' })
          continue
        }
        const folio = item.folio ?? generateFolio(taken)
        taken.add(folio)
        const output = await stampFolio(bytes, folio)
        const name = withPdfExtension(item.name, item.file.name)
        void saveFoliado(output, name)
        update(item.id, { status: 'listo', folio, output, name })
      } catch (err) {
        update(item.id, {
          status: 'error',
          message: err instanceof FoliadorError ? err.message : 'No se pudo procesar el archivo. El original no se modificó.',
        })
      }
    }
    setRunning(false)
  }

  const pending = items.filter((it) => it.status === 'pendiente' || it.status === 'error').length
  const identifying = items.some((it) => it.status === 'identificando')

  return (
    <div className="flex flex-col gap-4">
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        className="sr-only"
        aria-label="Seleccionar archivos PDF"
        onChange={(e) => {
          addFiles(e.target.files)
          e.target.value = ''
        }}
      />

      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={running}
        className="glass flex w-full flex-col items-center justify-center gap-4 rounded-3xl border border-dashed border-imss/40 px-6 py-10 text-center transition-shadow hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
      >
        <span className="flex size-16 items-center justify-center rounded-2xl border border-imss/25 bg-imss-soft text-imss-soft-foreground">
          <Stamp className="size-8" aria-hidden="true" />
        </span>
        <span className="flex flex-col gap-1">
          <span className="text-lg font-semibold tracking-wide">SELECCIONAR PDF</span>
          <span className="text-sm leading-relaxed text-muted-foreground text-pretty">
            Elige uno o varios archivos. El folio se coloca solo en la primera página.
          </span>
        </span>
        <span className="inline-flex items-center gap-2 rounded-full bg-imss px-4 py-2 text-sm font-semibold text-imss-foreground">
          <Upload className="size-4" aria-hidden="true" />
          SUBIR ARCHIVOS
        </span>
      </button>

      {items.length > 0 && (
        <section aria-labelledby="foliador-list" className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <h2 id="foliador-list" className="text-sm font-semibold tracking-wide text-muted-foreground">
              ARCHIVOS ({items.length})
            </h2>
            <Button onClick={processAll} disabled={running || identifying || pending === 0} className="bg-imss text-imss-foreground hover:bg-imss/90">
              {running ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Stamp className="size-4" aria-hidden="true" />}
              FOLIAR Y DESCARGAR
            </Button>
          </div>

          <ul className="flex flex-col gap-2">
            {items.map((item) => (
              <li key={item.id} className="glass flex flex-col gap-2 rounded-2xl border border-border p-3">
                <div className="flex items-center gap-2">
                  <FileText className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                  <label htmlFor={`name-${item.id}`} className="sr-only">
                    Nombre de descarga
                  </label>
                  <input
                    id={`name-${item.id}`}
                    value={item.name}
                    onChange={(e) => update(item.id, { name: e.target.value, nameEdited: true })}
                    disabled={item.status === 'procesando' || item.status === 'identificando'}
                    className="min-w-0 flex-1 rounded-lg border border-input bg-background px-2 py-1.5 text-sm"
                  />
                  {item.output && (
                    <Button
                      size="icon"
                      variant="outline"
                      aria-label={`Descargar ${item.name}`}
                      onClick={() => void saveFoliado(item.output!, withPdfExtension(item.name, item.file.name))}
                    >
                      <Download className="size-4" aria-hidden="true" />
                    </Button>
                  )}
                  {item.status !== 'procesando' && !running && (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label={`Quitar ${item.file.name}`}
                      onClick={() => setItems((prev) => prev.filter((it) => it.id !== item.id))}
                    >
                      <Trash2 className="size-4" aria-hidden="true" />
                    </Button>
                  )}
                </div>
                <StatusLine item={item} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}

function StatusLine({ item }: { item: Item }) {
  const base = 'flex items-center gap-1.5 text-xs font-medium'
  switch (item.status) {
    case 'identificando':
      return (
        <p className={`${base} text-muted-foreground`} role="status">
          <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
          IDENTIFICANDO CURP…
        </p>
      )
    case 'pendiente':
      if (item.curp === null && !item.nameEdited) {
        return (
          <p className={`${base} text-destructive`} role="alert">
            <XCircle className="size-3.5" aria-hidden="true" />
            {CURP_NOT_FOUND}
          </p>
        )
      }
      return <p className={`${base} text-muted-foreground`}>PENDIENTE</p>
    case 'procesando':
      return (
        <p className={`${base} text-muted-foreground`} role="status">
          <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
          PROCESANDO…
        </p>
      )
    case 'listo':
      return (
        <p className={`${base} text-imss`} role="status">
          <CheckCircle2 className="size-3.5" aria-hidden="true" />
          FOLIO <span className="font-mono">{item.folio}</span> · DESCARGADO
        </p>
      )
    case 'yaFoliado':
      return (
        <p className={`${base} text-muted-foreground`} role="status">
          <CheckCircle2 className="size-3.5" aria-hidden="true" />
          FOLIO EXISTENTE <span className="font-mono">{item.folio}</span> · {item.message}
        </p>
      )
    case 'error':
      return (
        <p className={`${base} text-destructive`} role="alert">
          <XCircle className="size-3.5" aria-hidden="true" />
          {item.message}
        </p>
      )
  }
}
