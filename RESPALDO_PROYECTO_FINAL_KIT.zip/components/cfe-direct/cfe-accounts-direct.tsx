'use client'

import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import { ChevronDown, Loader2, Plus, RefreshCw, Search, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { call, messageOf } from '@/lib/cfe-direct/client'
import { isUsable } from '@/lib/cfe-direct/select'
import {
  EMAIL,
  MANUAL_STATUSES,
  SERVICES_PER_ACCOUNT,
  STATUS_LABEL,
  type AccountStatus,
  type CfeDirectAccount,
} from '@/lib/cfe-direct/types'
import { cn } from '@/lib/utils'

const INPUT =
  'h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus-visible:border-[var(--cfe)] focus-visible:ring-3 focus-visible:ring-[var(--cfe-soft)]'

const STATUS_TONE: Record<AccountStatus, string> = {
  conectada: 'bg-[var(--cfe-soft)] text-[var(--cfe-strong)]',
  pendiente: 'bg-muted text-muted-foreground',
  'sesion-vencida': 'bg-destructive/10 text-destructive',
  'error-auth': 'bg-destructive/10 text-destructive',
  deshabilitada: 'bg-muted text-muted-foreground line-through',
}

export function CfeAccountsDirect() {
  const [accounts, setAccounts] = useState<CfeDirectAccount[] | null>(null)
  const [email, setEmail] = useState('')
  const [query, setQuery] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [open, setOpen] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await call<{ accounts: CfeDirectAccount[] }>('/api/cfe-direct/accounts')
      setAccounts(data.accounts)
      setError(null)
    } catch (e) {
      setAccounts((prev) => prev ?? [])
      setError(messageOf(e))
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function run(key: string, action: () => Promise<unknown>) {
    setBusy(key)
    setError(null)
    try {
      await action()
      await load()
    } catch (e) {
      setError(messageOf(e))
    } finally {
      setBusy(null)
    }
  }

  function onAdd(event: FormEvent) {
    event.preventDefault()
    const value = email.trim().toLowerCase()
    if (!EMAIL.test(value)) return setError('Correo no válido.')
    void run('add', async () => {
      await call('/api/cfe-direct/accounts', { method: 'POST', body: JSON.stringify({ email: value }) })
      setEmail('')
    })
  }

  const patch = (id: string, body: object) =>
    call(`/api/cfe-direct/accounts/${id}`, { method: 'PATCH', body: JSON.stringify(body) })

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!accounts) return []
    if (!q) return accounts
    return accounts.filter((a) => a.email.includes(q) || a.services.some((s) => s.number.includes(q)))
  }, [accounts, query])

  const usable = accounts?.filter((a) => isUsable(a.status)).length ?? 0

  return (
    <section className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">CUENTAS CFE</h2>
        <button
          type="button"
          onClick={() => void run('reload', load)}
          aria-label="Actualizar cuentas"
          className="flex size-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:text-foreground"
        >
          <RefreshCw className={cn('size-4', busy === 'reload' && 'animate-spin')} aria-hidden="true" />
        </button>
      </div>

      <p className="w-fit rounded-full bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
        CONEXIÓN CON CFE: PENDIENTE
      </p>

      <form onSubmit={onAdd} className="flex gap-2">
        <label htmlFor="cfe-email" className="sr-only">
          Correo electrónico
        </label>
        <input
          id="cfe-email"
          type="email"
          inputMode="email"
          autoComplete="off"
          placeholder="correo@ejemplo.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={INPUT}
        />
        <Button
          type="submit"
          disabled={busy === 'add'}
          className="h-11 shrink-0 rounded-xl bg-[var(--cfe)] px-4 text-[var(--cfe-fg)] hover:bg-[var(--cfe-strong)]"
        >
          {busy === 'add' ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Plus className="size-4" aria-hidden="true" />}
          <span className="hidden sm:inline">AGREGAR</span>
          <span className="sr-only sm:hidden">Agregar</span>
        </Button>
      </form>

      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <label htmlFor="cfe-search" className="sr-only">
          Buscar cuenta o número de servicio
        </label>
        <input
          id="cfe-search"
          type="search"
          placeholder="Buscar correo o servicio"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className={cn(INPUT, 'pl-9')}
        />
      </div>

      {error && (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      )}

      {accounts === null ? (
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          Cargando…
        </p>
      ) : (
        <>
          <p className="text-xs font-medium tracking-wide text-muted-foreground">
            {accounts.length} CUENTAS · {usable} UTILIZABLES
          </p>
          {filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">{accounts.length ? 'Sin coincidencias.' : 'Sin cuentas registradas.'}</p>
          ) : (
            <ul className="flex flex-col gap-2" aria-label="Cuentas CFE">
              {filtered.map((account) => {
                const expanded = open === account.id
                return (
                  <li key={account.id} className="flex flex-col gap-3 rounded-xl border border-border bg-background p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex min-w-0 flex-col gap-1.5">
                        <p className="truncate text-sm font-medium" title={account.email}>
                          {account.email}
                        </p>
                        <span className={cn('w-fit rounded-full px-2 py-0.5 text-xs font-semibold', STATUS_TONE[account.status])}>
                          {STATUS_LABEL[account.status]}
                        </span>
                        {account.lastError && <p className="text-xs text-destructive">{account.lastError}</p>}
                      </div>
                      <button
                        type="button"
                        aria-label={`Eliminar ${account.email}`}
                        disabled={busy === `del-${account.id}`}
                        onClick={() => {
                          if (window.confirm(`¿Eliminar ${account.email}?`))
                            void run(`del-${account.id}`, () => call(`/api/cfe-direct/accounts/${account.id}`, { method: 'DELETE' }))
                        }}
                        className="flex size-9 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="size-4" aria-hidden="true" />
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <label htmlFor={`status-${account.id}`} className="sr-only">
                        Estado de {account.email}
                      </label>
                      <select
                        id={`status-${account.id}`}
                        value={account.status}
                        disabled={busy === `st-${account.id}`}
                        onChange={(e) =>
                          void run(`st-${account.id}`, () => patch(account.id, { action: 'set-status', status: e.target.value }))
                        }
                        className="h-9 rounded-lg border border-input bg-background px-2 text-xs"
                      >
                        {MANUAL_STATUSES.map((s) => (
                          <option key={s} value={s}>
                            {STATUS_LABEL[s]}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        aria-expanded={expanded}
                        onClick={() => setOpen(expanded ? null : account.id)}
                        className="inline-flex h-9 items-center gap-1 rounded-lg px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                      >
                        {account.services.length}/{SERVICES_PER_ACCOUNT} servicios
                        <ChevronDown className={cn('size-4 transition-transform', expanded && 'rotate-180')} aria-hidden="true" />
                      </button>
                      <span className="text-xs text-muted-foreground">Límite CFE: sin confirmar</span>
                    </div>

                    {expanded && (
                      <ul className="flex flex-col gap-1" aria-label={`Servicios de ${account.email}`}>
                        {account.services.length === 0 && <li className="text-xs text-muted-foreground">Sin servicios.</li>}
                        {account.services.map((s) => (
                          <li key={s.number} className="flex items-center justify-between gap-2 rounded-lg bg-muted px-2 py-1">
                            <span className="font-mono text-xs">{s.number}</span>
                            <button
                              type="button"
                              aria-label={`Quitar ${s.number}`}
                              onClick={() =>
                                void run(`sv-${account.id}`, () => patch(account.id, { action: 'remove-service', serviceNumber: s.number }))
                              }
                              className="flex size-7 items-center justify-center rounded-full text-muted-foreground hover:text-destructive"
                            >
                              <X className="size-3.5" aria-hidden="true" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </li>
                )
              })}
            </ul>
          )}
        </>
      )}
    </section>
  )
}
