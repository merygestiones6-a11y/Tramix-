'use client'

import { useState, type CSSProperties, type FormEvent } from 'react'
import { ArrowLeft, Download, FileText, Loader2, Search, Settings } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { call, messageOf } from '@/lib/cfe-direct/client'
import { SERVICE_MAX_LENGTH, SERVICE_NUMBER, STATUS_LABEL, type ConsultResponse } from '@/lib/cfe-direct/types'
import { downloadPdf } from '@/lib/download'
import { AccessError, accessFetch } from '@/lib/outlook/client'
import { CfeAccountsDirect } from './cfe-accounts-direct'

/** CFE green, scoped to this module so the rest of TRAMIX keeps its own theme. */
export const CFE_THEME = {
  '--cfe': 'oklch(0.55 0.13 158)',
  '--cfe-strong': 'oklch(0.45 0.12 158)',
  '--cfe-soft': 'oklch(0.55 0.13 158 / 0.1)',
  '--cfe-fg': 'oklch(0.99 0.005 158)',
} as CSSProperties

const SELECTION_TEXT: Record<ConsultResponse['selection'], string> = {
  asociada: 'Cuenta asociada a este número',
  'menor-uso': 'Cuenta disponible asignada',
  'asociada-no-disponible': 'La cuenta asociada no está disponible',
  'sin-cuentas': 'No hay cuentas CFE disponibles',
}

class InvalidPdfError extends Error {}

export function CfeDirect() {
  const [view, setView] = useState<'consulta' | 'cuentas'>('consulta')
  const [service, setService] = useState('')
  const [touched, setTouched] = useState(false)
  const [loading, setLoading] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<ConsultResponse | null>(null)

  const valid = SERVICE_NUMBER.test(service)
  const showInvalid = touched && service.length > 0 && !valid

  async function onConsult(event: FormEvent) {
    event.preventDefault()
    setTouched(true)
    if (!valid || loading) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      setResult(await call<ConsultResponse>('/api/cfe-direct/consult', { method: 'POST', body: JSON.stringify({ serviceNumber: service }) }))
    } catch (e) {
      setError(messageOf(e))
    } finally {
      setLoading(false)
    }
  }

  async function onDownload() {
    const receipt = result?.receipt
    if (!receipt || downloading) return
    setDownloading(true)
    setError(null)
    try {
      const res = await accessFetch(`/api/cfe/receipts/${receipt.id}`)
      if (!res.ok) throw new Error(String(res.status))
      const blob = await res.blob()
      const head = new TextDecoder().decode(await blob.slice(0, 5).arrayBuffer())
      if (blob.size < 100 || head !== '%PDF-') throw new InvalidPdfError()
      downloadPdf(blob, receipt.fileName)
    } catch (e) {
      setError(
        e instanceof AccessError
          ? 'Tu sesión del panel venció. Vuelve a iniciar sesión.'
          : e instanceof InvalidPdfError
            ? 'El archivo recibido no es un PDF válido.'
            : 'No se pudo descargar el recibo.',
      )
    } finally {
      setDownloading(false)
    }
  }

  if (view === 'cuentas') {
    return (
      <div style={CFE_THEME} className="flex flex-col gap-4">
        <button
          type="button"
          onClick={() => setView('consulta')}
          className="inline-flex w-fit items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Consulta
        </button>
        <CfeAccountsDirect />
      </div>
    )
  }

  return (
    <div style={CFE_THEME} className="flex flex-col gap-4">
      <section className="relative flex flex-col gap-5 rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-xl bg-[var(--cfe-soft)] text-[var(--cfe-strong)]">
              <FileText className="size-5" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-semibold">Recibo de luz</h2>
          </div>
          <button
            type="button"
            onClick={() => setView('cuentas')}
            aria-label="Cuentas CFE"
            title="Cuentas CFE"
            className="flex size-10 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:bg-[var(--cfe-soft)] hover:text-[var(--cfe-strong)]"
          >
            <Settings className="size-5" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={onConsult} className="flex flex-col gap-3" noValidate>
          <label htmlFor="cfe-service" className="text-xs font-semibold tracking-wide text-muted-foreground">
            NÚMERO DE SERVICIO
          </label>
          <input
            id="cfe-service"
            inputMode="numeric"
            autoComplete="off"
            maxLength={SERVICE_MAX_LENGTH}
            placeholder="11 o 12 dígitos"
            value={service}
            onChange={(e) => {
              setService(e.target.value.replace(/\D/g, '').slice(0, SERVICE_MAX_LENGTH))
              setResult(null)
            }}
            onBlur={() => setTouched(true)}
            aria-invalid={showInvalid}
            aria-describedby="cfe-service-hint"
            className="h-12 rounded-xl border border-input bg-background px-4 font-mono text-lg tracking-[0.2em] outline-none transition-shadow focus-visible:border-[var(--cfe)] focus-visible:ring-3 focus-visible:ring-[var(--cfe-soft)] aria-invalid:border-destructive"
          />
          <p id="cfe-service-hint" className={showInvalid ? 'text-sm text-destructive' : 'text-sm text-muted-foreground'}>
            {showInvalid ? 'Debe tener 11 o 12 dígitos.' : `${service.length} dígitos`}
          </p>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <Button
              type="submit"
              disabled={loading}
              className="h-12 rounded-xl bg-[var(--cfe)] text-sm font-semibold text-[var(--cfe-fg)] hover:bg-[var(--cfe-strong)]"
            >
              {loading ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Search className="size-4" aria-hidden="true" />}
              CONSULTAR
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={!result?.receipt || downloading}
              onClick={onDownload}
              className="h-12 rounded-xl text-sm font-semibold"
            >
              {downloading ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Download className="size-4" aria-hidden="true" />}
              DESCARGAR PDF
            </Button>
          </div>
        </form>

        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}

        {result && (
          <div role="status" className="flex flex-col gap-2 rounded-xl border border-border bg-background p-4 text-sm">
            {result.receipt ? (
              <>
                <p className="font-semibold text-[var(--cfe-strong)]">Recibo disponible</p>
                <p className="break-all font-mono text-xs">{result.receipt.fileName}</p>
                <p className="text-muted-foreground">
                  {new Date(result.receipt.createdAt).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' })}
                </p>
              </>
            ) : (
              <>
                <p className="font-semibold">Sin recibo disponible</p>
                <p className="text-muted-foreground">La descarga automática desde CFE está pendiente de una fuente autorizada.</p>
              </>
            )}
            <p className="text-muted-foreground">
              {SELECTION_TEXT[result.selection]}
              {result.account ? ` · ${result.account.email} (${STATUS_LABEL[result.account.status]})` : ''}
            </p>
          </div>
        )}
      </section>
    </div>
  )
}
