'use client'

import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { ChevronDown, ChevronUp, GripVertical, TriangleAlert, X } from 'lucide-react'
import type { QueuedFile } from '@/hooks/use-file-queue'
import { formatBytes } from '@/lib/files'
import { cn } from '@/lib/utils'

interface FileRowProps {
  item: QueuedFile
  index: number
  total: number
  disabled: boolean
  onRemove: () => void
  onMoveUp: () => void
  onMoveDown: () => void
}

const iconButton =
  'inline-flex items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:pointer-events-none disabled:opacity-30'

export function FileRow({ item, index, total, disabled, onRemove, onMoveUp, onMoveDown }: FileRowProps) {
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } = useSortable({
    id: item.id,
    disabled,
  })

  return (
    <li
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={cn(
        'relative flex animate-rise items-center gap-1.5 rounded-2xl border bg-muted p-1.5 pr-1 transition-shadow',
        item.error ? 'border-destructive/50' : 'border-border',
        isDragging && 'z-10 border-primary/50 bg-popover shadow-[0_18px_40px_-16px_var(--color-primary)]',
      )}
    >
      {total > 1 ? (
        <button
          type="button"
          ref={setActivatorNodeRef}
          {...attributes}
          {...listeners}
          disabled={disabled}
          className={cn(iconButton, 'h-10 w-7 cursor-grab touch-none active:cursor-grabbing')}
          aria-label={`Arrastrar para reordenar ${item.file.name}`}
        >
          <GripVertical className="size-4" aria-hidden="true" />
        </button>
      ) : null}

      <span
        aria-hidden="true"
        className="flex size-10 shrink-0 flex-col items-center justify-center rounded-xl border border-primary/25 bg-accent text-[10px] font-bold tracking-wider text-accent-foreground"
      >
        PDF
      </span>

      <div className="flex min-w-0 flex-1 flex-col px-1.5">
        <span className="truncate text-sm font-medium">{item.file.name}</span>
        {item.error ? (
          <span className="flex items-center gap-1 text-xs text-destructive">
            <TriangleAlert className="size-3" aria-hidden="true" />
            {item.error}
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">
            {total > 1 ? `${index + 1}º · ` : ''}
            {formatBytes(item.file.size)}
          </span>
        )}
      </div>

      {total > 1 ? (
        <div className="flex flex-col">
          <button
            type="button"
            onClick={onMoveUp}
            disabled={disabled || index === 0}
            className={cn(iconButton, 'h-5 w-8')}
            aria-label={`Subir ${item.file.name}`}
          >
            <ChevronUp className="size-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={onMoveDown}
            disabled={disabled || index === total - 1}
            className={cn(iconButton, 'h-5 w-8')}
            aria-label={`Bajar ${item.file.name}`}
          >
            <ChevronDown className="size-4" aria-hidden="true" />
          </button>
        </div>
      ) : null}

      <button
        type="button"
        onClick={onRemove}
        disabled={disabled}
        className={cn(iconButton, 'size-10 hover:text-destructive')}
        aria-label={`Quitar ${item.file.name}`}
      >
        <X className="size-4" aria-hidden="true" />
      </button>
    </li>
  )
}
