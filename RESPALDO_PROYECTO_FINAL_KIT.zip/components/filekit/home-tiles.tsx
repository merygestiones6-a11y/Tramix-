'use client'

import { BadgeCheck, Download, FileText, Fingerprint, Hash, Landmark, Mail, Send, Stamp } from 'lucide-react'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { DocumentReceiverTile } from './document-receiver'

const TILE =
  'group relative flex aspect-square flex-col items-center justify-center gap-4 rounded-3xl p-4 text-center transition-[transform,box-shadow,filter] duration-300 active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background'

const ICON = 'flex size-16 items-center justify-center rounded-2xl transition-transform duration-300 group-hover:-translate-y-1 sm:size-20'

export function HomeTiles() {
  return (
    <div className="mx-auto grid w-full max-w-md grid-cols-2 gap-3 sm:gap-4">
      <Link
        href="/enviar-imss"
        className={cn(
          TILE,
          'bg-imss text-imss-foreground shadow-[0_18px_40px_-16px_var(--color-imss)] hover:brightness-110',
        )}
      >
        <span className={cn(ICON, 'bg-imss-foreground/15')}>
          <Send className="size-8 sm:size-9" aria-hidden="true" />
        </span>
        <span className="text-lg font-semibold tracking-wide sm:text-xl">IMSS</span>
      </Link>

      <Link href="/panel" className={cn(TILE, 'glass text-foreground hover:shadow-lg')}>
        <span className={cn(ICON, 'border border-imss/25 bg-imss-soft text-imss-soft-foreground')}>
          <Download className="size-8 sm:size-9" aria-hidden="true" />
        </span>
        <span className="flex flex-col gap-1">
                <span className="text-lg font-semibold tracking-wide sm:text-xl">DESCARGAR</span>

        </span>
      </Link>

      <DocumentReceiverTile tileClassName={TILE} iconClassName={ICON} />

      <Link href="/actanex" className={cn(TILE, 'glass text-foreground hover:shadow-lg')}>
        <span className={cn(ICON, 'border border-imss/25 bg-imss-soft text-imss-soft-foreground')}>
          <Landmark className="size-8 sm:size-9" aria-hidden="true" />
        </span>
        <span className="text-lg font-semibold tracking-wide sm:text-xl">ACTANEX</span>
      </Link>

      <Link
        href="/rfc-sat"
        className={cn(
          TILE,
          'glass col-span-2 mx-auto w-[calc(50%-0.375rem)] text-foreground hover:shadow-lg sm:w-[calc(50%-0.5rem)]',
        )}
      >
        <span className={cn(ICON, 'border border-imss/25 bg-imss-soft text-imss-soft-foreground')}>
          <BadgeCheck className="size-8 sm:size-9" aria-hidden="true" />
        </span>
        <span className="text-lg font-semibold tracking-wide sm:text-xl">RFC</span>
      </Link>

      <Link
        href="/cuentas-outlook"
        className="col-span-2 mx-auto inline-flex h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        <Mail className="size-4" aria-hidden="true" />
        LECTURA DE CORREOS IMSS
      </Link>

      <Link
        href="/cif-sat"
        className="col-span-2 mx-auto inline-flex h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        <FileText className="size-4" aria-hidden="true" />
        CIF SAT
      </Link>

      <Link
        href="/foliador-pdf"
        className="col-span-2 mx-auto inline-flex h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        <Stamp className="size-4" aria-hidden="true" />
        FOLIADOR PDF
      </Link>

      <Link
        href="/identity-lab"
        className="col-span-2 mx-auto inline-flex h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        <Fingerprint className="size-4" aria-hidden="true" />
        IDENTITY LAB
      </Link>

      <Link
        href="/consulta-nss"
        className="col-span-2 mx-auto inline-flex h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        <Hash className="size-4" aria-hidden="true" />
        CONSULTA NSS
      </Link>
    </div>
  )
}
