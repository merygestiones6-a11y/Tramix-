'use client'

import { type ReactNode, useCallback, useEffect, useRef } from 'react'
import { useAnalysis } from '@/hooks/use-analysis'
import { useFileQueue } from '@/hooks/use-file-queue'
import { ERRORS } from '@/lib/files'
import { takePendingUpload } from '@/lib/pending-upload'
import { AnalysisProgress } from './analysis-progress'
import { FileList } from './file-list'
import { HomeTiles } from './home-tiles'
import { Notice } from './notice'
import { ResultPanel } from './result-panel'

export function FileKitApp({ renderEmpty }: { renderEmpty?: (pick: () => void) => ReactNode } = {}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const resultRef = useRef<HTMLDivElement>(null)
  const queue = useFileQueue()
  const { markError } = queue
  const onUnreadable = useCallback((id: string) => markError(id, ERRORS.unreadable), [markError])
  const analysis = useAnalysis({ onUnreadable })
  const { state } = analysis
  const busy = state.status === 'running'

  const handleFiles = async (files: FileList | File[]) => {
    await queue.add(files)
  }

  const addToQueue = queue.add
  useEffect(() => {
    const pending = takePendingUpload()
    if (pending) addToQueue(pending)
  }, [addToQueue])

  // Any change to the list (add, remove, reorder) reprocesses it automatically.
  const { run, reset } = analysis
  const itemsRef = useRef(queue.items)
  itemsRef.current = queue.items
  const signature = queue.items.map((item) => item.id).join('|')
  useEffect(() => {
    if (!signature) {
      reset()
      return
    }
    // Short delay so a burst of picks or a drag settles into a single run.
    const timer = setTimeout(() => run(itemsRef.current.map(({ id, file }) => ({ id, file }))), 250)
    return () => clearTimeout(timer)
  }, [signature, run, reset])

  const startOver = () => {
    analysis.reset()
    queue.clear()
  }

  const doneRunId = state.status === 'done' ? state.runId : null
  useEffect(() => {
    if (doneRunId !== null && window.matchMedia('(max-width: 1023px)').matches) {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }, [doneRunId])

  return (
    <div className="flex flex-col gap-4">
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
        onChange={(event) => {
          const files = event.target.files
          if (files?.length) handleFiles(Array.from(files))
          event.target.value = ''
        }}
      />

      {queue.rejected.length ? (
        <Notice onDismiss={queue.dismissRejected}>
          <span className="font-semibold">{ERRORS.notPdf}</span>
          <span className="break-all text-muted-foreground">{queue.rejected.join(', ')}</span>
          {queue.items.length === 0 ? <span className="text-muted-foreground">{ERRORS.noFiles}</span> : null}
        </Notice>
      ) : null}

      {queue.items.length === 0 ? (
        renderEmpty ? renderEmpty(() => inputRef.current?.click()) : <HomeTiles />
      ) : (
        <FileList
          items={queue.items}
          disabled={busy}
          onRemove={queue.remove}
          onMove={queue.move}
          onAddMore={() => inputRef.current?.click()}
          onClear={startOver}
        />
      )}

      {state.status === 'running' ? <AnalysisProgress progress={state.progress} merging={state.merging} /> : null}

      {state.status === 'error' ? <Notice>{state.message}</Notice> : null}

      <div ref={resultRef} className="scroll-mt-20">
        {state.status === 'done' ? (
          <ResultPanel
            key={state.runId}
            result={state.result}
            fileCount={queue.items.length}
            originalName={queue.items[0]?.file.name ?? 'documento.pdf'}
            onStartOver={startOver}
          />
        ) : null}
      </div>
    </div>
  )
}
