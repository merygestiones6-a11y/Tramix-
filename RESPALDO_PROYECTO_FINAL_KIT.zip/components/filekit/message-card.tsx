'use client'

import { Check, ClipboardCopy, MessageSquareText, TriangleAlert } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { copyText } from '@/lib/clipboard'
import { cn } from '@/lib/utils'

interface MessageCardProps {
  /** Null while the mandatory name + CURP are missing: no message is generated with incomplete data. */
  message: string | null
  pendingReason: string
}

export function MessageCard({ message, pendingReason }: MessageCardProps) {
  const [state, setState] = useState<'idle' | 'copied' | 'failed'>('idle')
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current)
    },
    [],
  )

  if (message === null) {
    return (
      <section aria-labelledby="message-heading" className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
        <h2 id="message-heading" className="flex items-center gap-2 text-sm font-semibold">
          <MessageSquareText className="size-4 text-accent-foreground" aria-hidden="true" />
          Mensaje generado
        </h2>
        <p className="flex items-start gap-2 rounded-2xl border border-dashed border-warning/40 p-4 text-sm text-muted-foreground">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden="true" />
          <span>
            {pendingReason} El mensaje se generará al completar los datos.
          </span>
        </p>
      </section>
    )
  }

  const handleCopy = async () => {
    const ok = await copyText(message)
    setState(ok ? 'copied' : 'failed')
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setState('idle'), 2500)
  }

  return (
    <section aria-labelledby="message-heading" className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
      <h2 id="message-heading" className="flex items-center gap-2 text-sm font-semibold">
        <MessageSquareText className="size-4 text-accent-foreground" aria-hidden="true" />
        Mensaje generado
      </h2>

      {/* Raw text on purpose: asterisks must stay literal for WhatsApp. */}
      <pre className="overflow-x-auto rounded-2xl border border-border bg-muted p-4 font-mono text-sm leading-relaxed break-words whitespace-pre-wrap text-foreground">
        {message}
      </pre>

      <button
        type="button"
        onClick={handleCopy}
        className={cn(
          'inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-semibold tracking-wide transition-all active:scale-[0.98]',
          state === 'copied'
            ? 'bg-success text-success-foreground'
            : 'border border-border bg-secondary text-foreground hover:border-primary/40 hover:bg-accent',
        )}
      >
        {state === 'copied' ? (
          <>
            <Check className="size-4 animate-pop" aria-hidden="true" />
            MENSAJE COPIADO
          </>
        ) : (
          <>
            <ClipboardCopy className="size-4" aria-hidden="true" />
            COPIAR MENSAJE
          </>
        )}
      </button>
      <p aria-live="polite" className="sr-only">
        {state === 'copied' ? 'Mensaje copiado' : ''}
      </p>
      {state === 'failed' ? (
        <p className="text-xs text-warning">No se pudo copiar automáticamente. Mantén presionado el texto para copiarlo.</p>
      ) : null}
    </section>
  )
}
