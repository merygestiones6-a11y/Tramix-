'use client'

import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Loader2, Trash2 } from 'lucide-react'
import { mutate } from 'swr'

type Status = 'idle' | 'deleting' | 'error'

export function EmptyStorageButton() {
  const [open, setOpen] = useState(false)
  const [status, setStatus] = useState<Status>('idle')
  const cancelRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    cancelRef.current?.focus()
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && status !== 'deleting') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, status])

  async function confirmDelete() {
    setStatus('deleting')
    try {
      const res = await fetch('/api/panel/files', { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      await mutate('/api/panel/files')
      setStatus('idle')
      setOpen(false)
    } catch {
      setStatus('error')
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setStatus('idle')
          setOpen(true)
        }}
        className="inline-flex size-8 items-center justify-center rounded-full border border-border/60 bg-card/60 text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label="Vaciar archivos almacenados"
        title="Vaciar archivos almacenados"
      >
        <Trash2 className="size-4" aria-hidden="true" />
      </button>

      {open && createPortal(
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-background/70 p-4 backdrop-blur-sm sm:items-center"
          onClick={() => status !== 'deleting' && setOpen(false)}
        >
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="empty-storage-title"
            aria-describedby="empty-storage-desc"
            className="flex w-full max-w-sm flex-col gap-4 rounded-2xl border border-border/60 bg-card p-5 text-card-foreground shadow-2xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-destructive/10 text-destructive">
                <Trash2 className="size-5" aria-hidden="true" />
              </span>
              <div className="flex flex-col gap-1">
                <h2 id="empty-storage-title" className="text-base font-semibold">
                  ¿Vaciar todos los archivos?
                </h2>
                <p id="empty-storage-desc" className="text-sm leading-relaxed text-muted-foreground">
                  Se eliminarán de inmediato todos los archivos almacenados y su texto. Esta acción no se puede deshacer.
                </p>
              </div>
            </div>

            {status === 'error' && (
              <p role="alert" className="text-sm text-destructive">
                No se pudieron eliminar. Intenta de nuevo.
              </p>
            )}

            <div className="flex gap-2">
              <button
                ref={cancelRef}
                type="button"
                onClick={() => setOpen(false)}
                disabled={status === 'deleting'}
                className="h-11 flex-1 rounded-xl border border-border bg-background text-sm font-medium transition-colors hover:bg-muted disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                disabled={status === 'deleting'}
                className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-destructive text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
              >
                {status === 'deleting' ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Trash2 className="size-4" aria-hidden="true" />
                )}
                {status === 'deleting' ? 'Eliminando…' : 'Eliminar todo'}
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </>
  )
}
