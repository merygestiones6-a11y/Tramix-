'use client'

import { Check, Download, Loader2, RotateCcw, ScanText, TriangleAlert, Upload } from 'lucide-react'
import { useId, useState } from 'react'
import { downloadPdf } from '@/lib/download'
import {
  crossCheckDemographics,
  isCurpFormatValid,
  isNssFormatValid,
  normalizeCurp,
  normalizeName,
  normalizeNss,
  stateLabel,
} from '@/lib/extract'
import { ERRORS, formatBytes } from '@/lib/files'
import { buildDeliveryMessage } from '@/lib/message'
import { buildSuggestedFileName, finalizeFileName, toCustomPrefix } from '@/lib/naming'
import type { AnalysisResult } from '@/lib/pipeline/analyze'
import { getProcedureById } from '@/lib/procedures'
import { cn } from '@/lib/utils'
import { DataField } from './data-field'
import { DemographicsFields, type DemographicsOverrides, resolveDemographics } from './demographics-fields'
import { MessageCard } from './message-card'
import { CUSTOM_PROCEDURE, ProcedureField } from './procedure-field'

async function saveToPanel(bytes: Uint8Array, name: string) {
  const form = new FormData()
  form.append('file', new File([bytes as BlobPart], name, { type: 'application/pdf' }))
  const res = await fetch('/api/panel/files', { method: 'POST', body: form })
  if (!res.ok) throw new Error('upload-failed')
}

type UploadState = { status: 'idle' } | { status: 'uploading' } | { status: 'done'; name: string } | { status: 'error' }

interface ResultPanelProps {
  result: AnalysisResult
  fileCount: number
  originalName: string
  onStartOver: () => void
}

export function ResultPanel({ result, fileCount, originalName, onStartOver }: ResultPanelProps) {
  const fileNameId = useId()
  const [procedureId, setProcedureId] = useState(result.procedure?.rule.id ?? '')
  const [customProcedure, setCustomProcedure] = useState('')
  const nameConfidence = result.data.nameConfidence
  const unconfirmedName = nameConfidence === 'low' ? result.data.name : null
  const [name, setName] = useState(nameConfidence === 'low' ? '' : (result.data.name ?? ''))
  const [curp, setCurp] = useState(result.data.curp ?? '')
  const hasDetectedNss = Boolean(result.data.nss && isNssFormatValid(result.data.nss))
  const [nss, setNss] = useState(hasDetectedNss ? (result.data.nss ?? '') : '')
  const [editedFileName, setEditedFileName] = useState<string | null>(null)
  const [downloadedAs, setDownloadedAs] = useState<string | null>(null)
  const [fileNameError, setFileNameError] = useState<string | null>(null)
  const [upload, setUpload] = useState<UploadState>({ status: 'idle' })

  const prefix =
    procedureId === CUSTOM_PROCEDURE ? toCustomPrefix(customProcedure) : (getProcedureById(procedureId)?.prefix ?? '')
  const cleanCurp = normalizeCurp(curp)
  const suggestedFileName = buildSuggestedFileName({
    prefix,
    curp: isCurpFormatValid(cleanCurp) ? cleanCurp : '',
    fallbackName: originalName,
  })
  const fileName = editedFileName ?? suggestedFileName

  const [overrides, setOverrides] = useState<DemographicsOverrides>({ birthDate: null, sex: null, state: null })
  const demographicsCross = crossCheckDemographics(cleanCurp, result.data.documentFacts)
  const demographics = resolveDemographics(demographicsCross, overrides)

  const message = buildDeliveryMessage({
    name: normalizeName(name),
    curp: cleanCurp,
    nss: normalizeNss(nss),
    birthDate: demographics.birthDate,
    sex: demographics.sex,
    state: demographics.state ? stateLabel(demographics.state) : null,
  })

  const hasName = normalizeName(name).trim().split(' ').filter(Boolean).length >= 2
  const hasCurp = isCurpFormatValid(cleanCurp)
  const identityComplete = hasName && hasCurp
  const missingTitle = !hasName && !hasCurp ? 'Nombre y CURP no identificados' : !hasName ? 'Nombre no identificado' : 'CURP no identificada'

  const curpHint = cleanCurp && !isCurpFormatValid(cleanCurp) ? 'La CURP debe tener 18 caracteres válidos.' : undefined
  const nssHint = nss && !isNssFormatValid(normalizeNss(nss)) ? 'El NSS debe tener 11 dígitos.' : undefined

  const handleDownload = () => {
    const finalName = finalizeFileName(fileName)
    if (!finalName) {
      setFileNameError(ERRORS.emptyName)
      return
    }
    setFileNameError(null)
    downloadPdf(result.bytes, finalName)
    setDownloadedAs(finalName)
  }

  const handleUpload = async () => {
    const finalName = finalizeFileName(fileName)
    if (!finalName) {
      setFileNameError(ERRORS.emptyName)
      return
    }
    setFileNameError(null)
    setUpload({ status: 'uploading' })
    try {
      await saveToPanel(result.bytes, finalName)
      setUpload({ status: 'done', name: finalName })
    } catch {
      setUpload({ status: 'error' })
    }
  }

  return (
    <section aria-labelledby="result-heading" className="flex animate-rise flex-col gap-4">
      <div className="flex items-center gap-3 px-1">
        {identityComplete ? (
          <span className="flex size-10 shrink-0 animate-pop items-center justify-center rounded-full bg-success text-success-foreground shadow-[0_0_24px_-4px_var(--color-success)]">
            <Check className="size-5" strokeWidth={3} aria-hidden="true" />
          </span>
        ) : (
          <span className="flex size-10 shrink-0 animate-pop items-center justify-center rounded-full bg-warning/15 text-warning ring-1 ring-warning/40">
            <TriangleAlert className="size-5" aria-hidden="true" />
          </span>
        )}
        <div className="flex min-w-0 flex-1 flex-col">
          <h2 id="result-heading" className={cn('font-semibold', !identityComplete && 'text-warning')}>
            {identityComplete ? 'Análisis completado' : missingTitle}
          </h2>
          <p className="text-sm text-muted-foreground">
            {identityComplete
              ? downloadedAs
                ? 'Archivo descargado. Puedes editar y volver a descargar.'
                : 'Archivo listo. Revisa los datos y pulsa Descargar PDF.'
              : 'Escríbelo abajo para generar el mensaje.'}
          </p>
        </div>
        <button
          type="button"
          onClick={onStartOver}
          className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-border bg-muted px-3 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <RotateCcw className="size-3.5" aria-hidden="true" />
          Nuevo
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-2 lg:items-start">
        <div className="glass flex flex-col gap-5 rounded-3xl p-4 sm:p-5">
          <ProcedureField
            value={procedureId}
            customValue={customProcedure}
            detected={Boolean(result.procedure)}
            onChange={setProcedureId}
            onCustomChange={setCustomProcedure}
          />
          <div className="h-px bg-border" aria-hidden="true" />
          <DataField
            label="NOMBRE COMPLETO"
            value={name}
            detected={Boolean(result.data.name) && nameConfidence !== 'low'}
            status={nameConfidence === 'medium' ? 'VERIFICA EL NOMBRE' : undefined}
            missingLabel="NOMBRE NO IDENTIFICADO"
            placeholder="Introducir nombre"
            onChange={setName}
          >
            {unconfirmedName && !name ? (
              <button
                type="button"
                onClick={() => setName(unconfirmedName)}
                className="flex items-center justify-between gap-2 rounded-xl border border-dashed border-warning/40 px-3 py-2 text-left text-xs"
              >
                <span className="min-w-0 text-muted-foreground">
                  Posible nombre: <span className="font-medium text-foreground">{unconfirmedName}</span>
                </span>
                <span className="shrink-0 font-semibold text-accent-foreground">Usar</span>
              </button>
            ) : null}
          </DataField>
          <DataField
            label="CURP"
            value={curp}
            detected={Boolean(result.data.curp)}
            missingLabel="CURP NO IDENTIFICADA"
            placeholder="18 caracteres"
            onChange={(value) => setCurp(value.toUpperCase())}
            maxLength={18}
            mono
            hint={curpHint}
          />
          {hasDetectedNss ? (
            <DataField
              label="NSS"
              value={nss}
              detected
              missingLabel=""
              placeholder="11 dígitos"
              onChange={setNss}
              inputMode="numeric"
              maxLength={11}
              mono
              hint={nssHint}
            />
          ) : null}
          <div className="h-px bg-border" aria-hidden="true" />
          <DemographicsFields
            cross={demographicsCross}
            overrides={overrides}
            onOverride={(field, value) => setOverrides((current) => ({ ...current, [field]: value }))}
          />
          {result.usedOcr ? (
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <ScanText className="size-3.5" aria-hidden="true" />
              Se usó OCR para leer páginas escaneadas. Verifica los datos.
            </p>
          ) : null}
        </div>

        <div className="flex flex-col gap-4">
          <div className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
            <div className="flex items-center gap-3 rounded-2xl border border-border bg-muted p-3">
              <span
                aria-hidden="true"
                className="flex h-12 w-10 shrink-0 items-center justify-center rounded-lg border border-primary/30 bg-accent text-[10px] font-bold tracking-wider text-accent-foreground"
              >
                PDF
              </span>
              <div className="flex min-w-0 flex-col">
                <span className="truncate font-mono text-sm font-medium">{finalizeFileName(fileName) || '—'}</span>
                <span className="text-xs text-muted-foreground">
                  {result.pageCount} {result.pageCount === 1 ? 'página' : 'páginas'} ·{' '}
                  {formatBytes(result.bytes.byteLength)} ·{' '}
                  {result.merged ? `Unido de ${fileCount} archivos` : 'Original sin cambios'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor={fileNameId} className="text-xs font-semibold tracking-[0.14em] text-muted-foreground">
                  NOMBRE DEL ARCHIVO
                </label>
                {editedFileName !== null ? (
                  <button
                    type="button"
                    onClick={() => setEditedFileName(null)}
                    className="text-xs font-medium text-accent-foreground hover:underline"
                  >
                    Usar sugerido
                  </button>
                ) : null}
              </div>
              <input
                id={fileNameId}
                value={fileName}
                onChange={(event) => {
                  setEditedFileName(event.target.value)
                  setDownloadedAs(null)
                  setUpload({ status: 'idle' })
                }}
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                className={cn('field-input font-mono', fileNameError && 'border-destructive')}
              />
              {fileNameError ? <p className="text-xs text-destructive">{fileNameError}</p> : null}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleDownload}
                className="inline-flex h-13 min-w-0 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold tracking-wide text-primary-foreground shadow-[0_12px_32px_-12px_var(--color-primary)] transition-[transform,filter] hover:brightness-110 active:scale-[0.98]"
              >
                <Download className="size-5 shrink-0" aria-hidden="true" />
                DESCARGAR PDF
              </button>
              <button
                type="button"
                onClick={handleUpload}
                disabled={upload.status === 'uploading' || upload.status === 'done'}
                className="inline-flex h-13 shrink-0 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-accent px-4 text-sm font-semibold tracking-wide text-accent-foreground transition-[transform,filter] hover:brightness-110 active:scale-[0.98] disabled:active:scale-100 disabled:opacity-80"
              >
                {upload.status === 'uploading' ? (
                  <Loader2 className="size-5 animate-spin" aria-hidden="true" />
                ) : upload.status === 'done' ? (
                  <Check className="size-5" aria-hidden="true" />
                ) : (
                  <Upload className="size-5" aria-hidden="true" />
                )}
                {upload.status === 'uploading' ? 'SUBIENDO' : upload.status === 'done' ? 'SUBIDO' : 'SUBIR'}
              </button>
            </div>

            <p aria-live="polite" className="flex flex-col gap-2 text-center text-xs text-muted-foreground empty:hidden">
              {downloadedAs ? (
                <span className="flex flex-col items-center gap-0.5">
                  <span className="inline-flex items-center gap-1 font-medium text-success">
                    <Check className="size-3.5" aria-hidden="true" />
                    Descargado como
                  </span>
                  <span className="font-mono break-all text-foreground">{downloadedAs}</span>
                </span>
              ) : null}
              {upload.status === 'done' ? (
                <span className="flex flex-col items-center gap-0.5">
                  <span className="inline-flex items-center gap-1 font-medium text-success">
                    <Check className="size-3.5" aria-hidden="true" />
                    Guardado en DESCARGAR (12 h)
                  </span>
                  <a href="/panel" className="font-medium text-accent-foreground hover:underline">
                    Ver archivos guardados
                  </a>
                </span>
              ) : null}
              {upload.status === 'error' ? (
                <span className="font-medium text-destructive">No se pudo subir. Inténtalo de nuevo.</span>
              ) : null}
            </p>
          </div>

          <MessageCard
            message={identityComplete ? message : null}
            pendingReason={!hasName ? 'Falta el nombre completo del cliente.' : 'Falta una CURP válida de 18 caracteres.'}
          />
        </div>
      </div>
    </section>
  )
}
