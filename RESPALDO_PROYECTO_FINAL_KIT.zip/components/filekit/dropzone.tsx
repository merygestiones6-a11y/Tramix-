'use client'

import { FileText, FolderOpen } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'

export function Dropzone({ onPick, onDropFiles }: { onPick: () => void; onDropFiles: (files: FileList) => void }) {
  const [dragging, setDragging] = useState(false)

  return (
    <div
      onDragOver={(event) => {
        event.preventDefault()
        setDragging(true)
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(event) => {
        event.preventDefault()
        setDragging(false)
        if (event.dataTransfer.files.length) onDropFiles(event.dataTransfer.files)
      }}
      className={cn(
        'glass group relative overflow-hidden rounded-3xl p-1.5 transition-[transform,box-shadow] duration-300',
        dragging && 'scale-[1.01] ring-2 ring-primary/60',
      )}
    >
      <div
        className={cn(
          'relative flex flex-col items-center gap-5 rounded-[1.25rem] border border-dashed border-input px-6 py-10 text-center transition-colors sm:py-14',
          dragging ? 'border-primary bg-accent' : 'group-hover:border-primary/40',
        )}
      >
        <div className="relative">
          <span className="absolute inset-0 rounded-2xl bg-primary/30 blur-xl" aria-hidden="true" />
          <span className="relative flex size-16 items-center justify-center rounded-2xl border border-primary/30 bg-accent text-accent-foreground transition-transform duration-300 group-hover:-translate-y-0.5">
            <FileText className="size-7" aria-hidden="true" />
          </span>
        </div>

        <div className="flex flex-col gap-1.5">
          <h2 className="text-lg font-semibold tracking-tight">Seleccionar archivos</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Selecciona uno o varios PDF
            <span className="hidden sm:inline"> o arrástralos aquí</span>
          </p>
        </div>

        <button
          type="button"
          onClick={onPick}
          className="inline-flex h-13 w-full max-w-xs items-center justify-center gap-2 rounded-xl bg-primary px-6 text-sm font-semibold tracking-wide text-primary-foreground shadow-[0_10px_30px_-10px_var(--color-primary)] transition-[transform,filter] hover:brightness-110 active:scale-[0.98]"
        >
          <FolderOpen className="size-5" aria-hidden="true" />
          SELECCIONAR PDF
        </button>
      </div>
    </div>
  )
}
