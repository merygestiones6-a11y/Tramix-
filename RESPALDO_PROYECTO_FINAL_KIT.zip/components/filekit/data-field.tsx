'use client'

import { Check, TriangleAlert } from 'lucide-react'
import { useId } from 'react'
import { cn } from '@/lib/utils'

interface DataFieldProps {
  label: string
  value: string
  detected: boolean
  missingLabel: string
  placeholder: string
  onChange: (value: string) => void
  mono?: boolean
  inputMode?: 'text' | 'numeric'
  maxLength?: number
  hint?: string
  /** Warning label shown instead of "Detectado" when the value needs review. */
  status?: string
  children?: React.ReactNode
  className?: string
}

export function DataField({
  label,
  value,
  detected,
  missingLabel,
  placeholder,
  onChange,
  mono,
  inputMode = 'text',
  maxLength,
  hint,
  status,
  children,
  className,
}: DataFieldProps) {
  const id = useId()

  return (
    <div className={cn('flex flex-col gap-2', className)}>
      <div className="flex items-center justify-between gap-2">
        <label htmlFor={id} className="text-xs font-semibold tracking-[0.14em] text-muted-foreground">
          {label}
        </label>
        {detected && status ? (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-warning">
            <TriangleAlert className="size-3.5" aria-hidden="true" />
            {status}
          </span>
        ) : detected ? (
          <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
            <Check className="size-3.5" aria-hidden="true" />
            Detectado
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-warning">
            <TriangleAlert className="size-3.5" aria-hidden="true" />
            {missingLabel}
          </span>
        )}
      </div>
      <input
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        inputMode={inputMode}
        maxLength={maxLength}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="characters"
        spellCheck={false}
        aria-describedby={hint ? `${id}-hint` : undefined}
        className={cn('field-input uppercase', mono && 'font-mono tracking-wider', !detected && !value && 'border-warning/40')}
      />
      {hint ? (
        <p id={`${id}-hint`} className="text-xs text-warning">
          {hint}
        </p>
      ) : null}
      {children}
    </div>
  )
}
