'use client'

import { Check, PencilLine, TriangleAlert } from 'lucide-react'
import { useId } from 'react'
import { type CrossField, type Demographics, STATE_OPTIONS, isBirthDateFormatValid, stateLabel } from '@/lib/extract'
import { cn } from '@/lib/utils'

export interface DemographicsOverrides {
  birthDate: string | null
  sex: string | null
  /** CURP state code */
  state: string | null
}

interface DemographicsFieldsProps {
  cross: Demographics
  overrides: DemographicsOverrides
  onOverride: (field: keyof DemographicsOverrides, value: string | null) => void
}

export function resolveDemographics(cross: Demographics, overrides: DemographicsOverrides) {
  return {
    birthDate: overrides.birthDate ?? cross.birthDate.value ?? '',
    sex: overrides.sex ?? cross.sex.value ?? '',
    state: overrides.state ?? cross.state.value ?? '',
  }
}

const SEX_OPTIONS = ['HOMBRE', 'MUJER', 'NO BINARIO']

function StatusBadge({ field, edited }: { field: CrossField; edited: boolean }) {
  if (edited) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground">
        <PencilLine className="size-3.5" aria-hidden="true" />
        Editado
      </span>
    )
  }
  if (field.source === 'conflict') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-warning">
        <TriangleAlert className="size-3.5" aria-hidden="true" />
        CONFLICTO
      </span>
    )
  }
  if (field.source === 'both') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
        <Check className="size-3.5" aria-hidden="true" />
        CURP y documento coinciden
      </span>
    )
  }
  const label = { curp: 'Según la CURP', document: 'Según el documento', none: 'No identificado' }[field.source]
  return <span className="text-xs font-medium text-muted-foreground">{label}</span>
}

interface RowProps {
  label: string
  field: CrossField
  edited: boolean
  conflictUnresolved: boolean
  formatOption?: (value: string) => string
  onPick: (value: string) => void
  children: (id: string) => React.ReactNode
}

function Row({ label, field, edited, conflictUnresolved, formatOption = (v) => v, onPick, children }: RowProps) {
  const id = useId()
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-2">
        <label htmlFor={id} className="text-xs font-semibold tracking-[0.14em] text-muted-foreground">
          {label}
        </label>
        <StatusBadge field={field} edited={edited} />
      </div>
      {children(id)}
      {conflictUnresolved ? (
        <div className="flex flex-col gap-2 rounded-xl border border-dashed border-warning/40 p-3">
          <p className="text-xs text-muted-foreground">
            La CURP y el documento no coinciden. Elige el correcto o escríbelo.
          </p>
          <div className="flex flex-wrap gap-2">
            {field.options.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => onPick(option)}
                className="rounded-full border border-border bg-muted px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-primary/50"
              >
                {formatOption(option)}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  )
}

export function DemographicsFields({ cross, overrides, onOverride }: DemographicsFieldsProps) {
  const values = resolveDemographics(cross, overrides)
  const dateHint =
    values.birthDate && !isBirthDateFormatValid(values.birthDate) ? 'Usa el formato DD/MM/AAAA.' : undefined
  const unresolved = (key: keyof DemographicsOverrides) => cross[key].source === 'conflict' && overrides[key] === null

  return (
    <div className="flex flex-col gap-5">
      <Row
        label="FECHA DE NACIMIENTO"
        field={cross.birthDate}
        edited={overrides.birthDate !== null}
        conflictUnresolved={unresolved('birthDate')}
        onPick={(value) => onOverride('birthDate', value)}
      >
        {(id) => (
          <>
            <input
              id={id}
              value={values.birthDate}
              onChange={(event) => onOverride('birthDate', event.target.value)}
              placeholder="DD/MM/AAAA"
              inputMode="numeric"
              maxLength={10}
              autoComplete="off"
              aria-describedby={dateHint ? `${id}-hint` : undefined}
              className={cn('field-input font-mono tracking-wider', unresolved('birthDate') && 'border-warning/40')}
            />
            {dateHint ? (
              <p id={`${id}-hint`} className="text-xs text-warning">
                {dateHint}
              </p>
            ) : null}
          </>
        )}
      </Row>

      <div className="grid gap-5 sm:grid-cols-2">
        <Row
          label="SEXO"
          field={cross.sex}
          edited={overrides.sex !== null}
          conflictUnresolved={unresolved('sex')}
          onPick={(value) => onOverride('sex', value)}
        >
          {(id) => (
            <select
              id={id}
              value={values.sex}
              onChange={(event) => onOverride('sex', event.target.value)}
              className={cn('field-input', unresolved('sex') && 'border-warning/40')}
            >
              <option value="">Sin indicar</option>
              {SEX_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          )}
        </Row>

        <Row
          label="ENTIDAD"
          field={cross.state}
          edited={overrides.state !== null}
          conflictUnresolved={unresolved('state')}
          formatOption={stateLabel}
          onPick={(value) => onOverride('state', value)}
        >
          {(id) => (
            <select
              id={id}
              value={values.state}
              onChange={(event) => onOverride('state', event.target.value)}
              className={cn('field-input', unresolved('state') && 'border-warning/40')}
            >
              <option value="">Sin indicar</option>
              {STATE_OPTIONS.map((option) => (
                <option key={option.code} value={option.code}>
                  {option.label}
                </option>
              ))}
            </select>
          )}
        </Row>
      </div>
    </div>
  )
}
