'use client'

import { Check, ChevronDown, TriangleAlert } from 'lucide-react'
import { useId } from 'react'
import { PROCEDURE_RULES } from '@/lib/procedures'

export const CUSTOM_PROCEDURE = 'custom'

interface ProcedureFieldProps {
  value: string
  customValue: string
  detected: boolean
  onChange: (value: string) => void
  onCustomChange: (value: string) => void
}

export function ProcedureField({ value, customValue, detected, onChange, onCustomChange }: ProcedureFieldProps) {
  const id = useId()
  const rule = PROCEDURE_RULES.find((item) => item.id === value)

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-2">
        <label htmlFor={id} className="text-xs font-semibold tracking-[0.14em] text-muted-foreground">
          {detected ? 'TRÁMITE DETECTADO' : 'TRÁMITE'}
        </label>
        {detected ? (
          <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
            <Check className="size-3.5" aria-hidden="true" />
            Automático
          </span>
        ) : null}
      </div>

      {!detected ? (
        <p className="flex items-center gap-1.5 text-xs font-semibold text-warning">
          <TriangleAlert className="size-3.5 shrink-0" aria-hidden="true" />
          TRÁMITE NO IDENTIFICADO · selecciónalo abajo
        </p>
      ) : null}

      <div className="relative">
        <select
          id={id}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="field-input appearance-none pr-24 font-medium"
        >
          {!value ? <option value="">Selecciona un trámite…</option> : null}
          {PROCEDURE_RULES.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
          <option value={CUSTOM_PROCEDURE}>Otro…</option>
        </select>
        <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center gap-2">
          {rule ? (
            <span className="rounded-md border border-primary/30 bg-accent px-1.5 py-0.5 font-mono text-xs font-semibold text-accent-foreground">
              {rule.prefix}
            </span>
          ) : null}
          <ChevronDown className="size-4 text-muted-foreground" aria-hidden="true" />
        </span>
      </div>

      {value === CUSTOM_PROCEDURE ? (
        <input
          value={customValue}
          onChange={(event) => onCustomChange(event.target.value)}
          placeholder="Escribe el tipo de trámite (ej. ACTA)"
          aria-label="Tipo de trámite personalizado"
          autoComplete="off"
          autoCapitalize="characters"
          className="field-input animate-rise uppercase"
        />
      ) : null}
    </div>
  )
}
