import { EmptyStorageButton } from './empty-storage-button'
import { LogoMark } from './logo-mark'
import { ThemeToggle } from './theme-toggle'

export function AppHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/60 backdrop-blur-2xl backdrop-saturate-150">
      <div className="mx-auto flex h-14 w-full max-w-5xl items-center justify-between gap-3 px-4 sm:px-6">
        <a href="/" className="flex items-center gap-2.5 rounded-lg" aria-label="IMSS DIRECT, inicio">
          <LogoMark className="size-8" />
          <span className="text-base font-semibold tracking-wide">IMSS DIRECT</span>
        </a>
        <div className="flex items-center gap-2">
          <EmptyStorageButton />
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
