'use client'

import { Check, Copy, Download, FileText, Inbox, RefreshCw, Trash2, TriangleAlert, X } from 'lucide-react'
import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { readAndroidDocument } from '@/lib/imss-android'
import { AccessError, accessFetch } from '@/lib/outlook/client'
import { nssCanReceive, nssReceive, nssShowPortal, nssTakeEvents } from '@/lib/validar-nss'
import { usePoll } from '@/lib/outlook/use-poll'
import { cn } from '@/lib/utils'

function receivedTime(iso: string) {
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return null
  const parts = new Intl.DateTimeFormat('es-MX', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: 'America/Mexico_City',
  }).formatToParts(date)
  const hour = parts.find((p) => p.type === 'hour')?.value ?? ''
  const minute = parts.find((p) => p.type === 'minute')?.value ?? ''
  const pm = Number(new Intl.DateTimeFormat('en-US', { hour: 'numeric', hourCycle: 'h23', timeZone: 'America/Mexico_City' }).format(date)) >= 12
  return `${hour}:${minute} ${pm ? 'P. M.' : 'A. M.'}`
}

export type ReceivedDocument = {
  id: string
  name: string
  receivedAt: string
}

/** Each new IMSS e-mail link is opened once, one at a time, without pressing ABRIR ENLACE — panel open or closed. */
function useAutoOpen(documents: ReceiverResponse['items'], mutate: () => Promise<unknown>) {
  // Re-check whenever a link finishes, so the next pending e-mail opens right away.
  const [tick, setTick] = useState(0)
  useEffect(() => linkRunner.subscribe(() => setTick((t) => t + 1)), [])
  useEffect(() => {
    if (!nssCanReceive() || linkRunner.busy()) return
    const next = documents.find((doc) => doc.status === 'abrir' && doc.link && !linkRunner.attempted(doc.id))
    if (next?.link) void linkRunner.run(next.id, next.link, () => void mutate(), true)
  }, [documents, mutate, tick])
}

export function DocumentReceiverTile({ tileClassName, iconClassName }: { tileClassName: string; iconClassName: string }) {
  const [open, setOpen] = useState(false)
  // While the panel is closed, keep checking in the background; the open panel runs its own faster loop.
  const background = usePoll(open ? null : '/api/receiver', scanReceiver, { refreshInterval: 60_000 })
  useAutoOpen(open ? [] : (background.data?.items ?? []), background.mutate)

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        className={cn(
          tileClassName,
          'glass text-foreground hover:shadow-lg',
        )}
      >
        <span className={cn(iconClassName, 'border border-imss/25 bg-imss-soft text-imss-soft-foreground')}>
          <Inbox className="size-8 sm:size-9" aria-hidden="true" />
        </span>
        <span className="text-base font-semibold tracking-wide text-balance sm:text-xl">RECEPTOR DE DOCUMENTOS</span>
      </button>

      {open ? <DocumentReceiverPanel onClose={() => setOpen(false)} /> : null}
    </>
  )
}

type ReceiverResponse = {
  received: number
  items: (ReceivedDocument & {
    status: 'listo' | 'sin_datos' | 'enlace' | 'abrir' | 'mensaje' | 'accion'
    link?: string
    message?: string
    account?: string
    panelId?: string
    attendedAt?: string
  })[]
  note?: string
  deleted?: string[]
}

const STATUS_LABEL = {
  listo: 'EN DESCARGAR',
  sin_datos: 'EN DESCARGAR · REVISAR DATOS',
  enlace: 'ENLACE ABIERTO · DOCUMENTOS ENVIADOS A DESCARGAR',
  abrir: 'CORREO IMSS RECIBIDO · ABRIENDO ENLACE AUTOMÁTICAMENTE...',
  mensaje: 'MENSAJE RECIBIDO · REQUIERE INTERVENCIÓN MANUAL',
  accion: 'INTERVENCIÓN MANUAL REQUERIDA',
} as const

type LinkPhase = 'idle' | 'opening' | 'reading' | 'manual' | 'saving'

const LINK_LABEL: Record<LinkPhase, string> = {
  idle: 'ABRIR ENLACE',
  opening: 'ABRIENDO ENLACE...',
  reading: 'LEYENDO LA PÁGINA...',
  manual: 'INTERVENCIÓN MANUAL REQUERIDA · VER PÁGINA',
  saving: 'UNIENDO DOCUMENTOS Y ENVIANDO A DESCARGAR...',
}

/** All documents announced and none new for this long: the page is done. */
const SETTLE_MS = 800
/** Documents arrived but the page never said how many: wait this long for any further one. */
const IDLE_MS = 20_000
/**
 * A page that shows nothing for this long is closed and reopened on the next poll (no expiry).
 * While the user completes a CAPTCHA/verification there is no limit at all.
 */
const REOPEN_AFTER_MS = 2 * 60_000
const ATTEMPTED_KEY = 'receptor:auto-abiertos'

function SenderLine({ address }: { address?: string }) {
  const [copied, setCopied] = useState(false)
  if (!address) {
    return <span className="text-[11px] tracking-wide text-muted-foreground">DE: CORREO NO IDENTIFICADO</span>
  }
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(address)
    } catch {
      const field = document.createElement('textarea')
      field.value = address
      document.body.appendChild(field)
      field.select()
      document.execCommand('copy')
      field.remove()
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <span className="flex min-w-0 items-center gap-1 text-[11px] tracking-wide text-muted-foreground">
      <span className="truncate">{`DE: ${address}`}</span>
      <button
        type="button"
        onClick={copy}
        aria-label={copied ? 'Correo copiado' : `Copiar ${address}`}
        className="inline-flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      >
        {copied ? <Check className="size-3.5 text-primary" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
      </button>
    </span>
  )
}

type ReceiverDoc = ReceiverResponse['items'][number]
type CardView = 'esperando' | 'siguiente' | 'atencion' | null

/**
 * A link card without PDF is not a failure: the trámite may continue in a later e-mail
 * (same CURP, merged on the server). Only after ~3 min with nothing newer it needs attention.
 */
function cardView(doc: ReceiverDoc, documents: ReceiverDoc[], now: number): CardView {
  if (doc.status !== 'abrir' && doc.status !== 'mensaje' && doc.status !== 'accion') return null
  const at = new Date(doc.receivedAt).getTime()
  if (documents.some((other) => other.id !== doc.id && new Date(other.receivedAt).getTime() > at)) return 'siguiente'
  // The page answered with an error, block or verification instead of the PDFs.
  if (doc.status !== 'abrir') return 'atencion'
  // No time limit: keep waiting until the documents or another e-mail arrive.
  void now
  return 'esperando'
}

const VIEW_LABEL: Record<Exclude<CardView, null>, string> = {
  esperando: 'ENLACE ABIERTO · ESPERANDO DOCUMENTOS U OTRO CORREO...',
  siguiente: 'CONTINÚA EN EL SIGUIENTE CORREO',
  atencion: 'REQUIERE ATENCIÓN',
}

function useNow(intervalMs: number) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), intervalMs)
    return () => clearInterval(timer)
  }, [intervalMs])
  return now
}

/**
 * One shared link runner for the whole page: the automatic flow and the ABRIR ENLACE button use it,
 * and only one IMSS page is open at a time.
 */
const linkRunner = (() => {
  const phases = new Map<string, LinkPhase>()
  const listeners = new Set<() => void>()
  let active: string | null = null
  let attempted: Set<string> | null = null

  const notify = () => listeners.forEach((listener) => listener())
  const setPhase = (id: string, phase: LinkPhase) => {
    if (phase === 'idle') phases.delete(id)
    else phases.set(id, phase)
    notify()
  }

  function attemptedSet() {
    if (attempted) return attempted
    try {
      attempted = new Set(JSON.parse(sessionStorage.getItem(ATTEMPTED_KEY) || '[]') as string[])
    } catch {
      attempted = new Set()
    }
    return attempted
  }
  function markAttempted(id: string) {
    const set = attemptedSet()
    set.add(id)
    try {
      sessionStorage.setItem(ATTEMPTED_KEY, JSON.stringify([...set].slice(-200)))
    } catch {}
  }

  async function postMessage(itemId: string, message: string, manual: boolean) {
    await accessFetch('/api/receiver/link-message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemId, message, manual }),
    }).catch(() => null)
  }

  async function postDocuments(itemId: string, ids: string[]) {
    const form = new FormData()
    form.set('itemId', itemId)
    ids.forEach((docId, i) => {
      const bytes = readAndroidDocument(docId)
      if (bytes) form.append('file', new Blob([bytes as BlobPart], { type: 'application/pdf' }), `documento-imss-${i + 1}.pdf`)
    })
    if (!form.getAll('file').length) return false
    const res = await accessFetch('/api/receiver/link-document', { method: 'POST', body: form }).catch(() => null)
    return Boolean(res?.ok)
  }

  /** Open the exact e-mail link in the app's IMSS view; read, download, join and send to DESCARGAR. */
  async function run(id: string, link: string, onUpdate: () => void, auto = false) {
    if (active === id) {
      // Already running: show the page (e.g. to complete a verification).
      nssShowPortal(true)
      return
    }
    if (active) return
    if (!nssCanReceive()) {
      if (!auto) window.open(link, '_blank', 'noopener,noreferrer')
      return
    }
    markAttempted(id)
    if (!nssReceive(link)) {
      await postMessage(id, 'La app no pudo abrir el enlace del correo.', false)
      notify()
      onUpdate()
      return
    }
    active = id
    setPhase(id, 'opening')
    nssTakeEvents()

    const docIds: string[] = []
    let expected = 0
    let lastDocAt = 0
    let manual = false
    let deadline = Date.now() + REOPEN_AFTER_MS
    let result: 'documents' | 'message' | 'none' = 'none'
    let message = ''

    while (manual || docIds.length > 0 || Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 300))
      for (const event of nssTakeEvents()) {
        if (event.status === 'loading' && !manual) setPhase(id, 'reading')
        else if (event.status === 'manual') {
          if (!manual) {
            manual = true
            setPhase(id, 'manual')
            nssShowPortal(true)
            await postMessage(id, event.detail.message || 'El portal pide una verificación manual.', true)
            onUpdate()
          }
        } else if (event.status === 'resumed') {
          manual = false
          setPhase(id, 'reading')
          deadline = Date.now() + REOPEN_AFTER_MS
        } else if (event.status === 'documents') {
          manual = false
          setPhase(id, 'reading')
          expected = Math.max(expected, event.detail.count ?? 0)
        } else if (event.status === 'document') {
          if (!docIds.includes(event.detail.id)) docIds.push(event.detail.id)
          lastDocAt = Date.now()
        } else if (event.status === 'page_message' && !docIds.length) {
          result = 'message'
          message = event.detail.message || 'La página no mostró documentos.'
        }
      }
      if (result === 'message') break
      if (docIds.length) {
        const quiet = Date.now() - lastDocAt
        if ((expected && docIds.length >= expected && quiet > SETTLE_MS) || quiet > IDLE_MS) {
          result = 'documents'
          break
        }
      }
    }

    if (result === 'documents') {
      setPhase(id, 'saving')
      await postDocuments(id, docIds)
    } else if (result === 'message') {
      await postMessage(id, message, false)
    } else {
      // Nothing yet (slow portal): not a failure. Let the automatic flow open it again.
      attemptedSet().delete(id)
    }
    nssShowPortal(false)
    active = null
    setPhase(id, 'idle')
    onUpdate()
  }

  return {
    run,
    phase: (id: string) => phases.get(id) ?? 'idle',
    busy: () => active !== null,
    attempted: (id: string) => attemptedSet().has(id),
    subscribe(listener: () => void) {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },
  }
})()

function OpenLinkButton({ itemId, link, onUpdate }: { itemId: string; link: string; onUpdate: () => void }) {
  const [phase, setPhase] = useState<LinkPhase>(() => linkRunner.phase(itemId))
  useEffect(() => linkRunner.subscribe(() => setPhase(linkRunner.phase(itemId))), [itemId])
  const working = phase !== 'idle' && phase !== 'manual'
  const inApp = nssCanReceive()
  // In the app the link opens by itself: only progress is shown, and a button only to view a verification.
  if (inApp && phase === 'idle') return null
  if (inApp && working) {
    return (
      <span className="mt-1 text-xs font-semibold tracking-wide text-primary" aria-live="polite">
        {LINK_LABEL[phase]}
      </span>
    )
  }
  return (
    <button
      type="button"
      disabled={working}
      onClick={() => void linkRunner.run(itemId, link, onUpdate)}
      className={cn(
        'mt-1 flex h-9 items-center justify-center rounded-xl border px-3 text-xs font-semibold tracking-wide transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-70',
        phase === 'manual'
          ? 'border-primary bg-primary text-primary-foreground'
          : 'border-primary/40 bg-background text-primary hover:bg-accent',
      )}
    >
      {LINK_LABEL[phase]}
    </button>
  )
}

async function scanReceiver(url: string): Promise<ReceiverResponse> {
  const res = await accessFetch(url, { method: 'POST' })
  if (!res.ok) throw new Error(`receiver-${res.status}`)
  return res.json()
}

/** Reads the stored list only (no Outlook scan): fast, so new cards show up almost immediately. */
async function readReceiverState(): Promise<ReceiverResponse> {
  const res = await accessFetch('/api/receiver', { cache: 'no-store' })
  if (!res.ok) throw new Error(`receiver-${res.status}`)
  return res.json()
}

const DONE_STATUS = new Set(['listo', 'sin_datos'])

/**
 * Joins a newer response into what the panel already shows. A card missing from one response
 * (stale read) stays; only cards deleted on the server leave. A delivered PDF never goes back.
 */
function mergeReceiver(prev: ReceiverResponse | undefined, next: ReceiverResponse): ReceiverResponse {
  if (!prev) return next
  const deleted = new Set(next.deleted ?? [])
  const previous = new Map(prev.items.map((item) => [item.id, item]))
  const items = next.items.map((item) => {
    const old = previous.get(item.id)
    if (!old) return item
    if (DONE_STATUS.has(old.status) && !DONE_STATUS.has(item.status)) return { ...item, ...old }
    return old.attendedAt && !item.attendedAt ? { ...item, attendedAt: old.attendedAt } : item
  })
  const present = new Set(items.map((item) => item.id))
  for (const old of prev.items) if (!present.has(old.id) && !deleted.has(old.id)) items.push(old)
  items.sort((a, b) => new Date(b.receivedAt).getTime() - new Date(a.receivedAt).getTime())
  return {
    ...next,
    items,
    received: items.filter((item) => DONE_STATUS.has(item.status)).length,
  }
}

const promptedDocs = new Set<string>()

function isSavable(doc: ReceiverDoc) {
  return (doc.status === 'listo' || doc.status === 'sin_datos') && Boolean(doc.panelId)
}

function useNewDocumentPrompt(documents: ReceiverDoc[], loaded: boolean) {
  const seeded = useRef(false)
  const [queue, setQueue] = useState<ReceiverDoc[]>([])

  useEffect(() => {
    if (!loaded) return
    const fresh = documents.filter((doc) => isSavable(doc) && !promptedDocs.has(doc.id))
    fresh.forEach((doc) => promptedDocs.add(doc.id))
    // Documents already present when the panel opens are not new arrivals.
    if (!seeded.current) {
      seeded.current = true
      return
    }
    if (fresh.length) setQueue((current) => [...current, ...fresh])
  }, [documents, loaded])

  const current = queue.find((doc) => documents.some((d) => d.id === doc.id)) ?? null
  const dismiss = () => setQueue((items) => items.filter((doc) => doc.id !== current?.id))
  return { current, dismiss }
}

function NewDocumentPrompt({ doc, onDismiss }: { doc: ReceiverDoc; onDismiss: () => void }) {
  return (
    <div
      role="alertdialog"
      aria-labelledby="nuevo-doc-title"
      aria-describedby="nuevo-doc-name"
      className="flex flex-col gap-3 rounded-2xl border border-primary/40 bg-primary/10 px-4 py-3"
    >
      <p id="nuevo-doc-title" className="text-xs font-semibold leading-relaxed">
        NUEVO DOCUMENTO RECIBIDO. ¿DESEAS GUARDAR EL ARCHIVO EN ESTE DISPOSITIVO?
      </p>
      <p id="nuevo-doc-name" className="flex min-w-0 items-center gap-2 text-xs text-muted-foreground">
        <FileText className="size-4 shrink-0 text-destructive" aria-hidden="true" />
        <span className="truncate">{doc.name}</span>
      </p>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={onDismiss}
          className="h-9 flex-1 rounded-xl border border-border bg-card text-xs font-semibold tracking-wide focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          AHORA NO
        </button>
        <a
          href={`/api/panel/files/${encodeURIComponent(doc.panelId ?? '')}`}
          download={doc.name}
          onClick={onDismiss}
          className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-xl bg-primary text-xs font-semibold tracking-wide text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Download className="size-4" aria-hidden="true" />
          GUARDAR
        </a>
      </div>
    </div>
  )
}

function DocumentReceiverPanel({ onClose }: { onClose: () => void }) {
  const [locked, setLocked] = useState(false)
  const [data, setData] = useState<ReceiverResponse>()
  const apply = (next: ReceiverResponse) => {
    setLocked(false)
    setData((prev) => mergeReceiver(prev, next))
    return next
  }
  const onError = (error: unknown) => setLocked(error instanceof AccessError)
  // Fast read of the shared list, so cards appear right away and stay in sync with every device.
  const { mutate } = usePoll('/api/receiver#estado', async () => apply(await readReceiverState()), {
    refreshInterval: 3_000,
    onError,
  })
  // The Outlook scan keeps its own unchanged cadence; its result is merged in the same way.
  usePoll('/api/receiver', async (url) => apply(await scanReceiver(url)), { refreshInterval: 15_000, onError })
  const [confirming, setConfirming] = useState<string[] | null>(null)
  const [hidden, setHidden] = useState<Set<string>>(() => new Set())
  const [deleteError, setDeleteError] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [refreshError, setRefreshError] = useState(false)
  const documents = (data?.items ?? []).filter((doc) => !hidden.has(doc.id))
  const received = data?.received ?? 0
  const closeRef = useRef<HTMLButtonElement>(null)
  const now = useNow(15_000)

  async function refreshNow() {
    if (refreshing) return
    setRefreshing(true)
    setRefreshError(false)
    try {
      apply(await scanReceiver('/api/receiver?force=1'))
    } catch (error) {
      onError(error)
      setRefreshError(!(error instanceof AccessError))
    } finally {
      setRefreshing(false)
    }
  }

  async function deleteCards(ids: string[]) {
    setConfirming(null)
    setDeleteError(false)
    setHidden((current) => new Set([...current, ...ids]))
    try {
      const res = await accessFetch('/api/receiver', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids }),
      })
      if (!res.ok) throw new Error(`receiver-delete-${res.status}`)
      await mutate()
    } catch {
      setHidden((current) => new Set([...current].filter((id) => !ids.includes(id))))
      setDeleteError(true)
    }
  }

  useAutoOpen(documents, mutate)
  const newDoc = useNewDocumentPrompt(documents, Boolean(data))

  useEffect(() => {
    closeRef.current?.focus()
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/30 p-3 backdrop-blur-sm sm:items-center">
      <button type="button" aria-label="Cerrar" tabIndex={-1} onClick={onClose} className="absolute inset-0 cursor-default" />
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="receptor-title"
        className="glass relative flex w-full max-w-md flex-col gap-5 rounded-3xl p-5 text-foreground shadow-xl"
      >
        <header className="flex items-center justify-between gap-3">
          <h2 id="receptor-title" className="text-base font-semibold tracking-wide">
            RECEPTOR DE DOCUMENTOS
          </h2>
          <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void refreshNow()}
            disabled={refreshing}
            aria-label="Actualizar receptor"
            aria-busy={refreshing}
            title="Actualizar receptor"
            className="flex h-9 items-center justify-center gap-1.5 rounded-full border border-border bg-card px-3 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
          >
            <RefreshCw className={cn('size-4', refreshing && 'animate-spin')} aria-hidden="true" />
            <span className="hidden text-[11px] font-semibold tracking-wide sm:inline">ACTUALIZAR RECEPTOR</span>
          </button>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Cerrar panel"
            className="flex size-9 items-center justify-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
          </div>
        </header>

        {newDoc.current ? <NewDocumentPrompt doc={newDoc.current} onDismiss={newDoc.dismiss} /> : null}

        {confirming ? (
          <div
            role="alertdialog"
            aria-label="Confirmar eliminación"
            className="flex flex-col gap-3 rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3"
          >
            <p className="text-xs font-semibold leading-relaxed">
              {confirming.length === 1
                ? '¿ELIMINAR ESTE MENSAJE DEL RECEPTOR?'
                : `¿ELIMINAR ${confirming.length} MENSAJES DEL RECEPTOR?`}
              <span className="block font-normal text-muted-foreground">
                Los correos de Outlook y los PDF en DESCARGAR se conservan.
              </span>
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirming(null)}
                className="h-9 flex-1 rounded-xl border border-border bg-card text-xs font-semibold tracking-wide focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                CANCELAR
              </button>
              <button
                type="button"
                onClick={() => void deleteCards(confirming)}
                className="h-9 flex-1 rounded-xl bg-destructive text-xs font-semibold tracking-wide text-destructive-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                ELIMINAR
              </button>
            </div>
          </div>
        ) : null}
        {deleteError ? (
          <p role="alert" className="text-xs font-semibold text-destructive">
            No se pudo eliminar. Intenta de nuevo.
          </p>
        ) : null}
        {refreshError ? (
          <p role="alert" className="text-xs font-semibold text-destructive">
            No se pudo actualizar el receptor. Intenta de nuevo.
          </p>
        ) : null}

        <div className="flex items-center justify-between rounded-2xl border border-border bg-card px-4 py-3">
          <span className="text-xs font-semibold tracking-wide text-muted-foreground">DOCUMENTOS RECIBIDOS:</span>
          <span className="text-lg font-semibold tabular-nums" aria-live="polite">
            {received}
          </span>
        </div>

        {locked || data?.note ? (
          <p className="rounded-2xl border border-border bg-card px-4 py-3 text-xs leading-relaxed text-muted-foreground">
            {locked ? 'Ingresa tu clave de acceso en ' : `${data?.note} Vincula una en `}
            <Link href="/cuentas-outlook" className="font-semibold text-primary underline underline-offset-2">
              CUENTAS OUTLOOK
            </Link>
            .
          </p>
        ) : null}

        {documents.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-primary/30 px-4 py-10 text-center">
            <Inbox className="size-8 animate-pulse text-primary" aria-hidden="true" />
            <p className="text-sm font-semibold tracking-wide text-muted-foreground">ESPERANDO DOCUMENTOS...</p>
          </div>
        ) : (
          <ul className="flex max-h-72 flex-col gap-2 overflow-y-auto">
            {documents.map((doc) => {
              const view = cardView(doc, documents, now)
              const pending = Boolean(doc.link) && !doc.attendedAt
              return (
              <li
                key={doc.id}
                className={cn(
                  'flex flex-col gap-1 rounded-2xl border px-4 py-3',
                  pending ? 'border-warning bg-warning/15' : 'border-border bg-card',
                )}
              >
                {pending ? (
                  <span className="self-start rounded-full bg-warning px-2 py-0.5 text-[10px] font-bold tracking-wide text-warning-foreground">
                    PENDIENTE
                  </span>
                ) : null}
                <span className="flex min-w-0 items-center gap-2">
                  {doc.status === 'listo' || doc.status === 'sin_datos' ? (
                    <FileText className="size-4 shrink-0 text-destructive" aria-hidden="true" />
                  ) : null}
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{doc.name}</span>
                  {(doc.status === 'listo' || doc.status === 'sin_datos') && doc.panelId ? (
                    <a
                      href={`/api/panel/files/${encodeURIComponent(doc.panelId)}`}
                      download={doc.name}
                      aria-label={`Descargar ${doc.name}`}
                      title="Descargar PDF"
                      className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <Download className="size-4" aria-hidden="true" />
                    </a>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => setConfirming([doc.id])}
                    aria-label={`Eliminar ${doc.name}`}
                    title="Eliminar mensaje"
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                  </button>
                </span>
                <span
                  className={cn(
                    'flex items-center gap-1.5 text-xs font-semibold tracking-wide',
                    doc.status === 'listo' || view === 'atencion' ? 'text-primary' : 'text-muted-foreground',
                  )}
                >
                  {view === 'atencion' ? <TriangleAlert className="size-4 shrink-0" aria-hidden="true" /> : null}
                  {view ? VIEW_LABEL[view] : STATUS_LABEL[doc.status]}
                </span>
                {receivedTime(doc.receivedAt) ? (
                  <time dateTime={doc.receivedAt} className="text-[11px] tracking-wide text-muted-foreground">
                    {`RECIBIDO: ${receivedTime(doc.receivedAt)}`}
                  </time>
                ) : null}
                <SenderLine address={doc.account} />
                {(doc.status === 'accion' || doc.status === 'mensaje') && doc.message ? (
                  <p className="rounded-xl bg-accent px-3 py-2 text-xs leading-relaxed text-accent-foreground">{doc.message}</p>
                ) : null}
                {doc.link && (doc.status === 'abrir' || doc.status === 'mensaje' || doc.status === 'enlace' || doc.status === 'accion') ? (
                  <OpenLinkButton itemId={doc.id} link={doc.link} onUpdate={() => mutate()} />
                ) : null}
              </li>
              )
            })}
          </ul>
        )}

        {documents.length ? (
          <Link
            href="/panel"
            className="flex h-11 items-center justify-center rounded-2xl bg-primary text-sm font-semibold tracking-wide text-primary-foreground transition-[filter] hover:brightness-110"
          >
            ABRIR DESCARGAR
          </Link>
        ) : null}
      </section>
    </div>
  )
}
