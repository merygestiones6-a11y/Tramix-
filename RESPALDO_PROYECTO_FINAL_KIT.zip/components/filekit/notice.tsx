import { TriangleAlert, X } from 'lucide-react'
import type { ReactNode } from 'react'

export function Notice({ children, onDismiss }: { children: ReactNode; onDismiss?: () => void }) {
  return (
    <div
      role="alert"
      className="flex animate-rise items-start gap-3 rounded-2xl border border-warning/30 bg-warning/10 p-3.5 text-sm text-foreground"
    >
      <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden="true" />
      <div className="flex min-w-0 flex-1 flex-col gap-0.5 leading-relaxed">{children}</div>
      {onDismiss ? (
        <button
          type="button"
          onClick={onDismiss}
          className="-m-1 rounded-md p-1 text-muted-foreground hover:text-foreground"
          aria-label="Cerrar aviso"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      ) : null}
    </div>
  )
}
