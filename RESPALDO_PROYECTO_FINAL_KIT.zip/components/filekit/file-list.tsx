'use client'

import {
  closestCenter,
  DndContext,
  KeyboardSensor,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core'
import { restrictToVerticalAxis } from '@dnd-kit/modifiers'
import { SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable'
import { Plus, ScanSearch, Link2 } from 'lucide-react'
import type { QueuedFile } from '@/hooks/use-file-queue'
import { FileRow } from './file-row'

interface FileListProps {
  items: QueuedFile[]
  disabled: boolean
  onRemove: (id: string) => void
  onMove: (from: number, to: number) => void
  onAddMore: () => void
  onClear: () => void
}

export function FileList({ items, disabled, onRemove, onMove, onAddMore, onClear }: FileListProps) {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 120, tolerance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  )

  const handleDragEnd = ({ active, over }: DragEndEvent) => {
    if (!over || active.id === over.id) return
    const from = items.findIndex((item) => item.id === active.id)
    const to = items.findIndex((item) => item.id === over.id)
    onMove(from, to)
  }

  const multiple = items.length > 1

  return (
    <section aria-labelledby="files-heading" className="glass flex animate-rise flex-col gap-4 rounded-3xl p-4 sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-baseline gap-2">
          <h2 id="files-heading" className="text-xs font-semibold tracking-[0.14em] text-muted-foreground">
            ARCHIVOS SELECCIONADOS
          </h2>
          <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-semibold text-accent-foreground">
            {items.length} {items.length === 1 ? 'archivo' : 'archivos'}
          </span>
        </div>
        <button
          type="button"
          onClick={onClear}
          disabled={disabled}
          className="rounded-md px-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
        >
          Quitar todos
        </button>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        modifiers={[restrictToVerticalAxis]}
        onDragEnd={handleDragEnd}
      >
        <SortableContext items={items.map((item) => item.id)} strategy={verticalListSortingStrategy}>
          <ol className="flex flex-col gap-2">
            {items.map((item, index) => (
              <FileRow
                key={item.id}
                item={item}
                index={index}
                total={items.length}
                disabled={disabled}
                onRemove={() => onRemove(item.id)}
                onMoveUp={() => onMove(index, index - 1)}
                onMoveDown={() => onMove(index, index + 1)}
              />
            ))}
          </ol>
        </SortableContext>
      </DndContext>

      {multiple ? (
        <p className="text-xs leading-relaxed text-muted-foreground">
          Se unen automáticamente en este orden. Si los reordenas, el PDF se vuelve a generar.
        </p>
      ) : null}

      <div className="flex flex-col gap-2 sm:flex-row">
        <button
          type="button"
          onClick={onAddMore}
          disabled={disabled}
          className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-border bg-muted px-4 text-sm font-medium transition-colors hover:border-primary/40 hover:bg-accent disabled:opacity-50 sm:flex-1"
        >
          <Plus className="size-4" aria-hidden="true" />
          Agregar más archivos
        </button>
      </div>
    </section>
  )
}
