import { Layers } from 'lucide-react'
import { cn } from '@/lib/utils'

export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        'relative inline-flex items-center justify-center rounded-[30%] bg-imss text-imss-foreground shadow-[0_0_0_1px_oklch(1_0_0/0.12)_inset,0_6px_20px_-6px_var(--color-imss)]',
        className,
      )}
    >
      <Layers className="size-[55%]" strokeWidth={2.25} />
    </span>
  )
}
