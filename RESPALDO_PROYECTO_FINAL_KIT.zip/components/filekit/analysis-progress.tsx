import { Check, FileText } from 'lucide-react'
import type { AnalysisProgress as Progress, AnalysisStage } from '@/lib/pipeline/analyze'
import { cn } from '@/lib/utils'

type Step = 'merging' | 'analyzing' | 'extracting' | 'generating'

const STEP_OF: Record<AnalysisStage, Step> = {
  merging: 'merging',
  reading: 'analyzing',
  extracting: 'extracting',
  ocr: 'extracting',
  detecting: 'extracting',
  generating: 'generating',
}

const HEADLINE: Record<Step, string> = {
  merging: 'UNIENDO DOCUMENTOS…',
  analyzing: 'ANALIZANDO DOCUMENTO…',
  extracting: 'EXTRAYENDO DATOS…',
  generating: 'GENERANDO ARCHIVO…',
}

function stepsFor(merging: boolean): { key: Step; label: string }[] {
  return [
    ...(merging ? [{ key: 'merging' as const, label: 'Unir' }] : []),
    { key: 'analyzing', label: 'Analizar' },
    { key: 'extracting', label: 'Extraer datos' },
    { key: 'generating', label: 'Generar' },
  ]
}

export function AnalysisProgress({ progress, merging }: { progress: Progress; merging: boolean }) {
  const percent = Math.round(Math.min(progress.value, 1) * 100)
  const steps = stepsFor(merging)
  const currentStep = STEP_OF[progress.stage]
  const current = steps.findIndex((step) => step.key === currentStep)
  const headline = !merging && currentStep === 'merging' ? HEADLINE.analyzing : HEADLINE[currentStep]

  return (
    <section aria-live="polite" aria-busy="true" className="glass flex animate-rise flex-col gap-5 rounded-3xl p-5">
      <div className="flex items-center gap-4">
        <div className="relative flex size-12 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-primary/30 bg-accent text-accent-foreground">
          <FileText className="size-6" aria-hidden="true" />
          <span className="absolute inset-x-1.5 top-2 h-0.5 animate-scan rounded-full bg-primary shadow-[0_0_12px_var(--color-primary)]" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <p className="text-sm font-semibold tracking-wide">{headline}</p>
          <p className="truncate text-sm text-muted-foreground">{progress.detail}</p>
        </div>
        <span className="font-mono text-sm tabular-nums text-accent-foreground">{percent}%</span>
      </div>

      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
        aria-label="Progreso del análisis"
        className="relative h-1.5 overflow-hidden rounded-full bg-secondary"
      >
        <div
          className="relative h-full overflow-hidden rounded-full bg-primary transition-[width] duration-500 ease-out"
          style={{ width: `${Math.max(percent, 3)}%` }}
        >
          <span className="absolute inset-y-0 w-1/2 animate-shimmer bg-gradient-to-r from-transparent via-primary-foreground/40 to-transparent" />
        </div>
      </div>

      <ol className="flex flex-wrap gap-2">
        {steps.map((step, index) => {
          const done = index < current
          const active = index === current
          return (
            <li
              key={step.key}
              className={cn(
                'inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-xs font-medium transition-colors',
                done && 'border-success/30 bg-success/10 text-success',
                active && 'border-primary/40 bg-accent text-accent-foreground',
                !done && !active && 'border-border text-muted-foreground',
              )}
            >
              {done ? <Check className="size-3" aria-hidden="true" /> : null}
              {step.key === 'extracting' && progress.stage === 'ocr' ? 'OCR' : step.label}
            </li>
          )
        })}
      </ol>
    </section>
  )
}
