'use client'

import { useRef, useState } from 'react'
import { flushSync } from 'react-dom'
import { AlertTriangle, ArrowLeft, Check, Copy, Download, ExternalLink, FileText, Loader2, MapPin, RotateCcw, Upload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { CARD, Errors, useCopyFeedback } from '@/components/identity-lab/shared'
import { ACCEPT_ATTR } from '@/lib/identity-lab/doc-extract/limits'
import { ERROR_MESSAGE, type ErrorCode } from '@/lib/identity-lab/doc-extract/modes'
import { inspectFile, readDocument } from '@/lib/identity-lab/doc-extract/read-files'
import { streetLine, type BuroRecord } from '@/lib/buro/schema'
import { cn } from '@/lib/utils'

function setFolioInUrl(folio: string | null) {
  const url = new URL(window.location.href)
  if (folio) url.searchParams.set('folio', folio)
  else url.searchParams.delete('folio')
  window.history.replaceState(window.history.state, '', url)
}

export function BuroCredito({ initial, onExit }: { initial: BuroRecord | null; onExit: () => void }) {
  const [record, setRecord] = useState<BuroRecord | null>(initial)
  const [label, setLabel] = useState<string | null>(null)
  const [errors, setErrors] = useState<string[]>([])
  const busy = useRef(false)
  const input = useRef<HTMLInputElement>(null)

  async function process(file: File) {
    if (busy.current) return
    busy.current = true
    setErrors([])
    const t0 = performance.now()
    try {
      setLabel('Validando archivo')
      const check = await inspectFile(file)
      if ('error' in check) return setErrors([check.error])
      if (check.kind !== 'image' && check.kind !== 'pdf') return setErrors(['Sube una foto (JPG, PNG o WEBP) o un PDF de la credencial.'])
      setLabel('Leyendo credencial')
      const read = await readDocument(file, check.kind, (_, l) => setLabel(l), AbortSignal.timeout(60_000))
      if (!read.images.length && !read.segments.some((s) => s.text.trim())) {
        return setErrors([ERROR_MESSAGE[read.errorCode ?? 'ILEGIBLE']])
      }
      setLabel('Extrayendo datos y ubicando en Google Maps')
      const res = await fetch('/api/buro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ segments: read.segments, images: read.images }),
        signal: AbortSignal.timeout(75_000),
      })
      const data = (await res.json().catch(() => ({}))) as { record?: BuroRecord; error?: string; code?: string; requestId?: string }
      console.info(`[buro] id=${data.requestId ?? '-'} http=${res.status} total=${Math.round(performance.now() - t0)}ms${data.code ? ` codigo=${data.code}` : ''}`)
      if (!res.ok || !data.record) {
        return setErrors([`${data.error ?? ERROR_MESSAGE[(data.code as ErrorCode) ?? 'PROVEEDOR'] ?? 'Error del servidor.'}${data.requestId ? ` (solicitud ${data.requestId})` : ''}`])
      }
      setFolioInUrl(data.record.folio)
      setRecord(data.record)
    } catch (error) {
      const timeout = error instanceof DOMException && error.name === 'TimeoutError'
      setErrors([timeout ? ERROR_MESSAGE.TIEMPO : ERROR_MESSAGE.RED])
    } finally {
      busy.current = false
      setLabel(null)
      if (input.current) input.current.value = ''
    }
  }

  function another() {
    setFolioInUrl(null)
    setRecord(null)
    setErrors([])
  }

  function exit() {
    setFolioInUrl(null)
    onExit()
  }

  if (record) return <Preview record={record} onAnother={another} onExit={exit} />

  return (
    <section className={CARD} aria-labelledby="buro-title">
      <div className="flex items-center justify-between gap-2">
        <h2 id="buro-title" className="text-sm font-semibold tracking-wide text-foreground">
          BURÓ DE CRÉDITO
        </h2>
        <BackButton onClick={exit} />
      </div>
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border bg-card/50 p-5 text-center">
        {label ? <Loader2 className="size-6 animate-spin text-imss" aria-hidden="true" /> : <Upload className="size-6 text-imss" aria-hidden="true" />}
        <p className="text-sm leading-relaxed text-muted-foreground text-pretty" aria-live="polite">
          {label ?? 'Sube el frente de la credencial para votar del cliente (foto o PDF). Se extraen nombre, domicilio, código postal y RFC.'}
        </p>
        <Button type="button" variant="outline" className="rounded-full" disabled={Boolean(label)} onClick={() => input.current?.click()}>
          <FileText className="size-4" aria-hidden="true" />
          SUBIR CREDENCIAL
        </Button>
        <input
          ref={input}
          type="file"
          accept={ACCEPT_ATTR}
          className="sr-only"
          tabIndex={-1}
          aria-label="Subir credencial para votar"
          onChange={(e) => e.target.files?.[0] && process(e.target.files[0])}
        />
      </div>
      <p className="text-xs leading-relaxed text-muted-foreground">
        La credencial se lee con Vercel AI Gateway (modelo de Google) y la dirección se ubica con Google Maps. Los datos extraídos se guardan con el folio para poder volver a mostrarlos.
      </p>
      <Errors errors={errors} />
    </section>
  )
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1 rounded-lg text-xs text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <ArrowLeft className="size-3.5" aria-hidden="true" />
      Volver al extractor
    </button>
  )
}

type CaptureMap = { kind: 'image'; src: string; caption?: string } | { kind: 'none' }

type MapPrecision = 'EXACTA' | 'CALLE' | 'CODIGO_POSTAL' | 'MUNICIPIO'
interface MapLocation {
  lat: number
  lng: number
  zoom: number
  precision: MapPrecision
  source: 'google' | 'osm'
  googleImage: boolean
}

function precisionCaption(loc: MapLocation, cp: string | undefined, provider: 'google' | 'osm') {
  const where =
    loc.precision === 'EXACTA'
      ? 'Ubicación encontrada'
      : loc.precision === 'CALLE'
        ? 'Ubicación aproximada a nivel de calle'
        : loc.precision === 'CODIGO_POSTAL'
          ? `Ubicación aproximada: zona del código postal ${cp ?? ''}`.trim()
          : 'Ubicación aproximada: zona del municipio'
  const credit = provider === 'osm' ? ' · Mapa © colaboradores de OpenStreetMap' : ''
  return `${where}${credit}`
}

const loadTile = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('tile'))
    img.src = src
  })

/** Draws OpenStreetMap tiles (CORS-enabled) and the marker onto a canvas, so the PNG capture can include it. */
async function drawOsmMap(loc: MapLocation): Promise<string> {
  const W = 1024
  const H = 480
  const T = 256
  const n = 2 ** loc.zoom
  const rad = (loc.lat * Math.PI) / 180
  const left = ((loc.lng + 180) / 360) * n * T - W / 2
  const top = ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * n * T - H / 2

  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('canvas')
  ctx.fillStyle = '#e5e7eb'
  ctx.fillRect(0, 0, W, H)

  const jobs: Promise<void>[] = []
  for (let tx = Math.floor(left / T); tx <= Math.floor((left + W - 1) / T); tx++) {
    for (let ty = Math.floor(top / T); ty <= Math.floor((top + H - 1) / T); ty++) {
      if (ty < 0 || ty >= n) continue
      const wx = ((tx % n) + n) % n
      jobs.push(loadTile(`https://tile.openstreetmap.org/${loc.zoom}/${wx}/${ty}.png`).then((img) => ctx.drawImage(img, Math.round(tx * T - left), Math.round(ty * T - top))))
    }
  }
  await Promise.all(jobs)

  const x = W / 2
  const y = H / 2
  if (loc.precision === 'CODIGO_POSTAL' || loc.precision === 'MUNICIPIO') {
    ctx.beginPath()
    ctx.arc(x, y, 110, 0, Math.PI * 2)
    ctx.fillStyle = 'rgba(220,38,38,0.12)'
    ctx.fill()
    ctx.setLineDash([10, 8])
    ctx.lineWidth = 3
    ctx.strokeStyle = 'rgba(220,38,38,0.7)'
    ctx.stroke()
    ctx.setLineDash([])
  }
  ctx.beginPath()
  ctx.moveTo(x, y)
  ctx.bezierCurveTo(x - 8, y - 18, x - 22, y - 30, x - 22, y - 46)
  ctx.arc(x, y - 46, 22, Math.PI, 0)
  ctx.bezierCurveTo(x + 22, y - 30, x + 8, y - 18, x, y)
  ctx.closePath()
  ctx.fillStyle = '#dc2626'
  ctx.fill()
  ctx.lineWidth = 3
  ctx.strokeStyle = '#ffffff'
  ctx.stroke()
  ctx.beginPath()
  ctx.arc(x, y - 46, 8, 0, Math.PI * 2)
  ctx.fillStyle = '#ffffff'
  ctx.fill()

  return canvas.toDataURL('image/png')
}

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result))
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(blob)
  })
}

const LABEL = 'text-[10px] tracking-widest text-muted-foreground'

function CopyIcon({ label, value, copyKey, copied, onCopy }: { label: string; value: string; copyKey: string; copied: string | null; onCopy: (key: string, text: string) => void }) {
  const done = copied === copyKey
  return (
    <button
      type="button"
      data-capture-exclude=""
      onClick={() => onCopy(copyKey, value)}
      aria-label={done ? `${label} copiado` : `Copiar ${label.toLowerCase()}`}
      className="inline-flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-imss focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {done ? <Check className="size-3.5 text-success" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
    </button>
  )
}

/** One labeled value. undefined = not stored (older folio); '' = not found on the credential. */
function Datum({
  label,
  value,
  copyKey,
  copied,
  onCopy,
  className,
  valueClassName,
}: {
  label: string
  value: string | undefined
  copyKey: string
  copied: string | null
  onCopy: (key: string, text: string) => void
  className?: string
  valueClassName?: string
}) {
  const shown = value === undefined ? 'NO DISPONIBLE' : value || 'NO ENCONTRADO'
  return (
    <div className={cn('flex min-w-0 flex-col', className)}>
      <div className="flex min-h-6 items-center justify-between gap-1">
        <span className={LABEL}>{label}</span>
        {value ? <CopyIcon label={label} value={value} copyKey={copyKey} copied={copied} onCopy={onCopy} /> : null}
      </div>
      <p className={cn('break-words text-sm leading-snug', value ? 'text-foreground' : 'text-muted-foreground', valueClassName)}>{shown}</p>
    </div>
  )
}

function Preview({ record, onAnother, onExit }: { record: BuroRecord; onAnother: () => void; onExit: () => void }) {
  const sheet = useRef<HTMLElement>(null)
  const [capture, setCapture] = useState<CaptureMap | null>(null)
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState<string | null>(null)
  const { copied, failed, copy } = useCopyFeedback()

  const place = record.geo.place
  const mapQuery = place ? `${place.lat},${place.lng}` : record.geo.query
  const embed = `https://maps.google.com/maps?q=${encodeURIComponent(mapQuery)}&z=16&hl=es&output=embed`
  const openUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapQuery)}`
  const fecha = new Date(record.createdAt).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'America/Mexico_City' })
  const domicilio = record.domicilio ? record.domicilio.replace(/ \| /g, ', ') : ''
  const d = { copied, onCopy: copy }

  async function downloadPng() {
    const node = sheet.current
    if (saving || !node) return
    setSaving(true)
    setSaveMsg(null)
    const t0 = performance.now()
    let note: string | null = null
    let mapKind: CaptureMap['kind'] = 'none'
    try {
      const base = `/api/buro/mapa?folio=${encodeURIComponent(record.folio)}`
      const res = await fetch(base, { signal: AbortSignal.timeout(15_000) }).catch(() => null)
      let map: CaptureMap = { kind: 'none' }
      if (res?.ok) {
        const loc = (await res.json()) as MapLocation
        if (loc.googleImage) {
          const img = await fetch(`${base}&formato=imagen`, { signal: AbortSignal.timeout(15_000) }).catch(() => null)
          if (img?.ok) map = { kind: 'image', src: await blobToDataUrl(await img.blob()), caption: precisionCaption(loc, record.codigoPostal, 'google') }
        }
        if (map.kind === 'none') {
          const src = await drawOsmMap(loc).catch(() => null)
          if (src) map = { kind: 'image', src, caption: precisionCaption(loc, record.codigoPostal, 'osm') }
        }
        if (map.kind === 'none') note = 'Descargado sin el mapa: el servicio de mapas no devolvió la imagen. Intenta de nuevo.'
      } else {
        const code = res ? ((await res.json().catch(() => ({}))) as { code?: string }).code : 'RED'
        note =
          code === 'SIN_UBICACION'
            ? 'Descargado sin el mapa: no se encontró ni una ubicación aproximada para este domicilio.'
            : 'Descargado sin el mapa: no se pudo obtener la ubicación. Intenta de nuevo.'
      }
      mapKind = map.kind
      flushSync(() => setCapture(map))
      await Promise.all([...node.querySelectorAll('img')].map((img) => img.decode().catch(() => undefined)))

      const { toPng } = await import('html-to-image')
      const bg = getComputedStyle(document.body).backgroundColor || getComputedStyle(document.documentElement).backgroundColor
      const url = await toPng(node, {
        pixelRatio: 3,
        backgroundColor: bg,
        width: node.offsetWidth,
        height: node.scrollHeight,
        filter: (n) => !(n instanceof HTMLElement && (n.dataset.captureExclude !== undefined || n.tagName === 'IFRAME')),
      })
      const a = document.createElement('a')
      a.href = url
      a.download = `${record.folio}.png`
      a.click()
      setSaveMsg(note ?? 'Comprobante descargado.')
      console.info(`[buro] etapa=png mapa=${mapKind} total=${Math.round(performance.now() - t0)}ms`)
    } catch {
      console.error(`[buro] etapa=png codigo=GENERAR mapa=${mapKind}`)
      setSaveMsg('No se pudo generar la imagen. Intenta de nuevo.')
    } finally {
      setCapture(null)
      setSaving(false)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <article ref={sheet} aria-labelledby="buro-preview-title" className="glass flex flex-col gap-3 rounded-3xl p-4">
        <header className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 flex-col">
            <p className="text-[11px] font-semibold tracking-widest text-imss">BURÓ DE CRÉDITO</p>
            <h2 id="buro-preview-title" className="text-xs text-muted-foreground">
              Comprobante de trámite · {fecha}
            </h2>
          </div>
          <div className="flex shrink-0 flex-col items-end">
            <span className="flex items-center gap-0.5">
              <span className={LABEL}>FOLIO</span>
              <CopyIcon label="Folio" value={record.folio} copyKey="folio" {...d} />
            </span>
            <span className="font-mono text-sm font-semibold text-foreground">{record.folio}</span>
          </div>
        </header>

        <p role="status" className="w-fit rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs font-semibold tracking-wide text-warning">
          {'🟡 TRÁMITE EN PROCESO'}
        </p>

        <Datum
          label="NOMBRE COMPLETO"
          value={record.nombreCompleto}
          copyKey="nombreCompleto"
          valueClassName="text-lg font-semibold leading-tight text-balance"
          {...d}
        />
        <div className="grid grid-cols-3 gap-x-3">
          <Datum label="NOMBRE(S)" value={record.nombre} copyKey="nombre" {...d} />
          <Datum label="PRIMER APELLIDO" value={record.primerApellido} copyKey="primerApellido" {...d} />
          <Datum label="SEGUNDO APELLIDO" value={record.segundoApellido} copyKey="segundoApellido" {...d} />
        </div>

        <Datum label="DIRECCIÓN ORIGINAL (CREDENCIAL)" value={domicilio} copyKey="domicilio" {...d} />
        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
          <Datum label="CALLE Y NÚMERO" value={streetLine(record)} copyKey="calle" {...d} />
          <Datum label="COLONIA O POBLACIÓN" value={record.colonia} copyKey="colonia" {...d} />
          <Datum label="MUNICIPIO O DELEGACIÓN" value={record.municipio} copyKey="municipio" {...d} />
          <Datum label="CIUDAD" value={record.ciudad} copyKey="ciudad" {...d} />
          <Datum label="ESTADO" value={record.entidad} copyKey="entidad" {...d} />
          <Datum label="CÓDIGO POSTAL" value={record.codigoPostal} copyKey="cp" valueClassName="font-mono font-semibold" {...d} />
        </div>

        <Datum label="RFC" value={record.rfc.value ?? ''} copyKey="rfc" valueClassName="font-mono font-semibold" {...d} />

        <div className="overflow-hidden rounded-2xl border border-border">
          {capture?.kind === 'image' ? (
            // eslint-disable-next-line @next/next/no-img-element -- data URL used only for the PNG capture
            <img src={capture.src} alt="Mapa de la ubicación" className="block h-auto w-full" />
          ) : capture?.kind === 'none' ? null : (
            <iframe
              title="Ubicación en Google Maps"
              src={embed}
              className="block h-28 w-full sm:h-56"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          )}
          <div className="flex items-start gap-1.5 bg-card/60 px-3 py-2">
            <MapPin className="mt-0.5 size-3.5 shrink-0 text-imss" aria-hidden="true" />
            <p className="text-xs leading-snug text-muted-foreground">
              {capture?.kind === 'image' && capture.caption
                ? capture.caption
                : place
                  ? place.formatted
                  : domicilio || record.geo.query}
            </p>
          </div>
        </div>

        {record.warnings.length ? (
          <ul className="flex flex-col gap-1 rounded-2xl border border-warning/40 bg-warning/10 p-2.5">
            {record.warnings.map((w) => (
              <li key={w} className="flex items-start gap-1.5 text-xs leading-snug text-warning">
                <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
                {w}
              </li>
            ))}
          </ul>
        ) : null}
      </article>

      <div className="flex flex-wrap gap-2">
        <Button type="button" className="rounded-full bg-imss text-imss-foreground hover:bg-imss/90" disabled={saving} onClick={downloadPng}>
          {saving ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Download className="size-4" aria-hidden="true" />}
          {saving ? 'GENERANDO IMAGEN' : 'DESCARGAR COMPROBANTE'}
        </Button>
        <Button type="button" variant="outline" className="rounded-full" onClick={onAnother}>
          <RotateCcw className="size-4" aria-hidden="true" />
          PROCESAR OTRA CREDENCIAL
        </Button>
        <a
          href={openUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-9 items-center gap-2 rounded-full border border-border bg-card px-4 text-sm font-medium text-foreground hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <ExternalLink className="size-4" aria-hidden="true" />
          ABRIR EN GOOGLE MAPS
        </a>
        <BackButton onClick={onExit} />
      </div>
      <p className="text-xs text-muted-foreground" aria-live="polite">
        {failed ? 'No se pudo copiar. Mantén presionado el dato para copiarlo.' : saveMsg}
      </p>
    </div>
  )
}

