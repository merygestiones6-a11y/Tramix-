'use client'

import { Check, CircleAlert, CircleCheck, Copy, Link2, Loader2, Trash2 } from 'lucide-react'
import { useSearchParams } from 'next/navigation'
import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { AccessError, accessFetch, accessJson, navigateTop } from '@/lib/outlook/client'
import { usePoll } from '@/lib/outlook/use-poll'
import { cn } from '@/lib/utils'

interface LinkedAccount {
  id: string
  address: string
  status: 'ok' | 'reconnect'
  lastCheckAt?: string
  lastError?: string
  used?: boolean
}

const OUTCOME: Record<string, string> = {
  ok: 'Cuenta Outlook vinculada. IMSS DIRECT ya puede leer los correos del IMSS.',
  error: 'No se pudo vincular la cuenta. Vuelve a intentarlo.',
}

const REASON: Record<string, string> = {
  config: 'Falta configurar MICROSOFT_CLIENT_ID y MICROSOFT_CLIENT_SECRET en el servidor.',
  denied: 'Cancelaste la autorización en Microsoft.',
  state: 'La sesión de vinculación expiró o se abrió en otro navegador. Vuelve a pulsar VINCULAR CON MICROSOFT.',
  offline: 'Microsoft no entregó acceso permanente. Vuelve a intentarlo y acepta todos los permisos.',
  address: 'La cuenta de Microsoft no tiene un correo asociado.',
  exchange: 'Microsoft rechazó el código de autorización.',
  microsoft: 'Microsoft rechazó la solicitud de inicio de sesión.',
}

const CODE_HINT: Record<string, string> = {
  invalid_client: 'El secreto de cliente es incorrecto o expiró. Usa el campo "Valor" del secreto, no su ID.',
  unauthorized_client: 'La app de Microsoft no admite cuentas personales. Elige "Cualquier directorio y cuentas personales de Microsoft".',
  invalid_request: 'El URI de redirección no coincide con el registrado en Microsoft (plataforma "Web").',
  invalid_grant: 'El código ya se usó o expiró. Vuelve a vincular.',
}

function errorMessage(reason: string | null, code: string | null) {
  const base = (reason && REASON[reason]) || OUTCOME.error
  const hint = code ? CODE_HINT[code] : undefined
  return [base, hint, code ? `Código: ${code}` : null].filter(Boolean).join(' ')
}

function when(iso?: string) {
  if (!iso) return 'sin revisar'
  return new Date(iso).toLocaleString('es-MX', { dateStyle: 'short', timeStyle: 'short' })
}

/** Outlook accounts linked through Microsoft sign-in (read-only mail access). */
export function LinkedOutlook({ onLocked }: { onLocked: () => void }) {
  const params = useSearchParams()
  const outcome = params.get('outlook')
  const [connecting, setConnecting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const copyTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const handleError = (err: unknown) => {
    if (err instanceof AccessError) onLocked()
  }
  const accounts = usePoll(
    '/api/imss-mail/accounts',
    (url) => accessJson<{ accounts: LinkedAccount[]; signInReady: boolean }>(url),
    { refreshInterval: 30_000, onError: handleError },
  )

  async function connect() {
    setConnecting(true)
    setError(null)
    try {
      const res = await accessFetch('/api/outlook/connect', { method: 'POST' })
      if (!res.ok) throw new Error(String(res.status))
      const { url } = (await res.json()) as { url: string }
      navigateTop(url)
    } catch (err) {
      if (err instanceof AccessError) onLocked()
      else setError('No se pudo abrir el inicio de sesión de Microsoft.')
    } finally {
      setConnecting(false)
    }
  }

  async function copyAddress(id: string, address: string) {
    let copied = false
    try {
      await navigator.clipboard.writeText(address)
      copied = true
    } catch {
      // Android WebView may block the async Clipboard API; fall back to a hidden textarea.
      const field = document.createElement('textarea')
      field.value = address
      field.setAttribute('readonly', '')
      field.style.position = 'fixed'
      field.style.opacity = '0'
      document.body.appendChild(field)
      field.select()
      copied = document.execCommand('copy')
      field.remove()
    }
    if (!copied) return
    setCopiedId(id)
    if (copyTimer.current) clearTimeout(copyTimer.current)
    copyTimer.current = setTimeout(() => setCopiedId(null), 1800)
  }

  async function unlink(id: string) {
    try {
      await accessFetch(`/api/imss-mail/accounts/${id}`, { method: 'DELETE' })
      await accounts.mutate()
    } catch (err) {
      handleError(err)
    }
  }

  const list = accounts.data?.accounts ?? []
  const ready = accounts.data?.signInReady ?? false
  const usedCount = list.filter((account) => account.used).length

  return (
    <>
      <section aria-labelledby="linked-title" className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
        <div className="flex flex-col gap-1">
          {accounts.data ? (
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              CUENTAS AGREGADAS: {list.length}
              <span className="text-destructive">{' · USADAS: '}{usedCount}</span>
              {' · DISPONIBLES: '}
              {list.length - usedCount}
            </p>
          ) : null}
          <h2 id="linked-title" className="flex items-center gap-2 font-semibold">
            <Link2 className="size-4" aria-hidden="true" />
            Lectura de correos del IMSS
          </h2>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            Inicia sesión con Microsoft para que IMSS DIRECT lea los correos del IMSS y guarde los PDF en DESCARGAR. No se
            guarda ninguna contraseña.
          </p>
        </div>

        {outcome && OUTCOME[outcome] ? (
          <p role="status" className={cn('text-sm', outcome === 'ok' ? 'text-success' : 'text-destructive')}>
              {outcome === 'ok' ? OUTCOME.ok : errorMessage(params.get('reason'), params.get('code'))}
          </p>
        ) : null}

        {list.length ? (
          <ul className="flex flex-col gap-2">
            {list.map((account) => (
              <li
                key={account.id}
                className={cn(
                  'flex items-center gap-3 rounded-2xl border p-3',
                  account.used ? 'border-destructive bg-destructive/10' : 'border-border bg-card',
                )}
              >
                {account.status === 'ok' ? (
                  <CircleCheck className="size-4 shrink-0 text-success" aria-hidden="true" />
                ) : (
                  <CircleAlert className="size-4 shrink-0 text-destructive" aria-hidden="true" />
                )}
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className={cn('truncate text-sm font-semibold', account.used && 'text-destructive')}>
                    {account.address}
                    {account.used ? <span className="sr-only"> (ya utilizada)</span> : null}
                  </span>
                  <span
                    role={copiedId === account.id ? 'status' : undefined}
                    className={cn(
                      'text-xs',
                      copiedId === account.id ? 'font-semibold text-success' : 'text-muted-foreground',
                    )}
                  >
                    {copiedId === account.id
                      ? 'CORREO COPIADO'
                      : account.status === 'ok'
                      ? `Leyendo correos · última revisión ${when(account.lastCheckAt)}`
                      : 'Acceso vencido: vuelve a vincularla'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyAddress(account.id, account.address)}
                  aria-label={`Copiar ${account.address}`}
                  title="Copiar correo"
                  className={cn(
                    'flex size-9 shrink-0 items-center justify-center rounded-lg hover:bg-accent',
                    copiedId === account.id ? 'text-success' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {copiedId === account.id ? (
                    <Check className="size-4" aria-hidden="true" />
                  ) : (
                    <Copy className="size-4" aria-hidden="true" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => unlink(account.id)}
                  aria-label={`Desvincular ${account.address}`}
                  className="flex size-9 shrink-0 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-destructive"
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                </button>
              </li>
            ))}
          </ul>
        ) : accounts.data ? (
          <p className="text-sm text-muted-foreground">Aún no hay cuentas vinculadas.</p>
        ) : null}

        {error ? (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        ) : null}

        <Button
          type="button"
          size="lg"
          onClick={connect}
          disabled={connecting || !ready}
          className="h-12 rounded-xl text-sm font-semibold tracking-wide"
        >
          {connecting ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Link2 className="size-4" aria-hidden="true" />}
          VINCULAR CON MICROSOFT
        </Button>
        {accounts.data && !ready ? (
          <p className="text-xs leading-relaxed text-muted-foreground">
            El inicio de sesión de Microsoft aún no está habilitado en este servidor.
          </p>
        ) : null}
      </section>
    </>
  )
}
