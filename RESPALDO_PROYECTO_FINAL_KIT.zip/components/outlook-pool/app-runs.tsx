'use client'

import { AlertTriangle, Check, Hand, Loader2, RotateCw, Trash2 } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ACTIVE_RUN, canIntervene, outlookApp, runSteps, type AppRun } from '@/lib/outlook-app'
import { cn } from '@/lib/utils'

const STATUS_TEXT: Record<AppRun['status'], string> = {
  running: 'EN CURSO',
  manual: 'REQUIERE INTERVENCIÓN',
  uploading: 'ENVIANDO A DESCARGAR',
  done: 'COMPLETADO',
  error: 'REQUIERE INTERVENCIÓN',
  cancelled: 'CANCELADO',
}

const dateTime = new Intl.DateTimeFormat('es-MX', { dateStyle: 'short', timeStyle: 'short' })

function needsHelp(run: AppRun) {
  return run.status === 'manual' || run.status === 'error'
}

function StatusPill({ run }: { run: AppRun }) {
  return (
    <span
      className={cn(
        'shrink-0 rounded-full px-2 py-0.5 text-xs font-semibold',
        run.status === 'done' && 'bg-accent text-accent-foreground',
        needsHelp(run) && 'bg-destructive/10 text-destructive',
        (run.status === 'running' || run.status === 'uploading' || run.status === 'cancelled') && 'bg-muted text-muted-foreground',
      )}
    >
      {STATUS_TEXT[run.status]}
    </span>
  )
}

export function AppRunCard({ run }: { run: AppRun }) {
  const now = Date.now()
  const steps = runSteps(run)
  const reached = new Set(run.reached ?? [])
  const active = ACTIVE_RUN.has(run.status)
  const firstPending = steps.findIndex((s) => !reached.has(s.key))
  const expected = Math.max(run.expected ?? 0, 0)
  const got = run.docs.length
  const minutesLeft = run.holdUntil ? Math.max(0, Math.ceil((run.holdUntil - now) / 60_000)) : 0

  return (
    <li className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-3">
      <div className="flex items-start justify-between gap-2">
        <dl className="grid min-w-0 grid-cols-[auto_1fr] gap-x-2 gap-y-0.5 text-xs">
          <dt className="text-muted-foreground">IDENTIFICADOR</dt>
          <dd className="truncate font-mono text-sm font-semibold">{run.curp}</dd>
          <dt className="text-muted-foreground">CORREO</dt>
          <dd className="truncate">{run.email}</dd>
          <dt className="text-muted-foreground">FECHA / HORA</dt>
          <dd>{dateTime.format(run.startedAt)}</dd>
        </dl>
        <StatusPill run={run} />
      </div>

      <ol className="flex flex-col gap-1.5" aria-label="Progreso del trámite">
        {steps.map((step, index) => {
          const done = run.status === 'done' || reached.has(step.key)
          const here = !done && index === firstPending
          const label = step.key === 'pdf' && expected > 0 ? `${step.label} (${Math.min(got, expected)}/${expected})` : step.label
          return (
            <li key={step.key} className="flex items-center gap-2 text-sm">
              <span
                className={cn(
                  'flex size-5 shrink-0 items-center justify-center rounded-full border',
                  done ? 'border-primary bg-primary text-primary-foreground' : 'border-border',
                  here && needsHelp(run) && 'border-destructive text-destructive',
                )}
                aria-hidden="true"
              >
                {done ? (
                  <Check className="size-3" />
                ) : here && needsHelp(run) ? (
                  <AlertTriangle className="size-3" />
                ) : here && active ? (
                  <Loader2 className="size-3 animate-spin" />
                ) : null}
              </span>
              <span className={cn(done || here ? 'text-foreground' : 'text-muted-foreground')}>{label}</span>
            </li>
          )
        })}
        {!run.path && active && (
          <li className="pl-7 text-xs text-muted-foreground">Al abrir el correo se detecta si trae PDF adjuntos o el enlace del trámite.</li>
        )}
      </ol>

      {run.status === 'done' ? (
        <p role="status" className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Check className="size-4" aria-hidden="true" />
          COMPLETADO · PDF EN DESCARGAR
        </p>
      ) : needsHelp(run) ? (
        <p role="status" className="flex items-start gap-2 text-sm font-semibold leading-relaxed text-destructive">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {run.message || 'REQUIERE INTERVENCIÓN'}
        </p>
      ) : (
        <p role="status" className="text-sm leading-relaxed text-muted-foreground">
          {run.message}
        </p>
      )}

      {canIntervene(run, now) && (
        <div className="flex flex-col gap-2">
          <div className="flex gap-2">
            <Button
              type="button"
              variant={needsHelp(run) ? 'default' : 'outline'}
              className="h-10 flex-1 rounded-xl"
              onClick={() => outlookApp.intervene(run.id)}
            >
              <Hand className="size-4" aria-hidden="true" />
              INTERVENIR
            </Button>
            {run.status !== 'done' && (
              <Button
                type="button"
                variant="outline"
                className="h-10 rounded-xl"
                onClick={() => {
                  outlookApp.retryNext(run.id)
                  window.dispatchEvent(new Event('tramix-android'))
                }}
              >
                <RotateCw className="size-4" aria-hidden="true" />
                REINTENTAR
              </Button>
            )}
          </div>
          {!active && minutesLeft > 0 && (
            <p className="text-xs text-muted-foreground">
              Sesión disponible para intervenir {minutesLeft} min más. Después pasa a la papelera.
            </p>
          )}
        </div>
      )}
    </li>
  )
}

function TrashList({ runs }: { runs: AppRun[] }) {
  const [confirming, setConfirming] = useState(false)
  return (
    <section aria-labelledby="app-trash-title" className="glass flex flex-col gap-3 rounded-3xl p-4 sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <h2 id="app-trash-title" className="font-semibold">
          Papelera <span className="text-sm font-normal text-muted-foreground">({runs.length})</span>
        </h2>
        {confirming ? (
          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" className="rounded-xl" onClick={() => setConfirming(false)}>
              NO
            </Button>
            <Button
              type="button"
              variant="destructive"
              size="sm"
              className="rounded-xl"
              onClick={() => {
                outlookApp.emptyTrash()
                setConfirming(false)
                window.dispatchEvent(new Event('tramix-android'))
              }}
            >
              SÍ, VACIAR
            </Button>
          </div>
        ) : (
          <Button type="button" variant="outline" size="sm" className="rounded-xl" onClick={() => setConfirming(true)}>
            VACIAR PAPELERA
          </Button>
        )}
      </div>
      <p className="text-xs leading-relaxed text-muted-foreground">
        Solo elimina registros de IMSS DIRECT. Los correos de Outlook no se borran.
      </p>
      <ul className="flex flex-col gap-2">
        {runs.map((run) => (
          <li key={run.id} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3">
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <span className="truncate font-mono text-sm font-semibold">{run.curp}</span>
              <span className="truncate text-xs text-muted-foreground">{run.email}</span>
              <span className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                {dateTime.format(run.startedAt)}
                <StatusPill run={run} />
              </span>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="shrink-0 rounded-xl"
              aria-label={`Eliminar registro de ${run.curp}`}
              onClick={() => {
                outlookApp.deleteRun(run.id)
                window.dispatchEvent(new Event('tramix-android'))
              }}
            >
              <Trash2 className="size-4" aria-hidden="true" />
            </Button>
          </li>
        ))}
      </ul>
    </section>
  )
}

export function AppRuns({ runs }: { runs: AppRun[] }) {
  const tracking = runs.filter((r) => !r.trashed)
  const trash = runs.filter((r) => r.trashed)
  if (runs.length === 0) return null
  return (
    <>
      <section aria-labelledby="app-runs-title" className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
        <h2 id="app-runs-title" className="font-semibold">
          Trámites en seguimiento
        </h2>
        {tracking.length === 0 ? (
          <p className="text-sm text-muted-foreground">No hay trámites en seguimiento.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {tracking.map((run) => (
              <AppRunCard key={run.id} run={run} />
            ))}
          </ul>
        )}
      </section>
      {trash.length > 0 && <TrashList runs={trash} />}
    </>
  )
}
