'use client'

import { Activity, Loader2, Lock, LogIn, Mail, Plus, Search, Trash2 } from 'lucide-react'
import { Suspense, useMemo, useState, type FormEvent } from 'react'
import { LinkedOutlook } from '@/components/outlook-pool/linked-outlook'
import { outlookApp, SESSION_LABEL, useOutlookApp, type AppSession } from '@/lib/outlook-app'
import { Button } from '@/components/ui/button'
import { AccessError, accessFetch, accessJson, storeAccessToken } from '@/lib/outlook/client'
import { usePoll } from '@/lib/outlook/use-poll'
import { EMAIL_PATTERN, NEXT_STATUS, normalizeEmail, type PoolAccount, type PoolStatus } from '@/lib/outlook-pool/types'
import { cn } from '@/lib/utils'

type Filter = 'all' | PoolStatus

const FIELD =
  'h-12 w-full rounded-xl border border-input bg-background px-3.5 text-base text-foreground outline-none transition-[border-color,box-shadow] placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30'

const ERRORS: Record<string, string> = {
  'invalid-email': 'Escribe un correo válido.',
  'invalid-secret': 'El campo privado es obligatorio (máx. 512 caracteres).',
  duplicate: 'Ese correo ya está registrado.',
}

export function OutlookAccounts() {
  const [locked, setLocked] = useState(false)

  if (locked) return <AccessGate onUnlocked={() => setLocked(false)} />

  return (
    <Suspense fallback={null}>
      <LinkedOutlook onLocked={() => setLocked(true)} />
    </Suspense>
  )
}

function AccessGate({ onUnlocked }: { onUnlocked: () => void }) {
  const [key, setKey] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError(null)
    const res = await fetch('/api/imss-mail/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key }),
    }).catch(() => null)
    setBusy(false)
    if (!res?.ok) {
      setError('Clave incorrecta.')
      return
    }
    const { token } = (await res.json()) as { token: string }
    storeAccessToken(token)
    onUnlocked()
  }

  return (
    <form onSubmit={submit} className="glass flex flex-col gap-4 rounded-3xl p-5">
      <div className="flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-xl bg-accent text-accent-foreground">
          <Lock className="size-5" aria-hidden="true" />
        </span>
        <div className="flex flex-col">
          <h2 className="font-semibold">Acceso protegido</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">Ingresa la clave del panel.</p>
        </div>
      </div>
      <label htmlFor="pool-access" className="sr-only">
        Clave del panel
      </label>
      <input
        id="pool-access"
        type="password"
        autoComplete="current-password"
        value={key}
        onChange={(e) => setKey(e.target.value)}
        className={FIELD}
        placeholder="Clave de acceso"
      />
      {error && (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      )}
      <Button type="submit" size="lg" className="h-12 rounded-xl" disabled={busy || !key}>
        {busy && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
        ENTRAR
      </Button>
    </form>
  )
}

function AccountsManager({
  accounts,
  reload,
  onLocked,
}: {
  accounts: PoolAccount[] | undefined
  reload: () => Promise<void>
  onLocked: () => void
}) {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [pending, setPending] = useState<string | null>(null)
  const [actionError, setActionError] = useState<string | null>(null)
  const app = useOutlookApp()
  const sessionFor = (email: string) => app.accounts.find((s) => s.email === email.toLowerCase())

  const counts = useMemo(() => {
    const list = accounts ?? []
    return {
      available: list.filter((a) => a.status === 'available').length,
      in_use: list.filter((a) => a.status === 'in_use').length,
    }
  }, [accounts])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return (accounts ?? []).filter((a) => (filter === 'all' || a.status === filter) && (!q || a.email.includes(q)))
  }, [accounts, query, filter])

  async function run(id: string, request: () => Promise<Response>) {
    setPending(id)
    setActionError(null)
    try {
      const res = await request()
      if (!res.ok) throw new Error(String(res.status))
      await reload()
    } catch (error) {
      if (error instanceof AccessError) onLocked()
      else setActionError('No se pudo completar la acción. Intenta de nuevo.')
    } finally {
      setPending(null)
    }
  }

  const setStatus = (account: PoolAccount, status: PoolStatus) =>
    run(account.id, () =>
      accessFetch(`/api/outlook-pool/accounts/${account.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      }),
    )

  const remove = (account: PoolAccount) => {
    if (!window.confirm(`¿Eliminar ${account.email}?`)) return
    outlookApp.remove(account.email)
    void run(account.id, () => accessFetch(`/api/outlook-pool/accounts/${account.id}`, { method: 'DELETE' }))
  }

  const [cleaning, setCleaning] = useState(false)
  const [cleanNote, setCleanNote] = useState<string | null>(null)
  const finishedCount = (accounts ?? []).filter((a) => a.status === 'used').length

  async function cleanup() {
    if (
      !window.confirm(
        '¿Limpiar el apartado? Se eliminarán de forma permanente las cuentas usadas, las reservas abandonadas, las solicitudes terminadas y los trámites finalizados.',
      )
    )
      return
    setCleaning(true)
    setActionError(null)
    setCleanNote(null)
    try {
      const res = await accessFetch('/api/outlook-pool/cleanup', { method: 'POST' })
      if (!res.ok) throw new Error(String(res.status))
      const { emails, watches } = (await res.json()) as { emails: string[]; watches: number }
      emails.forEach((email) => outlookApp.remove(email))
      outlookApp.emptyTrash()
      await reload()
      const total = emails.length + watches
      setCleanNote(total ? `Se eliminaron ${total} registro${total === 1 ? '' : 's'}.` : 'No había nada que limpiar.')
    } catch (error) {
      if (error instanceof AccessError) onLocked()
      else setActionError('No se pudo limpiar el apartado. Intenta de nuevo.')
    } finally {
      setCleaning(false)
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-2 gap-3">
        <Counter label="Disponibles" value={counts.available} tone="available" loading={!accounts} />
        <Counter label="En uso" value={counts.in_use} tone="in_use" loading={!accounts} />
      </div>

      <AddAccountForm onCreated={reload} onLocked={onLocked} />

      {app.ready && !app.inApp && (
        <p className="glass rounded-2xl p-4 text-sm leading-relaxed text-muted-foreground">
          Las sesiones de Outlook (inicio de sesión, prueba y trámites automáticos) viven en la app Android IMSS DIRECT. Abre esta
          pantalla desde la app para usarlas.
        </p>
      )}
      {app.inApp && !app.supported && app.ready && (
        <p role="alert" className="glass rounded-2xl p-4 text-sm leading-relaxed text-destructive">
          Este teléfono no permite sesiones aisladas. Actualiza «Android System WebView» desde Play Store.
        </p>
      )}

      <section aria-labelledby="pool-list-title" className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <h2 id="pool-list-title" className="font-semibold">
            Cuentas
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{accounts ? `${accounts.length} en total` : ''}</span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-9 rounded-xl text-destructive hover:text-destructive"
              onClick={cleanup}
              disabled={cleaning || !accounts}
              aria-label="Limpiar cuentas y solicitudes terminadas"
            >
              {cleaning ? (
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Trash2 className="size-4" aria-hidden="true" />
              )}
              Limpiar{finishedCount ? ` (${finishedCount})` : ''}
            </Button>
          </div>
        </div>
        {cleanNote && (
          <p role="status" className="text-sm text-muted-foreground">
            {cleanNote}
          </p>
        )}

        <div className="relative">
          <Search
            className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <label htmlFor="pool-search" className="sr-only">
            Buscar correo
          </label>
          <input
            id="pool-search"
            type="search"
            inputMode="email"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar correo"
            className={cn(FIELD, 'pl-10')}
          />
        </div>

        <div role="tablist" aria-label="Filtrar por estado" className="grid grid-cols-4 gap-1 rounded-xl bg-muted p-1">
          {(
            [
              ['all', 'Todas'],
              ['available', 'Disponibles'],
              ['in_use', 'En uso'],
              ['used', 'Usadas'],
            ] as const
          ).map(([value, label]) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={filter === value}
              onClick={() => setFilter(value)}
              className={cn(
                'h-9 rounded-lg text-xs font-semibold transition-colors',
                filter === value ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {label}
            </button>
          ))}
        </div>

        {actionError && (
          <p role="alert" className="text-sm text-destructive">
            {actionError}
          </p>
        )}

        {!accounts ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Cargando cuentas…
          </div>
        ) : visible.length === 0 ? (
          <p className="py-10 text-center text-sm leading-relaxed text-muted-foreground">
            {accounts.length === 0 ? 'Aún no hay cuentas. Agrega la primera arriba.' : 'Sin resultados.'}
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {visible.map((account) => (
              <AccountRow
                key={account.id}
                account={account}
                session={app.inApp && app.supported ? (sessionFor(account.email) ?? null) : undefined}
                busy={pending === account.id}
                onAdvance={() => {
                  const next = NEXT_STATUS[account.status]
                  if (!next) return
                  if (next === 'used' && !window.confirm(`¿Marcar ${account.email} como usada? No podrá volver a usarse.`)) return
                  void setStatus(account, next)
                }}
                onDelete={() => remove(account)}
              />
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}

function Counter({
  label,
  value,
  tone,
  loading,
}: {
  label: string
  value: number
  tone: PoolStatus
  loading: boolean
}) {
  return (
    <div
      className={cn(
        'flex flex-col gap-1 rounded-2xl p-4',
        tone === 'available' ? 'bg-primary text-primary-foreground' : 'glass text-foreground',
      )}
    >
      <span
        className={cn(
          'text-xs font-semibold tracking-wide uppercase',
          tone === 'available' ? 'text-primary-foreground/80' : 'text-muted-foreground',
        )}
      >
        {label}
      </span>
      <span className="text-3xl font-semibold tabular-nums" aria-live="polite">
        {loading ? '—' : value}
      </span>
    </div>
  )
}

function AddAccountForm({ onCreated, onLocked }: { onCreated: () => Promise<void>; onLocked: () => void }) {
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState<string | null>(null)

  const normalized = normalizeEmail(email)
  const valid = EMAIL_PATTERN.test(normalized)

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (!valid) return
    setBusy(true)
    setError(null)
    setSaved(null)
    try {
      const res = await accessFetch('/api/outlook-pool/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalized }),
      })
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { error?: string }
        setError(ERRORS[body.error ?? ''] ?? 'No se pudo guardar la cuenta.')
        return
      }
      setSaved(normalized)
      setEmail('')
      if (outlookApp.available()) outlookApp.add(normalized)
      await onCreated()
    } catch (err) {
      if (err instanceof AccessError) onLocked()
      else setError('No se pudo guardar la cuenta.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <form
      onSubmit={submit}
      aria-labelledby="pool-add-title"
      className="glass flex flex-col gap-4 rounded-3xl p-4 sm:p-5"
    >
      <h2 id="pool-add-title" className="flex items-center gap-2 font-semibold">
        <Plus className="size-4" aria-hidden="true" />
        Agregar cuenta
      </h2>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="pool-email" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
          Correo
        </label>
        <div className="relative">
          <Mail
            className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <input
            id="pool-email"
            type="email"
            inputMode="email"
            autoComplete="off"
            autoCapitalize="none"
            spellCheck={false}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="cuenta@outlook.com"
            className={cn(FIELD, 'pl-10')}
          />
        </div>
      </div>

      {error && (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      )}
      {saved && (
        <p role="status" className="text-sm text-primary">
          {saved} guardada.{' '}
          {outlookApp.available() ? 'Inicia sesión en la ventana de Microsoft que se abrió.' : ''}
        </p>
      )}

      <Button type="submit" size="lg" className="h-12 rounded-xl text-sm font-semibold tracking-wide" disabled={!valid || busy}>
        {busy && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
        GUARDAR
      </Button>
    </form>
  )
}

const STATUS_LABEL: Record<PoolStatus, string> = {
  available: 'Disponible',
  in_use: 'En uso',
  used: 'Usada',
}

function SessionControls({ email, session }: { email: string; session: AppSession | null }) {
  const status = session?.status ?? 'login_required'
  return (
    <div className="flex flex-col gap-2 rounded-xl bg-muted p-2.5">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-xs font-semibold',
            status === 'available' && 'bg-primary text-primary-foreground',
            status === 'in_use' && 'bg-accent text-accent-foreground',
            status === 'error' && 'bg-destructive/10 text-destructive',
            status === 'login_required' && 'bg-card text-foreground',
          )}
        >
          {SESSION_LABEL[status]}
        </span>
        <span className="text-xs text-muted-foreground">{session?.message ?? 'Sin sesión en este teléfono'}</span>
      </div>
      <div className="flex gap-2">
        <Button
          type="button"
          variant={status === 'available' ? 'outline' : 'default'}
          className="h-9 flex-1 rounded-lg text-xs font-semibold"
          disabled={status === 'in_use'}
          onClick={() => (session ? outlookApp.login(email) : outlookApp.add(email))}
        >
          <LogIn className="size-3.5" aria-hidden="true" />
          INICIAR SESIÓN
        </Button>
        <Button
          type="button"
          variant="outline"
          className="h-9 flex-1 rounded-lg text-xs font-semibold"
          disabled={!session || status === 'in_use'}
          onClick={() => outlookApp.test(email)}
        >
          <Activity className="size-3.5" aria-hidden="true" />
          PROBAR SESIÓN
        </Button>
      </div>
    </div>
  )
}

function AccountRow({
  account,
  session,
  busy,
  onAdvance,
  onDelete,
}: {
  account: PoolAccount
  session?: AppSession | null
  busy: boolean
  onAdvance: () => void
  onDelete: () => void
}) {
  const { status } = account
  const action = status === 'available' ? 'Usar' : status === 'in_use' ? 'Marcar usada' : null
  return (
    <li className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-3">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <span
          className={cn('truncate text-sm font-medium', status === 'used' && 'text-muted-foreground line-through')}
          title={account.email}
        >
          {account.email}
        </span>
        <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span
            className={cn(
              'inline-flex w-fit items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-semibold',
              status === 'available' ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground',
            )}
          >
            <span
              className={cn('size-1.5 rounded-full', status === 'available' ? 'bg-primary' : 'bg-muted-foreground')}
              aria-hidden="true"
            />
            {STATUS_LABEL[status]}
          </span>
          {account.procedureCurp && status !== 'available' ? (
            <span className="font-mono text-xs text-muted-foreground">IMSS · {account.procedureCurp}</span>
          ) : null}
        </span>
      </div>
      <div className="flex gap-2">
        {action ? (
          <Button
            type="button"
            variant={status === 'available' ? 'default' : 'outline'}
            className="h-10 flex-1 rounded-xl sm:flex-none"
            onClick={onAdvance}
            disabled={busy}
          >
            {busy && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
            {action}
          </Button>
        ) : null}
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="size-10 shrink-0 rounded-xl text-destructive hover:text-destructive"
          onClick={onDelete}
          disabled={busy}
          aria-label={`Eliminar ${account.email}`}
        >
          <Trash2 className="size-4" aria-hidden="true" />
        </Button>
      </div>
      </div>
      {session !== undefined && <SessionControls email={account.email} session={session} />}
    </li>
  )
}
