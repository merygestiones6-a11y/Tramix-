'use client'

import { useRef, useState } from 'react'
import useSWR from 'swr'
import { SYSTEM_SERVICES, type Account } from '@/lib/rfc-sat/services'
import { ConsultForm } from '@/components/rfc-sat/consult-form'
import { HistoryList } from '@/components/rfc-sat/history-list'
import { BulkForm } from '@/components/rfc-sat/bulk-form'

export const fetcher = async (url: string) => {
  const res = await fetch(url)
  const data = await res.json()
  if (!res.ok) throw new Error(data.message || 'Error')
  return data
}

const SERVICE_ID = 'idcifv1'

const credits = (n: number) => Math.trunc(n).toLocaleString('es-MX')

export function PortalApp() {
  const { data, error, isLoading, isValidating, mutate } = useSWR<Account>('/api/rfc-sat/account', fetcher, {
    revalidateOnFocus: false,
  })

  const [showBulk, setShowBulk] = useState(false)
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const startHold = () => {
    holdTimer.current = setTimeout(() => mutate(), 1000)
  }

  const cancelHold = () => {
    if (holdTimer.current) clearTimeout(holdTimer.current)
  }

  const service =
    data?.services.find((s) => s.id === SERVICE_ID) ?? SYSTEM_SERVICES.find((s) => s.id === SERVICE_ID)!

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex flex-col gap-2">
          <h1
            className="select-none text-3xl font-semibold tracking-tight text-balance [-webkit-touch-callout:none] sm:text-4xl"
            onPointerDown={startHold}
            onPointerUp={cancelHold}
            onPointerLeave={cancelHold}
            onPointerCancel={cancelHold}
            onContextMenu={(e) => e.preventDefault()}
          >
            RFC
          </h1>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">{service.desc}</p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-2">
          {data && (
            <button
              type="button"
              onClick={() => mutate()}
              disabled={isValidating}
              title="Toca para actualizar el saldo"
              aria-live="polite"
              className="flex flex-col items-end rounded-md border bg-card px-2.5 py-1 leading-tight transition-colors hover:bg-muted disabled:opacity-60"
            >
              <span className="sr-only">{isValidating ? 'Actualizando crédito' : 'Crédito'}</span>
              <span
                className={`font-mono text-sm font-semibold tabular-nums ${
                  data.credits < service.cost ? 'text-destructive' : 'text-foreground'
                }`}
              >
                {credits(data.credits)}
              </span>
            </button>
          )}
          {data && (
            <button
              type="button"
              onClick={() => setShowBulk((v) => !v)}
              aria-expanded={showBulk}
              aria-controls="rfc-masivo"
              className="rounded-md border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground"
            >
              {showBulk ? 'Cerrar masivo' : 'Masivo'}
            </button>
          )}
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-destructive/40 bg-destructive/5 p-4 text-sm leading-relaxed text-destructive"
        >
          <p className="font-medium">No se pudo conectar con tu cuenta</p>
          <p>{error.message}</p>
        </div>
      )}

      {isLoading && <p className="text-sm text-muted-foreground">Entrando a tu cuenta...</p>}

      {data && (
        <div className="grid w-full grid-cols-1 items-start gap-5 lg:grid-cols-[380px_minmax(0,1fr)]">
          <div className="flex min-w-0 flex-col gap-5">
            <div id="rfc-masivo" hidden={!showBulk}>
              <BulkForm service={service} onDone={() => mutate()} />
            </div>
            <ConsultForm service={service} onDone={() => mutate()} />
          </div>
          <HistoryList />
        </div>
      )}
    </div>
  )
}
