'use client'

import { useMemo, useRef, useState } from 'react'
import { mutate as globalMutate } from 'swr'
import { Button } from '@/components/ui/button'
import { LUGAR_OPTIONS } from '@/lib/rfc-sat/lugares'
import type { Service } from '@/lib/rfc-sat/services'
import { cleanPdfName, downloadPdfFromUrl, saveBlob } from '@/lib/rfc-sat/download'

const DEFAULT_LUGAR = 'CUAUHTEMOC , CIUDAD DE MEXICO'
const MAX_ITEMS = 200
const PAUSE_MS = 1500

type Pair = { rfc: string; idcif: string }
type RowState = 'pendiente' | 'procesando' | 'listo' | 'error' | 'cancelado'
type Row = Pair & { state: RowState; message?: string; pdf?: { base64: string; filename?: string }; url?: string }

const TOKEN = /(?<![A-Z0-9Ñ&])([A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3})(?![A-Z0-9])|(?<!\d)(\d{11})(?!\d)/g

// Each RFC is paired with the first IDCIF that follows it, so the list works one per line or all in one block.
export function parsePairs(text: string): { pairs: Pair[]; sinIdcif: string[] } {
  const pairs: Pair[] = []
  const sinIdcif: string[] = []
  const seen = new Set<string>()
  let pendingRfc: string | null = null
  for (const m of text.toUpperCase().matchAll(TOKEN)) {
    if (m[1]) {
      if (pendingRfc) sinIdcif.push(pendingRfc)
      pendingRfc = m[1]
    } else if (m[2] && pendingRfc) {
      const key = `${pendingRfc}|${m[2]}`
      if (!seen.has(key)) {
        seen.add(key)
        pairs.push({ rfc: pendingRfc, idcif: m[2] })
      }
      pendingRfc = null
    }
  }
  if (pendingRfc) sinIdcif.push(pendingRfc)
  return { pairs, sinIdcif }
}

function savePdf(base64: string, filename?: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
  saveBlob(new Blob([bytes], { type: 'application/pdf' }), cleanPdfName(filename))
}

async function saveRow(row: Row) {
  if (row.pdf) savePdf(row.pdf.base64, row.pdf.filename)
  else if (row.url) await downloadPdfFromUrl(row.url, cleanPdfName(row.url, row.rfc))
}

const STATE_STYLE: Record<RowState, string> = {
  pendiente: 'text-muted-foreground',
  procesando: 'text-foreground',
  listo: 'text-success',
  error: 'text-destructive',
  cancelado: 'text-muted-foreground',
}

const STATE_LABEL: Record<RowState, string> = {
  pendiente: 'En espera',
  procesando: 'Consultando…',
  listo: 'Descargado',
  error: 'Error',
  cancelado: 'Cancelado',
}

export function BulkForm({ service, onDone }: { service: Service; onDone: () => void }) {
  const [text, setText] = useState('')
  const [lugar, setLugar] = useState(DEFAULT_LUGAR)
  const [rows, setRows] = useState<Row[]>([])
  const [running, setRunning] = useState(false)
  const stopRef = useRef(false)

  const parsed = useMemo(() => parsePairs(text), [text])
  const total = Math.min(parsed.pairs.length, MAX_ITEMS)

  const update = (i: number, patch: Partial<Row>) =>
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)))

  async function start() {
    if (!total || running) return
    const list = parsed.pairs.slice(0, MAX_ITEMS)
    if (!window.confirm(`Se harán ${list.length} consultas, una por una. Cada una usa ${service.cost} crédito. ¿Continuar?`)) return

    stopRef.current = false
    setRunning(true)
    setRows(list.map((p) => ({ ...p, state: 'pendiente' })))

    for (let i = 0; i < list.length; i++) {
      if (stopRef.current) {
        setRows((prev) => prev.map((r, idx) => (idx >= i && r.state === 'pendiente' ? { ...r, state: 'cancelado' } : r)))
        break
      }
      update(i, { state: 'procesando' })
      try {
        const res = await fetch('/api/rfc-sat/consult', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ serviceId: service.id, values: { rfc: list[i].rfc, idcif: list[i].idcif, lugar } }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.message || 'La consulta falló')
        const row: Row = { ...list[i], state: 'listo', pdf: data.pdf ?? undefined, url: data.downloadUrl ?? undefined }
        if (!row.pdf && !row.url) throw new Error('No se recibió PDF')
        try {
          await saveRow(row)
          update(i, row)
        } catch {
          update(i, { ...row, state: 'error', message: 'Consulta lista, falló la descarga' })
        }
      } catch (err) {
        update(i, { state: 'error', message: err instanceof Error ? err.message : 'Error de red' })
      }
      onDone()
      globalMutate('/api/rfc-sat/history')
      if (i < list.length - 1 && !stopRef.current) await new Promise((r) => setTimeout(r, PAUSE_MS))
    }
    setRunning(false)
  }

  const done = rows.filter((r) => r.state === 'listo').length
  const failed = rows.filter((r) => r.state === 'error').length
  const processed = rows.filter((r) => r.state !== 'pendiente' && r.state !== 'procesando').length

  return (
    <section aria-labelledby="masivo" className="flex min-w-0 flex-col gap-4 rounded-lg border bg-card p-4">
      <div className="flex flex-col gap-1">
        <h2 id="masivo" className="text-sm font-medium text-muted-foreground">
          Masivo
        </h2>
        <p className="text-xs leading-relaxed text-muted-foreground">
          Pega RFC e IDCIF en cualquier formato. Cada RFC se une con el IDCIF que le sigue.
        </p>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="bulk-text" className="text-sm font-medium">
          Lista de datos
        </label>
        <textarea
          id="bulk-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={running}
          rows={6}
          spellCheck={false}
          placeholder={'GODE561231GR8 12345678901\nXAXX010101000, 98765432109'}
          className="min-h-32 rounded-md border bg-background px-3 py-2 font-mono text-base uppercase leading-relaxed placeholder:normal-case disabled:opacity-60"
        />
        {text.trim() && (
          <p className="text-xs leading-relaxed text-muted-foreground" aria-live="polite">
            {parsed.pairs.length} pares detectados
            {parsed.pairs.length > MAX_ITEMS && ` (se procesarán los primeros ${MAX_ITEMS})`}
            {parsed.sinIdcif.length > 0 && (
              <span className="text-destructive">
                {' '}
                · {parsed.sinIdcif.length} RFC sin IDCIF: {parsed.sinIdcif.slice(0, 3).join(', ')}
                {parsed.sinIdcif.length > 3 && '…'}
              </span>
            )}
          </p>
        )}
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="bulk-lugar" className="text-sm font-medium">
          Lugar de emisión
        </label>
        <select
          id="bulk-lugar"
          value={lugar}
          onChange={(e) => setLugar(e.target.value)}
          disabled={running}
          className="h-11 min-w-0 rounded-md border bg-background px-3 text-base"
        >
          {LUGAR_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      {running ? (
        <Button type="button" size="lg" variant="outline" className="h-11" onClick={() => (stopRef.current = true)}>
          Detener después de la actual
        </Button>
      ) : (
        <Button type="button" size="lg" className="h-11" disabled={!total} onClick={start}>
          {total ? `Generar ${total} y descargar` : 'Generar masivo'}
        </Button>
      )}

      {rows.length > 0 && (
        <div className="flex flex-col gap-2" aria-live="polite">
          <p className="text-xs text-muted-foreground">
            {processed} de {rows.length} · {done} descargados{failed > 0 && ` · ${failed} con error`}
            {running && ' · No cierres esta pantalla'}
          </p>
          <ul className="flex max-h-80 flex-col divide-y overflow-y-auto rounded-md border">
            {rows.map((r, i) => (
              <li key={`${r.rfc}-${r.idcif}`} className="flex items-center justify-between gap-2 px-3 py-2">
                <div className="flex min-w-0 flex-col">
                  <span className="truncate font-mono text-sm">{r.rfc}</span>
                  <span className="truncate font-mono text-xs text-muted-foreground">{r.idcif}</span>
                  {r.message && <span className="text-xs text-destructive">{r.message}</span>}
                </div>
                {r.pdf || r.url ? (
                  <button
                    type="button"
                    onClick={() => saveRow(r).catch(() => update(i, { message: 'Falló la descarga' }))}
                    className="shrink-0 rounded-md border bg-background px-3 py-1.5 text-xs font-medium hover:bg-muted"
                  >
                    PDF
                  </button>
                ) : (
                  <span className={`shrink-0 text-xs font-medium ${STATE_STYLE[r.state]}`}>{STATE_LABEL[r.state]}</span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  )
}
