'use client'

import { useState } from 'react'
import { mutate as globalMutate } from 'swr'
import { Button } from '@/components/ui/button'
import { LUGAR_OPTIONS } from '@/lib/rfc-sat/lugares'
import type { Service } from '@/lib/rfc-sat/services'
import { cleanPdfName, downloadPdfFromUrl, saveBlob } from '@/lib/rfc-sat/download'

type Result = {
  downloadUrl: string | null
  pdf: { base64: string; filename?: string } | null
  info: Record<string, unknown> | null
}

const DEFAULT_LUGAR = 'CUAUHTEMOC , CIUDAD DE MEXICO'

const LABELS: Record<string, string> = { rfc: 'RFC', idcif: 'IDCIF', lugar: 'Lugar de emisión' }

function savePdf(base64: string, filename?: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
  saveBlob(new Blob([bytes], { type: 'application/pdf' }), cleanPdfName(filename))
}

function OriginalPdfButton({ url, filename }: { url: string; filename?: string }) {
  const [state, setState] = useState<'idle' | 'loading' | 'error'>('idle')

  async function handleClick() {
    setState('loading')
    try {
      await downloadPdfFromUrl(url, cleanPdfName(filename || url))
      setState('idle')
    } catch {
      setState('error')
    }
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={state === 'loading'}
      className="inline-flex h-9 items-center justify-center rounded-md border bg-background px-4 text-sm font-medium hover:bg-muted disabled:opacity-60"
    >
      {state === 'loading' ? 'Descargando…' : state === 'error' ? 'Reintentar descarga' : 'Descargar PDF original'}
    </button>
  )
}

export function ConsultForm({ service, onDone }: { service: Service; onDone: () => void }) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const [result, setResult] = useState<Result | null>(null)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const values = Object.fromEntries(new FormData(e.currentTarget).entries())
    setStatus('loading')
    setResult(null)
    try {
      const res = await fetch('/api/rfc-sat/consult', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serviceId: service.id, values }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message || 'La consulta falló')
      setResult(data)
      setStatus('ok')
      if (data.pdf) savePdf(data.pdf.base64, data.pdf.filename)
      onDone()
      globalMutate('/api/rfc-sat/history')
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Error de red')
      setStatus('error')
    }
  }

  return (
    <section aria-labelledby="datos" className="flex flex-col gap-4 rounded-lg border bg-card p-4">
      <h2 id="datos" className="text-sm font-medium text-muted-foreground">
        Datos para {service.name}
      </h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {service.fields.map((f) => {
          const label = LABELS[f] ?? f.toUpperCase()
          const id = `field-${f}`
          return (
            <div key={f} className="flex flex-col gap-1.5">
              <label htmlFor={id} className="text-sm font-medium">
                {label}
              </label>
              {f === 'lugar' ? (
                <select
                  id={id}
                  name={f}
                  required
                  defaultValue={DEFAULT_LUGAR}
                  className="h-11 rounded-md border bg-background px-3 text-base"
                >
                  <option value="" disabled>
                    Selecciona un lugar...
                  </option>
                  {LUGAR_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  id={id}
                  name={f}
                  required
                  autoComplete="off"
                  placeholder={`Escribe ${label}`}
                  className="h-11 rounded-md border bg-background px-3 font-mono text-base uppercase placeholder:font-sans placeholder:normal-case"
                />
              )}
            </div>
          )
        })}
        <Button type="submit" size="lg" disabled={status === 'loading'} className="h-11">
          {status === 'loading' ? 'Consultando, espera...' : 'Consultar y descargar'}
        </Button>
      </form>

      <div aria-live="polite">
        {status === 'error' && <p className="text-sm text-destructive">{message}</p>}
        {status === 'ok' && result && (
          <div className="flex flex-col gap-3 rounded-md bg-success/10 p-3">
            <p className="text-sm font-medium text-success">Consulta exitosa</p>
            {result.pdf && (
              <Button variant="outline" onClick={() => savePdf(result.pdf!.base64, result.pdf!.filename)}>
                Descargar PDF otra vez
              </Button>
            )}
            {result.downloadUrl && (
              <OriginalPdfButton url={result.downloadUrl} filename={result.pdf?.filename} />
            )}
            {result.info && (
              <pre className="overflow-x-auto rounded bg-background p-3 font-mono text-xs leading-relaxed">
                {JSON.stringify(result.info, null, 2)}
              </pre>
            )}
          </div>
        )}
      </div>
    </section>
  )
}
