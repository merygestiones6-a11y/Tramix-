'use client'

import { useState } from 'react'
import useSWR from 'swr'
import type { HistoryLog } from '@/lib/rfc-sat/services'
import { fetcher } from '@/components/rfc-sat/portal-app'
import { downloadPdfFromUrl } from '@/lib/rfc-sat/download'

function PdfButton({ url }: { url: string }) {
  const [state, setState] = useState<'idle' | 'loading' | 'error'>('idle')

  async function handleClick() {
    setState('loading')
    try {
      await downloadPdfFromUrl(url)
      setState('idle')
    } catch {
      setState('error')
    }
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={state === 'loading'}
      className="shrink-0 text-sm font-medium text-primary underline underline-offset-4 disabled:opacity-60"
    >
      {state === 'loading' ? 'Descargando…' : state === 'error' ? 'Reintentar' : 'PDF'}
    </button>
  )
}

export function HistoryList() {
  const { data } = useSWR<{ logs: HistoryLog[] }>('/api/rfc-sat/history', fetcher, { revalidateOnFocus: false })
  const logs = data?.logs.slice(0, 10) ?? []

  return (
    <section aria-labelledby="recientes" className="flex flex-col gap-3">
      <h2 id="recientes" className="text-sm font-medium text-muted-foreground">
        Descargas recientes
      </h2>
      {logs.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aún no hay consultas.</p>
      ) : (
        <ul className="flex flex-col divide-y rounded-lg border bg-card">
          {logs.map((l) => (
            <li key={l.id} className="flex items-center justify-between gap-3 p-3">
              <div className="flex min-w-0 flex-col">
                <span className="truncate text-sm font-medium">{l.service}</span>
                <span className="text-xs text-muted-foreground">
                  {new Date(l.created_at).toLocaleString('es-MX')} · {l.status}
                </span>
              </div>
              {l.result_url ? (
                <PdfButton url={l.result_url} />
              ) : (
                <span className="text-xs text-muted-foreground">—</span>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
