'use client'

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { AlertTriangle, Check, CheckCircle2, Copy, Download, ExternalLink, Loader2, MailCheck, RefreshCw, SearchX, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { cleanEmailInput, isValidEmail } from '@/lib/imss'
import { openAndroidDocument, readAndroidDocument, TRAMIX_APK_URL, type ImssDocument } from '@/lib/imss-android'
import { accessFetch } from '@/lib/outlook/client'
import {
  buildNssIntentUrl,
  CURP_PATTERN,
  DEFAULT_NSS_EMAIL,
  IMSS_LINK_PATTERN,
  nssCancel,
  nssDownload,
  nssOpenLink,
  nssRefresh,
  nssShowPortal,
  nssStart,
  nssSubmit,
  nssSupport,
  nssTakeEvents,
  type NssResult,
} from '@/lib/validar-nss'

type Phase = 'loading' | 'captcha' | 'widget' | 'submitting' | 'step' | 'result' | 'blocked'

const FIELD_LABELS: Record<string, string> = {
  curp: 'CURP',
  email: 'correo',
  confirm: 'confirmación de correo',
  captcha: 'CAPTCHA',
}
type SaveState = 'idle' | 'saving' | 'saved' | 'failed'

const noop = () => () => {}
const useSupport = () => useSyncExternalStore(noop, nssSupport, () => 'none' as const)

const fieldClass =
  'h-12 w-full rounded-xl border border-input bg-card px-4 text-base text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30 disabled:opacity-60'

export function ValidarNss() {
  const support = useSupport()
  const [curp, setCurp] = useState('')
  const [email, setEmail] = useState(DEFAULT_NSS_EMAIL)
  const [captcha, setCaptcha] = useState('')
  const [image, setImage] = useState<string | null>(null)
  const [phase, setPhase] = useState<Phase>('loading')
  const [notice, setNotice] = useState('')
  const [result, setResult] = useState<NssResult | null>(null)
  const [doc, setDoc] = useState<ImssDocument | null>(null)
  const [save, setSave] = useState<SaveState>('idle')
  const [pdfReady, setPdfReady] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const startedRef = useRef(false)

  const curpOk = CURP_PATTERN.test(curp)
  const emailOk = isValidEmail(email)

  const start = useCallback(() => {
    setImage(null)
    setCaptcha('')
    setNotice('')
    setResult(null)
    setDoc(null)
    setSave('idle')
    setPdfReady(false)
    setDownloading(false)
    setPhase('loading')
    if (!nssStart(email.trim() || DEFAULT_NSS_EMAIL)) {
      setPhase('blocked')
      setNotice('La app no pudo abrir el portal del IMSS.')
    }
  }, [email])

  useEffect(() => {
    if (support !== 'ready' || startedRef.current) return
    startedRef.current = true
    start()
    return () => nssCancel()
  }, [support, start])

  useEffect(() => {
    if (support !== 'ready') return
    const id = window.setInterval(() => {
      for (const event of nssTakeEvents()) {
        switch (event.status) {
          case 'loading':
            setPhase('loading')
            break
          case 'captcha':
            if (event.detail.image) setImage(event.detail.image)
            setCaptcha('')
            setPhase('captcha')
            setNotice(event.detail.retry ? event.detail.message || 'El IMSS rechazó el CAPTCHA. Escribe el nuevo código.' : '')
            break
          case 'captcha_widget':
            setPhase('widget')
            setNotice(event.detail.message || 'Resuelve la verificación en el portal.')
            break
          case 'submitting':
            setPhase('submitting')
            break
          case 'step': {
            const missing = (event.detail.missing ?? []).map((m) => FIELD_LABELS[m] ?? m)
            setPhase('step')
            setNotice(
              event.detail.reason === 'incomplete'
                ? `El IMSS pide completar: ${missing.length ? missing.join(', ') : 'campos del formulario'}.${event.detail.message ? ` ${event.detail.message}` : ''}`
                : event.detail.message || 'El IMSS pide un paso adicional (por ejemplo, domicilio). Complétalo en el portal oficial.',
            )
            break
          }
          case 'pdf_available':
            setPdfReady(true)
            break
          case 'result':
            setResult(event.detail)
            if (event.detail.hasPdf) setPdfReady(true)
            setPhase('result')
            nssShowPortal(false)
            break
          case 'fields_not_found':
          case 'load_error':
            setPhase('blocked')
            setNotice(event.detail.reason || event.detail.message || 'El portal del IMSS no respondió.')
            break
          case 'document':
            setDoc(event.detail)
            setDownloading(false)
            break
          case 'download_failed':
            setSave('failed')
            setDownloading(false)
            break
        }
      }
    }, 600)
    return () => window.clearInterval(id)
  }, [support])

  useEffect(() => {
    if (!doc || save !== 'idle') return
    const bytes = readAndroidDocument(doc.id)
    if (!bytes) {
      setSave('failed')
      return
    }
    setSave('saving')
    accessFetch('/api/validar-nss/document', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/pdf',
        'x-curp': encodeURIComponent(result?.curp || curp),
        'x-email': encodeURIComponent(email),
        'x-file-name': encodeURIComponent(doc.name),
      },
      body: bytes,
    })
      .then((res) => setSave(res.ok ? 'saved' : 'failed'))
      .catch(() => setSave('failed'))
  }, [doc, save, result, curp, email])

  const canSubmit = support === 'ready' && phase === 'captcha' && curpOk && emailOk && captcha.trim().length >= 3

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    if (nssSubmit(curp, email.trim(), captcha.trim())) setPhase('submitting')
  }

  const downloadPdf = () => {
    if (doc && save === 'saved') {
      openAndroidDocument(doc.id)
      return
    }
    const started = nssDownload()
    setDownloading(started)
    setSave(started ? 'idle' : 'failed')
  }

  return (
    <div className="flex flex-col gap-5">
      <form onSubmit={submit} className="glass flex flex-col gap-5 rounded-3xl border border-border p-5 sm:p-6" noValidate>
        <Field label="CURP" htmlFor="nss-curp" hint={curp && !curpOk ? 'Revisa la CURP: deben ser 18 caracteres válidos.' : undefined}>
          <input
            id="nss-curp"
            value={curp}
            onChange={(e) => setCurp(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 18))}
            className={cn(fieldClass, 'font-mono tracking-wider uppercase')}
            placeholder="ABCD000000HDFXXX00"
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            aria-invalid={Boolean(curp) && !curpOk}
            disabled={phase === 'submitting'}
          />
        </Field>

        <Field label="Correo" htmlFor="nss-email" hint={!emailOk ? 'Escribe un correo válido.' : undefined}>
          <input
            id="nss-email"
            type="email"
            inputMode="email"
            value={email}
            onChange={(e) => setEmail(cleanEmailInput(e.target.value))}
            className={fieldClass}
            autoComplete="email"
            aria-invalid={!emailOk}
            disabled={phase === 'submitting'}
          />
        </Field>

        <Field label="Confirmar correo" htmlFor="nss-email-confirm">
          <input id="nss-email-confirm" type="email" value={email} readOnly className={cn(fieldClass, 'bg-muted text-muted-foreground')} aria-readonly="true" />
        </Field>

        <CaptchaBox
          support={support}
          phase={phase}
          image={image}
          notice={notice}
          value={captcha}
          onChange={setCaptcha}
          onRefresh={() => {
            setPhase('loading')
            setImage(null)
            if (!nssRefresh()) start()
          }}
          onRetry={start}
        />

        <Button type="submit" size="lg" className="h-13 rounded-xl text-base font-semibold tracking-wide" disabled={!canSubmit}>
          {phase === 'submitting' ? (
            <>
              <Loader2 className="size-5 animate-spin" aria-hidden="true" />
              CONSULTANDO AL IMSS…
            </>
          ) : (
            'CONTINUAR TRÁMITE'
          )}
        </Button>
      </form>

      {phase === 'step' ? (
        <section aria-live="polite" className="glass flex flex-col gap-4 rounded-3xl border border-border p-5 sm:p-6">
          <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wide text-primary">
            <ExternalLink className="size-5" aria-hidden="true" />
            PASO OFICIAL DEL IMSS
          </h2>
          <p className="text-sm leading-relaxed text-pretty text-foreground">{notice}</p>
          <Button type="button" className="h-12 rounded-xl font-semibold" onClick={() => nssShowPortal(true)}>
            CONTINUAR EN EL PORTAL
          </Button>
          <p className="text-xs leading-relaxed text-muted-foreground">
            El portal se abre dentro de IMSS DIRECT con la misma sesión. Al terminar, el resultado aparece aquí.
          </p>
        </section>
      ) : null}

      {pdfReady && !result ? (
        <PdfButton save={save} downloading={downloading} hasDoc={Boolean(doc)} onClick={downloadPdf} />
      ) : null}

      {result ? (
        <ResultCard
          result={result}
          save={save}
          downloading={downloading}
          hasDoc={Boolean(doc)}
          pdfReady={pdfReady}
          onDownload={downloadPdf}
          onAgain={start}
        />
      ) : null}
    </div>
  )
}

function Field({ label, htmlFor, hint, children }: { label: string; htmlFor: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={htmlFor} className="text-xs font-semibold tracking-wide text-muted-foreground">
        {label}
      </label>
      {children}
      {hint ? <p className="text-sm text-destructive">{hint}</p> : null}
    </div>
  )
}

function CaptchaBox({
  support,
  phase,
  image,
  notice,
  value,
  onChange,
  onRefresh,
  onRetry,
}: {
  support: 'ready' | 'outdated' | 'none'
  phase: Phase
  image: string | null
  notice: string
  value: string
  onChange: (v: string) => void
  onRefresh: () => void
  onRetry: () => void
}) {
  if (support !== 'ready') return <OpenInApp outdated={support === 'outdated'} />

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-muted/50 p-4">
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs font-semibold tracking-wide text-muted-foreground">CAPTCHA oficial del IMSS</span>
        {phase === 'captcha' || phase === 'loading' ? (
          <button
            type="button"
            onClick={onRefresh}
            disabled={phase === 'loading'}
            className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-sm font-medium text-primary transition-colors hover:bg-accent disabled:opacity-50"
          >
            <RefreshCw className={cn('size-4', phase === 'loading' && 'animate-spin')} aria-hidden="true" />
            Otro código
          </button>
        ) : null}
      </div>

      <div className="flex min-h-20 items-center justify-center rounded-xl border border-border bg-card p-2" aria-live="polite">
        {phase === 'loading' ? (
          <span className="inline-flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Abriendo el portal del IMSS…
          </span>
        ) : phase === 'widget' ? (
          <div className="flex flex-col items-center gap-3 py-2 text-center">
            <p className="text-sm leading-relaxed text-muted-foreground">{notice}</p>
            <Button type="button" variant="outline" onClick={() => nssShowPortal(true)}>
              <ExternalLink className="size-4" aria-hidden="true" />
              Resolver en el portal
            </Button>
          </div>
        ) : phase === 'blocked' ? (
          <div className="flex flex-col items-center gap-3 py-2 text-center">
            <p className="text-sm leading-relaxed text-destructive">{notice}</p>
            <Button type="button" variant="outline" onClick={onRetry}>
              <RefreshCw className="size-4" aria-hidden="true" />
              Reintentar
            </Button>
          </div>
        ) : image ? (
          // eslint-disable-next-line @next/next/no-img-element -- data URL copied from the IMSS portal
          <img src={image} alt="Código CAPTCHA del portal del IMSS" className="h-auto max-h-28 w-auto max-w-full [image-rendering:pixelated]" />
        ) : (
          <span className="text-sm text-muted-foreground">Esperando el código…</span>
        )}
      </div>

      {phase === 'captcha' && notice ? (
        <p role="alert" className="flex items-start gap-2 text-sm leading-relaxed text-destructive">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {notice}
        </p>
      ) : null}

      <label htmlFor="nss-captcha" className="sr-only">
        Escribe el código CAPTCHA
      </label>
      <input
        id="nss-captcha"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/\s/g, '').slice(0, 32))}
        className={cn(fieldClass, 'text-center font-mono text-lg tracking-[0.3em]')}
        placeholder="Escribe el código"
        autoComplete="off"
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
        disabled={phase !== 'captcha'}
      />
    </div>
  )
}

function OpenInApp({ outdated }: { outdated: boolean }) {
  const [href, setHref] = useState(TRAMIX_APK_URL)
  useEffect(() => {
    if (!outdated && /android/i.test(navigator.userAgent)) setHref(buildNssIntentUrl(TRAMIX_APK_URL))
  }, [outdated])

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-muted/50 p-4">
      <p className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground">
        <Smartphone className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
        {outdated
          ? 'Tu app IMSS DIRECT es de una versión anterior. Instala la nueva versión para ver aquí el CAPTCHA oficial.'
          : 'El CAPTCHA oficial del IMSS solo puede mostrarse dentro de la app IMSS DIRECT para Android.'}
      </p>
      <a
        href={outdated ? TRAMIX_APK_URL : href}
        download={outdated || href === TRAMIX_APK_URL ? 'IMSS-DIRECT.apk' : undefined}
        className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-semibold text-foreground transition-colors hover:bg-accent"
      >
        <Download className="size-4" aria-hidden="true" />
        {outdated ? 'ACTUALIZAR APP' : 'ABRIR EN LA APP'}
      </a>
    </div>
  )
}

function PdfButton({ save, downloading, hasDoc, onClick }: { save: SaveState; downloading: boolean; hasDoc: boolean; onClick: () => void }) {
  const busy = downloading || save === 'saving'
  return (
    <div className="flex flex-col gap-2">
      <Button type="button" size="lg" className="h-12 rounded-xl font-semibold tracking-wide" onClick={onClick} disabled={busy}>
        {busy ? <Loader2 className="size-5 animate-spin" aria-hidden="true" /> : <Download className="size-5" aria-hidden="true" />}
        {busy ? 'DESCARGANDO PDF…' : hasDoc && save === 'saved' ? 'ABRIR PDF' : 'DESCARGAR PDF'}
      </Button>
      {save === 'saved' ? (
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Check className="size-4 text-primary" aria-hidden="true" />
          PDF guardado en DESCARGAR
        </p>
      ) : save === 'failed' ? (
        <p className="text-sm text-destructive">No se pudo guardar el PDF. Intenta de nuevo.</p>
      ) : null}
    </div>
  )
}

function LinkOpener() {
  const [url, setUrl] = useState('')
  const [error, setError] = useState('')
  const valid = IMSS_LINK_PATTERN.test(url.trim())
  return (
    <form
      className="flex flex-col gap-2"
      onSubmit={(e) => {
        e.preventDefault()
        if (!valid) return setError('Pega la liga completa del correo del IMSS.')
        setError(nssOpenLink(url.trim()) ? '' : 'No se pudo abrir la liga.')
      }}
    >
      <label htmlFor="nss-link" className="text-xs font-semibold tracking-wide text-muted-foreground">
        LIGA DEL CORREO DEL IMSS
      </label>
      <input
        id="nss-link"
        type="url"
        inputMode="url"
        value={url}
        onChange={(e) => setUrl(e.target.value.trim())}
        className={fieldClass}
        placeholder="https://serviciosdigitales.imss.gob.mx/…"
        autoComplete="off"
        spellCheck={false}
      />
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <Button type="submit" variant="outline" className="h-11 rounded-xl" disabled={!url}>
        <ExternalLink className="size-4" aria-hidden="true" />
        ABRIR LIGA EN IMSS DIRECT
      </Button>
    </form>
  )
}

function ResultCard({
  result,
  save,
  downloading,
  hasDoc,
  pdfReady,
  onDownload,
  onAgain,
}: {
  result: NssResult
  save: SaveState
  downloading: boolean
  hasDoc: boolean
  pdfReady: boolean
  onDownload: () => void
  onAgain: () => void
}) {
  const head = {
    found: { icon: CheckCircle2, title: 'NSS LOCALIZADO', tone: 'text-primary' },
    not_found: { icon: SearchX, title: 'NSS NO LOCALIZADO', tone: 'text-destructive' },
    link_sent: { icon: MailCheck, title: 'EL IMSS ENVIÓ UNA LIGA DE CONFIRMACIÓN', tone: 'text-primary' },
    error: { icon: AlertTriangle, title: 'EL IMSS NO PERMITIÓ LA CONSULTA', tone: 'text-destructive' },
  }[result.kind]
  const Icon = head.icon

  return (
    <section aria-live="polite" className="glass flex flex-col gap-4 rounded-3xl border border-border p-5 sm:p-6">
      <h2 className={cn('flex items-center gap-2 text-sm font-semibold tracking-wide', head.tone)}>
        <Icon className="size-5" aria-hidden="true" />
        {head.title}
      </h2>

      <dl className="flex flex-col gap-3">
        {result.curp ? <Row label="CURP" value={result.curp} mono /> : null}
        {result.name ? <Row label="NOMBRE COMPLETO" value={result.name} /> : null}
        {result.nss ? <Row label="NSS" value={result.nss} mono large /> : null}
        {result.kind === 'link_sent' && result.email ? <Row label="CORREO" value={result.email} /> : null}
      </dl>

      {result.kind === 'link_sent' ? (
        <>
          <p className="text-sm leading-relaxed text-muted-foreground">
            El IMSS envió una liga al correo. Pégala aquí para continuar el trámite dentro de IMSS DIRECT con la misma sesión.
          </p>
          <LinkOpener />
        </>
      ) : null}

      {result.message && result.kind !== 'found' ? (
        <p className="rounded-xl bg-muted px-4 py-3 text-sm leading-relaxed text-foreground">
          <span className="font-semibold">Mensaje del IMSS: </span>
          {result.message}
        </p>
      ) : null}

      {pdfReady || hasDoc ? <PdfButton save={save} downloading={downloading} hasDoc={hasDoc} onClick={onDownload} /> : null}

      <Button type="button" variant="outline" className="h-11 rounded-xl" onClick={onAgain}>
        NUEVA CONSULTA
      </Button>
    </section>
  )
}

function Row({ label, value, mono, large }: { label: string; value: string; mono?: boolean; large?: boolean }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
      <div className="flex min-w-0 flex-col gap-0.5">
        <dt className="text-xs font-semibold tracking-wide text-muted-foreground">{label}</dt>
        <dd className={cn('truncate text-foreground', mono && 'font-mono tracking-wider', large ? 'text-2xl font-semibold' : 'text-base')}>{value}</dd>
      </div>
      <button
        type="button"
        onClick={() => {
          void navigator.clipboard?.writeText(value).then(() => {
            setCopied(true)
            window.setTimeout(() => setCopied(false), 1500)
          })
        }}
        className="inline-flex size-10 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        aria-label={`Copiar ${label}`}
      >
        {copied ? <Check className="size-4 text-primary" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
      </button>
    </div>
  )
}
