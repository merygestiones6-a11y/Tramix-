'use client'

import { useState, type FormEvent, type ReactNode } from 'react'
import { FileText, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'

export type ConstanciaData = { rfc: string; idCif: string }
type Errors = Partial<Record<keyof ConstanciaData, string>>

type ConstanciaFormProps = {
  pending: boolean
  onGenerate: (data: ConstanciaData) => void
}

const inputClass =
  'h-12 w-full rounded-sm border border-input bg-card px-4 font-mono text-base tracking-wider text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-primary focus:ring-4 focus:ring-primary/10 aria-invalid:border-destructive aria-invalid:ring-destructive/10'

function Field({
  id,
  label,
  error,
  children,
}: {
  id: string
  label: string
  error?: string
  children: ReactNode
}) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} className="text-sm text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}

export function ConstanciaForm({ pending, onGenerate }: ConstanciaFormProps) {
  const [rfc, setRfc] = useState('')
  const [idCif, setIdCif] = useState('')
  const [errors, setErrors] = useState<Errors>({})

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const nextErrors: Errors = {}
    if (!isValidRfc(rfc)) nextErrors.rfc = 'Ingresa un RFC válido de 12 o 13 caracteres.'
    if (!isValidIdCif(idCif)) nextErrors.idCif = 'Ingresa un idCIF numérico válido.'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length === 0) onGenerate({ rfc, idCif })
  }

  const describedBy = (key: keyof ConstanciaData, id: string) =>
    errors[key] ? `${id}-error` : undefined

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-6">
      <Field id="cif-rfc" label="RFC" error={errors.rfc}>
        <input
          id="cif-rfc"
          name="rfc"
          value={rfc}
          onChange={(e) => setRfc(normalizeRfc(e.target.value))}
          placeholder="GIPL921215AK2"
          autoComplete="off"
          spellCheck={false}
          maxLength={13}
          aria-invalid={Boolean(errors.rfc)}
          aria-describedby={describedBy('rfc', 'cif-rfc')}
          className={inputClass}
        />
      </Field>

      <Field
        id="cif-idcif"
        label="idCIF / Identificador electrónico"
        error={errors.idCif}
      >
        <input
          id="cif-idcif"
          name="idCif"
          value={idCif}
          onChange={(e) => setIdCif(normalizeIdCif(e.target.value))}
          placeholder="16120218086"
          inputMode="numeric"
          autoComplete="off"
          aria-invalid={Boolean(errors.idCif)}
          aria-describedby={describedBy('idCif', 'cif-idcif')}
          className={inputClass}
        />
      </Field>

      <Button type="submit" size="lg" disabled={pending} className="h-12 gap-2 rounded-sm text-base font-semibold">
        {pending ? (
          <Loader2 className="size-5 animate-spin" aria-hidden="true" />
        ) : (
          <FileText className="size-5" aria-hidden="true" />
        )}
        {pending ? 'Consultando SAT…' : 'Generar constancia'}
      </Button>
    </form>
  )
}
