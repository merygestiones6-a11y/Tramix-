'use client'

import { useEffect, useState } from 'react'
import { Download, FileText } from 'lucide-react'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { downloadPdfFromUrl, hasNativeSaver, rfcFileName } from '@/lib/cifsat/pdf-download'
import { ConstanciaForm, type ConstanciaData } from './constancia-form'

type GeneratedPdf = { url: string; fileName: string; nombre: string }

export function ConstanciaGenerator() {
  const [pdf, setPdf] = useState<GeneratedPdf | null>(null)
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    return () => {
      if (pdf) URL.revokeObjectURL(pdf.url)
    }
  }, [pdf])

  async function handleGenerate(data: ConstanciaData) {
    setPending(true)
    setError(null)
    try {
      const res = await fetch('/api/cifsat/constancia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => null)
        throw new Error(body?.error ?? 'No se pudo generar la constancia.')
      }
      const nombre = decodeURIComponent(res.headers.get('X-Contribuyente-Nombre') ?? '')
      const blob = await res.blob()
      const fileName = rfcFileName(data.rfc)
      setPdf({ url: URL.createObjectURL(new File([blob], fileName, { type: 'application/pdf' })), fileName, nombre })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo generar la constancia.')
    } finally {
      setPending(false)
    }
  }

  return (
    <div className="grid overflow-hidden rounded-md border border-t-4 border-t-primary bg-card shadow-sm md:grid-cols-2">
      <div className="flex flex-col gap-6 p-6 sm:p-8">
        <ConstanciaForm pending={pending} onGenerate={handleGenerate} />
        {error && (
          <p
            role="alert"
            className="rounded-sm border border-l-4 border-destructive/30 border-l-destructive bg-destructive/5 px-4 py-3 text-sm text-destructive"
          >
            {error}
          </p>
        )}
      </div>

      <div className="flex flex-col border-t bg-muted/60 p-6 sm:p-8 md:border-l md:border-t-0">
        {pdf ? (
          <div className="flex flex-1 flex-col gap-4">
            {/* The Android WebView can't render PDFs in an iframe and instead auto-saves it under the blob's UUID. */}
            {!hasNativeSaver() && (
              <iframe
                src={`${pdf.url}#toolbar=0&view=FitH`}
                title="Vista previa de la Cédula de Identificación Fiscal"
                className="aspect-[612/792] w-full rounded-sm border bg-card"
              />
            )}
            <a
              href={pdf.url}
              download={pdf.fileName}
              onClick={(e) => {
                e.preventDefault()
                void downloadPdfFromUrl(pdf.url, pdf.fileName)
              }}
              className={cn(buttonVariants({ size: 'lg' }), 'h-12 gap-2 rounded-sm text-base font-semibold')}
            >
              <Download className="size-5" aria-hidden="true" />
              Descargar PDF
            </a>
          </div>
        ) : (
          <div className="flex min-h-72 flex-1 items-center justify-center rounded-md border border-dashed border-input bg-card p-10">
            <FileText className="size-16 text-primary/25" aria-label="Vista previa de la constancia" />
          </div>
        )}
      </div>
    </div>
  )
}
