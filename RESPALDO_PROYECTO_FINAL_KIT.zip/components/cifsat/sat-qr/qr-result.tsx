'use client'

import { useRef, useState } from 'react'
import { QRCodeCanvas } from 'qrcode.react'
import { Check, Copy, Download, ExternalLink, QrCode } from 'lucide-react'
import { Button, buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type QrResultProps = {
  url: string | null
  fileName: string
}

export function QrResult({ url, fileName }: QrResultProps) {
  const canvasWrapperRef = useRef<HTMLDivElement>(null)
  const [copied, setCopied] = useState(false)

  async function handleCopy() {
    if (!url) return
    await navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function handleDownload() {
    const canvas = canvasWrapperRef.current?.querySelector('canvas')
    if (!canvas) return
    const link = document.createElement('a')
    link.href = canvas.toDataURL('image/png')
    link.download = `${fileName}.png`
    link.click()
  }

  if (!url) {
    return (
      <div className="flex h-full min-h-72 items-center justify-center rounded-md border border-dashed border-input bg-card p-8">
        <QrCode className="size-16 text-primary/25" aria-label="Vista previa del QR" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-5" aria-live="polite">
      <div className="flex flex-col items-center rounded-md border bg-card p-6">
        <div ref={canvasWrapperRef} className="w-full max-w-64">
          <QRCodeCanvas
            value={url}
            size={1024}
            level="M"
            marginSize={2}
            bgColor="#ffffff"
            fgColor="#000000"
            title={`Código QR: ${url}`}
            style={{ width: '100%', height: 'auto' }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Button type="button" onClick={handleDownload} className="h-11 gap-2 rounded-sm font-semibold">
          <Download className="size-4" aria-hidden="true" />
          Descargar
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={handleCopy}
          className="h-11 gap-2 rounded-sm border-primary font-semibold text-primary"
        >
          {copied ? (
            <Check className="size-4" aria-hidden="true" />
          ) : (
            <Copy className="size-4" aria-hidden="true" />
          )}
          {copied ? 'Copiado' : 'Copiar'}
        </Button>
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(
            buttonVariants({ variant: 'outline' }),
            'h-11 gap-2 rounded-sm border-primary font-semibold text-primary',
          )}
        >
          <ExternalLink className="size-4" aria-hidden="true" />
          Abrir
        </a>
      </div>
    </div>
  )
}
