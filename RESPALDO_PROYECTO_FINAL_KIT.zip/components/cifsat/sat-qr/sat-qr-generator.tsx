'use client'

import { useState } from 'react'
import { QrForm } from './qr-form'
import { QrResult } from './qr-result'
import { buildSatValidatorUrl } from '@/lib/cifsat/sat-qr'

export function SatQrGenerator() {
  const [generated, setGenerated] = useState<{ idCif: string; rfc: string } | null>(null)

  const url = generated ? buildSatValidatorUrl(generated.idCif, generated.rfc) : null
  const fileName = generated ? `${generated.idCif}_${generated.rfc}` : 'sat-qr'

  return (
    <div className="grid overflow-hidden rounded-md border border-t-4 border-t-primary bg-card shadow-sm md:grid-cols-2">
      <div className="p-6 sm:p-8">
        <QrForm onGenerate={setGenerated} />
      </div>
      <div className="flex flex-col border-t bg-muted/60 p-6 sm:p-8 md:border-l md:border-t-0">
        <QrResult url={url} fileName={fileName} />
      </div>
    </div>
  )
}
