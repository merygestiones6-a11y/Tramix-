'use client'

import { useState, type FormEvent } from 'react'
import { QrCode } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  isValidIdCif,
  isValidRfc,
  normalizeIdCif,
  normalizeRfc,
} from '@/lib/cifsat/sat-qr'

type QrFormProps = {
  onGenerate: (data: { idCif: string; rfc: string }) => void
}

export function QrForm({ onGenerate }: QrFormProps) {
  const [rfc, setRfc] = useState('')
  const [idCif, setIdCif] = useState('')
  const [errors, setErrors] = useState<{ rfc?: string; idCif?: string }>({})

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const nextErrors: { rfc?: string; idCif?: string } = {}
    if (!isValidRfc(rfc)) nextErrors.rfc = 'Ingresa un RFC válido de 12 o 13 caracteres.'
    if (!isValidIdCif(idCif)) nextErrors.idCif = 'Ingresa un IDCIF numérico válido.'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length === 0) onGenerate({ idCif, rfc })
  }

  const inputClass =
    'h-12 w-full rounded-sm border border-input bg-card px-4 font-mono text-base tracking-wider text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-primary focus:ring-4 focus:ring-primary/10 aria-invalid:border-destructive aria-invalid:ring-destructive/10'

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <label htmlFor="rfc" className="text-sm font-medium text-foreground">
          RFC
        </label>
        <input
          id="rfc"
          name="rfc"
          value={rfc}
          onChange={(e) => setRfc(normalizeRfc(e.target.value))}
          placeholder="GIPL921215AK2"
          autoComplete="off"
          spellCheck={false}
          maxLength={13}
          aria-invalid={Boolean(errors.rfc)}
          aria-describedby={errors.rfc ? 'rfc-error' : undefined}
          className={inputClass}
        />
        {errors.rfc && (
          <p id="rfc-error" className="text-sm text-destructive">
            {errors.rfc}
          </p>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="idcif" className="text-sm font-medium text-foreground">
          IDCIF
        </label>
        <input
          id="idcif"
          name="idcif"
          value={idCif}
          onChange={(e) => setIdCif(normalizeIdCif(e.target.value))}
          placeholder="16120218086"
          inputMode="numeric"
          autoComplete="off"
          aria-invalid={Boolean(errors.idCif)}
          aria-describedby={errors.idCif ? 'idcif-error' : undefined}
          className={inputClass}
        />
        {errors.idCif && (
          <p id="idcif-error" className="text-sm text-destructive">
            {errors.idCif}
          </p>
        )}
      </div>

      <Button type="submit" size="lg" className="h-12 gap-2 rounded-sm text-base font-semibold">
        <QrCode className="size-5" aria-hidden="true" />
        Generar QR
      </Button>
    </form>
  )
}
