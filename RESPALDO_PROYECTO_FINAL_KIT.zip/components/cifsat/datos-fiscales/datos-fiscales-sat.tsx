'use client'

import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Check, Download, Eye, Loader2, RotateCcw, ScanSearch, TriangleAlert } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { PREVIEW_HASH, downloadPdfFromUrl, hasNativeSaver } from '@/lib/cifsat/pdf-download'
import { isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'

const STEPS = [
  'Validando',
  'Consultando SAT',
  'Obteniendo datos',
  'Consultando régimen',
  'Validando',
  'Generando URL',
  'Generando QR',
  'Generando PDF',
  'Listo',
] as const

type Errors = { rfc?: string; idCif?: string }
type Consulta = { rfc: string; nombre: string; cp: string; regimenes: string[] }
type Match = { description: string; code: string; catalogDescription: string }
type Resultado = { url: string; qr: string; pdfUrl: string }

const inputClass =
  'h-12 w-full rounded-sm border border-input bg-card px-4 font-mono text-base tracking-wider text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-primary focus:ring-4 focus:ring-primary/10 aria-invalid:border-destructive aria-invalid:ring-destructive/10'

async function callApi<T>(payload: Record<string, unknown>): Promise<T> {
  const res = await fetch('/api/cifsat/datos-fiscales', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const body = await res.json().catch(() => null)
  if (!res.ok || !body || body.error) throw new Error(body?.error ?? 'El servicio no respondió.')
  return body as T
}

function base64ToBlobUrl(base64: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
  return URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
}

function Stepper({ step, failed }: { step: number; failed: boolean }) {
  return (
    <ol className="grid grid-cols-1 gap-2 sm:grid-cols-3" aria-label="Estado del proceso">
      {STEPS.map((label, i) => {
        const done = i < step || (i === step && step === STEPS.length - 1)
        const current = i === step && !done
        return (
          <li
            key={`${label}-${i}`}
            aria-current={current ? 'step' : undefined}
            className={cn(
              'flex items-center gap-2 rounded-sm border px-3 py-2 font-mono text-xs uppercase tracking-wider',
              done && 'border-primary/20 bg-secondary text-primary',
              current && !failed && 'border-primary bg-card text-primary',
              current && failed && 'border-destructive bg-destructive/5 text-destructive',
              !done && !current && 'border-border bg-card text-muted-foreground',
            )}
          >
            {done ? (
              <Check className="size-4 shrink-0" aria-hidden="true" />
            ) : current && failed ? (
              <TriangleAlert className="size-4 shrink-0" aria-hidden="true" />
            ) : current ? (
              <Loader2 className="size-4 shrink-0 animate-spin" aria-hidden="true" />
            ) : (
              <span className="size-4 shrink-0 text-center tabular-nums">{i + 1}</span>
            )}
            {label}
          </li>
        )
      })}
    </ol>
  )
}

export function DatosFiscalesSat() {
  const [rfc, setRfc] = useState('')
  const [idCif, setIdCif] = useState('')
  const [errors, setErrors] = useState<Errors>({})
  const [step, setStep] = useState(-1)
  const [running, setRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [consulta, setConsulta] = useState<Consulta | null>(null)
  const [matches, setMatches] = useState<Match[] | null>(null)
  const [resultado, setResultado] = useState<Resultado | null>(null)
  const resultRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    return () => {
      if (resultado) URL.revokeObjectURL(resultado.pdfUrl)
    }
  }, [resultado])

  async function run(fromStep: number, prev: { consulta: Consulta | null; matches: Match[] | null }) {
    setRunning(true)
    setError(null)
    let current = fromStep
    let c = prev.consulta
    let m = prev.matches
    try {
      if (current <= 2 || !c) {
        current = 1
        setStep(1)
        c = await callApi<Consulta>({ action: 'consultar', rfc, idCif })
        current = 2
        setStep(2)
        setConsulta(c)
      }
      if (current <= 3 || !m) {
        current = 3
        setStep(3)
        m = (await callApi<{ matches: Match[] }>({ action: 'regimen', regimenes: c.regimenes })).matches
        setMatches(m)
      }
      current = 4
      setStep(4)
      const gen = await callApi<{ url: string; qr: string; pdf: string }>({
        action: 'generar',
        name: c.nombre,
        rfc: c.rfc,
        cp: c.cp,
        regimen: m.map((x) => x.code).join('|'),
      })
      setResultado({ url: gen.url, qr: gen.qr, pdfUrl: base64ToBlobUrl(gen.pdf) })
      setStep(STEPS.length - 1)
    } catch (err) {
      setStep(current)
      setError(err instanceof Error ? err.message : 'Ocurrió un error.')
    } finally {
      setRunning(false)
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setStep(0)
    const nextErrors: Errors = {}
    if (!isValidRfc(rfc)) nextErrors.rfc = 'Ingresa un RFC válido de 12 o 13 caracteres.'
    if (!isValidIdCif(idCif)) nextErrors.idCif = 'Ingresa un idCIF numérico válido.'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) {
      setStep(-1)
      return
    }
    setConsulta(null)
    setMatches(null)
    setResultado(null)
    run(1, { consulta: null, matches: null })
  }

  function reset() {
    setRfc('')
    setIdCif('')
    setErrors({})
    setStep(-1)
    setError(null)
    setConsulta(null)
    setMatches(null)
    setResultado(null)
  }

  const fileName = `DATOS_FISCALES_${(consulta?.rfc ?? rfc).trim().toUpperCase()}.pdf`

  return (
    <div className="flex flex-col gap-6">
      <form
        onSubmit={handleSubmit}
        noValidate
        className="flex flex-col gap-5 rounded-md border border-t-4 border-t-primary bg-card p-6 shadow-sm sm:p-8 md:flex-row md:items-start"
      >
        <div className="flex flex-1 flex-col gap-2">
          <label htmlFor="df-rfc" className="text-sm font-medium text-foreground">
            RFC
          </label>
          <input
            id="df-rfc"
            value={rfc}
            onChange={(e) => setRfc(normalizeRfc(e.target.value))}
            placeholder="LEOC780701976"
            autoComplete="off"
            spellCheck={false}
            maxLength={13}
            disabled={running}
            aria-invalid={Boolean(errors.rfc)}
            aria-describedby={errors.rfc ? 'df-rfc-error' : undefined}
            className={inputClass}
          />
          {errors.rfc && (
            <p id="df-rfc-error" className="text-sm text-destructive">
              {errors.rfc}
            </p>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-2">
          <label htmlFor="df-idcif" className="text-sm font-medium text-foreground">
            idCIF
          </label>
          <input
            id="df-idcif"
            value={idCif}
            onChange={(e) => setIdCif(normalizeIdCif(e.target.value))}
            placeholder="26100029635"
            inputMode="numeric"
            autoComplete="off"
            disabled={running}
            aria-invalid={Boolean(errors.idCif)}
            aria-describedby={errors.idCif ? 'df-idcif-error' : undefined}
            className={inputClass}
          />
          {errors.idCif && (
            <p id="df-idcif-error" className="text-sm text-destructive">
              {errors.idCif}
            </p>
          )}
        </div>
        <Button type="submit" size="lg" disabled={running} className="h-12 gap-2 rounded-sm text-base font-semibold md:mt-7">
          {running ? (
            <Loader2 className="size-5 animate-spin" aria-hidden="true" />
          ) : (
            <ScanSearch className="size-5" aria-hidden="true" />
          )}
          Consultar y generar
        </Button>
      </form>

      {step >= 0 && (
        <div className="flex flex-col gap-4" aria-live="polite">
          <Stepper step={step} failed={Boolean(error)} />
          {error && (
            <div
              role="alert"
              className="flex flex-col gap-3 rounded-sm border border-l-4 border-destructive/30 border-l-destructive bg-destructive/5 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <p className="text-sm text-destructive">{error}</p>
              <Button
                type="button"
                variant="outline"
                onClick={() => run(step, { consulta, matches })}
                className="shrink-0 gap-2 rounded-sm"
              >
                <RotateCcw className="size-4" aria-hidden="true" />
                Continuar
              </Button>
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        <Button
          type="button"
          variant="outline"
          disabled={!resultado}
          onClick={() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
          className="h-11 gap-2 rounded-sm"
        >
          <Eye className="size-4" aria-hidden="true" />
          Ver resultado
        </Button>
        {resultado ? (
          <a
            href={resultado.pdfUrl}
            download={fileName}
            onClick={(e) => {
              e.preventDefault()
              void downloadPdfFromUrl(resultado.pdfUrl, fileName)
            }}
            className="inline-flex h-11 items-center gap-2 rounded-sm bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            <Download className="size-4" aria-hidden="true" />
            Descargar PDF
          </a>
        ) : (
          <Button type="button" disabled className="h-11 gap-2 rounded-sm">
            <Download className="size-4" aria-hidden="true" />
            Descargar PDF
          </Button>
        )}
        <Button type="button" variant="ghost" onClick={reset} disabled={running} className="h-11 gap-2 rounded-sm">
          <RotateCcw className="size-4" aria-hidden="true" />
          Nueva consulta
        </Button>
      </div>

      {resultado && consulta && matches && (
        <div ref={resultRef} className="grid scroll-mt-24 grid-cols-1 gap-5 lg:grid-cols-5">
          <section
            aria-label="Datos obtenidos del SAT"
            className="flex flex-col gap-5 rounded-md border border-border bg-card p-6 shadow-sm lg:col-span-2"
          >
            <div className="flex items-start gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={resultado.qr}
                alt="QR de validación de datos fiscales"
                width={128}
                height={128}
                className="size-32 shrink-0 rounded-sm border border-border"
              />
              <dl className="flex min-w-0 flex-col gap-3">
                <div className="flex flex-col gap-0.5">
                  <dt className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Nombre</dt>
                  <dd className="text-pretty text-sm font-semibold text-foreground">{consulta.nombre}</dd>
                </div>
                <div className="flex flex-col gap-0.5">
                  <dt className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">RFC</dt>
                  <dd className="font-mono text-sm tracking-wider text-foreground">{consulta.rfc}</dd>
                </div>
                <div className="flex flex-col gap-0.5">
                  <dt className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Código postal</dt>
                  <dd className="font-mono text-sm tracking-wider text-foreground">{consulta.cp}</dd>
                </div>
              </dl>
            </div>
            <dl className="flex flex-col gap-2 border-t border-border pt-4">
              <dt className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Régimen fiscal</dt>
              {matches.map((m) => (
                <dd key={m.code} className="flex gap-3 text-sm leading-relaxed text-foreground">
                  <span className="font-mono font-semibold text-primary">{m.code}</span>
                  <span className="text-pretty">{m.catalogDescription}</span>
                </dd>
              ))}
            </dl>
            <div className="flex flex-col gap-1 border-t border-border pt-4">
              <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">URL del QR</span>
              <code className="break-all rounded-sm bg-muted px-3 py-2 font-mono text-xs leading-relaxed text-foreground">
                {resultado.url}
              </code>
            </div>
          </section>
          {/* The Android WebView can't render PDFs in an iframe and instead auto-saves it under the blob's UUID. */}
          {!hasNativeSaver() && (
            <section aria-label="Vista previa del PDF" className="overflow-hidden rounded-md border border-border bg-muted lg:col-span-3">
              <iframe src={`${resultado.pdfUrl}${PREVIEW_HASH}`} title="Datos fiscales PDF" className="h-[560px] w-full" />
            </section>
          )}
        </div>
      )}
    </div>
  )
}
