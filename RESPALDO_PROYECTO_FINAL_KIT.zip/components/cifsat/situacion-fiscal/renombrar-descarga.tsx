'use client'

import { useRef, useState } from 'react'
import { CheckCircle2, FileUp, Loader2 } from 'lucide-react'
import { downloadPdf, rfcFileName } from '@/lib/cifsat/pdf-download'

export function RenombrarDescarga() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [guardado, setGuardado] = useState<string | null>(null)

  async function procesar(file: File | null) {
    setError(null)
    setGuardado(null)
    if (!file) return
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setError('Selecciona un archivo PDF.')
      return
    }
    setLoading(true)
    try {
      const form = new FormData()
      form.append('archivo', file)
      const res = await fetch('/api/cifsat/situacion-fiscal/analizar', { method: 'POST', body: form })
      const body = await res.json().catch(() => null)
      if (!res.ok || !body || body.error) throw new Error(body?.error ?? 'El servicio no respondió.')
      const rfc: string | null = body.analisis?.rfc ?? null
      if (!rfc) throw new Error('No se encontró el RFC dentro del PDF.')
      const nombre = rfcFileName(rfc)
      downloadPdf(file, nombre)
      setGuardado(nombre)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ocurrió un error.')
    } finally {
      setLoading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  return (
    <div className="flex flex-col gap-3 border-t border-border px-5 py-4">
      <input
        ref={inputRef}
        id="renombrar-archivo"
        type="file"
        accept="application/pdf,.pdf"
        className="sr-only"
        disabled={loading}
        onChange={(e) => procesar(e.target.files?.[0] ?? null)}
      />
      <label
        htmlFor="renombrar-archivo"
        className="flex h-12 cursor-pointer items-center gap-3 rounded-sm border border-dashed border-input bg-background px-4 text-sm text-muted-foreground transition-colors hover:border-primary focus-within:border-primary"
      >
        {loading ? (
          <Loader2 className="size-5 shrink-0 animate-spin text-primary" aria-hidden="true" />
        ) : (
          <FileUp className="size-5 shrink-0 text-primary" aria-hidden="true" />
        )}
        <span className="truncate">Guardar PDF descargado como CIF_RFC.pdf</span>
      </label>
      <div aria-live="polite">
        {guardado && (
          <p className="flex items-center gap-2 text-sm text-foreground">
            <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />
            Guardado como <span className="font-mono font-semibold">{guardado}</span>
          </p>
        )}
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
      </div>
    </div>
  )
}
