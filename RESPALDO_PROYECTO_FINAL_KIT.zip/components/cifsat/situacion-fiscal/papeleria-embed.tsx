'use client'

import { useState } from 'react'
import { ExternalLink, Loader2 } from 'lucide-react'
import { RenombrarDescarga } from '@/components/cifsat/situacion-fiscal/renombrar-descarga'

const PAPELERIA_URL = 'https://papeleria.app/rfc-constancia-gratis'

export function PapeleriaEmbed() {
  const [loaded, setLoaded] = useState(false)

  return (
    <section
      aria-labelledby="papeleria-titulo"
      className="flex flex-col overflow-hidden rounded-md border border-t-4 border-t-primary bg-card shadow-sm"
    >
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-3">
        <h2 id="papeleria-titulo" className="font-serif text-base font-semibold text-foreground">
          PapeleriaApp
        </h2>
        <a
          href={PAPELERIA_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-9 items-center gap-2 rounded-sm border border-border px-3 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          <ExternalLink className="size-4" aria-hidden="true" />
          Abrir en nueva pestaña
        </a>
      </div>
      <div className="relative bg-muted">
        {!loaded && (
          <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
            <Loader2 className="size-6 animate-spin text-muted-foreground" />
          </div>
        )}
        <iframe
          src={PAPELERIA_URL}
          title="Constancia de situación fiscal en PapeleriaApp"
          onLoad={() => setLoaded(true)}
          allow="clipboard-write"
          referrerPolicy="strict-origin-when-cross-origin"
          className="relative h-[760px] w-full bg-card"
        />
      </div>
      <RenombrarDescarga />
    </section>
  )
}
