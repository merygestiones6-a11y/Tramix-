'use client'

import { useEffect, useRef, useState } from 'react'
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  ExternalLink,
  Eye,
  FileUp,
  Info,
  Loader2,
  RotateCcw,
  ScanSearch,
  ShieldAlert,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Analisis, Hallazgo } from '@/lib/cifsat/pdf-analisis'
import { PREVIEW_HASH, downloadPdf, rfcFileName } from '@/lib/cifsat/pdf-download'

const SAT_DESCARGA_URL = 'https://www.sat.gob.mx/aplicacion/53027/genera-tu-constancia-de-situacion-fiscal'

function base64ToBlobUrl(base64: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
  return URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
}

const linkBtn =
  'inline-flex h-11 items-center gap-2 rounded-sm px-4 text-sm font-semibold transition-colors'

function HallazgoItem({ h }: { h: Hallazgo }) {
  const Icon = h.severidad === 'ok' ? CheckCircle2 : h.severidad === 'alerta' ? AlertTriangle : Info
  const tone =
    h.severidad === 'ok' ? 'text-primary' : h.severidad === 'alerta' ? 'text-destructive' : 'text-muted-foreground'
  return (
    <li className="flex gap-3 border-t border-border py-3 first:border-t-0 first:pt-0">
      <Icon className={`mt-0.5 size-4 shrink-0 ${tone}`} aria-hidden="true" />
      <div className="flex flex-col gap-0.5">
        <p className="text-sm font-medium text-foreground">
          {h.titulo}
          {h.corregible && (
            <span className="ml-2 rounded-sm bg-primary/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-primary">
              Corregible
            </span>
          )}
        </p>
        <p className="text-pretty text-sm leading-relaxed text-muted-foreground">{h.detalle}</p>
      </div>
    </li>
  )
}

export function AnalizadorPdf() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [archivo, setArchivo] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [analisis, setAnalisis] = useState<Analisis | null>(null)
  const [corregidoUrl, setCorregidoUrl] = useState<string | null>(null)
  const [mostrarVista, setMostrarVista] = useState(false)

  useEffect(() => {
    return () => {
      if (corregidoUrl) URL.revokeObjectURL(corregidoUrl)
    }
  }, [corregidoUrl])

  function limpiarResultado() {
    setError(null)
    setAnalisis(null)
    setCorregidoUrl(null)
    setMostrarVista(false)
  }

  function onSelect(file: File | null) {
    limpiarResultado()
    if (file && file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setArchivo(null)
      setError('Selecciona un archivo PDF.')
      return
    }
    setArchivo(file)
  }

  async function analizar() {
    if (!archivo) return
    setLoading(true)
    limpiarResultado()
    try {
      const form = new FormData()
      form.append('archivo', archivo)
      const res = await fetch('/api/cifsat/situacion-fiscal/analizar', { method: 'POST', body: form })
      const body = await res.json().catch(() => null)
      if (!res.ok || !body || body.error) throw new Error(body?.error ?? 'El servicio no respondió.')
      setAnalisis(body.analisis)
      if (body.corregido) setCorregidoUrl(base64ToBlobUrl(body.corregido))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ocurrió un error.')
    } finally {
      setLoading(false)
    }
  }

  function reiniciar() {
    limpiarResultado()
    setArchivo(null)
    if (inputRef.current) inputRef.current.value = ''
  }

  const nombreSalida = analisis?.rfc
    ? rfcFileName(analisis.rfc)
    : archivo
      ? archivo.name.replace(/\.pdf$/i, '') + '_corregido.pdf'
      : 'corregido.pdf'
  const inseguro = analisis && !analisis.correccionSegura

  return (
    <section
      aria-labelledby="analizador-titulo"
      className="flex flex-col gap-5 rounded-md border border-t-4 border-t-primary bg-card p-6 shadow-sm sm:p-8"
    >
      <h3 id="analizador-titulo" className="font-serif text-lg font-semibold text-foreground">
        Analizar PDF
      </h3>

      <div className="flex flex-col gap-3 md:flex-row md:items-center">
        <input
          ref={inputRef}
          id="analizador-archivo"
          type="file"
          accept="application/pdf,.pdf"
          className="sr-only"
          onChange={(e) => onSelect(e.target.files?.[0] ?? null)}
        />
        <label
          htmlFor="analizador-archivo"
          className="flex h-12 min-w-0 flex-1 cursor-pointer items-center gap-3 rounded-sm border border-dashed border-input bg-background px-4 text-sm text-muted-foreground transition-colors hover:border-primary focus-within:border-primary"
        >
          <FileUp className="size-5 shrink-0 text-primary" aria-hidden="true" />
          <span className="truncate">{archivo ? archivo.name : 'Subir PDF'}</span>
        </label>
        <Button
          type="button"
          size="lg"
          onClick={analizar}
          disabled={!archivo || loading}
          className="h-12 gap-2 rounded-sm text-base font-semibold"
        >
          {loading ? (
            <Loader2 className="size-5 animate-spin" aria-hidden="true" />
          ) : (
            <ScanSearch className="size-5" aria-hidden="true" />
          )}
          Analizar documento
        </Button>
      </div>

      {error && (
        <p
          role="alert"
          className="rounded-sm border border-l-4 border-destructive/30 border-l-destructive bg-destructive/5 px-4 py-3 text-sm text-destructive"
        >
          {error}
        </p>
      )}

      {analisis && (
        <div className="flex flex-col gap-5">
          {inseguro && (
            <div
              role="alert"
              className="flex flex-col gap-3 rounded-sm border border-l-4 border-destructive/30 border-l-destructive bg-destructive/5 px-4 py-4"
            >
              <p className="flex items-center gap-2 text-sm font-semibold text-destructive">
                <ShieldAlert className="size-4" aria-hidden="true" />
                No se puede corregir de forma segura
              </p>
              <p className="text-pretty text-sm leading-relaxed text-foreground">
                El archivo presenta indicios de alteración o elementos que no deben modificarse. Se conserva intacto.
              </p>
              <div className="flex flex-wrap gap-3">
                {analisis.urlVerificacion && (
                  <a
                    href={analisis.urlVerificacion}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${linkBtn} bg-primary text-primary-foreground hover:bg-primary/90`}
                  >
                    <ExternalLink className="size-4" aria-hidden="true" />
                    Verificar en el SAT
                  </a>
                )}
                <a
                  href={SAT_DESCARGA_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${linkBtn} border border-border bg-card text-foreground hover:bg-muted`}
                >
                  <Download className="size-4" aria-hidden="true" />
                  Volver a descargar del SAT
                </a>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="flex flex-col gap-3">
              <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Visualización</p>
              <ul className="flex flex-col">
                {analisis.hallazgos
                  .filter((h) => h.categoria === 'visualizacion')
                  .map((h, i) => (
                    <HallazgoItem key={i} h={h} />
                  ))}
                {!analisis.hallazgos.some((h) => h.categoria === 'visualizacion') && (
                  <HallazgoItem
                    h={{ categoria: 'visualizacion', severidad: 'ok', titulo: 'Sin problemas de visualización', detalle: 'Rotación, área visible y tamaño correctos.', corregible: false }}
                  />
                )}
              </ul>
            </div>
            <div className="flex flex-col gap-3">
              <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Integridad</p>
              <ul className="flex flex-col">
                {analisis.hallazgos
                  .filter((h) => h.categoria === 'integridad')
                  .map((h, i) => (
                    <HallazgoItem key={i} h={h} />
                  ))}
                {!analisis.hallazgos.some((h) => h.categoria === 'integridad') && (
                  <HallazgoItem
                    h={{ categoria: 'integridad', severidad: 'ok', titulo: 'Sin indicios de alteración', detalle: `${analisis.paginas.length} páginas${analisis.productor ? ` · ${analisis.productor}` : ''}`, corregible: false }}
                  />
                )}
              </ul>
            </div>
          </div>

          {!inseguro && !corregidoUrl && (
            <p className="rounded-sm bg-muted px-4 py-3 text-sm text-foreground">
              El documento no requiere corrección.
            </p>
          )}

          <div className="flex flex-wrap gap-3">
            {corregidoUrl && (
              <>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setMostrarVista((v) => !v)}
                  aria-expanded={mostrarVista}
                  className="h-11 gap-2 rounded-sm"
                >
                  <Eye className="size-4" aria-hidden="true" />
                  {mostrarVista ? 'Ocultar vista previa' : 'Previsualizar resultado'}
                </Button>
                <Button
                  type="button"
                  size="lg"
                  onClick={async () => downloadPdf(await (await fetch(corregidoUrl)).blob(), nombreSalida)}
                  className="h-11 gap-2 rounded-sm text-sm font-semibold"
                >
                  <Download className="size-4" aria-hidden="true" />
                  Descargar
                </Button>
              </>
            )}
            {!inseguro && analisis.urlVerificacion && (
              <a
                href={analisis.urlVerificacion}
                target="_blank"
                rel="noopener noreferrer"
                className={`${linkBtn} border border-border bg-card text-foreground hover:bg-muted`}
              >
                <ExternalLink className="size-4" aria-hidden="true" />
                Verificar en el SAT
              </a>
            )}
            <Button type="button" variant="ghost" onClick={reiniciar} className="h-11 gap-2 rounded-sm">
              <RotateCcw className="size-4" aria-hidden="true" />
              Nuevo análisis
            </Button>
          </div>

          {corregidoUrl && mostrarVista && (
            <div className="overflow-hidden rounded-md border border-border bg-muted">
              <iframe src={corregidoUrl + PREVIEW_HASH} title="Vista previa del PDF corregido" className="h-[620px] w-full" />
            </div>
          )}
        </div>
      )}
    </section>
  )
}
