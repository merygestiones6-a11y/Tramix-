'use client'

import { useEffect, useState, type FormEvent } from 'react'
import { Download, Loader2, RotateCcw, ScanSearch } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { AnalizadorPdf } from '@/components/cifsat/situacion-fiscal/analizador-pdf'
import { PapeleriaEmbed } from '@/components/cifsat/situacion-fiscal/papeleria-embed'
import { isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'
import { PREVIEW_HASH, downloadPdf, rfcFileName } from '@/lib/cifsat/pdf-download'

type Errors = { rfc?: string; idCif?: string }
type Registro = {
  rfc: string
  idCif: string
  curp: string
  nombre: string
  inicioOperaciones: string
  estatus: string
  ultimoCambio: string
  domicilio: Record<string, string>
  regimenes: { regimen: string; fechaAlta: string }[]
}

const inputClass =
  'h-12 w-full rounded-sm border border-input bg-card px-4 font-mono text-base tracking-wider text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-primary focus:ring-4 focus:ring-primary/10 aria-invalid:border-destructive aria-invalid:ring-destructive/10'

function base64ToBlobUrl(base64: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
  return URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
}

function Dato({ label, value }: { label: string; value: string }) {
  if (!value) return null
  return (
    <div className="flex flex-col gap-0.5">
      <dt className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">{label}</dt>
      <dd className="text-pretty text-sm font-medium text-foreground">{value}</dd>
    </div>
  )
}

const fuentes = [
  { id: 'papeleria', label: 'PapeleriaApp' },
  { id: 'cifsat', label: 'Consulta CIFSAT' },
] as const

type Fuente = (typeof fuentes)[number]['id']

export function SituacionFiscal() {
  const [fuente, setFuente] = useState<Fuente>('papeleria')

  return (
    <div className="flex flex-col gap-6">
      <div role="tablist" aria-label="Origen de la constancia" className="flex w-full rounded-sm border border-border bg-card p-1 sm:w-fit">
        {fuentes.map((f) => (
          <button
            key={f.id}
            type="button"
            role="tab"
            aria-selected={fuente === f.id}
            onClick={() => setFuente(f.id)}
            className="h-10 flex-1 rounded-sm px-4 text-sm font-semibold text-muted-foreground transition-colors aria-selected:bg-primary aria-selected:text-primary-foreground sm:flex-none"
          >
            {f.label}
          </button>
        ))}
      </div>
      {fuente === 'papeleria' ? <PapeleriaEmbed /> : <ConsultaCifsat />}
    </div>
  )
}

function ConsultaCifsat() {
  const [rfc, setRfc] = useState('')
  const [idCif, setIdCif] = useState('')
  const [errors, setErrors] = useState<Errors>({})
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [registro, setRegistro] = useState<Registro | null>(null)
  const [pdfUrl, setPdfUrl] = useState<string | null>(null)

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl)
    }
  }, [pdfUrl])

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const nextErrors: Errors = {}
    if (!isValidRfc(rfc)) nextErrors.rfc = 'Ingresa un RFC válido de 12 o 13 caracteres.'
    if (!isValidIdCif(idCif)) nextErrors.idCif = 'Ingresa un idCIF numérico válido.'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) return

    setLoading(true)
    setError(null)
    setRegistro(null)
    setPdfUrl(null)
    try {
      const res = await fetch('/api/cifsat/situacion-fiscal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rfc, idCif }),
      })
      const body = await res.json().catch(() => null)
      if (!res.ok || !body || body.error) throw new Error(body?.error ?? 'El servicio no respondió.')
      setRegistro(body.record)
      setPdfUrl(base64ToBlobUrl(body.pdf))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ocurrió un error.')
    } finally {
      setLoading(false)
    }
  }

  function reset() {
    setRfc('')
    setIdCif('')
    setErrors({})
    setError(null)
    setRegistro(null)
    setPdfUrl(null)
  }

  const d = registro?.domicilio

  return (
    <div className="flex flex-col gap-6">
      <form
        onSubmit={handleSubmit}
        noValidate
        className="flex flex-col gap-5 rounded-md border border-t-4 border-t-primary bg-card p-6 shadow-sm sm:p-8 md:flex-row md:items-start"
      >
        <div className="flex flex-1 flex-col gap-2">
          <label htmlFor="sf-rfc" className="text-sm font-medium text-foreground">
            RFC
          </label>
          <input
            id="sf-rfc"
            value={rfc}
            onChange={(e) => setRfc(normalizeRfc(e.target.value))}
            placeholder="LEOC780701976"
            autoComplete="off"
            spellCheck={false}
            maxLength={13}
            disabled={loading}
            aria-invalid={Boolean(errors.rfc)}
            aria-describedby={errors.rfc ? 'sf-rfc-error' : undefined}
            className={inputClass}
          />
          {errors.rfc && (
            <p id="sf-rfc-error" className="text-sm text-destructive">
              {errors.rfc}
            </p>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-2">
          <label htmlFor="sf-idcif" className="text-sm font-medium text-foreground">
            idCIF
          </label>
          <input
            id="sf-idcif"
            value={idCif}
            onChange={(e) => setIdCif(normalizeIdCif(e.target.value))}
            placeholder="26100029635"
            inputMode="numeric"
            autoComplete="off"
            disabled={loading}
            aria-invalid={Boolean(errors.idCif)}
            aria-describedby={errors.idCif ? 'sf-idcif-error' : undefined}
            className={inputClass}
          />
          {errors.idCif && (
            <p id="sf-idcif-error" className="text-sm text-destructive">
              {errors.idCif}
            </p>
          )}
        </div>
        <Button type="submit" size="lg" disabled={loading} className="h-12 gap-2 rounded-sm text-base font-semibold md:mt-7">
          {loading ? (
            <Loader2 className="size-5 animate-spin" aria-hidden="true" />
          ) : (
            <ScanSearch className="size-5" aria-hidden="true" />
          )}
          Consultar y generar
        </Button>
      </form>

      {error && (
        <p
          role="alert"
          className="rounded-sm border border-l-4 border-destructive/30 border-l-destructive bg-destructive/5 px-4 py-3 text-sm text-destructive"
        >
          {error}
        </p>
      )}

      {registro && pdfUrl && d && (
        <>
          <div className="flex flex-wrap gap-3">
            <Button
              type="button"
              size="lg"
              onClick={async () => downloadPdf(await (await fetch(pdfUrl)).blob(), rfcFileName(registro.rfc))}
              className="h-11 gap-2 rounded-sm text-sm font-semibold"
            >
              <Download className="size-4" aria-hidden="true" />
              Descargar PDF
            </Button>
            <Button type="button" variant="ghost" onClick={reset} className="h-11 gap-2 rounded-sm">
              <RotateCcw className="size-4" aria-hidden="true" />
              Nueva consulta
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-5">
            <section
              aria-label="Datos obtenidos del SAT"
              className="flex flex-col gap-5 rounded-md border border-border bg-card p-6 shadow-sm lg:col-span-2"
            >
              <dl className="flex flex-col gap-3">
                <Dato label="Nombre o razón social" value={registro.nombre} />
                <Dato label="RFC" value={registro.rfc} />
                <Dato label="CURP" value={registro.curp} />
                <Dato label="Inicio de operaciones" value={registro.inicioOperaciones} />
                <Dato label="Situación" value={registro.estatus} />
                <Dato label="Último cambio" value={registro.ultimoCambio} />
              </dl>
              <dl className="flex flex-col gap-3 border-t border-border pt-4">
                <Dato label="Entidad federativa" value={d.entidad} />
                <Dato label="Municipio o delegación" value={d.municipio} />
                <Dato label="Colonia" value={d.colonia} />
                <Dato
                  label="Vialidad"
                  value={[d.vialidad, d.numeroExterior && `No. ext. ${d.numeroExterior}`, d.numeroInterior && `No. int. ${d.numeroInterior}`]
                    .filter(Boolean)
                    .join(', ')}
                />
                <Dato label="Código postal" value={d.codigoPostal} />
              </dl>
              {registro.regimenes.length > 0 && (
                <dl className="flex flex-col gap-3 border-t border-border pt-4">
                  {registro.regimenes.map((r) => (
                    <Dato key={r.regimen} label={r.fechaAlta ? `Régimen · alta ${r.fechaAlta}` : 'Régimen'} value={r.regimen} />
                  ))}
                </dl>
              )}
            </section>
            <section aria-label="Vista previa del PDF" className="overflow-hidden rounded-md border border-border bg-muted lg:col-span-3">
              <iframe src={pdfUrl + PREVIEW_HASH} title="Vista previa del PDF de situación fiscal" className="h-[620px] w-full" />
            </section>
          </div>
        </>
      )}

      <AnalizadorPdf />
    </div>
  )
}
