'use client'

import { useState } from 'react'
import { FileText, Landmark } from 'lucide-react'
import { cn } from '@/lib/utils'
import { ConstanciaGenerator } from '@/components/cifsat/constancia/constancia-generator'
import { DatosFiscalesSat } from '@/components/cifsat/datos-fiscales/datos-fiscales-sat'

type TabId = 'cif' | 'datosFiscales'

const tabs: { id: TabId; label: string; icon: typeof FileText }[] = [
  { id: 'cif', label: 'CONSTANCIA CIF', icon: FileText },
  { id: 'datosFiscales', label: 'DATOS FISCALES SAT', icon: Landmark },
]

export function CifSatTabs() {
  const [active, setActive] = useState<TabId>('cif')

  return (
    <div className="flex flex-col gap-5">
      <div role="tablist" aria-label="Servicios CIF SAT" className="grid grid-cols-2 gap-1 rounded-xl border border-border bg-card p-1">
        {tabs.map(({ id, label, icon: Icon }) => {
          const isActive = active === id
          return (
            <button
              key={id}
              id={`cifsat-tab-${id}`}
              type="button"
              role="tab"
              aria-selected={isActive}
              aria-controls={`cifsat-panel-${id}`}
              onClick={() => setActive(id)}
              className={cn(
                'inline-flex h-10 items-center justify-center gap-2 rounded-lg px-2 text-xs font-semibold tracking-wide transition-colors',
                isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent hover:text-foreground',
              )}
            >
              <Icon className="size-4 shrink-0" aria-hidden="true" />
              {label}
            </button>
          )
        })}
      </div>

      <section
        id="cifsat-panel-cif"
        role="tabpanel"
        aria-labelledby="cifsat-tab-cif"
        hidden={active !== 'cif'}
        className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8"
      >
        <ConstanciaGenerator />
      </section>

      <section
        id="cifsat-panel-datosFiscales"
        role="tabpanel"
        aria-labelledby="cifsat-tab-datosFiscales"
        hidden={active !== 'datosFiscales'}
        className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8"
      >
        <DatosFiscalesSat />
      </section>
    </div>
  )
}
