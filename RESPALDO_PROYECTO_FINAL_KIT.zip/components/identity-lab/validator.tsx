'use client'

import { useState, type FormEvent } from 'react'
import { ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { validateKey, type ValidationResult } from '@/lib/identity-lab/engine'
import { addHistory } from '@/lib/identity-lab/history'
import { cn } from '@/lib/utils'
import { CARD, Field, INPUT, StatusIcon } from './shared'
import { CurpCorrection } from './curp-correction'

const STATUS: Record<ValidationResult['status'], { label: string; className: string }> = {
  valida: { label: 'ESTRUCTURA VÁLIDA', className: 'border-success/30 bg-success/10 text-success' },
  invalida: { label: 'ESTRUCTURA INVÁLIDA', className: 'border-destructive/30 bg-destructive/10 text-destructive' },
  verificar: { label: 'REQUIERE VERIFICACIÓN', className: 'border-imss/30 bg-imss-soft text-imss-soft-foreground' },
}

export function Validator() {
  const [value, setValue] = useState('')
  const [result, setResult] = useState<ValidationResult | null>(null)

  function runValidation(input: string) {
    const r = validateKey(input)
    setResult(r)
    if (r.value) addHistory('VALIDADOR', r.value, [`${r.value} · ${STATUS[r.status].label}`])
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    runValidation(value)
  }

  function applyCorrection(corrected: string) {
    setValue(corrected)
    runValidation(corrected)
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={onSubmit} className={CARD} noValidate>
        <Field label="CURP O RFC">
          {(id) => (
            <input
              id={id}
              className={`${INPUT} font-mono tracking-wider`}
              value={value}
              maxLength={24}
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setValue(e.target.value.toUpperCase())}
              placeholder="Escribe o pega la clave"
            />
          )}
        </Field>
        <Button type="submit" className="h-11 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90">
          <ShieldCheck className="size-4" aria-hidden="true" />
          VALIDAR
        </Button>
      </form>

      {result ? (
        <section aria-label="Resultado de la validación" className={CARD}>
          <div className="flex flex-wrap items-center gap-2">
            <span className={cn('rounded-full border px-3 py-1 text-xs font-semibold', STATUS[result.status].className)}>
              {STATUS[result.status].label}
            </span>
            <span className="text-xs font-semibold text-muted-foreground">{result.kind}</span>
          </div>
          {result.value ? <p className="font-mono text-lg font-semibold tracking-wider break-all">{result.value}</p> : null}
          <p className="text-sm leading-relaxed text-pretty">{result.summary}</p>
          {result.checks.length ? (
            <ul className="flex flex-col gap-2">
              {result.checks.map((c) => (
                <li key={c.label} className="flex items-start gap-2 rounded-xl border border-border bg-card p-2.5 text-sm">
                  <StatusIcon ok={c.ok} />
                  <span className="flex flex-col">
                    <span className="font-semibold">{c.label}</span>
                    <span className="leading-relaxed text-muted-foreground">{c.detail}</span>
                  </span>
                </li>
              ))}
            </ul>
          ) : null}
          {result.status === 'invalida' && result.value ? (
            <CurpCorrection key={result.value} original={result.value} isCurp={result.kind === 'CURP' || result.kind === 'Desconocido'} onApply={applyCorrection} />
          ) : null}
        </section>
      ) : null}
    </div>
  )
}
