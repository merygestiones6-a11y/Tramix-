'use client'

import { useMemo, useState, type FormEvent } from 'react'
import { Check, Copy, Download, ListChecks, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { curpListToCsv, validateCurpList, type CurpListRow } from '@/lib/identity-lab/engine'
import { addHistory } from '@/lib/identity-lab/history'
import { cn } from '@/lib/utils'
import { CARD, Errors, useCopyFeedback } from './shared'

type Filter = 'todas' | CurpListRow['status']

const STATUS_STYLE: Record<CurpListRow['status'], { label: string; className: string }> = {
  valida: { label: 'VÁLIDA', className: 'text-success' },
  invalida: { label: 'INVÁLIDA', className: 'text-destructive' },
  duplicada: { label: 'DUPLICADA', className: 'text-muted-foreground' },
}

function downloadCsv(content: string, fileName: string) {
  const url = URL.createObjectURL(new Blob([content], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
}

export function CurpList() {
  const [text, setText] = useState('')
  const [rows, setRows] = useState<CurpListRow[]>([])
  const [error, setError] = useState<string | null>(null)
  const [filter, setFilter] = useState<Filter>('todas')
  const { copied, failed, copy } = useCopyFeedback()

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    const result = validateCurpList(text)
    setError(result.error)
    setRows(result.rows)
    setFilter('todas')
    if (result.rows.length) {
      const valid = result.rows.filter((r) => r.status === 'valida').length
      addHistory(
        'MASIVO',
        `Lista de CURP · ${result.rows.length} · ${valid} válidas`,
        result.rows.slice(0, 50).map((r) => `${r.curp || r.input} · ${STATUS_STYLE[r.status].label}`),
      )
    }
  }

  const counts = useMemo(
    () => ({
      valida: rows.filter((r) => r.status === 'valida').length,
      invalida: rows.filter((r) => r.status === 'invalida').length,
      duplicada: rows.filter((r) => r.status === 'duplicada').length,
    }),
    [rows],
  )
  const visible = filter === 'todas' ? rows : rows.filter((r) => r.status === filter)
  const validList = rows.filter((r) => r.status === 'valida').map((r) => r.curp).join('\n')
  const invalidList = rows.filter((r) => r.status === 'invalida').map((r) => r.curp || r.input).join('\n')

  const filters: { id: Filter; label: string }[] = [
    { id: 'todas', label: `TODAS (${rows.length})` },
    { id: 'valida', label: `VÁLIDAS (${counts.valida})` },
    { id: 'invalida', label: `INVÁLIDAS (${counts.invalida})` },
    { id: 'duplicada', label: `DUPLICADAS (${counts.duplicada})` },
  ]

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={onSubmit} className={CARD} noValidate>
        <div className="flex flex-col gap-1.5">
          <label htmlFor="curp-list" className="text-sm font-semibold">
            VALIDAR LISTA DE CURP
          </label>
          <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
            Pega todas las CURP: una por línea, o separadas por coma, punto y coma o tabulador (por ejemplo, copiadas de Excel).
          </p>
        </div>
        <textarea
          id="curp-list"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={6}
          spellCheck={false}
          autoComplete="off"
          placeholder={'GODE561231MDFMZM01\nBADD110313HCMLNS06'}
          className="min-h-36 w-full resize-y rounded-2xl border border-input bg-background p-3 font-mono text-sm uppercase tracking-wider outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button type="submit" disabled={!text.trim()} className="h-11 flex-1 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90">
            <ListChecks className="size-4" aria-hidden="true" />
            VALIDAR TODAS
          </Button>
          {text ? (
            <Button
              type="button"
              variant="outline"
              className="h-11 gap-2 rounded-full"
              onClick={() => {
                setText('')
                setRows([])
                setError(null)
              }}
            >
              <X className="size-4" aria-hidden="true" />
              LIMPIAR
            </Button>
          ) : null}
        </div>
      </form>

      {error ? <Errors errors={[error]} /> : null}

      {rows.length ? (
        <section aria-label="Resultados de la lista de CURP" className={CARD}>
          <p className="text-sm">
            <span className="font-semibold">{rows.length}</span> CURP · <span className="text-success">{counts.valida} válidas</span> ·{' '}
            <span className="text-destructive">{counts.invalida} inválidas</span> ·{' '}
            <span className="text-muted-foreground">{counts.duplicada} duplicadas</span>
          </p>

          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={!counts.valida}
              className="gap-1.5 rounded-full"
              onClick={() => void copy('validas', validList)}
            >
              {copied === 'validas' ? <Check className="size-4 text-success" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
              {copied === 'validas' ? 'COPIADAS' : 'COPIAR VÁLIDAS'}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={!counts.invalida}
              className="gap-1.5 rounded-full"
              onClick={() => void copy('invalidas', invalidList)}
            >
              {copied === 'invalidas' ? <Check className="size-4 text-success" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
              {copied === 'invalidas' ? 'COPIADAS' : 'COPIAR INVÁLIDAS'}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5 rounded-full"
              onClick={() => downloadCsv(curpListToCsv(rows), 'validacion-curp.csv')}
            >
              <Download className="size-4" aria-hidden="true" />
              EXPORTAR CSV
            </Button>
          </div>
          {failed ? (
            <p role="status" className="text-sm text-destructive">
              No se pudo copiar. Selecciona el texto manualmente.
            </p>
          ) : null}

          <div role="group" aria-label="Filtrar resultados" className="flex flex-wrap gap-1.5">
            {filters.map((f) => (
              <button
                key={f.id}
                type="button"
                aria-pressed={filter === f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  'rounded-full border px-3 py-1 text-xs font-semibold transition-colors',
                  filter === f.id ? 'border-imss bg-imss text-imss-foreground' : 'border-border bg-card text-muted-foreground hover:text-foreground',
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          <ul className="flex max-h-[28rem] flex-col gap-2 overflow-y-auto">
            {visible.map((r, i) => (
              <li key={`${r.line}-${i}-${r.input}`} className="flex flex-col gap-1 rounded-xl border border-border bg-card p-2.5 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs tracking-wider break-all sm:text-sm">{r.curp || r.input}</span>
                  <div className="flex shrink-0 items-center gap-1.5">
                    <span className={cn('text-xs font-semibold', STATUS_STYLE[r.status].className)}>{STATUS_STYLE[r.status].label}</span>
                    <button
                      type="button"
                      onClick={() => void copy(`row-${r.line}-${i}`, r.curp || r.input)}
                      aria-label={`Copiar ${r.curp || r.input}`}
                      className="rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                    >
                      {copied === `row-${r.line}-${i}` ? <Check className="size-4 text-success" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                    </button>
                  </div>
                </div>
                <span className={cn('leading-relaxed', r.status === 'invalida' ? 'text-destructive' : 'text-muted-foreground')}>
                  Línea {r.line} · {r.detail}
                </span>
              </li>
            ))}
          </ul>
          <p className="text-xs leading-relaxed text-muted-foreground">
            Revisa la estructura y el dígito verificador. No confirma que la CURP esté registrada en RENAPO.
          </p>
        </section>
      ) : null}
    </div>
  )
}
