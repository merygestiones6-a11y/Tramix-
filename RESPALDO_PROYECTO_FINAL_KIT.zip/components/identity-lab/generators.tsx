'use client'

import { useState, type FormEvent } from 'react'
import { Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  generateCurp,
  generateRfcFromCurp,
  generateRfcFromData,
  normalizeText,
  type GenerationResult,
} from '@/lib/identity-lab/engine'
import { addHistory } from '@/lib/identity-lab/history'
import { CARD, EMPTY_PERSON, Field, INPUT, PersonFields, ResultsList, type PersonValues } from './shared'

function personLabel(p: PersonValues): string {
  return normalizeText([p.nombre, p.primerApellido, p.segundoApellido].filter(Boolean).join(' '))
}

function SubmitButton({ children }: { children: string }) {
  return (
    <Button type="submit" className="h-11 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90">
      <Sparkles className="size-4" aria-hidden="true" />
      {children}
    </Button>
  )
}

export function RfcFromData() {
  const [person, setPerson] = useState<PersonValues>(EMPTY_PERSON)
  const [result, setResult] = useState<GenerationResult | null>(null)

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    const r = generateRfcFromData(person)
    setResult(r)
    if (r.ok) addHistory('RFC POR DATOS', `${personLabel(person)} · ${person.fechaNacimiento}`, r.candidates.map((c) => c.id))
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={onSubmit} className={CARD} noValidate>
        <PersonFields value={person} onChange={setPerson} />
        <SubmitButton>CALCULAR RFC</SubmitButton>
      </form>
      {result ? <ResultsList result={result} /> : null}
    </div>
  )
}

export function RfcFromCurp() {
  const [curp, setCurp] = useState('')
  const [person, setPerson] = useState<PersonValues>(EMPTY_PERSON)
  const [result, setResult] = useState<GenerationResult | null>(null)

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    const r = generateRfcFromCurp(curp, person)
    setResult(r)
    if (r.ok) addHistory('RFC POR CURP', normalizeText(curp), r.candidates.map((c) => c.id))
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={onSubmit} className={CARD} noValidate>
        <Field label="CURP">
          {(id) => (
            <input
              id={id}
              className={`${INPUT} font-mono tracking-wider`}
              value={curp}
              maxLength={18}
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setCurp(e.target.value.toUpperCase())}
              placeholder="18 caracteres"
            />
          )}
        </Field>
        <details className="rounded-2xl border border-border bg-card p-3">
          <summary className="cursor-pointer text-sm font-semibold">Nombre completo (opcional, para la homoclave)</summary>
          <div className="mt-3">
            <PersonFields value={person} onChange={setPerson} withDate={false} />
          </div>
        </details>
        <SubmitButton>CALCULAR RFC</SubmitButton>
      </form>
      {result ? <ResultsList result={result} /> : null}
    </div>
  )
}

export function CurpFromData() {
  const [person, setPerson] = useState<PersonValues>(EMPTY_PERSON)
  const [result, setResult] = useState<GenerationResult | null>(null)

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    const r = generateCurp(person)
    setResult(r)
    if (r.ok) {
      addHistory('CURP POR DATOS', `${personLabel(person)} · ${person.fechaNacimiento} · ${person.sexo} · ${person.entidad}`, r.candidates.map((c) => c.id))
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={onSubmit} className={CARD} noValidate>
        <PersonFields value={person} onChange={setPerson} withSexAndState />
        <SubmitButton>CALCULAR CURP</SubmitButton>
      </form>
      {result ? <ResultsList result={result} /> : null}
    </div>
  )
}
