'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import { AutofillPanel } from './autofill-panel'
import { Batch } from './batch'
import { CurpFromData, RfcFromCurp, RfcFromData } from './generators'
import { HistoryPanel } from './history-panel'
import { Validator } from './validator'

const TABS = [
  { id: 'llenado', label: 'LLENADO AUTOMÁTICO', Panel: AutofillPanel },
  { id: 'rfc-datos', label: 'RFC POR DATOS', Panel: RfcFromData },
  { id: 'rfc-curp', label: 'RFC POR CURP', Panel: RfcFromCurp },
  { id: 'curp-datos', label: 'CURP POR DATOS', Panel: CurpFromData },
  { id: 'validador', label: 'VALIDADOR', Panel: Validator },
  { id: 'masivo', label: 'MASIVO', Panel: Batch },
  { id: 'historial', label: 'HISTORIAL', Panel: HistoryPanel },
] as const

export function IdentityLab() {
  const [active, setActive] = useState<(typeof TABS)[number]['id']>('rfc-datos')

  return (
    <div className="flex flex-col gap-4">
      <div role="tablist" aria-label="Herramientas de IDENTITY LAB" className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            id={`tab-${t.id}`}
            aria-selected={active === t.id}
            aria-controls={`panel-${t.id}`}
            onClick={() => setActive(t.id)}
            className={cn(
              'h-11 rounded-full border px-3 text-xs font-semibold tracking-wide transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              active === t.id
                ? 'border-imss bg-imss text-imss-foreground'
                : 'border-border bg-card text-muted-foreground hover:bg-accent hover:text-foreground',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {TABS.map(({ id, Panel }) => (
        <div key={id} role="tabpanel" id={`panel-${id}`} aria-labelledby={`tab-${id}`} hidden={active !== id}>
          <Panel />
        </div>
      ))}
    </div>
  )
}
