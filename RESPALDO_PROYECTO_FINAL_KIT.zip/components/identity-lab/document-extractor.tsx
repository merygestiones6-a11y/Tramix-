'use client'

import { memo, useEffect, useRef, useState, type DragEvent } from 'react'
import { AlertTriangle, Check, Copy, Download, FileText, Filter, Landmark, Loader2, RotateCcw, ScanText, Upload, X } from 'lucide-react'
import { BuroCredito } from '@/components/buro/buro-credito'
import { Button } from '@/components/ui/button'
import type { BuroRecord } from '@/lib/buro/schema'
import { generateCurp, type CurpInput } from '@/lib/identity-lab/engine'
import { ACCEPT_ATTR, checkSelection, EXTRACT_LIMITS, SUPPORTED_LABEL, type DocKind } from '@/lib/identity-lab/doc-extract/limits'
import {
  ERROR_MESSAGE,
  evaluate,
  listText,
  MODE_LABEL,
  type ErrorCode,
  type Evaluation,
  type FileStatus,
} from '@/lib/identity-lab/doc-extract/modes'
import { inspectFile, readDocument, type ReadOutput } from '@/lib/identity-lab/doc-extract/read-files'
import { compareCurp, documentCurp, toCurpInput, type ExtractedPerson, type ExtractMode, type ModeData } from '@/lib/identity-lab/doc-extract/schema'
import { cn } from '@/lib/utils'
import { CARD, Errors, PersonFields, useCopyFeedback } from './shared'

interface PickedFile {
  id: string
  file: File
  kind: DocKind
  preview: string | null
}

interface Job {
  status: FileStatus
  label: string
  evaluation: Evaluation | null
  errorCode: ErrorCode | null
  warnings: string[]
  ms: number | null
  requestId: string | null
}

interface ApiResponse {
  result?: ModeData
  error?: string
  code?: ErrorCode
  requestId?: string
  timings?: { modelMs?: number; serverMs?: number }
}

type ReadResult = ReadOutput & { timings: { readMs: number; ocrMs: number; imageBytes: number } }

const KIND_LABEL: Record<DocKind, string> = { pdf: 'PDF', image: 'IMAGEN', docx: 'DOCX', txt: 'TXT' }
const BUTTON_MODES: Exclude<ExtractMode, 'general'>[] = ['curp', 'rfc', 'fiscal', 'cfe']
const DONE: FileStatus[] = ['COMPLETADO', 'INCOMPLETO']

const STATUS_STYLE: Record<FileStatus, string> = {
  PENDIENTE: 'border-border bg-muted text-muted-foreground',
  PROCESANDO: 'border-imss/30 bg-imss-soft text-imss-soft-foreground',
  COMPLETADO: 'border-success/30 bg-success/10 text-success',
  INCOMPLETO: 'border-warning/40 bg-warning/10 text-warning',
  ERROR: 'border-destructive/30 bg-destructive/10 text-destructive',
}

const jobKey = (mode: ExtractMode, id: string) => `${mode}:${id}`
const isAbort = (e: unknown) => e instanceof DOMException && e.name === 'AbortError'
const hasContent = (r: ReadOutput) => r.segments.some((s) => s.text.trim()) || r.images.length > 0

class Cancelled extends Error {}

/** FIFO slots shared by every file and mode; queued work of an abandoned mode can be dropped. */
function createScheduler(limit: number) {
  let active = 0
  let queue: { mode: ExtractMode; resolve: () => void; reject: (e: Error) => void }[] = []
  return {
    acquire(mode: ExtractMode) {
      if (active < limit) {
        active++
        return Promise.resolve()
      }
      return new Promise<void>((resolve, reject) => queue.push({ mode, resolve, reject }))
    },
    release() {
      const next = queue.shift()
      if (next) next.resolve()
      else active--
    },
    dropQueued(keep?: ExtractMode) {
      const dropped = queue.filter((q) => q.mode !== keep)
      queue = queue.filter((q) => q.mode === keep)
      dropped.forEach((q) => q.reject(new Cancelled()))
    },
  }
}

export function DocumentExtractor({ initialBuro = null }: { initialBuro?: BuroRecord | null } = {}) {
  const [buroOpen, setBuroOpen] = useState(Boolean(initialBuro))
  const [files, setFiles] = useState<PickedFile[]>([])
  const [mode, setMode] = useState<ExtractMode>('general')
  const [jobs, setJobs] = useState<Record<string, Job>>({})
  const [errors, setErrors] = useState<string[]>([])
  const [dragging, setDragging] = useState(false)
  const [onlyPending, setOnlyPending] = useState(false)
  const filesRef = useRef<PickedFile[]>([])
  const modeRef = useRef<ExtractMode>('general')
  const jobsRef = useRef<Record<string, Job>>({})
  const inflight = useRef(new Set<string>())
  const readCache = useRef(new Map<string, Promise<ReadResult>>())
  const scheduler = useRef(createScheduler(EXTRACT_LIMITS.concurrency))
  const session = useRef(new AbortController())
  const fileInput = useRef<HTMLInputElement>(null)
  const { copied, failed, copy } = useCopyFeedback()

  useEffect(() => {
    // Strict Mode remounts in development; a fresh controller keeps the remounted panel usable.
    const controller = new AbortController()
    session.current = controller
    const cache = readCache.current
    return () => {
      controller.abort()
      cache.clear()
      filesRef.current.forEach((f) => f.preview && URL.revokeObjectURL(f.preview))
    }
  }, [])

  function commitJobs(update: (prev: Record<string, Job>) => Record<string, Job>) {
    jobsRef.current = update(jobsRef.current)
    setJobs(jobsRef.current)
  }

  function patchJob(key: string, patch: Partial<Job>) {
    commitJobs((prev) => (prev[key] ? { ...prev, [key]: { ...prev[key], ...patch } } : prev))
  }

  /** The text and prepared images of a file, read once and reused by every mode. */
  function getRead(f: PickedFile, onLabel: (label: string) => void, signal: AbortSignal): Promise<ReadResult> {
    const cache = readCache.current
    const hit = cache.get(f.id)
    if (hit) {
      cache.delete(f.id)
      cache.set(f.id, hit)
      return hit
    }
    const pending = readDocument(f.file, f.kind, (_, label) => onLabel(label), signal) as Promise<ReadResult>
    cache.set(f.id, pending)
    pending.then(
      (r) => {
        if (r.errorCode && !hasContent(r)) cache.delete(f.id)
      },
      () => cache.delete(f.id),
    )
    while (cache.size > EXTRACT_LIMITS.readCacheEntries) cache.delete(cache.keys().next().value!)
    return pending
  }

  async function processJob(m: ExtractMode, f: PickedFile, signal: AbortSignal) {
    const key = jobKey(m, f.id)
    try {
      await scheduler.current.acquire(m)
    } catch {
      inflight.current.delete(key)
      commitJobs((prev) => {
        const next = { ...prev }
        delete next[key]
        return next
      })
      return
    }
    const t0 = performance.now()
    const elapsed = () => Math.round(performance.now() - t0)
    try {
      if (signal.aborted) return
      patchJob(key, { status: 'PROCESANDO', label: 'Leyendo archivo' })
      const reused = readCache.current.has(f.id)
      const read = await getRead(f, (label) => patchJob(key, { label }), signal)
      const readMs = elapsed()
      if (!hasContent(read)) {
        const code = read.errorCode ?? 'ILEGIBLE'
        patchJob(key, { status: 'ERROR', errorCode: code, warnings: [...read.errors, ...read.warnings], ms: elapsed() })
        console.info(`[identity-lab/extract] modo=${m} tipo=${f.kind} bytes=${f.file.size} lectura=${readMs}ms etapa=lectura codigo=${code}`)
        return
      }
      patchJob(key, { label: 'Analizando con IA', warnings: read.warnings })

      const tPrep = performance.now()
      const body = JSON.stringify({ mode: m, segments: read.segments, images: read.images })
      const prepMs = Math.round(performance.now() - tPrep)
      const tFetch = performance.now()
      let res: Response
      try {
        res = await fetch('/api/identity-lab/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body,
          signal: AbortSignal.any([signal, AbortSignal.timeout(EXTRACT_LIMITS.requestTimeoutMs)]),
        })
      } catch (error) {
        if (signal.aborted) return
        const code: ErrorCode = error instanceof DOMException && error.name === 'TimeoutError' ? 'TIEMPO' : 'RED'
        patchJob(key, { status: 'ERROR', errorCode: code, ms: elapsed() })
        console.info(`[identity-lab/extract] modo=${m} tipo=${f.kind} total=${elapsed()}ms etapa=red codigo=${code}`)
        return
      }
      const data = (await res.json().catch(() => ({}))) as ApiResponse
      const fetchMs = Math.round(performance.now() - tFetch)
      const serverMs = data.timings?.serverMs
      // Only durations, sizes, stages and codes: never names, CURP, RFC, IDCIF, service numbers or text.
      console.info(
        `[identity-lab/extract] id=${data.requestId ?? '-'} modo=${m} tipo=${f.kind} bytes=${f.file.size} lectura=${reused ? 'reutilizada' : `${read.timings.readMs}ms`} ocr=${reused ? 0 : read.timings.ocrMs}ms imagenes=${read.images.length}(${read.timings.imageBytes}B) preparar=${prepMs}ms envio=${body.length}B red=${serverMs != null ? fetchMs - serverMs : '?'}ms modelo=${data.timings?.modelMs ?? '?'}ms total=${elapsed()}ms http=${res.status}${data.code ? ` codigo=${data.code}` : ''}`,
      )
      if (!res.ok || !data.result || data.result.mode !== m) {
        const code: ErrorCode = data.code ?? (res.status === 504 ? 'TIEMPO' : res.status === 413 ? 'LIMITE' : 'RESPUESTA')
        patchJob(key, { status: 'ERROR', errorCode: code, requestId: data.requestId ?? null, ms: elapsed() })
        return
      }
      const evaluation = evaluate(data.result)
      patchJob(key, { status: evaluation.status, evaluation, errorCode: null, requestId: data.requestId ?? null, ms: elapsed() })
    } catch (error) {
      if (isAbort(error) || signal.aborted) return
      patchJob(key, { status: 'ERROR', errorCode: 'ILEGIBLE', ms: elapsed() })
    } finally {
      scheduler.current.release()
      inflight.current.delete(key)
    }
  }

  /** Queues a mode for files without a result in that mode; repeated clicks never duplicate work. */
  function enqueue(m: ExtractMode, items: PickedFile[], force = false) {
    const signal = session.current.signal
    const queued: PickedFile[] = []
    for (const f of items) {
      const key = jobKey(m, f.id)
      if (inflight.current.has(key)) continue
      const existing = jobsRef.current[key]
      if (!force && existing && (DONE.includes(existing.status) || existing.status === 'ERROR')) continue
      inflight.current.add(key)
      queued.push(f)
    }
    if (!queued.length) return
    commitJobs((prev) => {
      const next = { ...prev }
      for (const f of queued) {
        next[jobKey(m, f.id)] = { status: 'PENDIENTE', label: 'En cola', evaluation: null, errorCode: null, warnings: [], ms: null, requestId: null }
      }
      return next
    })
    for (const f of queued) void processJob(m, f, signal)
  }

  async function addFiles(list: FileList | File[]) {
    const incoming = Array.from(list)
    if (!incoming.length) return
    const selectionError = checkSelection([...filesRef.current.map((f) => f.file.size), ...incoming.map((f) => f.size)])
    if (selectionError) {
      setErrors([selectionError])
      return
    }
    const checks = await Promise.all(incoming.map((file) => inspectFile(file)))
    const accepted: PickedFile[] = []
    const rejected: string[] = []
    checks.forEach((check, i) => {
      if ('error' in check) rejected.push(check.error)
      else {
        const file = incoming[i]
        accepted.push({ id: crypto.randomUUID(), file, kind: check.kind, preview: check.kind === 'image' ? URL.createObjectURL(file) : null })
      }
    })
    setErrors(rejected)
    filesRef.current = [...filesRef.current, ...accepted]
    setFiles(filesRef.current)
    if (fileInput.current) fileInput.current.value = ''
    enqueue(modeRef.current, accepted)
  }

  function onDrop(e: DragEvent) {
    e.preventDefault()
    setDragging(false)
    addFiles(e.dataTransfer.files)
  }

  function selectMode(next: ExtractMode) {
    if (next !== modeRef.current) {
      scheduler.current.dropQueued(next)
      modeRef.current = next
      setMode(next)
    }
    enqueue(next, filesRef.current)
  }

  function retry(items: PickedFile[]) {
    enqueue(modeRef.current, items, true)
  }

  function removeFile(id: string) {
    const target = filesRef.current.find((f) => f.id === id)
    if (target?.preview) URL.revokeObjectURL(target.preview)
    readCache.current.delete(id)
    filesRef.current = filesRef.current.filter((f) => f.id !== id)
    setFiles(filesRef.current)
    commitJobs((prev) => Object.fromEntries(Object.entries(prev).filter(([k]) => !k.endsWith(`:${id}`))))
  }

  function reset() {
    session.current.abort()
    session.current = new AbortController()
    scheduler.current.dropQueued()
    inflight.current.clear()
    readCache.current.clear()
    filesRef.current.forEach((f) => f.preview && URL.revokeObjectURL(f.preview))
    filesRef.current = []
    setFiles([])
    commitJobs(() => ({}))
    setErrors([])
    setOnlyPending(false)
    if (fileInput.current) fileInput.current.value = ''
  }

  const rows = files.map((f, index) => ({ f, index, job: jobs[jobKey(mode, f.id)] ?? null }))
  const count = (s: FileStatus) => rows.filter((r) => r.job?.status === s).length
  const completed = count('COMPLETADO')
  const incomplete = count('INCOMPLETO')
  const failedCount = count('ERROR')
  const finished = completed + incomplete + failedCount
  const busy = finished < rows.length && rows.some((r) => r.job && !DONE.includes(r.job.status) && r.job.status !== 'ERROR')
  const list = listText(mode, rows.map((r) => ({ fileName: r.f.file.name, evaluation: r.job?.evaluation ?? null })))
  const visible = onlyPending ? rows.filter((r) => r.job?.status === 'INCOMPLETO' || r.job?.status === 'ERROR') : rows
  const failedFiles = rows.filter((r) => r.job?.status === 'ERROR').map((r) => r.f)

  function download() {
    const blob = new Blob([`${list}\n`], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `identity-lab-${mode}-${new Date().toISOString().slice(0, 10)}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (buroOpen) return <BuroCredito initial={initialBuro} onExit={() => setBuroOpen(false)} />

  return (
    <div className="flex flex-col gap-4">
      <section className={CARD} aria-labelledby="extractor-title">
        <h2 id="extractor-title" className="flex items-center gap-2 text-sm font-semibold tracking-wide text-foreground">
          <ScanText className="size-5 text-imss" aria-hidden="true" />
          EXTRACTOR DE DOCUMENTOS
        </h2>

        <div
          onDragOver={(e) => {
            e.preventDefault()
            setDragging(true)
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={cn(
            'flex flex-col items-center gap-3 rounded-2xl border border-dashed p-5 text-center transition-colors',
            dragging ? 'border-imss bg-imss-soft' : 'border-border bg-card/50',
          )}
        >
          <Upload className="size-6 text-imss" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
            {SUPPORTED_LABEL} · hasta {EXTRACT_LIMITS.maxFileBytes / 1024 / 1024} MB por archivo · lotes de hasta {EXTRACT_LIMITS.maxFiles} archivos
          </p>
          <Button type="button" variant="outline" className="rounded-full" onClick={() => fileInput.current?.click()}>
            <FileText className="size-4" aria-hidden="true" />
            SELECCIONAR ARCHIVOS
          </Button>
          <input
            ref={fileInput}
            type="file"
            multiple
            accept={ACCEPT_ATTR}
            className="sr-only"
            tabIndex={-1}
            aria-label="Seleccionar archivos"
            onChange={(e) => e.target.files && addFiles(e.target.files)}
          />
        </div>

        <div className="flex flex-col gap-2">
          <p id="extractor-modes" className="text-xs font-semibold tracking-wide text-muted-foreground">
            {mode === 'general' ? 'DETECCIÓN AUTOMÁTICA ACTIVA · ELIGE UNA EXTRACCIÓN ESPECÍFICA' : `MODO: ${MODE_LABEL[mode]}`}
          </p>
          <div role="group" aria-labelledby="extractor-modes" className="grid grid-cols-2 gap-2">
            {BUTTON_MODES.map((m) => (
              <Button
                key={m}
                type="button"
                variant={mode === m ? 'default' : 'outline'}
                aria-pressed={mode === m}
                className={cn('h-auto min-h-11 whitespace-normal rounded-2xl text-xs leading-tight', mode === m && 'bg-imss text-imss-foreground hover:bg-imss/90')}
                onClick={() => selectMode(m)}
              >
                {MODE_LABEL[m]}
              </Button>
            ))}
            <Button
              type="button"
              variant="outline"
              className="col-span-2 h-auto min-h-11 whitespace-normal rounded-2xl text-xs leading-tight"
              onClick={() => setBuroOpen(true)}
            >
              <Landmark className="size-4" aria-hidden="true" />
              BURÓ DE CRÉDITO
            </Button>
          </div>
          {mode !== 'general' ? (
            <button
              type="button"
              onClick={() => selectMode('general')}
              className="self-start text-xs text-imss underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Volver a detección automática
            </button>
          ) : null}
        </div>

        <p className="text-xs leading-relaxed text-muted-foreground">
          Los archivos se leen en tu dispositivo. El texto y las imágenes se envían a Vercel AI Gateway (modelo de Google) para interpretarlos; no se guardan.
        </p>

        <Errors errors={errors} />
      </section>

      {rows.length ? (
        <section className={CARD} aria-labelledby="extractor-results">
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between gap-2">
              <h2 id="extractor-results" className="text-sm font-semibold tracking-wide text-foreground">
                RESULTADOS · {MODE_LABEL[mode]}
              </h2>
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground" aria-live="polite">
                {busy ? <Loader2 className="size-3.5 animate-spin text-imss" aria-hidden="true" /> : null}
                {finished} de {rows.length}
              </p>
            </div>
            <div
              role="progressbar"
              aria-label="Progreso del lote"
              aria-valuemin={0}
              aria-valuemax={rows.length}
              aria-valuenow={finished}
              className="h-1.5 overflow-hidden rounded-full bg-muted"
            >
              <div className="h-full bg-imss transition-[width]" style={{ width: `${(finished / rows.length) * 100}%` }} />
            </div>
            <p className="text-xs text-muted-foreground">
              <span className="text-success">{completed} completos</span> · <span className="text-warning">{incomplete} incompletos</span> ·{' '}
              <span className="text-destructive">{failedCount} con error</span>
            </p>
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <Button type="button" className="rounded-full bg-imss text-imss-foreground hover:bg-imss/90" disabled={!list} onClick={() => copy('all', list)}>
              {copied === 'all' ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
              COPIAR LISTA COMPLETA
            </Button>
            <Button type="button" variant="outline" className="rounded-full" disabled={!list} onClick={download}>
              <Download className="size-4" aria-hidden="true" />
              DESCARGAR TXT
            </Button>
            {incomplete + failedCount > 0 ? (
              <Button type="button" variant="outline" className="rounded-full" aria-pressed={onlyPending} onClick={() => setOnlyPending((v) => !v)}>
                <Filter className="size-4" aria-hidden="true" />
                {onlyPending ? 'VER TODOS' : `VER PENDIENTES (${incomplete + failedCount})`}
              </Button>
            ) : null}
            {failedFiles.length ? (
              <Button type="button" variant="outline" className="rounded-full" onClick={() => retry(failedFiles)}>
                <RotateCcw className="size-4" aria-hidden="true" />
                REINTENTAR FALLIDOS ({failedFiles.length})
              </Button>
            ) : null}
          </div>
          {failed ? <p className="text-xs text-destructive">No se pudo copiar.</p> : null}

          <ol className="flex flex-col gap-3" aria-label="Archivos del lote">
            {visible.map(({ f, index, job }) => (
              <FileCard
                key={f.id}
                index={index}
                file={f}
                job={job}
                mode={mode}
                copied={copied}
                onCopy={copy}
                onRetry={() => retry([f])}
                onRemove={() => removeFile(f.id)}
              />
            ))}
          </ol>

          <Button type="button" variant="outline" className="rounded-full" onClick={reset}>
            <RotateCcw className="size-4" aria-hidden="true" />
            PROCESAR OTROS DOCUMENTOS
          </Button>
        </section>
      ) : null}
    </div>
  )
}

const FileCard = memo(function FileCard({
  index,
  file: f,
  job,
  mode,
  copied,
  onCopy,
  onRetry,
  onRemove,
}: {
  index: number
  file: PickedFile
  job: Job | null
  mode: ExtractMode
  copied: string | null
  onCopy: (key: string, text: string) => void
  onRetry: () => void
  onRemove: () => void
}) {
  const status: FileStatus = job?.status ?? 'PENDIENTE'
  const working = status === 'PENDIENTE' || status === 'PROCESANDO'
  const evaluation = job?.evaluation
  const prefix = `${mode}:${f.id}`

  return (
    <li className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-3" aria-busy={working}>
      <div className="flex items-center gap-3">
        <div className="flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-border bg-muted">
          {f.preview ? (
            // eslint-disable-next-line @next/next/no-img-element -- local object URL preview
            <img src={f.preview} alt="" className="size-full object-cover" />
          ) : (
            <FileText className="size-5 text-muted-foreground" aria-hidden="true" />
          )}
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <p className="truncate text-sm font-medium text-foreground">
            {index + 1}. {f.file.name}
          </p>
          <p className="text-xs text-muted-foreground">
            {KIND_LABEL[f.kind]} · {(f.file.size / 1024 / 1024).toFixed(2)} MB{job?.ms ? ` · ${(job.ms / 1000).toFixed(1)} s` : ''}
          </p>
        </div>
        <span className={cn('shrink-0 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide', STATUS_STYLE[status])}>{status}</span>
        <Button type="button" variant="ghost" size="icon" className="size-8 shrink-0 rounded-full" aria-label={`Quitar ${f.file.name}`} onClick={onRemove}>
          <X className="size-4" aria-hidden="true" />
        </Button>
      </div>

      {working ? (
        <p className="flex items-center gap-1.5 text-xs text-muted-foreground" aria-live="polite">
          <Loader2 className="size-3.5 animate-spin text-imss" aria-hidden="true" />
          {job?.label ?? 'En cola'}
        </p>
      ) : null}

      {status === 'ERROR' && job?.errorCode ? (
        <div role="alert" className="flex flex-col gap-1 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          <p className="leading-relaxed">{ERROR_MESSAGE[job.errorCode]}</p>
          {job.warnings.map((w) => (
            <p key={w} className="text-xs leading-relaxed">
              {w}
            </p>
          ))}
          <p className="text-xs opacity-80">
            Código {job.errorCode}
            {job.requestId ? ` · solicitud ${job.requestId}` : ''}
          </p>
        </div>
      ) : job?.warnings.length ? (
        <div className="flex flex-col gap-1 rounded-xl border border-imss/30 bg-imss-soft p-3 text-xs text-imss-soft-foreground">
          {job.warnings.map((w) => (
            <p key={w} className="flex items-start gap-2 leading-relaxed">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
              {w}
            </p>
          ))}
        </div>
      ) : null}

      {evaluation ? <EvaluationView evaluation={evaluation} mode={mode} prefix={prefix} copied={copied} onCopy={onCopy} /> : null}

      {status === 'ERROR' || status === 'INCOMPLETO' ? (
        <Button type="button" variant="outline" size="sm" className="self-start rounded-full" onClick={onRetry}>
          <RotateCcw className="size-4" aria-hidden="true" />
          REINTENTAR
        </Button>
      ) : null}
    </li>
  )
})

function CopyButton({ id, text, label, copied, onCopy }: { id: string; text: string; label: string; copied: string | null; onCopy: (key: string, text: string) => void }) {
  return (
    <Button type="button" variant="outline" size="sm" className="shrink-0 rounded-full" aria-label={label} onClick={() => onCopy(id, text)}>
      {copied === id ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
      COPIAR
    </Button>
  )
}

function EvaluationView({
  evaluation,
  mode,
  prefix,
  copied,
  onCopy,
}: {
  evaluation: Evaluation
  mode: ExtractMode
  prefix: string
  copied: string | null
  onCopy: (key: string, text: string) => void
}) {
  return (
    <div className="flex flex-col gap-3">
      {evaluation.notes.map((n) => (
        <p key={n} className="text-sm text-warning">
          {n}
        </p>
      ))}

      {evaluation.block ? (
        <div className="flex justify-end">
          <CopyButton id={`${prefix}:block`} text={evaluation.block} label="Copiar datos detectados" copied={copied} onCopy={onCopy} />
        </div>
      ) : null}

      {evaluation.people.map((p, pi) => (
        <div key={pi} className="flex flex-col gap-2">
          {p.label ? <h3 className="text-xs font-semibold tracking-wide text-imss">{p.label}</h3> : null}

          {p.line ? (
            <div className="flex items-center justify-between gap-2 rounded-xl border border-imss/30 bg-imss-soft p-3">
              <div className="flex min-w-0 flex-col gap-1">
                <p className="break-all font-mono text-base font-semibold text-imss-soft-foreground">{p.line.value}</p>
                {p.line.condition === 'CANDIDATA' ? (
                  <p className="text-[11px] font-semibold tracking-wide text-warning">
                    {mode === 'rfc' ? 'RFC CANDIDATO' : 'CURP CANDIDATA'} · PENDIENTE DE VERIFICACIÓN OFICIAL
                  </p>
                ) : (
                  <p className="text-[11px] font-semibold tracking-wide text-imss-soft-foreground/80">EXTRAÍDO DEL DOCUMENTO</p>
                )}
              </div>
              <CopyButton id={`${prefix}:${pi}`} text={p.line.value} label={`Copiar ${p.line.value}`} copied={copied} onCopy={onCopy} />
            </div>
          ) : null}

          {p.fields.length ? (
            <dl className="flex flex-col divide-y divide-border rounded-xl border border-border">
              {p.fields.map((field, fi) => (
                <div key={fi} className="flex flex-col gap-0.5 px-3 py-2">
                  <dt className="flex flex-wrap items-center gap-2 text-[11px] font-semibold tracking-wide text-muted-foreground">
                    {field.campo}
                    {field.origin === 'DE LA CURP' ? <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px]">DERIVADO DE LA CURP</span> : null}
                  </dt>
                  <dd className={cn('break-words font-mono text-sm', field.missing ? 'text-destructive' : 'text-foreground')}>
                    {field.valor}
                    {field.pagina ? <span className="ml-2 font-sans text-xs text-muted-foreground">p. {field.pagina}</span> : null}
                  </dd>
                </div>
              ))}
            </dl>
          ) : null}

          {p.notes.map((n) => (
            <p key={n} className="text-xs leading-relaxed text-muted-foreground">
              {n}
            </p>
          ))}

          {mode === 'curp' && p.person?.datosCurp ? <CurpCandidate person={p.person} /> : null}
        </div>
      ))}

      {evaluation.contradicciones.length ? (
        <div role="alert" className="flex flex-col gap-1 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          <p className="font-semibold">CONTRADICCIONES</p>
          {evaluation.contradicciones.map((c) => (
            <p key={c} className="leading-relaxed">
              {c}
            </p>
          ))}
        </div>
      ) : null}
    </div>
  )
}

function CurpCandidate({ person }: { person: ExtractedPerson }) {
  const [values, setValues] = useState<CurpInput>(() => toCurpInput(person.datosCurp!))
  const [outcome, setOutcome] = useState<{ curp: string | null; errors: string[] } | null>(null)
  const { copied, copy } = useCopyFeedback()
  const printed = documentCurp(person)

  function calculate() {
    const generated = generateCurp(values, 1)
    setOutcome({ curp: generated.ok ? generated.candidates[0]?.id ?? null : null, errors: generated.errors })
  }

  const diff = outcome?.curp && printed ? compareCurp(printed, outcome.curp) : null

  return (
    <details className="rounded-2xl border border-border bg-card/50 p-3">
      <summary className="cursor-pointer text-xs font-semibold tracking-wide text-foreground">CURP CANDIDATA</summary>
      <div className="mt-3 flex flex-col gap-3">
        <PersonFields value={values} onChange={setValues} withSexAndState />
        <Button type="button" variant="outline" className="rounded-full" onClick={calculate}>
          CALCULAR CURP
        </Button>
        {outcome ? <Errors errors={outcome.errors} /> : null}
        {outcome?.curp ? (
          <div className="flex flex-col gap-2 rounded-2xl border border-imss/30 bg-imss-soft p-3">
            <div className="flex items-center justify-between gap-2">
              <p className="break-all font-mono text-base font-semibold text-imss-soft-foreground">{outcome.curp}</p>
              <Button type="button" variant="outline" size="sm" className="shrink-0 rounded-full" onClick={() => copy('curp', outcome.curp!)}>
                {copied === 'curp' ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                COPIAR
              </Button>
            </div>
            <p className="text-xs font-semibold tracking-wide text-imss-soft-foreground">CANDIDATA PENDIENTE DE VERIFICACIÓN OFICIAL</p>
            {printed ? (
              diff && diff.length ? (
                <p className="text-xs text-destructive">
                  Difiere de la CURP del documento ({printed}) en la(s) posición(es) {diff.join(', ')}.
                </p>
              ) : (
                <p className="text-xs text-success">Coincide con la CURP del documento.</p>
              )
            ) : null}
          </div>
        ) : null}
      </div>
    </details>
  )
}
