'use client'

import { useState } from 'react'
import { ArrowLeftRight, ScanText, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  fieldLabel,
  missingFields,
  parseFreeText,
  REQUIRED_FOR_CURP,
  REQUIRED_FOR_RFC,
  type AutofillResult,
  type NameOrder,
} from '@/lib/identity-lab/autofill'
import { generateCurp, generateRfcFromData, normalizeText, type GenerationResult } from '@/lib/identity-lab/engine'
import { addHistory } from '@/lib/identity-lab/history'
import { CARD, EMPTY_PERSON, Field, PersonFields, ResultsList, type PersonValues } from './shared'

const PRIMARY = 'h-11 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90'

export function AutofillPanel() {
  const [text, setText] = useState('')
  const [order, setOrder] = useState<NameOrder>('nombre-primero')
  const [parsed, setParsed] = useState<AutofillResult | null>(null)
  const [person, setPerson] = useState<PersonValues>(EMPTY_PERSON)
  const [curp, setCurp] = useState<GenerationResult | null>(null)
  const [rfc, setRfc] = useState<GenerationResult | null>(null)

  function detect(nextOrder: NameOrder) {
    const r = parseFreeText(text, nextOrder)
    setOrder(nextOrder)
    setParsed(r)
    setPerson(r.values)
    setCurp(null)
    setRfc(null)
  }

  const label = normalizeText([person.nombre, person.primerApellido, person.segundoApellido].filter(Boolean).join(' '))
  const missingCurp = missingFields(person, REQUIRED_FOR_CURP)
  const missingRfc = missingFields(person, REQUIRED_FOR_RFC)

  function calcCurp() {
    const r = generateCurp(person)
    setCurp(r)
    if (r.ok) addHistory('CURP POR DATOS', `${label} · ${person.fechaNacimiento} · ${person.sexo} · ${person.entidad}`, r.candidates.map((c) => c.id))
  }

  function calcRfc() {
    const r = generateRfcFromData(person)
    setRfc(r)
    if (r.ok) addHistory('RFC POR DATOS', `${label} · ${person.fechaNacimiento}`, r.candidates.map((c) => c.id))
  }

  return (
    <div className="flex flex-col gap-4">
      <div className={CARD}>
        <Field label="TEXTO CON LOS DATOS">
          {(id) => (
            <textarea
              id={id}
              rows={5}
              value={text}
              onChange={(e) => setText(e.target.value)}
              spellCheck={false}
              autoComplete="off"
              className="w-full resize-y rounded-xl border border-border bg-card p-3 text-base leading-relaxed text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:text-sm"
              placeholder="Pega aquí el texto"
            />
          )}
        </Field>
        <Button type="button" className={PRIMARY} onClick={() => detect('nombre-primero')} disabled={!text.trim()}>
          <ScanText className="size-4" aria-hidden="true" />
          DETECTAR DATOS
        </Button>
      </div>

      {parsed ? (
        <div className={CARD}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold tracking-wide">REVISA Y CORRIGE</h2>
            {parsed.orderAssumed ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-9 gap-1.5 rounded-full text-xs"
                onClick={() => detect(order === 'nombre-primero' ? 'apellidos-primero' : 'nombre-primero')}
              >
                <ArrowLeftRight className="size-3.5" aria-hidden="true" />
                {order === 'nombre-primero' ? 'APELLIDOS PRIMERO' : 'NOMBRE PRIMERO'}
              </Button>
            ) : null}
          </div>

          {parsed.detected.length ? null : (
            <p className="text-xs leading-relaxed text-muted-foreground" aria-live="polite">
              No se detectaron datos.
            </p>
          )}
          {parsed.warnings.length ? (
            <ul className="flex flex-col gap-1 rounded-2xl border border-border bg-card p-3 text-xs leading-relaxed text-muted-foreground">
              {parsed.warnings.map((w) => (
                <li key={w}>{w}</li>
              ))}
            </ul>
          ) : null}

          {parsed.sexSuggestion && person.sexo === parsed.sexSuggestion.sexo ? (
            <p className="rounded-2xl border border-imss/40 bg-card p-3 text-xs leading-relaxed text-foreground" role="note">
              <span className="font-semibold">SEXO SUGERIDO: {parsed.sexSuggestion.sexo === 'H' ? 'HOMBRE' : 'MUJER'}</span> · confírmalo
            </p>
          ) : null}

          <PersonFields value={person} onChange={setPerson} withSexAndState />

          {missingCurp.length ? (
            <p className="text-xs font-medium leading-relaxed text-foreground" role="status">
              Falta completar: {missingCurp.map(fieldLabel).join(', ')}.
            </p>
          ) : null}

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <Button type="button" className={PRIMARY} onClick={calcCurp} disabled={missingCurp.length > 0}>
              <Sparkles className="size-4" aria-hidden="true" />
              CALCULAR CURP
            </Button>
            <Button type="button" className={PRIMARY} onClick={calcRfc} disabled={missingRfc.length > 0}>
              <Sparkles className="size-4" aria-hidden="true" />
              CALCULAR RFC
            </Button>
          </div>
        </div>
      ) : null}

      {curp ? (
        <section aria-label="CURP posible" className="flex flex-col gap-2">
          <h3 className="px-1 text-xs font-semibold tracking-wide text-muted-foreground">CURP POSIBLE</h3>
          <ResultsList result={curp} />
        </section>
      ) : null}
      {rfc ? (
        <section aria-label="RFC posible" className="flex flex-col gap-2">
          <h3 className="px-1 text-xs font-semibold tracking-wide text-muted-foreground">RFC POSIBLE</h3>
          <ResultsList result={rfc} />
        </section>
      ) : null}
    </div>
  )
}
