'use client'

import { useRef, useState } from 'react'
import { Download, FileSpreadsheet, Upload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { batchToCsv, CSV_TEMPLATE, processBatch, type BatchRow } from '@/lib/identity-lab/engine'
import { addHistory } from '@/lib/identity-lab/history'
import { cn } from '@/lib/utils'
import { CARD, Errors } from './shared'
import { CurpList } from './curp-list'

function downloadCsv(content: string, fileName: string) {
  const url = URL.createObjectURL(new Blob([content], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
}

const ROW_STYLE: Record<BatchRow['status'], string> = {
  ok: 'text-success',
  error: 'text-destructive',
  duplicado: 'text-muted-foreground',
}

export function Batch() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [rows, setRows] = useState<BatchRow[]>([])
  const [fileName, setFileName] = useState('')
  const [error, setError] = useState<string | null>(null)

  async function onFile(file: File | undefined) {
    if (!file) return
    setError(null)
    setRows([])
    if (file.size > 5 * 1024 * 1024) {
      setError('El archivo supera 5 MB.')
      return
    }
    const result = processBatch(await file.text())
    setFileName(file.name)
    if (result.error) {
      setError(result.error)
      return
    }
    setRows(result.rows)
    const ok = result.rows.filter((r) => r.status === 'ok')
    addHistory('MASIVO', `${file.name} · ${result.rows.length} filas`, ok.slice(0, 50).map((r) => `Fila ${r.row}: ${r.curp} · ${r.rfc}`))
  }

  const counts = {
    ok: rows.filter((r) => r.status === 'ok').length,
    error: rows.filter((r) => r.status === 'error').length,
    duplicado: rows.filter((r) => r.status === 'duplicado').length,
  }

  return (
    <div className="flex flex-col gap-4">
      <CurpList />
      <div className={CARD}>
        <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
          Columnas: nombre, primer_apellido, segundo_apellido, fecha_nacimiento, sexo, entidad
        </p>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="sr-only"
          aria-label="Importar CSV"
          onChange={(e) => {
            void onFile(e.target.files?.[0])
            e.target.value = ''
          }}
        />
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button type="button" onClick={() => inputRef.current?.click()} className="h-11 flex-1 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90">
            <Upload className="size-4" aria-hidden="true" />
            IMPORTAR CSV
          </Button>
          <Button type="button" variant="outline" onClick={() => downloadCsv(CSV_TEMPLATE, 'plantilla-identity-lab.csv')} className="h-11 gap-2 rounded-full">
            <FileSpreadsheet className="size-4" aria-hidden="true" />
            PLANTILLA
          </Button>
        </div>
      </div>

      {error ? <Errors errors={[error]} /> : null}

      {rows.length ? (
        <section aria-label="Resultados del lote" className={CARD}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm">
              <span className="font-semibold">{rows.length}</span> filas · <span className="text-success">{counts.ok} calculadas</span> ·{' '}
              <span className="text-destructive">{counts.error} con error</span> · <span className="text-muted-foreground">{counts.duplicado} duplicadas</span>
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5 rounded-full"
              onClick={() => downloadCsv(batchToCsv(rows), `${fileName.replace(/\.csv$/i, '') || 'lote'}-resultados.csv`)}
            >
              <Download className="size-4" aria-hidden="true" />
              EXPORTAR CSV
            </Button>
          </div>
          <ul className="flex max-h-[28rem] flex-col gap-2 overflow-y-auto">
            {rows.map((r) => (
              <li key={r.row} className="flex flex-col gap-1 rounded-xl border border-border bg-card p-2.5 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">Fila {r.row}</span>
                  <span className={cn('text-xs font-semibold uppercase', ROW_STYLE[r.status])}>{r.status}</span>
                </div>
                <span className="text-muted-foreground break-words">
                  {[r.input.nombre, r.input.primerApellido, r.input.segundoApellido].filter(Boolean).join(' ') || '(sin nombre)'}
                </span>
                {r.status === 'ok' ? (
                  <span className="font-mono text-xs tracking-wider break-all sm:text-sm">
                    CURP {r.curp} · RFC {r.rfc}
                  </span>
                ) : (
                  <span className={cn('leading-relaxed', ROW_STYLE[r.status])}>{r.message}</span>
                )}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  )
}
