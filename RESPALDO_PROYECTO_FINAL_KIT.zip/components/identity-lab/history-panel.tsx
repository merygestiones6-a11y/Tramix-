'use client'

import { useMemo, useState } from 'react'
import { Check, Copy, Search, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { clearHistory, removeHistory, useHistory } from '@/lib/identity-lab/history'
import { normalizeText } from '@/lib/identity-lab/engine'
import { cn } from '@/lib/utils'
import { CARD, INPUT, useCopyFeedback } from './shared'

const DATE = new Intl.DateTimeFormat('es-MX', { dateStyle: 'short', timeStyle: 'short' })

export function HistoryPanel() {
  const history = useHistory()
  const [query, setQuery] = useState('')
  const { copied, failed, copy } = useCopyFeedback()

  const filtered = useMemo(() => {
    const q = normalizeText(query)
    if (!q) return history
    return history.filter((e) => normalizeText([e.tool, e.query, ...e.results].join(' ')).includes(q))
  }, [history, query])

  return (
    <div className="flex flex-col gap-4">
      <div className={CARD}>
        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              type="search"
              aria-label="Buscar en el historial"
              className={cn(INPUT, 'pl-9 normal-case')}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar nombre, CURP o RFC"
            />
          </div>
          <Button
            type="button"
            variant="outline"
            disabled={!history.length}
            className="h-11 gap-2 rounded-full"
            onClick={() => {
              if (window.confirm('¿Eliminar todo el historial de IDENTITY LAB?')) clearHistory()
            }}
          >
            <Trash2 className="size-4" aria-hidden="true" />
            BORRAR TODO
          </Button>
        </div>

        <p role="status" aria-live="polite" className={cn('min-h-5 text-sm font-semibold', failed ? 'text-destructive' : 'text-success')}>
          {copied ? 'COPIADO' : failed ? 'No se pudo copiar' : ''}
        </p>

        {filtered.length ? (
          <ul className="flex flex-col gap-2">
            {filtered.map((e) => (
              <li key={e.id} className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex min-w-0 flex-col">
                    <span className="text-xs font-semibold tracking-wide text-imss-soft-foreground">{e.tool}</span>
                    <span className="text-sm break-words">{e.query}</span>
                    <span className="text-xs text-muted-foreground">{DATE.format(e.at)}</span>
                  </div>
                  <div className="flex shrink-0 items-center">
                    <button
                      type="button"
                      aria-label="Copiar resultados"
                      onClick={() => copy(e.id, e.results.join('\n'))}
                      className="flex size-9 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {copied === e.id ? <Check className="size-4 text-success" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                    </button>
                    <button
                      type="button"
                      aria-label="Eliminar registro"
                      onClick={() => removeHistory(e.id)}
                      className="flex size-9 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <Trash2 className="size-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
                <ol className="flex flex-col gap-0.5 font-mono text-xs tracking-wider break-all sm:text-sm">
                  {e.results.map((r, i) => (
                    <li key={`${e.id}-${i}`}>
                      {i + 1}. {r}
                    </li>
                  ))}
                </ol>
              </li>
            ))}
          </ul>
        ) : (
          <p className="py-6 text-center text-sm text-muted-foreground">{history.length ? 'Sin coincidencias.' : 'Aún no hay consultas guardadas.'}</p>
        )}
      </div>
    </div>
  )
}
