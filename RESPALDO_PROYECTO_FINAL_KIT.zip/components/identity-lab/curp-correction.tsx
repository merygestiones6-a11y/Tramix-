'use client'

import { useMemo, useState } from 'react'
import { Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  cleanKey,
  diffKeys,
  suggestCurpCorrections,
  validateCurp,
  type CurpCorrection as Correction,
  type DiffPart,
} from '@/lib/identity-lab/engine'
import { cn } from '@/lib/utils'
import { INPUT } from './shared'

const KIND_LABEL: Record<Correction['kind'], string> = {
  matematica: 'CORRECCIÓN MATEMÁTICA',
  estructural: 'CORRECCIÓN ESTRUCTURAL',
  probable: 'POSIBLE CORRECCIÓN',
}

function DiffLine({ parts, label }: { parts: DiffPart[]; label: string }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      <p className="font-mono text-base font-semibold tracking-wider break-all">
        {parts.length ? (
          parts.map((p, i) =>
            p.type === 'same' ? (
              <span key={i}>{p.text}</span>
            ) : p.type === 'removed' ? (
              <del key={i} className="rounded bg-destructive/15 px-0.5 text-destructive decoration-2">
                {p.text}
              </del>
            ) : (
              <ins key={i} className="rounded bg-success/15 px-0.5 text-success no-underline">
                {p.text}
              </ins>
            ),
          )
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </p>
    </div>
  )
}

export function CurpCorrection({
  original,
  isCurp,
  onApply,
}: {
  original: string
  isCurp: boolean
  onApply: (value: string) => void
}) {
  const options = useMemo(() => suggestCurpCorrections(original), [original])
  const [selected, setSelected] = useState(0)
  const [manual, setManual] = useState<string | null>(null)

  if (!isCurp && !options.length) return null

  const proposed = manual ?? options[selected]?.value ?? original
  const diff = diffKeys(original, proposed)
  const proposedValid = proposed.length > 0 && validateCurp(proposed).status !== 'invalida'
  const changed = proposed !== original
  const unique = options.length === 1 && manual === null

  return (
    <div aria-label="Corrección sugerida" role="region" className="flex flex-col gap-3 rounded-2xl border border-imss/30 bg-imss-soft/40 p-3">
      <div className="flex items-center gap-2">
        <Wand2 className="size-4 text-imss" aria-hidden="true" />
        <h3 className="text-sm font-semibold">CORRECCIÓN SUGERIDA</h3>
      </div>

      {options.length === 0 ? (
        <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
          No hay una corrección fiable que pueda calcularse solo con la clave. Edítala manualmente con los datos del documento.
        </p>
      ) : options.length > 1 ? (
        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1 text-xs font-semibold text-muted-foreground">
            HAY {options.length} POSIBILIDADES · ELIGE UNA
          </legend>
          {options.map((o, i) => (
            <label
              key={o.value}
              className={cn(
                'flex cursor-pointer items-start gap-2 rounded-xl border bg-card p-2.5 text-sm',
                manual === null && selected === i ? 'border-imss' : 'border-border',
              )}
            >
              <input
                type="radio"
                name="curp-correction"
                className="mt-1 accent-imss"
                checked={manual === null && selected === i}
                onChange={() => {
                  setSelected(i)
                  setManual(null)
                }}
              />
              <span className="flex flex-col gap-0.5">
                <span className="font-mono font-semibold tracking-wider break-all">{o.value}</span>
                <span className="text-xs font-semibold text-imss">{KIND_LABEL[o.kind]}</span>
                <span className="leading-relaxed text-muted-foreground">{o.reason}</span>
              </span>
            </label>
          ))}
        </fieldset>
      ) : null}

      {unique ? (
        <div className="flex flex-col gap-0.5 text-sm">
          <span className="text-xs font-semibold text-imss">{KIND_LABEL[options[0].kind]}</span>
          <span className="leading-relaxed text-muted-foreground">{options[0].reason}</span>
        </div>
      ) : null}

      <div className="flex flex-col gap-2 rounded-xl border border-border bg-card p-2.5">
        <DiffLine label="ORIGINAL" parts={diff.original} />
        <DiffLine label="PROPUESTA" parts={diff.proposed} />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="curp-correction-manual" className="text-xs font-semibold text-muted-foreground">
          EDITAR PROPUESTA
        </label>
        <input
          id="curp-correction-manual"
          className={`${INPUT} font-mono tracking-wider`}
          value={proposed}
          maxLength={24}
          autoComplete="off"
          spellCheck={false}
          onChange={(e) => setManual(cleanKey(e.target.value))}
        />
        <p className={cn('text-xs leading-relaxed', proposedValid ? 'text-success' : 'text-muted-foreground')}>
          {proposedValid ? 'La propuesta cumple la estructura.' : 'La propuesta todavía no cumple la estructura.'} No confirma que exista en RENAPO.
        </p>
      </div>

      <Button
        type="button"
        disabled={!changed || !proposed}
        onClick={() => onApply(proposed)}
        className="h-11 gap-2 rounded-full bg-imss text-imss-foreground hover:bg-imss/90"
      >
        <Wand2 className="size-4" aria-hidden="true" />
        APLICAR CORRECCIÓN
      </Button>
    </div>
  )
}
