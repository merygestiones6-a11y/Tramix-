'use client'

import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import { AlertTriangle, Check, CheckCircle2, CircleHelp, Copy, CopyCheck, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { copyText } from '@/lib/clipboard'
import { STATES, type Candidate, type CurpInput, type GenerationResult } from '@/lib/identity-lab/engine'
import { cn } from '@/lib/utils'

export const CARD = 'glass flex flex-col gap-4 rounded-3xl p-4 sm:p-6'
export const INPUT =
  'h-11 w-full rounded-xl border border-border bg-card px-3 text-base text-foreground uppercase placeholder:normal-case placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:text-sm'

export function Field({ label, children, hint }: { label: string; children: (id: string) => ReactNode; hint?: string }) {
  const id = useId()
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-xs font-semibold tracking-wide text-muted-foreground">
        {label}
      </label>
      {children(id)}
      {hint ? <p className="text-xs leading-relaxed text-muted-foreground">{hint}</p> : null}
    </div>
  )
}

export type PersonValues = CurpInput

export const EMPTY_PERSON: PersonValues = {
  nombre: '',
  primerApellido: '',
  segundoApellido: '',
  fechaNacimiento: '',
  sexo: '',
  entidad: '',
}

export function PersonFields({
  value,
  onChange,
  withSexAndState = false,
  withDate = true,
}: {
  value: PersonValues
  onChange: (next: PersonValues) => void
  withSexAndState?: boolean
  withDate?: boolean
}) {
  const set = (key: keyof PersonValues) => (v: string) => onChange({ ...value, [key]: v })
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <Field label="NOMBRE(S)">
          {(id) => (
            <input id={id} className={INPUT} autoComplete="off" value={value.nombre} onChange={(e) => set('nombre')(e.target.value)} placeholder="Ej. María José" />
          )}
        </Field>
      </div>
      <Field label="PRIMER APELLIDO">
        {(id) => (
          <input id={id} className={INPUT} autoComplete="off" value={value.primerApellido} onChange={(e) => set('primerApellido')(e.target.value)} placeholder="Ej. de la Cruz" />
        )}
      </Field>
      <Field label="SEGUNDO APELLIDO">
        {(id) => (
          <input id={id} className={INPUT} autoComplete="off" value={value.segundoApellido} onChange={(e) => set('segundoApellido')(e.target.value)} placeholder="Opcional" />
        )}
      </Field>
      {withDate ? (
        <Field label="FECHA DE NACIMIENTO">
          {(id) => (
            <input id={id} type="date" min="1900-01-01" className={INPUT} value={value.fechaNacimiento} onChange={(e) => set('fechaNacimiento')(e.target.value)} />
          )}
        </Field>
      ) : null}
      {withSexAndState ? (
        <>
          <Field label="SEXO">
            {(id) => (
              <select id={id} className={INPUT} value={value.sexo} onChange={(e) => set('sexo')(e.target.value)}>
                <option value="">Selecciona</option>
                <option value="H">H · Hombre</option>
                <option value="M">M · Mujer</option>
                <option value="X">X · No binario</option>
              </select>
            )}
          </Field>
          <div className="sm:col-span-2">
            <Field label="ENTIDAD DE NACIMIENTO">
              {(id) => (
                <select id={id} className={INPUT} value={value.entidad} onChange={(e) => set('entidad')(e.target.value)}>
                  <option value="">Selecciona</option>
                  {STATES.map((s) => (
                    <option key={s.code} value={s.code}>
                      {s.code} · {s.name}
                    </option>
                  ))}
                </select>
              )}
            </Field>
          </div>
        </>
      ) : null}
    </div>
  )
}

/** Copies and shows a short confirmation; returns the key currently confirmed. */
export function useCopyFeedback() {
  const [copied, setCopied] = useState<string | null>(null)
  const [failed, setFailed] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(timer.current), [])
  async function copy(key: string, text: string) {
    const ok = await copyText(text)
    clearTimeout(timer.current)
    setCopied(ok ? key : null)
    setFailed(!ok)
    timer.current = setTimeout(() => {
      setCopied(null)
      setFailed(false)
    }, 1600)
  }
  return { copied, failed, copy }
}

const STATUS_STYLE: Record<Candidate['status'], string> = {
  'estructura-valida': 'border-success/30 bg-success/10 text-success',
  parcial: 'border-imss/30 bg-imss-soft text-imss-soft-foreground',
  verificar: 'border-destructive/30 bg-destructive/10 text-destructive',
}

export function Errors({ errors }: { errors: string[] }) {
  if (!errors.length) return null
  return (
    <div role="alert" className="flex flex-col gap-1 rounded-2xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
      {errors.map((e) => (
        <p key={e} className="flex items-start gap-2 leading-relaxed">
          <XCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {e}
        </p>
      ))}
    </div>
  )
}

export function ResultsList({ result }: { result: GenerationResult }) {
  const { copied, failed, copy } = useCopyFeedback()
  if (!result.ok) return <Errors errors={result.errors} />
  const all = result.candidates.map((c) => c.id).join('\n')

  return (
    <section aria-label="Resultados" className={CARD}>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold tracking-wide">
          {result.candidates.length === 1 ? '1 RESULTADO' : `${result.candidates.length} RESULTADOS`}
        </h2>
        <Button type="button" variant="outline" size="sm" onClick={() => copy('__all', all)} className="gap-1.5 rounded-full">
          {copied === '__all' ? <CopyCheck className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
          COPIAR TODOS
        </Button>
      </div>

      <ol className="flex flex-col gap-2">
        {result.candidates.map((c) => (
          <li key={c.id} className="relative flex flex-col gap-2 rounded-2xl border border-border bg-card p-3 pr-12">
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-imss text-xs font-semibold text-imss-foreground" aria-label={`Posición ${c.rank}`}>
                {c.rank}
              </span>
              <span className="font-mono text-base font-semibold tracking-wider break-all sm:text-lg">{c.id}</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className={cn('rounded-full border px-2 py-0.5 text-xs font-semibold', STATUS_STYLE[c.status])}>{c.statusLabel}</span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{c.reason}</p>
            <button
              type="button"
              onClick={() => copy(c.id, c.id)}
              aria-label={`Copiar ${c.id}`}
              className="absolute top-2 right-2 flex size-9 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {copied === c.id ? <Check className="size-4 text-success" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
            </button>
          </li>
        ))}
      </ol>

      <p role="status" aria-live="polite" className={cn('min-h-5 text-sm font-semibold', failed ? 'text-destructive' : 'text-success')}>
        {copied === '__all' ? 'RESULTADOS COPIADOS' : copied ? 'COPIADO' : failed ? 'No se pudo copiar' : ''}
      </p>

      {result.notes.length ? (
        <details className="rounded-2xl border border-border bg-card p-3 text-sm">
          <summary className="cursor-pointer font-semibold">Reglas aplicadas</summary>
          <ul className="mt-2 flex flex-col gap-1.5 leading-relaxed text-muted-foreground">
            {result.notes.map((n) => (
              <li key={n} className="flex items-start gap-2">
                <CircleHelp className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                {n}
              </li>
            ))}
          </ul>
        </details>
      ) : null}
    </section>
  )
}

export function StatusIcon({ ok }: { ok: boolean | null }) {
  if (ok === true) return <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" aria-label="Correcto" />
  if (ok === false) return <XCircle className="mt-0.5 size-4 shrink-0 text-destructive" aria-label="Incorrecto" />
  return <AlertTriangle className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-label="Por verificar" />
}
