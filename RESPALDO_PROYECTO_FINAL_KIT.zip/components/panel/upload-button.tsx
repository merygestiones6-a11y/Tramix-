'use client'

import { Upload } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useRef, useState } from 'react'
import { setPendingUpload } from '@/lib/pending-upload'
import { cn } from '@/lib/utils'

export function UploadButton() {
  const router = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const send = (files: FileList | null) => {
    if (!files?.length) return
    setPendingUpload(Array.from(files))
    router.push('/')
  }

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
        onChange={(event) => {
          send(event.target.files)
          event.target.value = ''
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => {
          event.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault()
          setDragging(false)
          send(event.dataTransfer.files)
        }}
        className={cn(
          'inline-flex h-9 shrink-0 items-center gap-2 rounded-full border border-border bg-card px-4 text-xs font-semibold tracking-wide text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:h-10',
          dragging && 'ring-2 ring-ring ring-offset-2 ring-offset-background',
        )}
      >
        <Upload className="size-4" aria-hidden="true" />
        SUBIR
      </button>
    </>
  )
}
