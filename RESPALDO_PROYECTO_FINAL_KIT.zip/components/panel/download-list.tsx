'use client'

import { Check, ClipboardCopy, Clock, Download, Eye, FileText, Inbox, Loader2 } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { copyText } from '@/lib/clipboard'
import { outlookApp } from '@/lib/outlook-app'
import { FILE_TTL_MS, type PanelFile } from '@/lib/panel/config'
import { cn } from '@/lib/utils'
import { formatBytes, formatRemaining, formatUploadedAt } from './format'

function useNow(serverTime?: string) {
  const [offset, setOffset] = useState(0)
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (serverTime) setOffset(new Date(serverTime).getTime() - Date.now())
  }, [serverTime])
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 15000)
    return () => clearInterval(id)
  }, [])
  return now + offset
}

export function DownloadList({
  files,
  serverTime,
  loading,
  failed,
  onExpired,
  onRetry,
}: {
  files: PanelFile[]
  serverTime?: string
  loading: boolean
  failed: boolean
  onExpired: () => void
  onRetry: () => void
}) {
  const now = useNow(serverTime)
  const active = files.filter((file) => new Date(file.expiresAt).getTime() > now)
  const hadExpired = active.length < files.length

  useEffect(() => {
    if (hadExpired) onExpired()
  }, [hadExpired, onExpired])

  if (loading) {
    return (
      <div className="glass flex items-center justify-center gap-2 rounded-3xl p-10 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
        Cargando archivos…
      </div>
    )
  }

  if (failed) {
    return (
      <div className="glass flex flex-col items-center gap-3 rounded-3xl p-8 text-center">
        <p className="text-sm text-destructive">No se pudo cargar la lista.</p>
        <button type="button" onClick={onRetry} className="text-sm font-semibold text-primary hover:underline">
          Reintentar
        </button>
      </div>
    )
  }

  if (active.length === 0) {
    return (
      <div className="glass flex flex-col items-center gap-2 rounded-3xl px-4 py-12 text-center">
        <Inbox className="size-6 text-muted-foreground" aria-hidden="true" />
        <p className="text-sm font-medium">No hay archivos activos</p>
        <p className="text-xs text-muted-foreground">Los PDF terminados aparecerán aquí durante 12 horas.</p>
      </div>
    )
  }

  return (
    <ul className="flex flex-col gap-3" aria-label="Archivos activos">
      {active.map((file) => (
        <FileCard key={file.id} file={file} now={now} />
      ))}
    </ul>
  )
}

function FileCard({ file, now }: { file: PanelFile; now: number }) {
  const remaining = new Date(file.expiresAt).getTime() - now
  const fraction = Math.max(0, Math.min(1, remaining / FILE_TTL_MS))
  const lowTime = remaining < 60 * 60 * 1000

  return (
    <li className="glass flex flex-col gap-3 rounded-3xl p-4">
      <div className="flex items-start gap-3">
        <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <FileText className="size-5" aria-hidden="true" />
        </span>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <p className="truncate text-sm font-semibold" title={file.name}>
            {file.name}
          </p>
          <p className="text-xs text-muted-foreground tabular-nums">
            Subido {formatUploadedAt(file.uploadedAt)} · {formatBytes(file.size)}
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <Clock className="size-3.5" aria-hidden="true" />
            Disponible
          </span>
          <span className={cn('font-semibold tabular-nums', lowTime ? 'text-warning' : 'text-foreground')}>
            {formatRemaining(remaining)}
          </span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-muted" aria-hidden="true">
          <div
            className={cn('h-full rounded-full transition-[width] duration-700', lowTime ? 'bg-warning' : 'bg-primary')}
            style={{ width: `${fraction * 100}%` }}
          />
        </div>
      </div>

      <div className={cn('grid gap-2', isPdf(file) ? 'grid-cols-3' : 'grid-cols-2')}>
        {isPdf(file) && <PreviewButton file={file} />}
        <DownloadButton file={file} />
        <CopyTextButton file={file} />
      </div>
    </li>
  )
}

type NativeSaver = { saveDataUrl?: (name: string, mime: string, dataUrl: string) => void }

function nativeSaver(): NativeSaver['saveDataUrl'] | null {
  if (typeof window === 'undefined') return null
  const b = (window as unknown as { TramixAndroid?: NativeSaver }).TramixAndroid
  return b && typeof b.saveDataUrl === 'function' ? b.saveDataUrl.bind(b) : null
}

function DownloadButton({ file }: { file: PanelFile }) {
  const [busy, setBusy] = useState(false)
  const href = `/api/panel/files/${file.id}`

  // Inside the Android WebView a blob/anchor download throws "A WebView method was called on thread…",
  // so the file is fetched here and handed to the native saver, which writes it to the device.
  async function save(event: React.MouseEvent<HTMLAnchorElement>) {
    const saveDataUrl = nativeSaver()
    if (!saveDataUrl) return
    event.preventDefault()
    if (busy) return
    setBusy(true)
    try {
      const res = await fetch(href, { cache: 'no-store' })
      if (!res.ok) throw new Error('unavailable')
      const blob = await res.blob()
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => resolve(String(reader.result))
        reader.onerror = () => reject(reader.error)
        reader.readAsDataURL(blob)
      })
      saveDataUrl(file.name, blob.type || 'application/pdf', dataUrl)
    } catch {
      window.location.href = href
    } finally {
      setBusy(false)
    }
  }

  return (
    <a
      href={href}
      download={file.name}
      onClick={save}
      aria-busy={busy}
      className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary text-xs font-semibold tracking-wide text-primary-foreground transition-all hover:bg-primary/90 active:scale-[0.98]"
    >
      {busy ? (
        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
      ) : (
        <Download className="size-4" aria-hidden="true" />
      )}
      DESCARGAR
    </a>
  )
}

function isPdf(file: PanelFile) {
  return file.name.toLowerCase().endsWith('.pdf')
}

function PreviewButton({ file }: { file: PanelFile }) {
  const [busy, setBusy] = useState(false)
  const href = `/api/panel/files/${file.id}`

  async function open() {
    if (!outlookApp.available()) {
      window.open(href, '_blank', 'noopener,noreferrer')
      return
    }
    setBusy(true)
    try {
      const res = await fetch(href, { cache: 'no-store' })
      if (!res.ok) throw new Error('unavailable')
      const bytes = new Uint8Array(await res.arrayBuffer())
      let binary = ''
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000))
      if (!outlookApp.preview(file.name, btoa(binary))) window.open(href, '_blank', 'noopener,noreferrer')
    } catch {
      window.open(href, '_blank', 'noopener,noreferrer')
    } finally {
      setBusy(false)
    }
  }

  return (
    <button
      type="button"
      onClick={open}
      disabled={busy}
      className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-background/60 text-xs font-semibold tracking-wide text-foreground transition-all hover:border-primary/40 active:scale-[0.98] disabled:opacity-60"
    >
      {busy ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Eye className="size-4" aria-hidden="true" />}
      VER
    </button>
  )
}

class NoDataError extends Error {}

async function fetchMessage(id: string): Promise<string> {
  const res = await fetch(`/api/panel/files/${id}/message`, { cache: 'no-store' })
  if (res.status === 422) throw new NoDataError('no-data')
  if (!res.ok) throw new Error('message-unavailable')
  const body = (await res.json()) as { message: string }
  return body.message
}

type CopyOutcome = 'copied' | 'no-data' | 'failed'

/** Safari only allows async clipboard writes when the promise is handed to ClipboardItem inside the tap. */
async function copyFetchedMessage(id: string): Promise<CopyOutcome> {
  const pending = fetchMessage(id)
  pending.catch(() => {})
  if (typeof ClipboardItem !== 'undefined' && navigator.clipboard?.write) {
    try {
      const blob = pending.then((message) => new Blob([message], { type: 'text/plain' }))
      await navigator.clipboard.write([new ClipboardItem({ 'text/plain': blob })])
      return 'copied'
    } catch {
      // Fall through to the plain-text path below.
    }
  }
  try {
    return (await copyText(await pending)) ? 'copied' : 'failed'
  } catch (error) {
    return error instanceof NoDataError ? 'no-data' : 'failed'
  }
}

function CopyTextButton({ file }: { file: PanelFile }) {
  const [state, setState] = useState<'idle' | 'copying' | CopyOutcome>('idle')
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => () => void (timer.current && clearTimeout(timer.current)), [])

  const status = file.textStatus
  const unavailable = status !== 'ready'
  const label =
    status === 'pending'
      ? 'EXTRAYENDO…'
      : status === 'empty'
        ? 'SIN TEXTO'
        : status === 'unsupported'
          ? 'SIN TEXTO'
          : status === 'failed'
            ? 'TEXTO NO DISPONIBLE'
            : null

  const handleCopy = async () => {
    if (unavailable || state === 'copying') return
    setState('copying')
    const outcome = await copyFetchedMessage(file.id)
    setState(outcome)
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setState('idle'), outcome === 'no-data' ? 4000 : 2500)
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      disabled={unavailable}
      aria-live="polite"
      className={cn(
        'inline-flex h-11 items-center justify-center gap-2 rounded-xl border text-xs font-semibold tracking-wide transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60',
        state === 'copied'
          ? 'border-success bg-success text-success-foreground'
          : state === 'failed' || state === 'no-data'
            ? 'border-destructive/40 text-destructive'
            : 'border-border bg-background/60 text-foreground hover:border-primary/40',
      )}
    >
      {label ? (
        <>
          {status === 'pending' ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
          {label}
        </>
      ) : state === 'copying' ? (
        <>
          <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          COPIANDO
        </>
      ) : state === 'copied' ? (
        <>
          <Check className="size-4 animate-pop" aria-hidden="true" />
          COPIADO
        </>
      ) : state === 'no-data' ? (
        'SIN NOMBRE O CURP'
      ) : state === 'failed' ? (
        'NO SE PUDO COPIAR'
      ) : (
        <>
          <ClipboardCopy className="size-4" aria-hidden="true" />
          COPIAR TEXTO
        </>
      )}
    </button>
  )
}
