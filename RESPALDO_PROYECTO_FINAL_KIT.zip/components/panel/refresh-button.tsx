'use client'

import { RefreshCw } from 'lucide-react'
import { useState } from 'react'
import { useSWRConfig } from 'swr'
import { cn } from '@/lib/utils'
import { PANEL_FILES_KEY, scanMail } from './panel-app'

export function RefreshButton() {
  const { mutate } = useSWRConfig()
  const [busy, setBusy] = useState(false)

  async function refresh() {
    if (busy) return
    setBusy(true)
    try {
      await mutate(PANEL_FILES_KEY)
      await scanMail(true)
      await mutate(PANEL_FILES_KEY)
    } finally {
      setBusy(false)
    }
  }

  return (
    <button
      type="button"
      onClick={refresh}
      aria-busy={busy}
      aria-label="Actualizar descargas"
      title="Actualizar"
      className="inline-flex size-9 shrink-0 items-center justify-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:size-10"
    >
      <RefreshCw className={cn('size-4', busy && 'animate-spin')} aria-hidden="true" />
    </button>
  )
}
