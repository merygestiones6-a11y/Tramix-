'use client'

import useSWR from 'swr'
import { accessFetch } from '@/lib/outlook/client'
import type { PanelFile } from '@/lib/panel/config'
import { DownloadList } from './download-list'

export const PANEL_FILES_KEY = '/api/panel/files'

interface ListResponse {
  files: PanelFile[]
  serverTime: string
}

async function fetchFiles(url: string): Promise<ListResponse> {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) throw new Error('list-failed')
  return res.json()
}

/** Asks the receiver to read the Outlook inboxes now; the server skips it if a pass ran seconds ago. */
export async function scanMail(force = false): Promise<void> {
  await accessFetch(`/api/receiver${force ? '?force=1' : ''}`, { method: 'POST', cache: 'no-store' }).catch(() => null)
}

export function PanelApp() {
  const { data, error, isLoading, mutate } = useSWR(PANEL_FILES_KEY, fetchFiles, {
    refreshInterval: (latest) => (latest?.files.some((file) => file.textStatus === 'pending') ? 2000 : 5000),
    revalidateOnFocus: true,
    dedupingInterval: 1500,
  })

  // While DESCARGAR is open, new IMSS e-mails are pulled in without waiting for the cron;
  // as soon as a pass ends the list is reloaded, so a new PDF shows up immediately.
  useSWR(
    '/api/receiver#descargar',
    async () => {
      await scanMail()
      await mutate()
      return Date.now()
    },
    { refreshInterval: 15000, revalidateOnFocus: true, dedupingInterval: 10000 },
  )

  return (
    <DownloadList
      files={data?.files ?? []}
      serverTime={data?.serverTime}
      loading={isLoading}
      failed={Boolean(error)}
      onExpired={() => mutate()}
      onRetry={() => mutate()}
    />
  )
}
