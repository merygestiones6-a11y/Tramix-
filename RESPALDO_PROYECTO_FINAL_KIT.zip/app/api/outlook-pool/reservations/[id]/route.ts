import { unauthorized } from '@/lib/outlook/access'
import { canManage, completeReservation, isPoolId, releaseReservation } from '@/lib/outlook-pool/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** body: { token, action: 'release' | 'complete' } */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isPoolId(id)) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  const body = (await request.json().catch(() => null)) as { token?: unknown; action?: unknown } | null
  const token = typeof body?.token === 'string' && /^[a-f0-9]{32}$/.test(body.token) ? body.token : null
  if (!token) return Response.json({ error: 'invalid-token' }, { status: 400, headers: NO_STORE })

  if (body?.action === 'release') {
    return Response.json({ ok: await releaseReservation(id, token) }, { headers: NO_STORE })
  }
  if (body?.action === 'complete') {
    const ok = await completeReservation(id, token)
    return Response.json({ ok }, { status: ok ? 200 : 409, headers: NO_STORE })
  }
  return Response.json({ error: 'invalid-action' }, { status: 400, headers: NO_STORE })
}
