import { unauthorized } from '@/lib/outlook/access'
import { deleteFinishedWatches } from '@/lib/outlook/store'
import { canManage, deleteFinishedPoolAccounts } from '@/lib/outlook-pool/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  try {
    const [emails, watches] = await Promise.all([deleteFinishedPoolAccounts(), deleteFinishedWatches()])
    return Response.json({ emails, accounts: emails.length, watches }, { headers: NO_STORE })
  } catch {
    return Response.json({ error: 'cleanup-failed' }, { status: 500, headers: NO_STORE })
  }
}
