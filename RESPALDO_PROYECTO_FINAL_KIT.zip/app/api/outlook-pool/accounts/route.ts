import { unauthorized } from '@/lib/outlook/access'
import { canManage, createPoolAccount, listPoolAccounts } from '@/lib/outlook-pool/store'
import { EMAIL_PATTERN, normalizeEmail } from '@/lib/outlook-pool/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

export async function GET(request: Request) {
  if (!canManage(request)) return unauthorized()
  return Response.json({ accounts: await listPoolAccounts() }, { headers: NO_STORE })
}

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { email?: unknown; secret?: unknown } | null
  const email = typeof body?.email === 'string' ? normalizeEmail(body.email) : ''
  const secret = typeof body?.secret === 'string' ? body.secret : ''

  if (!EMAIL_PATTERN.test(email) || email.length > 254) {
    return Response.json({ error: 'invalid-email' }, { status: 400, headers: NO_STORE })
  }
  if (secret.length > 512) {
    return Response.json({ error: 'invalid-secret' }, { status: 400, headers: NO_STORE })
  }

  const result = await createPoolAccount(email, secret)
  if (result === 'duplicate') return Response.json({ error: 'duplicate' }, { status: 409, headers: NO_STORE })
  return Response.json({ account: result }, { status: 201, headers: NO_STORE })
}
