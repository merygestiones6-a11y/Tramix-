import { unauthorized } from '@/lib/outlook/access'
import { canManage, deletePoolAccount, isPoolId, setPoolStatus } from '@/lib/outlook-pool/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isPoolId(id)) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  const body = (await request.json().catch(() => null)) as { status?: unknown } | null
  const status = body?.status
  if (status !== 'in_use' && status !== 'used') {
    return Response.json({ error: 'invalid-status' }, { status: 400, headers: NO_STORE })
  }

  const account = await setPoolStatus(id, status)
  if (!account) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  if (account === 'invalid') return Response.json({ error: 'invalid-transition' }, { status: 409, headers: NO_STORE })
  return Response.json({ account }, { headers: NO_STORE })
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isPoolId(id)) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  await deletePoolAccount(id)
  return new Response(null, { status: 204, headers: NO_STORE })
}
