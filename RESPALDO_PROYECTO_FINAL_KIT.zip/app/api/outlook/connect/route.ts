import { hasAccess, issueConnectTicket, unauthorized, verifyConnectTicket } from '@/lib/outlook/access'
import { CALLBACK_PATH, getOrigin, microsoftConfig, requestHost } from '@/lib/outlook/config'
import { pkceChallenge, randomToken, seal } from '@/lib/outlook/crypto'
import { authorizeUrl } from '@/lib/outlook/graph'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const OAUTH_COOKIE = 'tramix_oauth'

/** Called by the panel (with the access header); returns a one-time URL that can open in a new tab. */
export async function POST(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  if (!microsoftConfig()) return Response.json({ error: 'microsoft-not-configured' }, { status: 503 })
  const url = `${getOrigin(request)}/api/outlook/connect?ticket=${encodeURIComponent(issueConnectTicket())}`
  return Response.json({ url }, { headers: { 'Cache-Control': 'no-store' } })
}

export async function GET(request: Request) {
  const cfg = microsoftConfig()
  const ticket = new URL(request.url).searchParams.get('ticket') ?? ''
  if (!cfg || !verifyConnectTicket(ticket)) return unauthorized()

  // The state cookie must live on the same host as the registered redirect URI.
  const origin = getOrigin(request)
  if (new URL(origin).host !== requestHost(request)) {
    return Response.redirect(`${origin}/api/outlook/connect?ticket=${encodeURIComponent(ticket)}`, 302)
  }

  const state = randomToken(24)
  const verifier = randomToken(48)
  const cookie = seal(JSON.stringify({ state, verifier, exp: Date.now() + 10 * 60 * 1000 }), 'oauth-state', cfg.clientSecret)
  const target = authorizeUrl({ redirectUri: `${origin}${CALLBACK_PATH}`, state, challenge: pkceChallenge(verifier) })

  return new Response(null, {
    status: 302,
    headers: {
      Location: target,
      'Cache-Control': 'no-store',
      'Set-Cookie': `${OAUTH_COOKIE}=${cookie}; Path=/api/outlook; HttpOnly; Secure; SameSite=Lax; Max-Age=600`,
    },
  })
}
