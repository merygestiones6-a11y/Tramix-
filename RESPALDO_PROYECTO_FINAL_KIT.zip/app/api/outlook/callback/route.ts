import { CALLBACK_PATH, getOrigin, microsoftConfig } from '@/lib/outlook/config'
import { safeEqual, shortHash, unseal } from '@/lib/outlook/crypto'
import { exchangeCode, getMe, sealRefreshToken } from '@/lib/outlook/graph'
import { getAccount, saveAccount } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const OAUTH_COOKIE = 'tramix_oauth'

function readCookie(request: Request, name: string): string | null {
  for (const part of (request.headers.get('cookie') ?? '').split(';')) {
    const [k, ...v] = part.trim().split('=')
    if (k === name) return v.join('=')
  }
  return null
}

function finish(origin: string, outcome: 'ok' | 'error', reason?: string, code?: string) {
  const query = new URLSearchParams({
    outlook: outcome,
    ...(reason ? { reason } : {}),
    ...(code ? { code: code.slice(0, 80) } : {}),
  })
  return new Response(null, {
    status: 302,
    headers: {
      Location: `${origin}/cuentas-outlook?${query.toString()}`,
      'Cache-Control': 'no-store',
      'Set-Cookie': `${OAUTH_COOKIE}=; Path=/api/outlook; HttpOnly; Secure; SameSite=Lax; Max-Age=0`,
    },
  })
}

export async function GET(request: Request) {
  const origin = getOrigin(request)
  const cfg = microsoftConfig()
  if (!cfg) return finish(origin, 'error', 'config')

  const params = new URL(request.url).searchParams
  const msError = params.get('error')
  if (msError) {
    console.error('[outlook] authorize error', msError, params.get('error_description'))
    return finish(origin, 'error', msError === 'access_denied' ? 'denied' : 'microsoft', msError)
  }

  const raw = readCookie(request, OAUTH_COOKIE)
  const saved = raw ? unseal(raw, 'oauth-state', cfg.clientSecret) : null
  const parsed = saved ? (JSON.parse(saved) as { state: string; verifier: string; exp: number }) : null
  const state = params.get('state') ?? ''
  const code = params.get('code') ?? ''
  if (!parsed || parsed.exp < Date.now() || !code || !safeEqual(state, parsed.state)) return finish(origin, 'error', 'state')

  try {
    const tokens = await exchangeCode(code, `${origin}${CALLBACK_PATH}`, parsed.verifier)
    if (!tokens.refresh_token) return finish(origin, 'error', 'offline')
    const me = await getMe(tokens.access_token)
    const address = (me.mail || me.userPrincipalName || '').toLowerCase()
    if (!address) return finish(origin, 'error', 'address')

    const id = shortHash(`ms:${me.id}`, 20)
    const now = new Date().toISOString()
    const existing = await getAccount(id)
    await saveAccount({
      id,
      address,
      name: me.displayName ?? address,
      refresh: sealRefreshToken(tokens.refresh_token),
      status: 'ok',
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    })
    return finish(origin, 'ok')
  } catch (error) {
    console.error('[outlook] callback failed', error)
    return finish(origin, 'error', 'exchange', error instanceof Error ? error.message : undefined)
  }
}
