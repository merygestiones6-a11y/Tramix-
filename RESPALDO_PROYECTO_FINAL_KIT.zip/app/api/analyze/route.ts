import { mergePdfs } from '@/lib/pdf/merge'
import { detectFromBytes } from '@/lib/pipeline/core'
import type { RemoteMeta } from '@/lib/pipeline/remote-types'
import { nodeEngine, openPdf } from '@/lib/server/node-engine'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

const MAX_FILES = 20
const NO_STORE = { 'Cache-Control': 'no-store' }

/**
 * Processes the uploaded PDFs in memory only: nothing is written to disk or
 * stored, and the bytes are released when the request ends.
 */
export async function POST(request: Request) {
  let form: FormData
  try {
    form = await request.formData()
  } catch {
    return Response.json({ error: 'bad-request' }, { status: 400, headers: NO_STORE })
  }

  const files = form.getAll('files').filter((entry): entry is File => entry instanceof File)
  if (files.length === 0 || files.length > MAX_FILES) {
    return Response.json({ error: 'bad-request' }, { status: 400, headers: NO_STORE })
  }

  const sources: Uint8Array[] = []
  for (const [index, file] of files.entries()) {
    const bytes = new Uint8Array(await file.arrayBuffer())
    try {
      const { close } = await openPdf(bytes)
      await close()
    } catch {
      return Response.json({ error: 'unreadable', index }, { status: 422, headers: NO_STORE })
    }
    sources.push(bytes)
  }

  try {
    const merged = sources.length > 1
    const bytes = merged ? await mergePdfs(sources) : sources[0]
    const outcome = await detectFromBytes(bytes, nodeEngine)

    const meta: RemoteMeta = {
      merged,
      pageCount: outcome.pageCount,
      usedOcr: outcome.usedOcr,
      data: outcome.data,
      procedureId: outcome.procedure?.rule.id ?? null,
      procedureScore: outcome.procedure?.score ?? 0,
    }

    return new Response(merged ? Buffer.from(bytes) : null, {
      status: 200,
      headers: {
        ...NO_STORE,
        'Content-Type': merged ? 'application/pdf' : 'application/octet-stream',
        'X-FileKit-Meta': encodeURIComponent(JSON.stringify(meta)),
      },
    })
  } catch (error) {
    console.error('[FileKit] server analysis failed', error)
    return Response.json({ error: 'failed' }, { status: 500, headers: NO_STORE })
  }
}
