import QRCode from 'qrcode'
import { generateDatosFiscalesPdf } from '@/lib/cifsat/datos-fiscales-pdf'
import {
  buildDatosFiscalesUrl,
  getRegimenCatalog,
  matchRegimenes,
  validateDatosFiscales,
} from '@/lib/cifsat/sat-datos-fiscales'
import { SatLookupError, lookupSatValidacion360 } from '@/lib/cifsat/sat-lookup'
import { isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'

export const runtime = 'nodejs'

const json = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } })

function fail(error: unknown, scope: string) {
  if (error instanceof SatLookupError) return json({ error: error.message }, error.status)
  console.error(`[datos-fiscales] ${scope} failed:`, error)
  return json({ error: 'Ocurrió un error inesperado. Intenta de nuevo.' }, 500)
}

async function consultar(body: Record<string, unknown>) {
  const rfc = normalizeRfc(String(body.rfc ?? ''))
  const idCif = normalizeIdCif(String(body.idCif ?? ''))
  if (!isValidRfc(rfc) || !isValidIdCif(idCif)) return json({ error: 'RFC o idCIF inválido.' }, 422)

  const record = await lookupSatValidacion360(idCif, rfc)
  const regimenes = record.regimenes.map((r) => r.regimen).filter(Boolean)
  const missing = [
    !record.nombre && 'nombre',
    !regimenes.length && 'régimen fiscal',
    !record.domicilio.codigoPostal && 'código postal',
  ].filter(Boolean)
  if (missing.length) {
    return json({ error: `El SAT no devolvió: ${missing.join(', ')}. No se puede generar el documento.` }, 422)
  }
  return json({ rfc: record.rfc, nombre: record.nombre, cp: record.domicilio.codigoPostal, regimenes })
}

async function regimen(body: Record<string, unknown>) {
  const descriptions = Array.isArray(body.regimenes) ? body.regimenes.map(String).filter(Boolean) : []
  if (!descriptions.length) return json({ error: 'No hay régimen para consultar.' }, 422)
  const catalog = await getRegimenCatalog()
  return json({ matches: matchRegimenes(descriptions, catalog) })
}

async function generar(body: Record<string, unknown>) {
  const data = {
    name: String(body.name ?? '').trim(),
    rfc: normalizeRfc(String(body.rfc ?? '')),
    regimen: String(body.regimen ?? '').trim(),
    cp: String(body.cp ?? '').trim(),
  }
  if (!data.name || !isValidRfc(data.rfc) || !/^\d{3}(\|\d{3})*$/.test(data.regimen) || !/^\d{5}$/.test(data.cp)) {
    return json({ error: 'Faltan datos obligatorios. No se generó el documento.' }, 422)
  }

  // Only SAT-confirmed data can produce a document.
  const equal = await validateDatosFiscales(data)
  if (!equal) {
    return json({ error: 'El SAT no confirmó estos datos fiscales. No se generó el documento.' }, 422)
  }

  const url = buildDatosFiscalesUrl(data)
  const qr = await QRCode.toDataURL(url, { errorCorrectionLevel: 'H', margin: 1, width: 480 })
  const pdf = await generateDatosFiscalesPdf(data, url)
  return json({ url, qr, pdf: Buffer.from(pdf).toString('base64') })
}

export async function POST(request: Request) {
  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return json({ error: 'Solicitud inválida.' }, 400)
  }

  const action = String(body.action ?? '')
  try {
    if (action === 'consultar') return await consultar(body)
    if (action === 'regimen') return await regimen(body)
    if (action === 'generar') return await generar(body)
    return json({ error: 'Acción no válida.' }, 400)
  } catch (error) {
    return fail(error, action)
  }
}
