import { generateSituacionFiscalPdf } from '@/lib/cifsat/situacion-fiscal-pdf'
import { SatLookupError, lookupSatValidacion360 } from '@/lib/cifsat/sat-lookup'
import { buildSatValidatorUrl, isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'

export const runtime = 'nodejs'

// SAT returns "AVENIDA (AV.) AVENIDA EJERCITO NACIONAL": the type is repeated with its abbreviation.
function cleanVialidad(value: string) {
  const text = value.replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim()
  const [first, ...rest] = text.split(' ')
  return rest[0] === first ? rest.join(' ') : text
}

const json = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } })

export async function POST(request: Request) {
  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return json({ error: 'Solicitud inválida.' }, 400)
  }

  const rfc = normalizeRfc(String(body.rfc ?? ''))
  const idCif = normalizeIdCif(String(body.idCif ?? ''))
  if (!isValidRfc(rfc) || !isValidIdCif(idCif)) return json({ error: 'RFC o idCIF inválido.' }, 422)

  try {
    const record = await lookupSatValidacion360(idCif, rfc)
    record.domicilio.vialidad = cleanVialidad(record.domicilio.vialidad)
    const pdf = await generateSituacionFiscalPdf(record, buildSatValidatorUrl(idCif, rfc))
    return json({ record, pdf: Buffer.from(pdf).toString('base64') })
  } catch (error) {
    if (error instanceof SatLookupError) return json({ error: error.message }, error.status)
    console.error('[situacion-fiscal] failed:', error)
    return json({ error: 'Ocurrió un error inesperado. Intenta de nuevo.' }, 500)
  }
}
