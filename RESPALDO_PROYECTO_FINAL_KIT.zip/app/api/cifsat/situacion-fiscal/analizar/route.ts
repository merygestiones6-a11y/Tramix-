import { NextResponse } from 'next/server'
import { analizarPdf, corregirVisualizacion } from '@/lib/cifsat/pdf-analisis'

export const runtime = 'nodejs'

const MAX_BYTES = 10 * 1024 * 1024

export async function POST(request: Request) {
  let file: File | null = null
  try {
    const form = await request.formData()
    const value = form.get('archivo')
    file = value instanceof File ? value : null
  } catch {
    return NextResponse.json({ error: 'No se recibió el archivo.' }, { status: 400 })
  }

  if (!file) return NextResponse.json({ error: 'Selecciona un PDF.' }, { status: 400 })
  if (file.size > MAX_BYTES) return NextResponse.json({ error: 'El PDF supera 10 MB.' }, { status: 413 })

  const bytes = new Uint8Array(await file.arrayBuffer())
  if (Buffer.from(bytes.subarray(0, 5)).toString('latin1') !== '%PDF-') {
    return NextResponse.json({ error: 'El archivo no es un PDF.' }, { status: 400 })
  }

  try {
    const analisis = await analizarPdf(bytes)
    let corregido: string | null = null
    if (analisis.correccionSegura && analisis.hayCorrecciones) {
      corregido = Buffer.from(await corregirVisualizacion(bytes)).toString('base64')
    }
    return NextResponse.json({ analisis, corregido })
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'No se pudo analizar el PDF.' },
      { status: 422 },
    )
  }
}
