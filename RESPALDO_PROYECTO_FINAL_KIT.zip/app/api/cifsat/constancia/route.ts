import { generateCifPdf } from '@/lib/cifsat/cif-pdf'
import { SatLookupError, lookupSatName } from '@/lib/cifsat/sat-lookup'
import { isValidIdCif, isValidRfc, normalizeIdCif, normalizeRfc } from '@/lib/cifsat/sat-qr'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return Response.json({ error: 'Solicitud inválida.' }, { status: 400 })
  }

  const rfc = normalizeRfc(String(body.rfc ?? ''))
  const idCif = normalizeIdCif(String(body.idCif ?? ''))

  if (!isValidRfc(rfc) || !isValidIdCif(idCif)) {
    return Response.json({ error: 'Datos inválidos.' }, { status: 422 })
  }

  let nombre: string
  try {
    nombre = await lookupSatName(idCif, rfc)
  } catch (error) {
    if (error instanceof SatLookupError) {
      return Response.json({ error: error.message }, { status: error.status })
    }
    console.error('[constancia] SAT lookup failed:', error)
    return Response.json({ error: 'No se pudo consultar el validador del SAT.' }, { status: 502 })
  }

  try {
    const bytes = await generateCifPdf({ rfc, idCif, nombre })
    return new Response(Buffer.from(bytes), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="CIF_${rfc}.pdf"`,
        'Cache-Control': 'no-store',
        'X-Contribuyente-Nombre': encodeURIComponent(nombre),
      },
    })
  } catch (error) {
    console.error('[constancia] PDF generation failed:', error)
    return Response.json({ error: 'No se pudo generar la constancia.' }, { status: 500 })
  }
}
