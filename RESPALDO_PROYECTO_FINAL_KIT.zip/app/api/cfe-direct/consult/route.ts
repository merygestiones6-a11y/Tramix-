import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe-direct/http'
import { consult } from '@/lib/cfe-direct/store'
import { SERVICE_NUMBER } from '@/lib/cfe-direct/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { serviceNumber?: unknown } | null
  const service = typeof body?.serviceNumber === 'string' ? body.serviceNumber.replace(/\s/g, '') : ''
  if (!SERVICE_NUMBER.test(service)) return fail('invalid-service')
  try {
    return Response.json(await consult(service), { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
