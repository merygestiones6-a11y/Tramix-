import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe-direct/http'
import { addAccount, getState } from '@/lib/cfe-direct/store'
import { EMAIL } from '@/lib/cfe-direct/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  if (!canManage(request)) return unauthorized()
  try {
    return Response.json(await getState(), { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { email?: unknown } | null
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : ''
  if (!EMAIL.test(email) || email.length > 254) return fail('invalid-email')
  try {
    return Response.json({ account: await addAccount(email) }, { status: 201, headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
