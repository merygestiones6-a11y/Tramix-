import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { acceptLinkMessage } from '@/lib/outlook/receiver'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** The page opened with ABRIR ENLACE showed a message instead of documents → MENSAJE RECIBIDO card. */
export async function POST(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { itemId?: unknown; message?: unknown; manual?: unknown } | null
  const cardId = typeof body?.itemId === 'string' ? body.itemId : ''
  const message = typeof body?.message === 'string' ? body.message : ''
  if (!/^[a-zA-Z0-9_-]{8,64}$/.test(cardId)) return Response.json({ error: 'invalid-item' }, { status: 400, headers: NO_STORE })
  const result = await acceptLinkMessage(cardId, message.slice(0, 2000), body?.manual === true)
  if ('error' in result) return Response.json(result, { status: 404, headers: NO_STORE })
  return Response.json({ ok: true, item: result.item }, { headers: NO_STORE })
}
