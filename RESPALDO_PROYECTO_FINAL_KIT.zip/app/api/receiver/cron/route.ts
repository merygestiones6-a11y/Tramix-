import { scanReceiver } from '@/lib/outlook/receiver'
import { retireUsedAccounts } from '@/lib/outlook/retire-used'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

/** Scheduled pass (vercel.json cron) so documents arrive even when nobody has FileKit open. */
export async function GET(request: Request) {
  const secret = process.env.CRON_SECRET
  if (secret && request.headers.get('authorization') !== `Bearer ${secret}`) {
    return Response.json({ error: 'unauthorized' }, { status: 401 })
  }
  try {
    const { received } = await scanReceiver()
    const retire = await retireUsedAccounts().catch((error) => {
      console.error('[receiver] retire check failed', error)
      return null
    })
    return Response.json({ received, retired: retire?.retired ?? null })
  } catch (error) {
    console.error('[receiver] cron scan failed', error)
    return Response.json({ error: 'scan-failed' }, { status: 500 })
  }
}
