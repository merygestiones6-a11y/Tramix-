import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { deleteReceiverItems, readReceiver, scanReceiver } from '@/lib/outlook/receiver'
import type { ReceiverState } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

function publicState({ received, items, note, lastCheckAt, deleted, metrics }: ReceiverState) {
  // Recent deletions let open panels drop those cards without confusing them with a stale read.
  return Response.json(
    { received, items, note, lastCheckAt, deleted: (deleted ?? []).slice(-300), metrics },
    { headers: { 'Cache-Control': 'no-store' } },
  )
}

export async function GET(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  return publicState(await readReceiver())
}

/** Removes receiver cards only; Outlook e-mails and DESCARGAR PDFs are kept. */
export async function DELETE(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { ids?: unknown } | null
  const ids = Array.isArray(body?.ids)
    ? body.ids.filter((id): id is string => typeof id === 'string' && id.length > 0 && id.length <= 200).slice(0, 500)
    : []
  if (!ids.length) return Response.json({ error: 'no-ids' }, { status: 400 })
  return publicState(await deleteReceiverItems(ids))
}

/** Checks the linked Outlook accounts and sends every new PDF to DESCARGAR. */
export async function POST(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  try {
    const force = new URL(request.url).searchParams.get('force') === '1'
    return publicState(await scanReceiver({ force }))
  } catch (error) {
    console.error('[receiver] scan failed', error)
    return publicState(await readReceiver())
  }
}
