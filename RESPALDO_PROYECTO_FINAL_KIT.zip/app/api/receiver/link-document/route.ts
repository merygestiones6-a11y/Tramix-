import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { acceptLinkPdfs } from '@/lib/outlook/receiver'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

const NO_STORE = { 'Cache-Control': 'no-store' }
const MAX_BYTES = 30 * 1024 * 1024
const MAX_FILES = 6

function header(request: Request, name: string, max: number) {
  try {
    return decodeURIComponent(request.headers.get(name) ?? '').trim().slice(0, max)
  } catch {
    return ''
  }
}

/**
 * The documents downloaded from the page of one IMSS e-mail link (multipart, several `file` fields;
 * a single raw PDF body is also accepted) → joined into one PDF → SUBIR reading → DESCARGAR.
 */
export async function POST(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  if (Number(request.headers.get('content-length') ?? 0) > MAX_BYTES) {
    return Response.json({ error: 'too-large' }, { status: 413, headers: NO_STORE })
  }

  let cardId = header(request, 'x-item-id', 64)
  const files: { bytes: Uint8Array; name: string | null }[] = []
  if ((request.headers.get('content-type') ?? '').startsWith('multipart/form-data')) {
    const form = await request.formData().catch(() => null)
    if (!form) return Response.json({ error: 'invalid-body' }, { status: 400, headers: NO_STORE })
    const fromForm = form.get('itemId')
    if (typeof fromForm === 'string') cardId = fromForm.trim().slice(0, 64)
    for (const entry of form.getAll('file').slice(0, MAX_FILES)) {
      if (typeof entry === 'string') continue
      files.push({ bytes: new Uint8Array(await entry.arrayBuffer()), name: entry.name?.slice(0, 160) || null })
    }
  } else {
    files.push({ bytes: new Uint8Array(await request.arrayBuffer()), name: header(request, 'x-file-name', 160) || null })
  }

  if (!/^[a-zA-Z0-9_-]{8,64}$/.test(cardId)) return Response.json({ error: 'invalid-item' }, { status: 400, headers: NO_STORE })
  const result = await acceptLinkPdfs(cardId, files)
  if ('error' in result) return Response.json(result, { status: result.error === 'unknown-card' ? 404 : 415, headers: NO_STORE })
  return Response.json({ ok: true, item: result.item }, { headers: NO_STORE })
}
