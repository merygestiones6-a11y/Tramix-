import { NextResponse } from 'next/server'

const API_URL = 'https://api.datosnonstop.com/v1/imss/nss'
const CURP_REGEX = /^[A-Z]{4}\d{6}[HMX][A-Z]{5}[A-Z\d]\d$/
const NSS_REGEX = /^\d{11}$/
const REQUEST_TIMEOUT_MS = 25_000

export const dynamic = 'force-dynamic'

type ApiFoundResponse = { status: 'found'; nss?: unknown }
type ApiNotFoundResponse = { status: 'not_found'; message?: unknown }

function reply(body: Record<string, string>, status: number) {
  return NextResponse.json(body, {
    status,
    headers: { 'Cache-Control': 'no-store' },
  })
}

function notFoundReason(message: unknown): string {
  if (typeof message !== 'string') return 'No se encontró un NSS para esta CURP.'
  const text = message.toLowerCase()
  if (text.includes('renapo')) return 'La CURP no está registrada en RENAPO.'
  if (text.includes('subdelegaci')) return 'Es necesario acudir a una subdelegación del IMSS.'
  if (text.includes('24 horas') || text.includes('más de dos veces') || text.includes('mas de dos veces')) {
    return 'Límite de consultas alcanzado para esta CURP. Intenta en 24 horas.'
  }
  return 'No se encontró un NSS para esta CURP.'
}

export async function POST(request: Request) {
  // Keys pasted into the env UI sometimes keep surrounding quotes or spaces.
  const apiKey = process.env.DATOSNONSTOP_API_KEY?.trim().replace(/^["']+|["']+$/g, '').trim()
  if (!apiKey) {
    return reply({ error: 'Servicio no configurado: falta la clave de API.' }, 503)
  }

  let curp: string
  try {
    const body = (await request.json()) as { curp?: unknown }
    curp = typeof body.curp === 'string' ? body.curp.trim().toUpperCase() : ''
  } catch {
    return reply({ error: 'Solicitud inválida.' }, 400)
  }

  if (!CURP_REGEX.test(curp)) {
    return reply({ error: 'La CURP no tiene un formato válido.' }, 400)
  }

  let upstream: Response
  try {
    upstream = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({ curp }),
      cache: 'no-store',
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    })
  } catch (error) {
    const timedOut = error instanceof Error && error.name === 'TimeoutError'
    return reply(
      { error: timedOut ? 'El servicio tardó demasiado. Intenta de nuevo.' : 'No se pudo conectar con el servicio.' },
      504,
    )
  }

  const data: unknown = await upstream.json().catch(() => null)

  if (!upstream.ok) {
    switch (upstream.status) {
      case 400:
        return reply({ error: 'La CURP no tiene un formato válido.' }, 400)
      case 401:
      case 403:
        return reply({ error: 'Credencial del servicio inválida.' }, 502)
      case 402:
        return reply({ error: 'Sin saldo disponible en el servicio.' }, 502)
      case 429:
        return reply({ error: 'Demasiadas consultas. Intenta más tarde.' }, 429)
      default:
        return reply({ error: 'El servicio no está disponible. Intenta más tarde.' }, 502)
    }
  }

  const result = data as ApiFoundResponse | ApiNotFoundResponse | null

  if (result?.status === 'not_found') {
    return reply({ error: notFoundReason(result.message), code: 'not_found' }, 404)
  }

  if (result?.status === 'found') {
    const nss = typeof result.nss === 'string' ? result.nss.trim() : ''
    if (NSS_REGEX.test(nss)) {
      return reply({ nss }, 200)
    }
  }

  return reply({ error: 'Respuesta inesperada del servicio.' }, 502)
}
