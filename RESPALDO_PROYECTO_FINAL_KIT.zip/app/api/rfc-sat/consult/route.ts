import { NextResponse } from 'next/server'
import { absoluteUrl, satimexFetch, SatimexError } from '@/lib/rfc-sat/satimex'
import { SYSTEM_SERVICES } from '@/lib/rfc-sat/services'

export const maxDuration = 120

const SAFE_ID = /^[\w-]{1,64}$/

export async function POST(req: Request) {
  try {
    const { serviceId, values } = await req.json()
    if (typeof serviceId !== 'string' || !SAFE_ID.test(serviceId) || typeof values !== 'object' || !values) {
      return NextResponse.json({ message: 'Datos inválidos' }, { status: 400 })
    }

    const clean: Record<string, string> = {}
    for (const [k, v] of Object.entries(values)) {
      if (typeof v === 'string' && /^[\w-]{1,40}$/.test(k)) clean[k] = v.trim().slice(0, 200)
    }

    const native = SYSTEM_SERVICES.some((s) => s.id === serviceId)
    const path = native ? `/services/${serviceId}` : `/services/custom/${serviceId}`
    const data = await satimexFetch(path, { method: 'POST', body: JSON.stringify(clean) })

    if (!data.ok) {
      return NextResponse.json({ message: data.message || 'La consulta falló' }, { status: 422 })
    }

    const pdf = data.data?.type === 'pdf' ? { base64: data.data.base64, filename: data.data.filename } : null
    return NextResponse.json({
      downloadUrl: absoluteUrl(data.download_url),
      pdf,
      info: !pdf && data.data && typeof data.data === 'object' ? data.data : null,
    })
  } catch (e) {
    const err = e instanceof SatimexError ? e : new SatimexError('Error de red o tiempo excedido')
    return NextResponse.json({ message: err.message }, { status: err.status })
  }
}
