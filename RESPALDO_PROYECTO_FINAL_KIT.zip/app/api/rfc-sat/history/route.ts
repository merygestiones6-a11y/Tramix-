import { NextResponse } from 'next/server'
import { absoluteUrl, satimexFetch, SatimexError } from '@/lib/rfc-sat/satimex'
import type { HistoryLog } from '@/lib/rfc-sat/services'

export async function GET() {
  try {
    const data = await satimexFetch('/services/history?page=1')
    if (!data.ok) throw new SatimexError(data.message || 'No se pudo cargar el historial', 502)
    const logs: HistoryLog[] = (data.logs ?? []).map((l: any) => ({
      id: l.id,
      service: l.service,
      cost: Number(l.cost ?? 0),
      status: String(l.status ?? ''),
      created_at: l.created_at,
      result_url: absoluteUrl(l.result_path),
    }))
    return NextResponse.json({ logs })
  } catch (e) {
    const err = e instanceof SatimexError ? e : new SatimexError('Error de conexión con Satimex')
    return NextResponse.json({ message: err.message }, { status: err.status })
  }
}
