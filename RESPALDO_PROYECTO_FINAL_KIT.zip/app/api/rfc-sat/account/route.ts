import { NextResponse } from 'next/server'
import { satimexFetch, SatimexError } from '@/lib/rfc-sat/satimex'
import { SYSTEM_SERVICES, type Account, type Service } from '@/lib/rfc-sat/services'

export async function GET() {
  try {
    const [me, list] = await Promise.all([satimexFetch('/services/me'), satimexFetch('/services/list')])
    if (!me.ok) throw new SatimexError(me.message || 'No se pudo cargar la cuenta', 502)

    const prices: Record<string, number> = me.user?.prices ?? {}
    const custom: Service[] = (list.ok ? list.services : []).map((s: any) => ({
      id: String(s.id),
      name: String(s.name ?? ''),
      cost: Number(s.cost ?? 0),
      fields: typeof s.fields === 'string' ? s.fields.split(',').map((f: string) => f.trim()).filter(Boolean) : (s.fields ?? []),
      desc: String(s.desc ?? s.description ?? ''),
      native: false,
    }))

    const seen = new Set<string>()
    const services = [...SYSTEM_SERVICES, ...custom]
      .filter((s) => {
        const key = s.name.trim().toLowerCase()
        if (seen.has(key)) return false
        seen.add(key)
        return true
      })
      .map((s) => ({ ...s, cost: Number(prices[s.id] ?? s.cost) }))

    const account: Account = {
      username: me.user.username,
      credits: Number(me.user.credits ?? 0),
      services,
    }
    return NextResponse.json(account)
  } catch (e) {
    const err = e instanceof SatimexError ? e : new SatimexError('Error de conexión con Satimex')
    return NextResponse.json({ message: err.message }, { status: err.status })
  }
}
