import { NextResponse } from 'next/server'
import { descargarArchivo, GoatError, marcarDescargados } from '@/lib/actanex/goat'

export async function GET(request: Request, { params }: { params: Promise<{ ruta: string }> }) {
  const { ruta } = await params
  const id = Number(new URL(request.url).searchParams.get('id'))

  try {
    const { res, nombre } = await descargarArchivo(ruta)
    const buffer = await res.arrayBuffer()
    if (Number.isInteger(id) && id > 0) await marcarDescargados([id]).catch((e) => console.error('[goat] marcar', e))
    return new Response(buffer, {
      headers: {
        'content-type': res.headers.get('content-type') ?? 'application/pdf',
        'content-disposition': `attachment; filename="${nombre.replace(/"/g, '')}"`,
        'cache-control': 'no-store',
      },
    })
  } catch (error) {
    const message = error instanceof GoatError ? error.message : 'No se pudo descargar.'
    return NextResponse.json({ error: message }, { status: 502 })
  }
}
