import { NextResponse } from 'next/server'
import { crearSolicitudes, GoatError, listarSolicitudes } from '@/lib/actanex/goat'
import { curpValida, TIPOS, usaSegundaCurp } from '@/lib/actanex/curp'
import { conHoraDeRecepcion } from '@/lib/actanex/recibidos'

const MAX_POR_ENVIO = 50

function errorResponse(error: unknown) {
  const message = error instanceof GoatError ? error.message : 'Error inesperado al hablar con GOAT.'
  console.error('[goat]', error)
  return NextResponse.json({ error: message }, { status: 502 })
}

export async function GET() {
  try {
    return NextResponse.json({ registros: await conHoraDeRecepcion(await listarSolicitudes()) })
  } catch (error) {
    return errorResponse(error)
  }
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null)
  const tipo = String(body?.tipo ?? '')
  const folio = body?.folio === true
  const items: unknown[] = Array.isArray(body?.items) ? body.items : []

  if (!TIPOS.includes(tipo as (typeof TIPOS)[number])) {
    return NextResponse.json({ error: 'Tipo inválido' }, { status: 400 })
  }
  if (items.length === 0 || items.length > MAX_POR_ENVIO) {
    return NextResponse.json({ error: `Envía entre 1 y ${MAX_POR_ENVIO} solicitudes a la vez.` }, { status: 400 })
  }

  const limpias = []
  for (const raw of items) {
    const item = (raw ?? {}) as Record<string, unknown>
    const curp = typeof item.curp === 'string' ? item.curp.trim().toUpperCase() : null
    const segunda = typeof item.CurpOpcional === 'string' ? item.CurpOpcional.trim().toUpperCase() : null
    const cadena = typeof item.cadena === 'string' ? item.cadena.trim().slice(0, 50) : null
    if (!curp && !cadena) return NextResponse.json({ error: 'Cada solicitud necesita CURP o cadena.' }, { status: 400 })
    if (curp && !curpValida(curp)) return NextResponse.json({ error: `CURP inválida: ${curp}` }, { status: 400 })
    if (segunda && !curpValida(segunda)) return NextResponse.json({ error: `CURP inválida: ${segunda}` }, { status: 400 })
    limpias.push({
      curp: curp || null,
      CurpOpcional: usaSegundaCurp(tipo) ? segunda || null : null,
      cadena: curp ? null : cadena || null,
    })
  }

  try {
    await crearSolicitudes(tipo, folio, limpias)
    return NextResponse.json({ ok: true, enviadas: limpias.length })
  } catch (error) {
    return errorResponse(error)
  }
}
