import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { receiptFileName } from '@/lib/cfe/holder'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { saveReceipt } from '@/lib/cfe/store'
import { MAX_RECEIPT_BYTES, SERVICE_NUMBER } from '@/lib/cfe/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const PDF_MAGIC = [0x25, 0x50, 0x44, 0x46] // %PDF

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const form = await request.formData().catch(() => null)
  const file = form?.get('file')
  if (!(file instanceof File)) return fail('invalid-pdf')
  if (file.size > MAX_RECEIPT_BYTES) return fail('too-large')

  const bytes = new Uint8Array(await file.arrayBuffer())
  if (!PDF_MAGIC.every((b, i) => bytes[i] === b)) return fail('invalid-pdf')

  const holderRaw = String(form?.get('holder') ?? '').replace(/\s+/g, ' ').trim().toUpperCase().slice(0, 120)
  const serviceRaw = String(form?.get('serviceNumber') ?? '').replace(/\s/g, '')
  if (serviceRaw && !SERVICE_NUMBER.test(serviceRaw)) return fail('invalid-service')
  const holder = holderRaw || null
  const serviceNumber = serviceRaw || null

  try {
    const receipt = await saveReceipt({ bytes, holder, serviceNumber, fileName: receiptFileName(holder, serviceNumber) })
    return Response.json({ receipt }, { status: 201, headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
