import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { deleteReceipt, isCfeId, readReceipt } from '@/lib/cfe/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type Context = { params: Promise<{ id: string }> }

export async function GET(request: Request, { params }: Context) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isCfeId(id)) return fail('not-found')
  try {
    const found = await readReceipt(id)
    if (!found) return fail('not-found')
    const inline = new URL(request.url).searchParams.get('inline') === '1'
    const name = encodeURIComponent(found.receipt.fileName)
    return new Response(found.stream, {
      headers: {
        ...NO_STORE,
        'Content-Type': 'application/pdf',
        'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${name}`,
      },
    })
  } catch (error) {
    return handle(error)
  }
}

export async function DELETE(request: Request, { params }: Context) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isCfeId(id)) return fail('not-found')
  try {
    await deleteReceipt(id)
    return Response.json({ ok: true }, { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
