import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { NO_STORE } from '@/lib/cfe/http'
import { deviceHandle } from '@/lib/cfe/device-http'
import { listDevices } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** FileKit admin: registered devices (no tokens) and the job queue. */
export async function GET(request: Request) {
  if (!canManage(request)) return unauthorized()
  try {
    return Response.json(await listDevices(), { headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
