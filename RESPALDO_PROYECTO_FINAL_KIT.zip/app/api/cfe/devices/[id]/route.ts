import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { NO_STORE } from '@/lib/cfe/http'
import { deviceFail, deviceHandle } from '@/lib/cfe/device-http'
import { isDeviceId, revokeDevice } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** FileKit admin: revokes a device token; its active job goes back to the queue. */
export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isDeviceId(id)) return deviceFail('not-found')
  try {
    await revokeDevice(id)
    return Response.json({ ok: true }, { headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
