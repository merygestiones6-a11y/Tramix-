import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { activateAccount, deleteAccount, isCfeId, removeService } from '@/lib/cfe/store'
import { SERVICE_NUMBER } from '@/lib/cfe/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type Context = { params: Promise<{ id: string }> }

export async function PATCH(request: Request, { params }: Context) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isCfeId(id)) return fail('not-found')
  const body = (await request.json().catch(() => null)) as { action?: unknown; serviceNumber?: unknown } | null
  try {
    if (body?.action === 'activate') await activateAccount(id)
    else if (body?.action === 'remove-service') {
      const service = typeof body.serviceNumber === 'string' ? body.serviceNumber : ''
      if (!SERVICE_NUMBER.test(service)) return fail('invalid-service')
      await removeService(id, service)
    } else return fail('not-found')
    return Response.json({ ok: true }, { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}

export async function DELETE(request: Request, { params }: Context) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isCfeId(id)) return fail('not-found')
  try {
    await deleteAccount(id)
    return Response.json({ ok: true }, { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
