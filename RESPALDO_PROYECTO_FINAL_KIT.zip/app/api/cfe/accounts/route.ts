import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { addAccount } from '@/lib/cfe/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { email?: unknown; password?: unknown } | null
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : ''
  const password = typeof body?.password === 'string' ? body.password : ''
  if (!EMAIL.test(email) || email.length > 254) return fail('invalid-email')
  if (!password || password.length > 256) return fail('invalid-password')
  try {
    return Response.json({ account: await addAccount(email, password) }, { status: 201, headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
