import { NO_STORE } from '@/lib/cfe/http'
import { deviceHandle, requireDevice } from '@/lib/cfe/device-http'
import { heartbeat } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Device reports CONECTADO. Auth: `Authorization: Bearer <device token>`. */
export async function POST(request: Request) {
  const auth = await requireDevice(request)
  if (auth instanceof Response) return auth
  try {
    await heartbeat(auth.deviceId)
    return Response.json({ state: 'CONECTADO' }, { headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
