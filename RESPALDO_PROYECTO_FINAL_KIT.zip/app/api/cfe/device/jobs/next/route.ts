import { NO_STORE } from '@/lib/cfe/http'
import { deviceHandle, jobView, requireDevice } from '@/lib/cfe/device-http'
import { claimNextJob, LEASE_MS } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Leases the next pending CFE request (11-digit service number) to this device.
 * 200 `{ job }` while there is work, 204 when the queue is empty.
 * Calling again before finishing returns the same job (safe to retry).
 */
export async function POST(request: Request) {
  const auth = await requireDevice(request)
  if (auth instanceof Response) return auth
  try {
    const job = await claimNextJob(auth.deviceId)
    if (!job) return new Response(null, { status: 204, headers: NO_STORE })
    return Response.json({ job: jobView(job), leaseMs: LEASE_MS }, { headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
