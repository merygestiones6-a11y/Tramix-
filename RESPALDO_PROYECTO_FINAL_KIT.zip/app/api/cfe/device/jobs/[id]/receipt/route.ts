import { NO_STORE } from '@/lib/cfe/http'
import { ingestReceipt } from '@/lib/cfe/ingest'
import { deviceFail, deviceHandle, jobView, requireDevice } from '@/lib/cfe/device-http'
import { completeJob, failJob, isDeviceId, jobForUpload } from '@/lib/cfe/device-store'
import { MAX_RECEIPT_BYTES, type CfeErrorCode } from '@/lib/cfe/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Errors a new attempt can fix; the rest go to manual import. */
const RETRYABLE: CfeErrorCode[] = ['server-error']

/**
 * Device uploads the PDF for its leased job. Body: raw `application/pdf`.
 * Runs the existing CFE flow (detect holder + service → validate 11 digits → rename → save → DESCARGADO).
 * Re-uploading after success returns the stored receipt; the same PDF is never saved twice.
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireDevice(request)
  if (auth instanceof Response) return auth
  const { id } = await params
  if (!isDeviceId(id)) return deviceFail('not-found')

  const declared = Number(request.headers.get('content-length') ?? 0)
  if (declared > MAX_RECEIPT_BYTES) return deviceFail('too-large', 413)

  try {
    const job = await jobForUpload(auth.deviceId, id)
    if (job.status === 'completed') {
      return Response.json({ job: jobView(job), duplicate: true }, { headers: NO_STORE })
    }

    const bytes = new Uint8Array(await request.arrayBuffer())
    const result = await ingestReceipt({
      bytes,
      source: 'authorized',
      expectedServiceNumber: job.serviceNumber,
      requestId: job.requestId,
    })

    if (!result.ok) {
      const failed = await failJob(auth.deviceId, id, result.error, RETRYABLE.includes(result.error))
      return Response.json(
        { error: result.error, holder: result.holder, serviceNumber: result.serviceNumber, job: jobView(failed) },
        { status: 422, headers: NO_STORE },
      )
    }
    if (result.receipt.serviceNumber !== job.serviceNumber) {
      const failed = await failJob(auth.deviceId, id, 'service-mismatch', false)
      return Response.json({ error: 'service-mismatch', job: jobView(failed) }, { status: 422, headers: NO_STORE })
    }

    const done = await completeJob(auth.deviceId, id, result.receipt.id)
    return Response.json(
      { job: jobView(done), receipt: { id: result.receipt.id, fileName: result.receipt.fileName }, duplicate: result.duplicate },
      { status: result.duplicate ? 200 : 201, headers: NO_STORE },
    )
  } catch (error) {
    return deviceHandle(error)
  }
}
