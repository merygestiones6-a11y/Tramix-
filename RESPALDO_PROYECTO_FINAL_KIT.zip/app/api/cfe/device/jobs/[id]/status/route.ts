import { NO_STORE } from '@/lib/cfe/http'
import { deviceFail, deviceHandle, jobView, requireDevice } from '@/lib/cfe/device-http'
import { isDeviceId, reportJobState, type DeviceJobState } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const ALLOWED: DeviceJobState[] = ['CONECTADO', 'PROCESANDO', 'ERROR']

/**
 * Body: `{ "state": "CONECTADO" | "PROCESANDO" | "ERROR", "message"?: string, "retryable"?: boolean }`.
 * COMPLETADO is set by FileKit only after the uploaded PDF passes the CFE flow.
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireDevice(request)
  if (auth instanceof Response) return auth
  const { id } = await params
  if (!isDeviceId(id)) return deviceFail('not-found')
  const body = (await request.json().catch(() => null)) as { state?: unknown; message?: unknown; retryable?: unknown } | null
  const state = body?.state as DeviceJobState
  if (!ALLOWED.includes(state)) return deviceFail('invalid-state')
  try {
    const job = await reportJobState(auth.deviceId, id, {
      state,
      message: typeof body?.message === 'string' ? body.message : null,
      retryable: typeof body?.retryable === 'boolean' ? body.retryable : true,
    })
    return Response.json({ job: jobView(job) }, { headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
