import { NO_STORE } from '@/lib/cfe/http'
import { deviceFail, deviceHandle, enrollmentAllowed } from '@/lib/cfe/device-http'
import { registerDevice } from '@/lib/cfe/device-store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Registers an Android device.
 * Auth: `Authorization: Bearer <CFE_DEVICE_ENROLL_SECRET>`. Body: `{ "name": "Pixel 7" }`.
 * Returns the device token once; the device must store it and use it from then on.
 */
export async function POST(request: Request) {
  const denied = enrollmentAllowed(request)
  if (denied) return denied
  const body = (await request.json().catch(() => null)) as { name?: unknown } | null
  const name = typeof body?.name === 'string' ? body.name.replace(/[\u0000-\u001f]/g, '').trim().slice(0, 60) : ''
  if (!name) return deviceFail('invalid-name')
  try {
    const result = await registerDevice(name)
    return Response.json({ ...result, state: 'CONECTADO' }, { status: 201, headers: NO_STORE })
  } catch (error) {
    return deviceHandle(error)
  }
}
