import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { handle, NO_STORE } from '@/lib/cfe/http'
import { getCfeState } from '@/lib/cfe/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  if (!canManage(request)) return unauthorized()
  try {
    return Response.json(await getCfeState(), { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
