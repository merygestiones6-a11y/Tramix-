import { safeEqual } from '@/lib/outlook/crypto'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { ingestReceipt } from '@/lib/cfe/ingest'
import { isCfeId } from '@/lib/cfe/store'
import { MAX_RECEIPT_BYTES } from '@/lib/cfe/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Push entry point for an officially authorized CFE receipt source.
 * Auth: `Authorization: Bearer <CFE_INGEST_SECRET>`. Disabled until that variable is set.
 * Body: raw `application/pdf` (optional `X-Service-Number` / `X-Request-Id` headers),
 * or multipart with `file` and optional `serviceNumber` / `requestId`.
 */
export async function POST(request: Request) {
  const secret = process.env.CFE_INGEST_SECRET?.trim()
  if (!secret) return fail('not-configured')
  const token = request.headers.get('authorization')?.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() ?? ''
  if (!token || !safeEqual(token, secret)) return fail('unauthorized')

  const declared = Number(request.headers.get('content-length') ?? 0)
  if (declared > MAX_RECEIPT_BYTES + 64 * 1024) return fail('too-large')

  let bytes: Uint8Array
  let serviceNumber: string | null
  let requestId: string | null
  const type = request.headers.get('content-type') ?? ''
  if (type.startsWith('multipart/form-data')) {
    const form = await request.formData().catch(() => null)
    const file = form?.get('file')
    if (!(file instanceof File)) return fail('invalid-pdf')
    if (file.size > MAX_RECEIPT_BYTES) return fail('too-large')
    bytes = new Uint8Array(await file.arrayBuffer())
    serviceNumber = String(form?.get('serviceNumber') ?? '') || null
    requestId = String(form?.get('requestId') ?? '') || null
  } else {
    bytes = new Uint8Array(await request.arrayBuffer())
    serviceNumber = request.headers.get('x-service-number')
    requestId = request.headers.get('x-request-id')
  }
  if (requestId && !isCfeId(requestId)) requestId = null

  try {
    const result = await ingestReceipt({ bytes, source: 'authorized', expectedServiceNumber: serviceNumber, requestId })
    if (!result.ok) {
      return Response.json(result, { status: fail(result.error).status, headers: NO_STORE })
    }
    return Response.json(result, { status: result.duplicate ? 200 : 201, headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
