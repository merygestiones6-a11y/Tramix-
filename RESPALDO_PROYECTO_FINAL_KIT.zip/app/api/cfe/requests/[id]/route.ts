import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { deleteRequest, isCfeId } from '@/lib/cfe/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isCfeId(id)) return fail('not-found')
  try {
    await deleteRequest(id)
    return Response.json({ ok: true }, { headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
