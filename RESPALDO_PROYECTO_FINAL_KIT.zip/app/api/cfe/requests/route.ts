import { unauthorized } from '@/lib/outlook/access'
import { canManage } from '@/lib/outlook-pool/store'
import { fail, handle, NO_STORE } from '@/lib/cfe/http'
import { createRequest } from '@/lib/cfe/store'
import { SERVICE_NUMBER } from '@/lib/cfe/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { serviceNumber?: unknown } | null
  const service = typeof body?.serviceNumber === 'string' ? body.serviceNumber.replace(/\s/g, '') : ''
  if (!SERVICE_NUMBER.test(service)) return fail('invalid-service')
  try {
    return Response.json({ request: await createRequest(service) }, { status: 201, headers: NO_STORE })
  } catch (error) {
    return handle(error)
  }
}
