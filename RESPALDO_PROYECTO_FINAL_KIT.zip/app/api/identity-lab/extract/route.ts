import { classifyModelError, runExtraction } from '@/lib/identity-lab/doc-extract/model'
import { ERROR_MESSAGE, type ErrorCode } from '@/lib/identity-lab/doc-extract/modes'
import { extractRequestSchema } from '@/lib/identity-lab/doc-extract/schema'

export const runtime = 'nodejs'
export const maxDuration = 60

const MAX_BODY_CHARS = 4_400_000

function fail(code: ErrorCode, status: number, requestId: string, message = ERROR_MESSAGE[code]) {
  return Response.json({ error: message, code, requestId }, { status, headers: { 'Cache-Control': 'no-store', 'X-Request-Id': requestId } })
}

export async function POST(request: Request) {
  const t0 = performance.now()
  const requestId = crypto.randomUUID().slice(0, 8)
  const raw = await request.text()
  if (raw.length > MAX_BODY_CHARS) return fail('LIMITE', 413, requestId, 'El archivo es demasiado grande para analizarse.')

  let body: unknown
  try {
    body = JSON.parse(raw)
  } catch {
    return fail('SOLICITUD', 400, requestId, 'Solicitud no válida.')
  }

  const parsed = extractRequestSchema.safeParse(body)
  if (!parsed.success) return fail('SOLICITUD', 400, requestId, parsed.error.issues[0]?.message ?? 'Solicitud no válida.')
  const parseMs = Math.round(performance.now() - t0)
  const { mode, segments, images } = parsed.data

  try {
    const { result, timings } = await runExtraction(parsed.data, request.signal)
    const totalMs = Math.round(performance.now() - t0)
    // Only sizes, durations and ids are logged: request bodies contain personal data.
    console.log(
      `[identity-lab/extract] id=${requestId} modo=${mode} bytes=${raw.length} segmentos=${segments.length} imagenes=${images.length} parse=${parseMs}ms preparar=${timings.buildMs}ms modelo=${timings.modelMs}ms total=${totalMs}ms tokens=${timings.inputTokens ?? '?'}/${timings.outputTokens ?? '?'}`,
    )
    return Response.json(
      { result, requestId, timings: { parseMs, ...timings, serverMs: totalMs } },
      {
        headers: {
          'Cache-Control': 'no-store',
          'X-Request-Id': requestId,
          'Server-Timing': `parse;dur=${parseMs}, model;dur=${timings.modelMs}, total;dur=${totalMs}`,
        },
      },
    )
  } catch (error) {
    const { code, status } = classifyModelError(error)
    const statusCode = (error as { statusCode?: number })?.statusCode ?? (error as { lastError?: { statusCode?: number } })?.lastError?.statusCode
    console.error(`[identity-lab/extract] id=${requestId} modo=${mode} etapa=modelo codigo=${code} http=${statusCode ?? '-'} tras=${Math.round(performance.now() - t0)}ms`)
    return fail(code, status, requestId)
  }
}
