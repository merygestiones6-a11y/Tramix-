import { after } from 'next/server'
import { deleteHandoff, isValidToken, openHandoff } from '@/lib/foliador-handoff'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

function asciiFallback(name: string) {
  return name.normalize('NFD').replace(/[^\x20-\x7e]/g, '').replace(/["\\]/g, '') || 'documento.pdf'
}

export async function GET(_request: Request, { params }: { params: Promise<{ token: string; name: string }> }) {
  const { token } = await params
  if (!isValidToken(token)) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  const file = await openHandoff(token)
  if (!file) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  after(() => deleteHandoff(file.pathname))
  return new Response(file.stream, {
    headers: {
      ...NO_STORE,
      'Content-Type': 'application/pdf',
      'Content-Length': String(file.size),
      'Content-Disposition': `attachment; filename="${asciiFallback(file.name)}"; filename*=UTF-8''${encodeURIComponent(file.name)}`,
    },
  })
}
