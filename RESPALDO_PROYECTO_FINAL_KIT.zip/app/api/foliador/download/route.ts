import { after } from 'next/server'
import { isSafePdfName, MAX_HANDOFF_BYTES, storeHandoff, sweepExpiredHandoffs } from '@/lib/foliador-handoff'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

export async function POST(request: Request) {
  const form = await request.formData().catch(() => null)
  const file = form?.get('file')
  const name = form?.get('name')
  if (!(file instanceof Blob) || typeof name !== 'string' || !isSafePdfName(name)) {
    return Response.json({ error: 'invalid' }, { status: 400, headers: NO_STORE })
  }
  if (file.size === 0 || file.size > MAX_HANDOFF_BYTES) {
    return Response.json({ error: 'size' }, { status: 413, headers: NO_STORE })
  }
  const bytes = await file.arrayBuffer()
  if (new TextDecoder().decode(bytes.slice(0, 5)) !== '%PDF-') {
    return Response.json({ error: 'not-pdf' }, { status: 400, headers: NO_STORE })
  }

  const token = await storeHandoff(bytes, name)
  after(sweepExpiredHandoffs)
  return Response.json(
    { url: `/api/foliador/download/${token}/${encodeURIComponent(name)}` },
    { headers: NO_STORE },
  )
}
