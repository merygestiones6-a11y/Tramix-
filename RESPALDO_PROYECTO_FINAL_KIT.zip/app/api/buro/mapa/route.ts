import { getRecord } from '@/lib/buro/store'
import { streetLine, type BuroRecord } from '@/lib/buro/schema'

export const runtime = 'nodejs'

const UA = 'TRAMIX-comprobante/1.0 (vercel.app)'

type Precision = 'EXACTA' | 'CALLE' | 'CODIGO_POSTAL' | 'MUNICIPIO'
const ZOOM: Record<Precision, number> = { EXACTA: 16, CALLE: 16, CODIGO_POSTAL: 15, MUNICIPIO: 13 }

/**
 * Map for the comprobante PNG (the interactive iframe is cross-origin and cannot be captured).
 * Default: JSON with the best available location so the browser can draw OpenStreetMap tiles.
 * `formato=imagen`: same-origin Google Static Maps image (only with GOOGLE_MAPS_API_KEY; the key never reaches the browser).
 */
export async function GET(request: Request) {
  const params = new URL(request.url).searchParams
  const record = await getRecord(params.get('folio') ?? '')
  if (!record) return Response.json({ code: 'FOLIO' }, { status: 404 })

  const key = process.env.GOOGLE_MAPS_API_KEY
  if (params.get('formato') === 'imagen') {
    if (!key) return Response.json({ code: 'SIN_CLAVE' }, { status: 503 })
    return googleStatic(record, key)
  }

  const t0 = Date.now()
  const loc = await locate(record)
  if (!loc) {
    console.error('[buro] etapa=mapa-ubicacion codigo=sin-ubicacion')
    return Response.json({ code: 'SIN_UBICACION' }, { status: 404 })
  }
  console.info(`[buro] etapa=mapa-ubicacion fuente=${loc.source} precision=${loc.precision} total=${Date.now() - t0}ms`)
  return Response.json(
    { ...loc, zoom: ZOOM[loc.precision], googleImage: Boolean(key && record.geo.place) },
    { headers: { 'Cache-Control': 'private, max-age=3600' } },
  )
}

async function googleStatic(record: BuroRecord, key: string): Promise<Response> {
  const place = record.geo.place
  const target = place ? `${place.lat},${place.lng}` : record.geo.query
  if (!target.trim()) return Response.json({ code: 'SIN_DIRECCION' }, { status: 404 })
  const url = new URL('https://maps.googleapis.com/maps/api/staticmap')
  url.searchParams.set('size', '640x300')
  url.searchParams.set('scale', '2')
  url.searchParams.set('zoom', '16')
  url.searchParams.set('language', 'es')
  url.searchParams.set('region', 'mx')
  url.searchParams.set('markers', `color:red|${target}`)
  url.searchParams.set('key', key)
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(10_000), cache: 'no-store' })
    const type = res.headers.get('content-type') ?? ''
    if (!res.ok || !type.startsWith('image/')) {
      console.error(`[buro] etapa=mapa-estatico codigo=http-${res.status}`)
      return Response.json({ code: 'PROVEEDOR' }, { status: 502 })
    }
    return new Response(res.body, { headers: { 'Content-Type': type, 'Cache-Control': 'private, max-age=3600' } })
  } catch {
    console.error('[buro] etapa=mapa-estatico codigo=red')
    return Response.json({ code: 'RED' }, { status: 502 })
  }
}

async function nominatim(params: Record<string, string>): Promise<{ lat: number; lng: number } | null> {
  const url = new URL('https://nominatim.openstreetmap.org/search')
  url.searchParams.set('format', 'jsonv2')
  url.searchParams.set('limit', '1')
  url.searchParams.set('countrycodes', 'mx')
  url.searchParams.set('accept-language', 'es')
  for (const [k, v] of Object.entries(params)) if (v) url.searchParams.set(k, v)
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(6_000), cache: 'no-store' })
    if (!res.ok) return null
    const [hit] = (await res.json()) as { lat: string; lon: string }[]
    return hit ? { lat: Number(hit.lat), lng: Number(hit.lon) } : null
  } catch {
    return null
  }
}

/** Most precise location first; each fallback is less precise and labeled as such. */
async function locate(record: BuroRecord): Promise<{ lat: number; lng: number; precision: Precision; source: 'google' | 'osm' } | null> {
  const place = record.geo.place
  if (place) return { lat: place.lat, lng: place.lng, precision: place.aproximada ? 'CALLE' : 'EXACTA', source: 'google' }

  const entidad = record.entidad ?? ''
  const municipio = record.municipio ?? ''
  const cp = record.codigoPostal ?? ''
  const street = streetLine(record)

  if (street && (municipio || cp)) {
    const hit = await nominatim({ street, city: municipio, state: entidad, postalcode: cp })
    if (hit) return { ...hit, precision: 'CALLE', source: 'osm' }
  }
  if (/^\d{5}$/.test(cp)) {
    const hit = await nominatim({ postalcode: cp, country: 'México' })
    if (hit) return { ...hit, precision: 'CODIGO_POSTAL', source: 'osm' }
  }
  if (municipio || entidad) {
    const hit = await nominatim({ q: [record.colonia, municipio, entidad].filter(Boolean).join(', ') })
    if (hit) return { ...hit, precision: 'MUNICIPIO', source: 'osm' }
  }
  return null
}
