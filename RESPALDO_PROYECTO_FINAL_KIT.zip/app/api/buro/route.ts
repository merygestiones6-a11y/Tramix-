import { readCredential, buildFields } from '@/lib/buro/extract'
import { geocode } from '@/lib/buro/geocode'
import { addressQuery, buroRequestSchema, compareAddress, type BuroRecord } from '@/lib/buro/schema'
import { newFolio, saveRecord } from '@/lib/buro/store'
import { classifyModelError } from '@/lib/identity-lab/doc-extract/model'
import { ERROR_MESSAGE } from '@/lib/identity-lab/doc-extract/modes'

export const runtime = 'nodejs'
export const maxDuration = 60

const MAX_BODY_CHARS = 4_400_000

const fail = (error: string, code: string, status: number, requestId: string) =>
  Response.json({ error, code, requestId }, { status, headers: { 'Cache-Control': 'no-store' } })

export async function POST(request: Request) {
  const t0 = performance.now()
  const requestId = crypto.randomUUID().slice(0, 8)
  const raw = await request.text()
  if (raw.length > MAX_BODY_CHARS) return fail('El archivo es demasiado grande para analizarse.', 'LIMITE', 413, requestId)

  let body: unknown
  try {
    body = JSON.parse(raw)
  } catch {
    return fail('Solicitud no válida.', 'SOLICITUD', 400, requestId)
  }
  const parsed = buroRequestSchema.safeParse(body)
  if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? 'Solicitud no válida.', 'SOLICITUD', 400, requestId)

  let reading: Awaited<ReturnType<typeof readCredential>>
  try {
    reading = await readCredential(parsed.data, request.signal)
  } catch (error) {
    const { code, status } = classifyModelError(error)
    console.error(`[buro] id=${requestId} etapa=modelo codigo=${code} tras=${Math.round(performance.now() - t0)}ms`)
    return fail(ERROR_MESSAGE[code], code, status, requestId)
  }

  const fields = buildFields(reading.credential)
  if (!fields.nombreCompleto && !fields.domicilio) {
    console.info(`[buro] id=${requestId} etapa=lectura codigo=ILEGIBLE modelo=${reading.modelMs}ms`)
    return fail('No se pudieron leer el nombre ni el domicilio. Usa una foto más nítida del frente de la credencial.', 'ILEGIBLE', 422, requestId)
  }

  const query = addressQuery(fields)
  const tGeo = performance.now()
  const geo = fields.domicilio ? await geocode(query, request.signal) : { status: 'NO_ENCONTRADA' as const, place: null, code: 'sin-direccion' }
  const geoMs = Math.round(performance.now() - tGeo)

  const record: BuroRecord = {
    ...fields,
    folio: newFolio(),
    createdAt: new Date().toISOString(),
    geo: { status: geo.status, place: geo.place, query },
    comparison: compareAddress(fields, geo.place),
  }
  if (geo.status === 'NO_ENCONTRADA' && fields.domicilio) record.warnings.push('Google Maps no encontró la dirección de la credencial.')
  if (record.comparison.result === 'NO COINCIDE') record.warnings.push('La ubicación de Google Maps no coincide con la credencial. Se conserva la dirección original.')

  try {
    await saveRecord(record)
  } catch {
    console.error(`[buro] id=${requestId} etapa=guardar codigo=BLOB`)
    return fail('No se pudo guardar el folio. Intenta de nuevo.', 'ALMACEN', 502, requestId)
  }

  // Only durations, statuses and codes: never names, addresses, RFC or postal codes.
  console.info(
    `[buro] id=${requestId} modelo=${reading.modelMs}ms geo=${geoMs}ms geoEstado=${geo.status}(${geo.code}) comparacion=${record.comparison.result} total=${Math.round(performance.now() - t0)}ms tokens=${reading.usage.inputTokens ?? '?'}/${reading.usage.outputTokens ?? '?'}`,
  )
  return Response.json({ record, requestId }, { headers: { 'Cache-Control': 'no-store' } })
}
