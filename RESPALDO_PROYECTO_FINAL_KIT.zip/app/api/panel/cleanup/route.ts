import { deleteOldImssMail } from '@/lib/outlook/store'
import { deleteExpiredUploads } from '@/lib/panel/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Daily safety sweep (vercel.json cron). The per-file workflow timers do the exact 12h deletion. */
export async function GET(request: Request) {
  const secret = process.env.CRON_SECRET
  if (secret && request.headers.get('authorization') !== `Bearer ${secret}`) {
    return Response.json({ error: 'unauthorized' }, { status: 401 })
  }
  const removed = await deleteExpiredUploads()
  const imssRemoved = await deleteOldImssMail().catch((error) => {
    console.error('[imss-mail] cleanup failed', error)
    return 0
  })
  return Response.json({ removed, imssRemoved })
}
