import { after } from 'next/server'
import { start } from 'workflow/api'
import { MAX_FILES_PER_UPLOAD, MAX_UPLOAD_BYTES } from '@/lib/panel/config'
import { extractDocumentText } from '@/lib/panel/extract-text'
import {
  deleteAllUploads,
  expiresAtOf,
  listActiveFiles,
  newId,
  storeOriginal,
  storeText,
  storeTextMarker,
} from '@/lib/panel/store'
import { expireUpload } from '@/workflows/expire-upload'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

const NO_STORE = { 'Cache-Control': 'no-store' }

export async function GET() {
  const files = await listActiveFiles()
  return Response.json({ files, serverTime: new Date().toISOString() }, { headers: NO_STORE })
}

export async function DELETE() {
  const deleted = await deleteAllUploads()
  return Response.json({ deleted }, { headers: NO_STORE })
}

/** Accepts multipart `file` fields. */
export async function POST(request: Request) {
  let form: FormData
  try {
    form = await request.formData()
  } catch {
    return Response.json({ error: 'bad-request' }, { status: 400, headers: NO_STORE })
  }

  const files = form.getAll('file').filter((entry): entry is File => entry instanceof File && entry.size > 0)
  if (files.length === 0 || files.length > MAX_FILES_PER_UPLOAD) {
    return Response.json({ error: 'bad-request' }, { status: 400, headers: NO_STORE })
  }
  const total = files.reduce((sum, file) => sum + file.size, 0)
  if (total > MAX_UPLOAD_BYTES) {
    return Response.json({ error: 'too-large' }, { status: 413, headers: NO_STORE })
  }

  const stored: { id: string; name: string; uploadedAt: string; expiresAt: string }[] = []
  for (const file of files) {
    const now = Date.now()
    const id = newId(now)
    const bytes = new Uint8Array(await file.arrayBuffer())
    await storeOriginal(id, file)
    const expiresAt = new Date(expiresAtOf(id)).toISOString()
    await start(expireUpload, [id, expiresAt])
    stored.push({ id, name: file.name, uploadedAt: new Date(now).toISOString(), expiresAt })

    after(async () => {
      try {
        const result = await extractDocumentText(file.name, file.type, bytes)
        if (result.status === 'ready') await storeText(id, result.text)
        else await storeTextMarker(id, result.status)
      } catch (error) {
        console.error('[panel] text extraction failed', id, error)
        await storeTextMarker(id, 'failed').catch(() => {})
      }
    })
  }

  return Response.json({ files: stored }, { status: 201, headers: NO_STORE })
}
