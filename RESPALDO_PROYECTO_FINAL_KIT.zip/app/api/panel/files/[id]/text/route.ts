import { isExpired, isValidId, readText } from '@/lib/panel/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  if (!isValidId(id) || isExpired(id)) {
    return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  }
  const text = await readText(id)
  if (text === null) return Response.json({ error: 'not-ready' }, { status: 404, headers: NO_STORE })
  return Response.json({ text }, { headers: NO_STORE })
}
