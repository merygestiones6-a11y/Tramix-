import { isExpired, isValidId, openOriginal } from '@/lib/panel/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

function asciiFallback(name: string) {
  return name.normalize('NFD').replace(/[^\x20-\x7e]/g, '').replace(/["\\]/g, '') || 'archivo'
}

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  if (!isValidId(id) || isExpired(id)) {
    return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  }

  const file = await openOriginal(id)
  if (!file) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  return new Response(file.stream, {
    headers: {
      ...NO_STORE,
      'Content-Type': file.contentType,
      'Content-Length': String(file.size),
      'Content-Disposition': `attachment; filename="${asciiFallback(file.name)}"; filename*=UTF-8''${encodeURIComponent(file.name)}`,
    },
  })
}
