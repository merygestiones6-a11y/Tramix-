import { createHash } from 'node:crypto'
import { unauthorized } from '@/lib/outlook/access'
import { documentName } from '@/lib/outlook/imss-mail'
import { listDocuments, saveDocument } from '@/lib/outlook/store'
import { canManage } from '@/lib/outlook-pool/store'
import { CURP_PATTERN } from '@/lib/validar-nss'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }
const MAX_BYTES = 4 * 1024 * 1024
const WATCH_ID = 'validar-nss'

const fail = (error: string, status: number) => Response.json({ error }, { status, headers: NO_STORE })

const isPdf = (bytes: Uint8Array) =>
  bytes.length > 4 && bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46

function header(request: Request, name: string, max: number) {
  try {
    return decodeURIComponent(request.headers.get(name) ?? '').trim().slice(0, max)
  } catch {
    return ''
  }
}

/** Saves the PDF obtained by "NO DERECHO IMSS" into the existing Descargas module. */
export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()

  const curp = header(request, 'x-curp', 18).toUpperCase()
  if (!CURP_PATTERN.test(curp)) return fail('invalid-curp', 400)
  if (Number(request.headers.get('content-length') ?? 0) > MAX_BYTES) return fail('too-large', 413)

  const bytes = new Uint8Array(await request.arrayBuffer())
  if (bytes.byteLength === 0 || bytes.byteLength > MAX_BYTES) return fail('invalid-size', 413)
  if (!isPdf(bytes)) return fail('not-pdf', 415)

  const original = header(request, 'x-file-name', 160)
  const email = header(request, 'x-email', 254)
  const docId = createHash('sha256').update(bytes).digest('hex').slice(0, 32)
  const existing = await listDocuments()
  const already = existing.find((d) => d.id === docId)
  if (already) return Response.json({ ok: true, id: already.id, name: already.name }, { headers: NO_STORE })

  const fromOutlook = request.headers.get('x-origin') === 'outlook'
  const taken = new Set(existing.map((d) => d.name.toLowerCase()))
  const name = documentName(original || null, curp, taken)
  const doc = await saveDocument(
    {
      id: docId,
      name,
      originalName: original || name,
      curp,
      watchId: fromOutlook ? 'outlook-app' : WATCH_ID,
      source: 'portal',
      account: email,
      subject: fromOutlook ? 'IMSS · Outlook (app IMSS DIRECT)' : 'NO DERECHO IMSS · portal oficial IMSS',
      receivedAt: new Date().toISOString(),
    },
    bytes,
  )
  return Response.json({ ok: true, id: doc.id, name: doc.name }, { headers: NO_STORE })
}
