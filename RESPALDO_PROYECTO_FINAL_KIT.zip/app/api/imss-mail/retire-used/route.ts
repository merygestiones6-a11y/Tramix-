import { hasAccess } from '@/lib/outlook/access'
import { retireUsedAccounts } from '@/lib/outlook/retire-used'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

/**
 * Scheduled (vercel.json cron): removes used accounts whose trámite finished more than 1 hour ago.
 * `?dry=1` (signed-in users only) reports what would happen without deleting anything.
 */
export async function GET(request: Request) {
  const dryRun = new URL(request.url).searchParams.get('dry') === '1'
  const secret = process.env.CRON_SECRET
  const isCron = !secret || request.headers.get('authorization') === `Bearer ${secret}`
  if (dryRun ? !hasAccess(request) && !isCron : !isCron) {
    return Response.json({ error: 'unauthorized' }, { status: 401 })
  }
  try {
    const { hiddenIds: _ids, ...summary } = await retireUsedAccounts({ dryRun })
    console.log('[imss-mail] retire-used', JSON.stringify({ dryRun, ...summary }))
    return Response.json({ dryRun, ...summary }, { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) {
    console.error('[imss-mail] retire-used failed', error)
    return Response.json({ error: 'retire-failed' }, { status: 500 })
  }
}
