import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { microsoftConfig } from '@/lib/outlook/config'
import { loadSnapshot, retireUsedAccounts } from '@/lib/outlook/retire-used'
import { toPublicAccount } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  const snapshot = await loadSnapshot()
  const { accounts: stored, receiver, watches, retired } = snapshot

  // Same check the receiver runs: accounts past 1 h from a confirmed IMSS trámite e-mail are retired here too.
  const hidden = new Set(
    (await retireUsedAccounts({ snapshot }).catch((error) => {
      console.error('[imss-mail] retire check failed', error)
      return { hiddenIds: retired.map((r) => r.id) }
    })).hiddenIds,
  )

  // Accounts used before `usedAt` existed are recognised from the IMSS e-mails already recorded.
  const seen = new Set<string>()
  for (const item of receiver?.items ?? []) if (item.account) seen.add(item.account.toLowerCase())
  for (const watch of watches) for (const m of watch.messages ?? []) if (m.account) seen.add(m.account.toLowerCase())
  for (const r of retired) seen.add(r.id.toLowerCase()).add(r.address.toLowerCase())

  const accounts = stored
    .filter((account) => !hidden.has(account.id))
    .map((account) => ({
      ...toPublicAccount(account),
      used: Boolean(account.usedAt) || seen.has(account.address.toLowerCase()) || seen.has(account.id.toLowerCase()),
    }))
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  return Response.json(
    { accounts, signInReady: microsoftConfig() !== null },
    { headers: { 'Cache-Control': 'no-store' } },
  )
}
