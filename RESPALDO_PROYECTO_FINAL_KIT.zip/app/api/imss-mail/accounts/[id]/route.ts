import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { deleteAccount, isAccountId } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!hasAccess(request)) return unauthorized()
  const { id } = await params
  if (!isAccountId(id)) return Response.json({ error: 'not-found' }, { status: 404 })
  await deleteAccount(id)
  return Response.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } })
}
