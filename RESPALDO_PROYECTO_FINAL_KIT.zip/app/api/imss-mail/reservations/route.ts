import { unauthorized } from '@/lib/outlook/access'
import { validateCurp } from '@/lib/curp-validator'
import { canManage } from '@/lib/outlook-pool/store'
import { reserveLinkedAccount } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** ENVIAR IMSS: takes one account from LECTURA DE CORREOS DEL IMSS for this CURP. */
export async function POST(request: Request) {
  if (!canManage(request)) return unauthorized()
  const body = (await request.json().catch(() => null)) as { curp?: unknown } | null
  const curp = typeof body?.curp === 'string' ? body.curp.trim().toUpperCase() : ''
  if (!validateCurp(curp).valid) return Response.json({ error: 'invalid-curp' }, { status: 400, headers: NO_STORE })

  const reservation = await reserveLinkedAccount(curp)
  if (!reservation) return Response.json({ error: 'no-accounts' }, { status: 409, headers: NO_STORE })
  return Response.json({ reservation }, { status: 201, headers: NO_STORE })
}
