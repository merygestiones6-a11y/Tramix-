import { start } from 'workflow/api'
import { unauthorized } from '@/lib/outlook/access'
import { WATCH_WINDOW_MS } from '@/lib/outlook/config'
import { canManage } from '@/lib/outlook-pool/store'
import {
  completeLinkedAccount,
  getWatch,
  isAccountId,
  linkAssignmentWatch,
  newWatchId,
  releaseLinkedAccount,
  saveWatch,
  type Watch,
} from '@/lib/outlook/store'
import { imssMailWatch } from '@/workflows/imss-mail-watch'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** body: { token, action: 'release' | 'complete' }. Complete also starts watching that same inbox. */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!canManage(request)) return unauthorized()
  const { id } = await params
  if (!isAccountId(id)) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })

  const body = (await request.json().catch(() => null)) as { token?: unknown; action?: unknown } | null
  const token = typeof body?.token === 'string' && /^[a-f0-9]{32}$/.test(body.token) ? body.token : null
  if (!token) return Response.json({ error: 'invalid-token' }, { status: 400, headers: NO_STORE })

  if (body?.action === 'release') {
    return Response.json({ ok: await releaseLinkedAccount(id, token) }, { headers: NO_STORE })
  }
  if (body?.action !== 'complete') return Response.json({ error: 'invalid-action' }, { status: 400, headers: NO_STORE })

  const assignment = await completeLinkedAccount(id, token)
  if (!assignment) return Response.json({ ok: false }, { status: 409, headers: NO_STORE })

  // Retried completes reuse the watch already started for this trámite.
  const existing = assignment.watchId ? await getWatch(assignment.watchId) : null
  if (existing) return Response.json({ ok: true, watchId: existing.id }, { headers: NO_STORE })

  const now = Date.now()
  const watch: Watch = {
    id: newWatchId(now),
    curp: assignment.curp,
    email: assignment.address.toLowerCase(),
    accountId: assignment.accountId,
    submittedAt: new Date(now).toISOString(),
    deadline: new Date(now + WATCH_WINDOW_MS).toISOString(),
    status: 'waiting',
    checks: 0,
    messages: [],
    documentIds: [],
  }
  await saveWatch(watch)
  await linkAssignmentWatch(assignment, watch.id)
  await start(imssMailWatch, [watch.id])
  return Response.json({ ok: true, watchId: watch.id }, { headers: NO_STORE })
}
