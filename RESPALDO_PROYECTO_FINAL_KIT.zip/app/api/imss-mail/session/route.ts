import { accessCookie, checkAccessKey, hasAccess, isAccessConfigured, issueAccessToken } from '@/lib/outlook/access'
import { CALLBACK_PATH, getOrigin, microsoftConfig } from '@/lib/outlook/config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

export async function GET(request: Request) {
  return Response.json(
    {
      accessConfigured: isAccessConfigured(),
      microsoftConfigured: microsoftConfig() !== null,
      unlocked: hasAccess(request),
      redirectUri: `${getOrigin(request)}${CALLBACK_PATH}`,
    },
    { headers: NO_STORE },
  )
}

export async function POST(request: Request) {
  if (!isAccessConfigured()) return Response.json({ error: 'not-configured' }, { status: 503, headers: NO_STORE })
  const body = (await request.json().catch(() => null)) as { key?: unknown } | null
  const key = typeof body?.key === 'string' ? body.key.slice(0, 200) : ''
  if (!checkAccessKey(key)) {
    await new Promise((resolve) => setTimeout(resolve, 600))
    return Response.json({ error: 'invalid-key' }, { status: 401, headers: NO_STORE })
  }
  const token = issueAccessToken()
  return Response.json({ token }, { headers: { ...NO_STORE, 'Set-Cookie': accessCookie(token) } })
}

export async function DELETE() {
  return Response.json({ ok: true }, { headers: { ...NO_STORE, 'Set-Cookie': accessCookie(null) } })
}
