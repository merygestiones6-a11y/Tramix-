import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { deleteDocument, getDocument, isDocumentId, openDocumentFile } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

function asciiFallback(name: string) {
  return name.normalize('NFD').replace(/[^\x20-\x7e]/g, '').replace(/["\\]/g, '') || 'documento.pdf'
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!hasAccess(request)) return unauthorized()
  const { id } = await params
  const meta = isDocumentId(id) ? await getDocument(id) : null
  const file = meta ? await openDocumentFile(id) : null
  if (!meta || !file) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  return new Response(file.stream, {
    headers: {
      ...NO_STORE,
      'Content-Type': 'application/pdf',
      'Content-Length': String(file.size),
      'Content-Disposition': `attachment; filename="${asciiFallback(meta.name)}"; filename*=UTF-8''${encodeURIComponent(meta.name)}`,
    },
  })
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!hasAccess(request)) return unauthorized()
  const { id } = await params
  if (!isDocumentId(id)) return Response.json({ error: 'not-found' }, { status: 404 })
  await deleteDocument(id)
  return Response.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } })
}
