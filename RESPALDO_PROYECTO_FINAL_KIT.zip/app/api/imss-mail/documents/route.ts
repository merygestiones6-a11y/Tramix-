import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { listDocuments } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  return Response.json({ documents: await listDocuments() }, { headers: { 'Cache-Control': 'no-store' } })
}
