import { createHash } from 'node:crypto'
import { documentName } from '@/lib/outlook/imss-mail'
import { getWatch, isWatchId, listDocuments, saveDocument, saveWatch } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }
// Vercel Functions accept request bodies up to 4.5 MB; IMSS constancias are far smaller.
const MAX_BYTES = 4 * 1024 * 1024

const fail = (error: string, status: number) => Response.json({ error }, { status, headers: NO_STORE })

const isPdf = (bytes: Uint8Array) =>
  bytes.length > 4 && bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46

/**
 * Stores the PDF the TRAMIX app captured from the IMSS portal in Descargas and closes the trámite.
 * Like the watch status route, the unguessable watch id is the capability.
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const watch = isWatchId(id) ? await getWatch(id) : null
  if (!watch || watch.status === 'cancelled') return fail('not-found', 404)

  if (Number(request.headers.get('content-length') ?? 0) > MAX_BYTES) return fail('too-large', 413)
  const bytes = new Uint8Array(await request.arrayBuffer())
  if (bytes.byteLength === 0 || bytes.byteLength > MAX_BYTES) return fail('invalid-size', 413)
  if (!isPdf(bytes)) return fail('not-pdf', 415)

  let original = ''
  try {
    original = decodeURIComponent(request.headers.get('x-file-name') ?? '').slice(0, 160)
  } catch {}

  const docId = createHash('sha256').update(bytes).digest('hex').slice(0, 32)
  const taken = new Set(
    (await listDocuments()).filter((d) => d.watchId === watch.id && d.id !== docId).map((d) => d.name.toLowerCase()),
  )
  const name = documentName(original || null, watch.curp, taken)
  const doc = await saveDocument(
    {
      id: docId,
      name,
      originalName: original || name,
      curp: watch.curp,
      watchId: watch.id,
      source: 'portal',
      account: watch.email,
      subject: 'Portal oficial IMSS',
      receivedAt: new Date().toISOString(),
    },
    bytes,
  )

  if (!watch.documentIds.includes(doc.id)) watch.documentIds.push(doc.id)
  watch.status = 'found'
  await saveWatch(watch)
  return Response.json({ ok: true, id: doc.id, name: doc.name }, { headers: NO_STORE })
}
