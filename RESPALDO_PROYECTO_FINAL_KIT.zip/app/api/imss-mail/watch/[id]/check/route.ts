import { checkWatch } from '@/lib/outlook/imss-mail'
import { isWatchId } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

/** "Revisar ahora". The checker itself ignores calls closer than 15 s apart. */
export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  if (!isWatchId(id)) return Response.json({ error: 'not-found' }, { status: 404 })
  const result = await checkWatch(id)
  return Response.json(result, { headers: { 'Cache-Control': 'no-store' } })
}
