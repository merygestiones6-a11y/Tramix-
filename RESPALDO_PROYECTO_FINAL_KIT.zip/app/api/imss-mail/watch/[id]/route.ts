import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { activeDownloadIds, watchProgress } from '@/lib/outlook/progress'
import { getWatch, isWatchId, listAccounts, saveWatch } from '@/lib/outlook/store'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** Coarse progress for the IMSS module. The id is unguessable and nothing from the mailbox body is returned. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const watch = isWatchId(id) ? await getWatch(id) : null
  if (!watch) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  const progress = await watchProgress(watch, await listAccounts(), await activeDownloadIds())
  return Response.json(
    {
      id: watch.id,
      status: watch.status,
      checks: watch.checks,
      lastCheckAt: watch.lastCheckAt ?? null,
      deadline: watch.deadline,
      ...progress,
      accountErrors: progress.accountErrors.length,
    },
    { headers: NO_STORE },
  )
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!hasAccess(request)) return unauthorized()
  const { id } = await params
  const watch = isWatchId(id) ? await getWatch(id) : null
  if (!watch) return Response.json({ error: 'not-found' }, { status: 404, headers: NO_STORE })
  if (watch.status === 'waiting') {
    watch.status = 'cancelled'
    await saveWatch(watch)
  }
  return Response.json({ ok: true }, { headers: NO_STORE })
}
