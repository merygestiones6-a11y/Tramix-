import { start } from 'workflow/api'
import { validateCurp } from '@/lib/curp-validator'
import { cleanEmailInput, isValidEmail } from '@/lib/imss'
import { hasAccess, unauthorized } from '@/lib/outlook/access'
import { WATCH_WINDOW_MS } from '@/lib/outlook/config'
import { activeDownloadIds, watchProgress } from '@/lib/outlook/progress'
import { listAccounts, listWatches, newWatchId, saveWatch, type Watch } from '@/lib/outlook/store'
import { imssMailWatch } from '@/workflows/imss-mail-watch'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const NO_STORE = { 'Cache-Control': 'no-store' }

/** Linked-account panel: every trámite being watched (key required). */
export async function GET(request: Request) {
  if (!hasAccess(request)) return unauthorized()
  const [all, accounts, downloads] = await Promise.all([listWatches(), listAccounts(), activeDownloadIds()])
  const watches = await Promise.all(
    all.slice(0, 30).map(async (w) => ({
      id: w.id,
      curp: w.curp,
      email: w.email,
      status: w.status,
      submittedAt: w.submittedAt,
      checks: w.checks,
      ...(await watchProgress(w, accounts, downloads)),
    })),
  )
  return Response.json({ watches }, { headers: NO_STORE })
}

/**
 * Called by /imss-nss right after the IMSS form is sent. Public on purpose (the module has no
 * key), but it only accepts a valid CURP + e-mail, reuses an active watch and never returns mail content.
 */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { curp?: unknown; email?: unknown } | null
  const curp = typeof body?.curp === 'string' ? body.curp.trim().toUpperCase() : ''
  const email = typeof body?.email === 'string' ? cleanEmailInput(body.email).toLowerCase() : ''
  if (!validateCurp(curp).valid || !isValidEmail(email)) {
    return Response.json({ error: 'bad-request' }, { status: 400, headers: NO_STORE })
  }

  const accounts = (await listAccounts()).filter((a) => a.status === 'ok').length
  const active = (await listWatches()).find((w) => w.status === 'waiting' && w.curp === curp && w.email === email)
  if (active) return Response.json({ id: active.id, accounts, reused: true }, { headers: NO_STORE })

  const now = Date.now()
  const watch: Watch = {
    id: newWatchId(now),
    curp,
    email,
    submittedAt: new Date(now).toISOString(),
    deadline: new Date(now + WATCH_WINDOW_MS).toISOString(),
    status: 'waiting',
    checks: 0,
    messages: [],
    documentIds: [],
  }
  await saveWatch(watch)
  await start(imssMailWatch, [watch.id])
  return Response.json({ id: watch.id, accounts, reused: false }, { status: 201, headers: NO_STORE })
}
