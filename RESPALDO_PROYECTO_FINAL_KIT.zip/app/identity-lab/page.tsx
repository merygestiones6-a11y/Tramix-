import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { IdentityLab } from '@/components/identity-lab/identity-lab'

export const metadata: Metadata = {
  title: 'IDENTITY LAB · IMSS DIRECT',
  description: 'Cálculo y validación estructural de CURP y RFC conforme a las reglas de RENAPO y el SAT.',
}

export default function IdentityLabPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">IDENTITY LAB</h1>
        <IdentityLab />
      </main>
    </div>
  )
}
