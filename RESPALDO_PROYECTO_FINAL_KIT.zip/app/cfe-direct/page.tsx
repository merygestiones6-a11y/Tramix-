import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { CfeDirect } from '@/components/cfe-direct/cfe-direct'

export const metadata: Metadata = {
  title: 'CFE DIRECT · IMSS DIRECT',
  description: 'Consulta de recibos de luz CFE por número de servicio y administración de cuentas CFE.',
}

export default function CfeDirectPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">CFE DIRECT</h1>
        <CfeDirect />
      </main>
    </div>
  )
}
