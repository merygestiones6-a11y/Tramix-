import { AppHeader } from '@/components/filekit/app-header'
import { FileKitApp } from '@/components/filekit/filekit-app'

export default function HomePage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-5xl flex-col gap-8 px-4 pt-8 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-12">
        <div className="flex flex-col gap-2 text-center">
          <h1 className="brand-title text-4xl font-semibold text-balance sm:text-5xl">IMSS DIRECT</h1>
        </div>
        <div className="mx-auto w-full max-w-2xl has-[[aria-labelledby=result-heading]]:max-w-5xl">
          <FileKitApp />
        </div>
      </main>
    </div>
  )
}
