import type { Metadata } from 'next'
import { AppHeader } from '@/components/filekit/app-header'
import { PanelApp } from '@/components/panel/panel-app'
import { RefreshButton } from '@/components/panel/refresh-button'
import { UploadButton } from '@/components/panel/upload-button'

export const metadata: Metadata = {
  title: 'Descargar · IMSS DIRECT',
  description: 'Descarga y copia el texto de tus archivos guardados. Cada archivo se elimina a las 12 horas.',
  robots: { index: false, follow: false },
}

export default function PanelPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <div className="flex items-center justify-between gap-3">
          <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">Descargas</h1>
          <div className="flex items-center gap-2">
            <RefreshButton />
            <UploadButton />
          </div>
        </div>
        <PanelApp />
      </main>
    </div>
  )
}
