import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { NssLookup } from '@/components/consulta-nss/nss-lookup'

export const metadata: Metadata = {
  title: 'CONSULTA NSS · IMSS DIRECT',
  description: 'Obtén el Número de Seguro Social a partir de una CURP.',
}

export default function ConsultaNssPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">CONSULTA NSS</h1>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            Obtén el Número de Seguro Social a partir de una CURP.
          </p>
        </div>
        <section aria-label="Consulta NSS" className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
          <NssLookup />
        </section>
        <p className="text-center text-xs text-muted-foreground">No almacenamos la CURP ni el NSS.</p>
      </main>
    </div>
  )
}
