import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { DocumentExtractor } from '@/components/identity-lab/document-extractor'
import { getRecord } from '@/lib/buro/store'

export const metadata: Metadata = {
  title: 'EXTRACTOR DE DOCUMENTOS · IMSS DIRECT',
  description: 'Extracción de CURP, RFC, RFC + IDCIF y número de servicio CFE a partir de PDF, imágenes, DOCX y TXT.',
}

export default async function ExtractorDocumentosPage({ searchParams }: { searchParams: Promise<{ folio?: string | string[] }> }) {
  const { folio } = await searchParams
  const initialBuro = typeof folio === 'string' ? await getRecord(folio) : null

  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">EXTRACTOR DE DOCUMENTOS</h1>
        <DocumentExtractor initialBuro={initialBuro} />
      </main>
    </div>
  )
}
