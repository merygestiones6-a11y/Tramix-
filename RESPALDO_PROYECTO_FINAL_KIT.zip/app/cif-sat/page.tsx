import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { CifSatTabs } from '@/components/cifsat/cifsat-tabs'

export const metadata: Metadata = {
  title: 'CIF SAT · IMSS DIRECT',
  description: 'Constancia CIF y datos fiscales del SAT.',
}

export default function CifSatPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">CIF SAT</h1>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            Constancia CIF y datos fiscales del SAT a partir del RFC e IDCIF.
          </p>
        </div>
        <CifSatTabs />
      </main>
    </div>
  )
}
