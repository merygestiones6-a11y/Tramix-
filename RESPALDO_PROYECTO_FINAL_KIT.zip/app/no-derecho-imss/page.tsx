import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { ValidarNss } from '@/components/validar-nss/validar-nss'

export const metadata: Metadata = {
  title: 'NO DERECHO IMSS · IMSS DIRECT',
  description: 'Completa el trámite en el portal oficial del IMSS sin salir de IMSS DIRECT y guarda el PDF en Descargas.',
}

export default function NoDerechoImssPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">NO DERECHO IMSS</h1>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            Trámite en el portal oficial del IMSS. Tú escribes el CAPTCHA y completas los pasos que pida; el resultado y el PDF quedan
            aquí mismo.
          </p>
        </div>
        <ValidarNss />
      </main>
    </div>
  )
}
