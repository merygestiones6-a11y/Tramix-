import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { AppHeader } from '@/components/filekit/app-header'
import { ReciboLuz } from '@/components/cfe/recibo-luz'

export const metadata: Metadata = {
  title: 'Recibo de luz · IMSS DIRECT',
  description: 'Cuentas CFE, números de servicio y recibos PDF renombrados con el titular.',
}

export default function ReciboLuzPage() {
  return (
    <div className="relative min-h-dvh overflow-x-clip">
      <div className="ambient pointer-events-none absolute inset-x-0 top-0 h-[36rem]" aria-hidden="true" />
      <AppHeader />
      <main className="relative mx-auto flex w-full max-w-xl flex-col gap-6 px-4 pt-6 pb-[max(2.5rem,env(safe-area-inset-bottom))] sm:px-6 sm:pt-10">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-1.5 rounded-lg text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver
        </Link>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">Recibo de luz</h1>
          <p className="text-sm leading-relaxed text-pretty text-muted-foreground">
            Administra cuentas CFE (hasta 10 servicios cada una), registra solicitudes e importa el PDF del recibo: se renombra
            con el titular y queda guardado aquí.
          </p>
        </div>
        <ReciboLuz />
      </main>
    </div>
  )
}
