import { redirect } from 'next/navigation'

export default function ValidarNssPage() {
  redirect('/no-derecho-imss')
}
